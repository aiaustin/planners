
static L1();
static L2();
static L3();
static L4();
static object LI6();
#define VC1
#define VC2
#define VC3 object  V4;
#define VC4 object  V6;
static object LI5();
#define VMB5 object  V13;
#define VMS5
#define VMV5
#define VMR5(VMT5) return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V45 ,V44 ,V43 ,V36 ,V34 ,V33 ,V31 ,V29 ,V27; object Vcs[3];
#define VMS6  register object *sup=vs_top+4;vs_top=sup;
#define VMV6 vs_reserve(4);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V59 ,V57 ,V54;
#define VMS7 vs_top += 1;
#define VMV7 vs_reserve(1);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static object LI8();
#define VMB8 register object *base=vs_top;
#define VMS8 vs_top += 1;
#define VMV8 vs_reserve(1);
#define VMR8(VMT8) vs_top=base ; return(VMT8);
#define VM8 1
#define VM7 1
#define VM6 4
#define VM5 0
#define VM4 4
#define VM3 4
#define VM2 3
#define VM1 3
static char * VVi[53]={
#define Cdata VV[52]
(char *)(L1),
(char *)(L2),
(char *)(L3),
(char *)(L4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8)
};
#define VV ((object *)VVi)
static object  LnkTLI51() ;
static object  (*LnkLI51)() = LnkTLI51;
static object  LnkTLI50() ;
static object  (*LnkLI50)() = LnkTLI50;
static object  LnkTLI49() ;
static object  (*LnkLI49)() = LnkTLI49;
static object  LnkTLI48() ;
static object  (*LnkLI48)() = LnkTLI48;
static  LnkT47() ;
static  (*Lnk47)() = LnkT47;
static object  LnkTLI46() ;
static object  (*LnkLI46)() = LnkTLI46;
static object  LnkTLI45() ;
static object  (*LnkLI45)() = LnkTLI45;
static object  LnkTLI44() ;
static object  (*LnkLI44)() = LnkTLI44;
static object  LnkTLI43() ;
static object  (*LnkLI43)() = LnkTLI43;
static object  LnkTLI42() ;
static object  (*LnkLI42)() = LnkTLI42;
static object  LnkTLI41() ;
static object  (*LnkLI41)() = LnkTLI41;
static object  LnkTLI40() ;
static object  (*LnkLI40)() = LnkTLI40;
