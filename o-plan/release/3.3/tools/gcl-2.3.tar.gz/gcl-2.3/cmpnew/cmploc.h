
static L2();
static L3();
static object LI10();
static L12();
static L13();
static L16();
static L19();
static L22();
static object LI1();
#define VMB1
#define VMS1
#define VMV1
#define VMR1(VMT1) return(VMT1);
#define VC2
#define VC3
static object LI4();
#define VMB4 object  V17 ,V16 ,V15;
#define VMS4
#define VMV4
#define VMR4(VMT4) return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top; object  V23 ,V22;
#define VMS5 vs_top += 1;
#define VMV5 vs_reserve(1);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6
#define VMS6
#define VMV6
#define VMR6(VMT6) return(VMT6);
static object LI7();
#define VMB7
#define VMS7
#define VMV7
#define VMR7(VMT7) return(VMT7);
static object LI8();
#define VMB8
#define VMS8
#define VMV8
#define VMR8(VMT8) return(VMT8);
static object LI9();
#define VMB9
#define VMS9
#define VMV9
#define VMR9(VMT9) return(VMT9);
static object LI10();
#define VMB10 object  V40; object Vcs[2];
#define VMS10
#define VMV10
#define VMR10(VMT10) return(VMT10);
static object LI11();
#define VMB11
#define VMS11
#define VMV11
#define VMR11(VMT11) return(VMT11);
#define VC12 object  V47 ,V46;
#define VC13 object  V57 ,V56 ,V55;
static object LI14();
#define VMB14 object  V62;
#define VMS14
#define VMV14
#define VMR14(VMT14) return(VMT14);
static object LI15();
#define VMB15
#define VMS15
#define VMV15
#define VMR15(VMT15) return(VMT15);
#define VC16 object  V74 ,V73;
static object LI17();
#define VMB17 object  V79;
#define VMS17
#define VMV17
#define VMR17(VMT17) return(VMT17);
static object LI18();
#define VMB18
#define VMS18
#define VMV18
#define VMR18(VMT18) return(VMT18);
#define VC19 object  V90 ,V89;
static object LI20();
#define VMB20 object  V95;
#define VMS20
#define VMV20
#define VMR20(VMT20) return(VMT20);
static object LI21();
#define VMB21
#define VMS21
#define VMV21
#define VMR21(VMT21) return(VMT21);
#define VC22 object  V106 ,V105;
static object LI23();
#define VMB23 object  V111;
#define VMS23
#define VMV23
#define VMR23(VMT23) return(VMT23);
static object LI24();
#define VMB24
#define VMS24
#define VMV24
#define VMR24(VMT24) return(VMT24);
#define VM24 0
#define VM23 0
#define VM22 3
#define VM21 0
#define VM20 0
#define VM19 3
#define VM18 0
#define VM17 0
#define VM16 3
#define VM15 0
#define VM14 0
#define VM13 5
#define VM12 3
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 1
#define VM4 0
#define VM3 2
#define VM2 4
#define VM1 0
static char * VVi[50]={
#define Cdata VV[49]
(char *)(LI1),
(char *)(L2),
(char *)(L3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10),
(char *)(LI11),
(char *)(L12),
(char *)(L13),
(char *)(LI14),
(char *)(LI15),
(char *)(L16),
(char *)(LI17),
(char *)(LI18),
(char *)(L19),
(char *)(LI20),
(char *)(LI21),
(char *)(L22),
(char *)(LI23),
(char *)(LI24)
};
#define VV ((object *)VVi)
static object  LnkTLI48() ;
static object  (*LnkLI48)() = LnkTLI48;
static  LnkT45() ;
static  (*Lnk45)() = LnkT45;
static object  LnkTLI44() ;
static object  (*LnkLI44)() = LnkTLI44;
static object  LnkTLI43() ;
static object  (*LnkLI43)() = LnkTLI43;
static object  LnkTLI42() ;
static object  (*LnkLI42)() = LnkTLI42;
static  LnkT41() ;
static  (*Lnk41)() = LnkT41;
static  LnkT40() ;
static  (*Lnk40)() = LnkT40;
static  LnkT39() ;
static  (*Lnk39)() = LnkT39;
static  LnkT38() ;
static  (*Lnk38)() = LnkT38;
static object  LnkTLI37() ;
static object  (*LnkLI37)() = LnkTLI37;
static object  LnkTLI36() ;
static object  (*LnkLI36)() = LnkTLI36;
static  LnkT35() ;
static  (*Lnk35)() = LnkT35;
static object  LnkTLI34() ;
static object  (*LnkLI34)() = LnkTLI34;
