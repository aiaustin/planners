
static L1();
static L4();
static object LI5();
#define VC1
static object LI2();
#define VMB2 register object *base=vs_top; object  V8 ,V6 ,V4;
#define VMS2  register object *sup=vs_top+2;vs_top=sup;
#define VMV2 vs_reserve(2);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top; object  V14 ,V13;
#define VMS3  register object *sup=vs_top+6;vs_top=sup;
#define VMV3 vs_reserve(6);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
#define VC4 object  V31 ,V29 ,V28 ,V26 ,V25;
static object LI5();
#define VMB5 register object *base=vs_top; object  V58 ,V57 ,V56 ,V55 ,V54; object Vcs[7];
#define VMS5  register object *sup=vs_top+5;vs_top=sup;
#define VMV5 vs_reserve(5);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
#define VM5 5
#define VM4 11
#define VM3 6
#define VM2 2
#define VM1 4
static char * VVi[17]={
#define Cdata VV[16]
(char *)(L1),
(char *)(LI2),
(char *)(LI3),
(char *)(L4),
(char *)(LI5)
};
#define VV ((object *)VVi)
static  LnkT15() ;
static  (*Lnk15)() = LnkT15;
static object  LnkTLI14() ;
static object  (*LnkLI14)() = LnkTLI14;
static object  LnkTLI13() ;
static object  (*LnkLI13)() = LnkTLI13;
