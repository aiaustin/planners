
static L1();
static L3();
static L4();
static L5();
static L8();
static object LI9();
#define VC1 object  V5 ,V4 ,V3;
static object LI2();
#define VMB2 register object *base=vs_top; object  V10;
#define VMS2  register object *sup=vs_top+3;vs_top=sup;
#define VMV2 vs_reserve(3);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
#define VC3 object  V41 ,V40 ,V39 ,V38 ,V37 ,V36 ,V35 ,V34 ,V33 ,V32 ,V31 ,V30 ,V29 ,V28 ,V27 ,V26;
#define VC4 object  V60 ,V59 ,V58 ,V57 ,V56 ,V55 ,V54 ,V53 ,V52 ,V51 ,V50;
#define VC5 object  V63;
static object LI6();
#define VMB6 register object *base=vs_top; object  V72 ,V71;
#define VMS6  register object *sup=vs_top+6;vs_top=sup;
#define VMV6 vs_reserve(6);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V77;
#define VMS7  register object *sup=vs_top+1;vs_top=sup;
#define VMV7 vs_reserve(1);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
#define VC8 object  V116 ,V115 ,V114 ,V113 ,V112 ,V101 ,V93 ,V92 ,V91 ,V90 ,V89;
static object LI9();
#define VMB9 register object *base=vs_top; object  V162 ,V161 ,V160 ,V159 ,V158 ,V147 ,V146 ,V145 ,V144 ,V143 ,V133 ,V132 ,V131 ,V130 ,V129; object Vcs[2];
#define VMS9  register object *sup=vs_top+5;vs_top=sup;
#define VMV9 vs_reserve(5);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
#define VM9 5
#define VM8 7
#define VM7 1
#define VM6 6
#define VM5 6
#define VM4 7
#define VM3 7
#define VM2 3
#define VM1 4
static char * VVi[36]={
#define Cdata VV[35]
(char *)(L1),
(char *)(LI2),
(char *)(L3),
(char *)(L4),
(char *)(L5),
(char *)(LI6),
(char *)(LI7),
(char *)(L8),
(char *)(LI9)
};
#define VV ((object *)VVi)
static object  LnkTLI34() ;
static object  (*LnkLI34)() = LnkTLI34;
static object  LnkTLI33() ;
static object  (*LnkLI33)() = LnkTLI33;
static  LnkT10() ;
static  (*Lnk10)() = LnkT10;
static  LnkT32() ;
static  (*Lnk32)() = LnkT32;
