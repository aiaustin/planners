
static L1();
static L2();
static L3();
static object LI4();
static L5();
static L6();
static L7();
static L8();
static L9();
static L10();
static L11();
static L12();
static L13();
static L14();
static L15();
static L16();
static L17();
static L18();
static L19();
static L20();
static L21();
static L22();
static L23();
static L24();
static L25();
static L26();
static L27();
static L28();
static L29();
static L30();
static L31();
#define VC1
#define VC2 object  V17 ,V16 ,V15 ,V12 ,V11 ,V10;
#define VC3 object  V23 ,V22 ,V21 ,V20;
static object LI4();
#define VMB4 register object *base=vs_top; object  V32 ,V31 ,V25; object Vcs[1];
#define VMS4  register object *sup=vs_top+13;vs_top=sup;
#define VMV4 vs_reserve(13);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
#define VC5
#define VC6 object  V41;
#define VC7 object  V43;
#define VC8
#define VC9 object  V45;
#define VC10
#define VC11 object  V47;
#define VC12
#define VC13 object  V49;
#define VC14
#define VC15 object  V51;
#define VC16
#define VC17 object  V53;
#define VC18
#define VC19 object  V55;
#define VC20
#define VC21 object  V57;
#define VC22
#define VC23 object  V59;
#define VC24
#define VC25 object  V61;
#define VC26
#define VC27 object  V63;
#define VC28
#define VC29 object  V65;
#define VC30
#define VC31 object  V81 ,V78 ,V69 ,V68;
#define VM31 6
#define VM30 1
#define VM29 2
#define VM28 1
#define VM27 2
#define VM26 1
#define VM25 2
#define VM24 1
#define VM23 2
#define VM22 1
#define VM21 2
#define VM20 1
#define VM19 2
#define VM18 1
#define VM17 2
#define VM16 1
#define VM15 2
#define VM14 1
#define VM13 2
#define VM12 1
#define VM11 2
#define VM10 1
#define VM9 2
#define VM8 1
#define VM7 2
#define VM6 9
#define VM5 2
#define VM4 13
#define VM3 6
#define VM2 6
#define VM1 19
static char * VVi[78]={
#define Cdata VV[77]
(char *)(L1),
(char *)(L2),
(char *)(L3),
(char *)(LI4),
(char *)(L5),
(char *)(L6),
(char *)(L7),
(char *)(L8),
(char *)(L9),
(char *)(L10),
(char *)(L11),
(char *)(L12),
(char *)(L13),
(char *)(L14),
(char *)(L15),
(char *)(L16),
(char *)(L17),
(char *)(L18),
(char *)(L19),
(char *)(L20),
(char *)(L21),
(char *)(L22),
(char *)(L23),
(char *)(L24),
(char *)(L25),
(char *)(L26),
(char *)(L27),
(char *)(L28),
(char *)(L29),
(char *)(L30),
(char *)(L31)
};
#define VV ((object *)VVi)
static  LnkT76() ;
static  (*Lnk76)() = LnkT76;
static  LnkT75() ;
static  (*Lnk75)() = LnkT75;
static  LnkT74() ;
static  (*Lnk74)() = LnkT74;
static  LnkT73() ;
static  (*Lnk73)() = LnkT73;
static  LnkT72() ;
static  (*Lnk72)() = LnkT72;
