
fasload(char *file)
{
 printf("this is a dummy\n");

}
