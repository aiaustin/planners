#define NEED_MP_H
#include "include.h"


#ifdef CMAC
#include "cmac.c"
#endif
