Updated: Sat Sep 18 22:28:32 2004 by Jeff Dalton

This "imports" directory contains jar files for non-I-X software
used by the main I-X classes -- but not jar files needed only by
specific communication strategies or specific applications.

jdom.jar, version beta-8
  
  JDOM is an XML-processing API.

  See http://jdom.org/

junit.jar, version 3.8.1

  JUnit is a regression testing framework.
  It is needed only by the Java files in the "test" directory,
  not for the normal operation of I-X software.

  See http://www.junit.org/

mgraph.jar, MGraph licenced version 1.2.3

  See http://www.singleton-labs.com

openmap.jar, version 4.5.4

  See http://openmap.bbn.com

jena2/

  RDF and OWL Utilities

  http://jena.sourceforge.net/

The terms of the open source licences of some of the software
provided as jar files in this directory (or its subdirectories)
require that we provide a way to obtain the source code of that
software.  That can be done by sending e-mail to i-x@aiai.ed.ac.uk.
