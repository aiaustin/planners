/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed 17 April 2002 by Austin Tate
 * Copyright: (c) 2002, AIAI, University of Edinburgh
 */

package isample;

import javax.swing.*;

import ix.itest.*;
import ix.icore.*;
import ix.util.*;

public class IsampleTest extends Itest {

    public IsampleTest() {
	super("I-Test");
    }

    /**
     * Main program.
     */
    public static void main(String[] argv) {
        Util.printGreeting("I-Test Example");
        new IsampleTest().mainStartup(argv);
    }

    /**
     * Command-line argument processing used by all versions of I-Test.
     * Add in any special extra parameter handlign required here.
     * @see ix.icore.IXAgent#processCommandLineArguments()
     */
    protected void processCommandLineArguments() {
        super.processCommandLineArguments();
    }

}


