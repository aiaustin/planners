package ix.ip2;

import ix.icore.IXAgentExtension;
import ix.iface.util.ToolController;
import ix.ip2.map.MapWhiteboard;

public class MapViewExtension implements IXAgentExtension {

    private Ip2 ip2;
    
    public MapViewExtension(Ip2 ip2) {
	this.ip2 = ip2;
    }

    public void installExtension() {
	ip2.addTool(new ToolController("Map Views") {
	    public Object createTool(){
	        return new MapWhiteboard(ip2);
	    }
	});
    }
}

//javac -classpath ../../../../ix.jar:. ix/ip2/MapViewExtension.java
