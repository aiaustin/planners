Stephen Potter (stephenp@inf.ed.ac.uk)
updated: Fri Mar 03 14:52:32 2006

Scripts:

Invoke scripts - alter these for your own use:
	jabber-aibo-ix.bat
	xml-aibo-ix.bat

Base scripts, called by the above - think before you alter these:
        base-jabber-run-ix-aibo.bat	
	base-xml-run-ix-aibo.bat

Compile script - recompiles AIBO controller code:
	compile-controller.bat