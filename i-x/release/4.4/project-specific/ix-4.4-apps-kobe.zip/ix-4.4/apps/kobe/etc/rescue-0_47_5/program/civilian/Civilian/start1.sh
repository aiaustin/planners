#! /bin/sh
./foo -file config.txt $*
