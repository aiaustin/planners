#! /bin/sh
./civilian -file config.txt -rulefile test2.txt $*
