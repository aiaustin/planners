/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#include "objects.h"
#include "simCollapse.h"

using namespace Librescue;
using namespace std;

//Prototype
double P(double pga, double lambda, double zeta);

int collapse_check(Building* bPtr, int accel){

  double pga = (accel+1)*100 + 50;
  double lambda_a; //collapse
  double lambda_ha; //moderate��collapse
  double lambda_mp; //slight��collapse
  double zeta_a; //collapse
  double zeta_ha; //moderate��collapse
  double zeta_mp; //slight��collapse
  float m = ((float)rand()/RAND_MAX); //random number 0��1


  if (bPtr->getAttributes() == WOOD){ //��¤�ξ��
    lambda_a = 6.883;
    lambda_ha = 5.683;
    lambda_mp = 4.045;
    zeta_a = 0.636;
    zeta_ha = 0.910;
    zeta_mp = 1.441;
    
    if (m <=  P(pga, lambda_a, zeta_a))
      return COLLAPSE;
    else if (m <= P(pga, lambda_ha, zeta_ha))
      return MODERATE;
    else if (m <= P(pga, lambda_mp, zeta_mp))
      return SLIGHT;
    else
      return NODAMAGE;
  }

  else if (bPtr->getAttributes() == S || bPtr->getAttributes() == RC){ //RC, S �ξ��
    lambda_a = 8.523;
    lambda_ha = 7.377;
    lambda_mp = 7.862;
    zeta_a = 1.067;
    zeta_ha = 1.314;
    zeta_mp = 6.897;
    
    if (m <=  P(pga, lambda_a, zeta_a))
      return COLLAPSE;
    else if (m <= P(pga, lambda_ha, zeta_ha))
      return MODERATE;
    else if (m <= P(pga, lambda_mp, zeta_mp))
      return SLIGHT;
    else
      return NODAMAGE;
  }
  return 0;
}
