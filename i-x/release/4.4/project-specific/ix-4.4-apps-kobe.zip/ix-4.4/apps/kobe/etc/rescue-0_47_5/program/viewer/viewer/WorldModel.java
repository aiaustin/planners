package viewer;

import java.io.*;
import java.util.*;
import viewer.object.*;
import java.nio.*;

public class WorldModel implements Constants {
	public final HashMap idObjMap = new HashMap();

	public final ArrayList nodeList          = new ArrayList();
	public final ArrayList roadList          = new ArrayList();
	public final ArrayList buildingList      = new ArrayList();
	public final ArrayList movingObjectList  = new ArrayList();
	public final ArrayList ambulanceTeamList = new ArrayList();
	public final ArrayList fireBrigadeList   = new ArrayList();
	public final ArrayList policeForceList   = new ArrayList();
	public final ArrayList civilianList      = new ArrayList();

	private int m_time = 0;
	public int time() { return m_time; }

	/**File used to log some information during the simulation.*/
	private PrintWriter _debugFile;//DEBUG

	/**
	 * Constructor of the class.
	 */
	public WorldModel()
	{
		try {
			_debugFile = new PrintWriter(new FileWriter("DebugInfo.txt"));//DEBUG
		}
		catch (IOException ex)
			{
				System.err.println("Error openning DebugInfo.txt.");
				System.err.println(ex.getMessage());
			}

	}

	public void add(RealObject obj) {
		idObjMap.put(new Integer(obj.id), obj);
		if      (obj instanceof Node)     nodeList    .add(obj);
		else if (obj instanceof Road)     roadList    .add(obj);
		else if (obj instanceof Building) buildingList.add(obj);
		else if (obj instanceof MovingObject) {
			movingObjectList.add(obj);
			switch (obj.type()) {
			default: break;
			case TYPE_AMBULANCE_TEAM:  ambulanceTeamList.add(obj); break;
			case TYPE_FIRE_BRIGADE:    fireBrigadeList.add(obj);   break;
			case TYPE_POLICE_FORCE:    policeForceList.add(obj);   break;
			case TYPE_CIVILIAN:        civilianList.add(obj);      break;
			}
		}
	}

	public RealObject get(int id) {
		return (RealObject) idObjMap.get(new Integer(id));
	}

	public void update(DataInputStream dis, int time) {
		m_time = time;
		System.out.println("Updating world model");
		try {
			int type = dis.readInt();
			while (type != TYPE_NULL) {
				int id = dis.readInt();
				RescueObject obj = get(id);
				if (obj == null) {
					obj = newRescueObject(type, id);
					if (obj instanceof RealObject)
						add((RealObject) obj);
				}
				int propType = dis.readInt();
				while (propType != PROPERTY_NULL) {
					obj.input(propType, getProperty(propType, dis));
					propType = dis.readInt();
				}
				type = dis.readInt();
			}
		} catch (IOException e) { Util.myassert(false, e); }

		if (time == 0) {
			m_initTotalHp = 0;
			for (Iterator it = movingObjectList.iterator();  it.hasNext();  )
				m_initTotalHp += ((Humanoid) it.next()).hp();
		}
		VIEWER.setStatus();

		//If the simulation is finished, we save the stats and close the viewer.
		if(WORLD.time() >= 300)
			{
				try{Thread.currentThread().sleep(5000);}catch(Exception e){}
				WORLD.saveStatInFile(); //To save the stats of the simulation in a file.
				System.exit(0);
			}
	}

	private RescueObject newRescueObject(int type, int id) {
		RescueObject obj;
		switch (type) {
		case TYPE_WORLD:            obj = new World(id);           break;
		case TYPE_RIVER:            obj = new River(id);           break;
		case TYPE_RIVER_NODE:       obj = new RiverNode(id);       break;
		case TYPE_ROAD:             obj = new Road(id);            break;
		case TYPE_NODE:             obj = new Node(id);            break;
		case TYPE_BUILDING:         obj = new Building(id);        break;
		case TYPE_AMBULANCE_CENTER: obj = new AmbulanceCenter(id); break;
		case TYPE_FIRE_STATION:     obj = new FireStation(id);     break;
		case TYPE_POLICE_OFFICE:    obj = new PoliceOffice(id);    break;
		case TYPE_REFUGE:           obj = new Refuge(id);          break;
		case TYPE_CIVILIAN:         obj = new Civilian(id);        break;
		case TYPE_AMBULANCE_TEAM:   obj = new AmbulanceTeam(id);   break;
		case TYPE_FIRE_BRIGADE:     obj = new FireBrigade(id);     break;
		case TYPE_POLICE_FORCE:     obj = new PoliceForce(id);     break;
		case TYPE_CAR:              obj = new Car(id);             break;
		default: Util.myassert(false, "illeagle object type" + type); throw new Error();
		}
		return obj;
	}

	private int[] m_buf = new int[2048];
	private int[] getProperty(int type, DataInputStream dis) throws IOException {
		if (type < 0x80  ||  0xff < type)
			// integer tyep prpoerty
			return new int[] { dis.readInt() };
		if (type < 0xc0) {
			// list tyep prpoerty
			int[] result = new int[dis.readInt() / 4];  // 4: sizeof(int)
			for (int i = 0;  i < result.length;  i ++)
				result[i] = dis.readInt();
			return result;
		}
		// array type property
		int i = -1;
		do {
			m_buf[++ i] = dis.readInt();
		} while (m_buf[i] != 0);
		int[] result = new int[i];
		System.arraycopy(m_buf, 0, result, 0, i);
		return result;
	}

	private int m_minX = Integer.MAX_VALUE;
	private int m_minY = Integer.MAX_VALUE;
	private int m_maxX = Integer.MIN_VALUE;
	private int m_maxY = Integer.MIN_VALUE;
	public int minX() { return m_minX; }
	public int maxX() { return m_maxX; }
	public int minY() { return m_minY; }
	public int maxY() { return m_maxY; }

	public void setWorldRange() {
		Iterator it = idObjMap.values().iterator();
		System.out.println(idObjMap.values().size()+" objects");
		int roads = 0;
		int nodes = 0;
		int buildings = 0;
		int civilians = 0;
		while (it.hasNext()) {
			Object obj = it.next();
			if (obj instanceof Building) ++buildings;
			if (obj instanceof Road) ++roads;
			if (obj instanceof Node) ++nodes;
			if (obj instanceof Civilian) ++civilians;
			if (!(obj instanceof PointObject))
				continue;
			PointObject po = (PointObject) obj;
			if (m_minX > po.x()) m_minX = po.x();
			if (m_maxX < po.x()) m_maxX = po.x();
			if (m_minY > po.y()) m_minY = po.y();
			if (m_maxY < po.y()) m_maxY = po.y();
		}
		System.out.println(roads+" roads");
		System.out.println(nodes+" nodes");
		System.out.println(buildings+" buildings");
		System.out.println(civilians+" civilians");
	}

	private IO io() { return Main.io(); }

	public void extractNextPositionPropertys() {
		if (!io().hasUpdateData(m_time + 1))
			return;
		DataInputStream dis = io().updateData(m_time + 1);
		try {
			int type = dis.readInt();
			while (type != TYPE_NULL) {
				int id = dis.readInt();
				RescueObject obj = get(id);
				int pos = 0, posEx = 0, route[] = new int[0];
				MovingObject mv = null;
				if (obj instanceof MovingObject) {
					mv = (MovingObject) obj;
					pos   = mv.motionlessPosition().id;
					posEx = mv.positionExtra();
				}
				int propType = dis.readInt();
				while (propType != PROPERTY_NULL) {
					int[] val = getProperty(propType, dis);
					switch (propType) {
					default: break;
					case PROPERTY_POSITION:         pos   = val[0]; break;
					case PROPERTY_POSITION_EXTRA:   posEx = val[0]; break;
					case PROPERTY_POSITION_HISTORY: route = val;    break;
					}
					propType = dis.readInt();
				}
				if (obj instanceof MovingObject)
					mv.prepareForAnimation(pos, posEx, route);
				type = dis.readInt();
			}
		} catch (IOException e) { Util.myassert(false, e); }
	}

	public void progress() { playback(m_time + 1); }

	public void playback(int time) {
		for (int i = (time > m_time) ? m_time : 0;
			 i <= time  &&  io().hasUpdateData(i);
			 i ++) {
			System.out.println("Updating timestep "+i);
			update(io().updateData(i), i);
		}
	}

	public void parseCommands() {
		DataInputStream dis = io().commandsData(m_time + 1);
		//DEBUG
		_debugFile.println("");
		_debugFile.println("************************");
		_debugFile.println("Time: " + m_time);
		_debugFile.println("************************");
		//END DEBUG
		try {
			int command = dis.readInt();
			while (command != HEADER_NULL) {
				int remainderToNextCommand = dis.readInt();
				if (remainderToNextCommand != 0) {
					int senderId = dis.readInt();
					while (senderId != HEADER_NULL) {
						RealObject sender = get(senderId);
						byte[] buf = new byte[dis.readInt()];
						dis.read(buf, 0, buf.length);
						ByteBuffer byteBuffer = ByteBuffer.allocate(buf.length);
						byteBuffer = byteBuffer.put(buf);
						byteBuffer.rewind();
						switch (command) {
						default:
							break;
						case AK_MOVE:
							if(command == AK_MOVE && !(sender instanceof Civilian)) _debugFile.print("Move (" + senderId + "): ");
						case AK_RESCUE:
							if(command == AK_RESCUE && !(sender instanceof Civilian)) _debugFile.print("Rescue (" + senderId + "): ");
						case AK_LOAD:
							if(command == AK_LOAD && !(sender instanceof Civilian)) _debugFile.print("Load (" + senderId + "): ");
						case AK_UNLOAD:
							if(command == AK_UNLOAD && !(sender instanceof Civilian)) _debugFile.print("Unload (" + senderId + "): ");
						case AK_EXTINGUISH:
							if(command == AK_EXTINGUISH && !(sender instanceof Civilian)) _debugFile.print("Extinguish (" + senderId + "): ");
						case AK_CLEAR:
							if(command == AK_CLEAR && !(sender instanceof Civilian)) _debugFile.print("Clear (" + senderId + "): ");

							if(!(sender instanceof Civilian))
								{
									while(byteBuffer.hasRemaining())
										{
											_debugFile.print(byteBuffer.getInt() + ", ");
										}
									_debugFile.println("");
								}
							sender.setAction(command, buf);
							break;
						case AK_TELL:
						case AK_SAY:
							sender.setCommunication(command, buf);
						}
						senderId = dis.readInt();
					}
				}
				command = dis.readInt();
			}
		} catch (IOException e) { Util.myassert(false, e); }
	}

	// -------------------------------------------------------------------- score
	private int m_initTotalHp;
	private int _numDeads = 0;
	private int _numLiving = 0;
	private double _totalHp = 0;
	private double _totalNonburnedBldgArea = 0;
	private double _totalBldgArea = 0;

	public double score() {
        double totalHp = 0;
        int numLiving = 0;
        for (Iterator it = movingObjectList.iterator(); it.hasNext();) {
            int hp = ((Humanoid) it.next()).hp();
            totalHp += hp;
            if (hp > 0)
                numLiving++;
        }

        double totalBldgArea = 0;
        double totalNonburnedBldgArea = 0;
        for (Iterator it = buildingList.iterator(); it.hasNext();) {
            Building b = (Building) it.next();
            int area = b.buildingAreaTotal();
            totalBldgArea += area;
            double factor = 1.0;
            switch (b.fieryness()) {
			case 0:
				break;
			case 1 :   
			case 4 :
			case 5 :
				factor = 0.666666;
				break;
			case 2 :                    
			case 6 :
				factor = 0.333333;
				break;
			default :
				factor = 0;
				break;
            }
            totalNonburnedBldgArea += (factor * area);
        }

        return (numLiving + totalHp / m_initTotalHp)
			* Math.sqrt(totalNonburnedBldgArea / totalBldgArea);
    }

	/**
     * This method save the stat of the simulation at the end of it. Stats are saved
     * in a file to be used automatically and analyse. The format of a line in
     * the file is: score;dead;totalNumberOfAgent;RemaningHPOfAllAgents;HPAtInitial;AreaNotBurnt;AreaAtInitial;
     * safe;heating;onFire;Severe;Saved;PatBurnt;HalfBurnt;FullBurnt;Building0%;25%;50%;75%;100%;
     * Road0%;25%;50%;75%;100%;
     */
    public void saveStatInFile()
    {
        PrintWriter printWriter = null;
        try
			{
				printWriter = new PrintWriter(new FileWriter("SimulationsStats.txt", true), true);

				String stats = new String();
				stats = stats.concat("" + "" + Main.m_simulationID + ";");
				stats = stats.concat("" + "" + score() + ";");
				stats = stats.concat("" + "" + _numDeads + ";");
				stats = stats.concat("" + "" + _numLiving + ";");
				stats = stats.concat("" + "" + _totalHp + ";");
				stats = stats.concat("" + "" + m_initTotalHp + ";");
				stats = stats.concat("" + "" + _totalNonburnedBldgArea + ";");
				stats = stats.concat("" + "" + _totalBldgArea);

				printWriter.println(stats);

			}
        catch(java.io.IOException e)
			{
				System.out.println("IO Exception: SimulationsStats.txt");
				System.out.println(e.getMessage());
			}
        finally
			{
				if (printWriter != null)
					{
						printWriter.close();
					}
			}

        //Close the debug file
        _debugFile.close();

    }//END saveStatInFile
}
