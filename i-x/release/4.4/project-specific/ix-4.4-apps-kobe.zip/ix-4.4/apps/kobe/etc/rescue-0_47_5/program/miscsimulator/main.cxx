/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#include "common.h"
#include "config.h"
#include "connection.h"
#include "tcp.h"
#include "input.h"
#include "output.h"
#include "objectpool.h"
#include "objects.h"

//#ifdef MISC
//#  include "MiscObjectPool.hxx"
//#  include "MiscHumanoid.hxx"
//#else
//#  include "ObjectPool.hxx"
//#endif

//#include "objects.hxx"


//#ifdef MISC_CLASS
//#include "misc_class.hxx"
//#endif
//#include "simBlockage.h"
#include "PolygonData.hxx"
#include "MISC_ENUM.hxx"
#include "miscsimulator.h"

using namespace Librescue;
using namespace Rescue;
using namespace std;

int main2(int argc, char** argv);

void commands(INT_32& time, Input& input, Output& output, Connection* connection, const Address& kernelAddress, Config& config);
void commands(INT_32& time, Header type, Input& input, Config& config);
void load(INT_32& time, MovingObject* agent, Input& input, Config& config);
void unload(INT_32& time, MovingObject* agent, Input& input);
void rescue(INT_32& time, MovingObject* agent, Input& input, Config& config);
void stretch(INT_32& time, MovingObject* agent, Input& input, Config& config);
void move(INT_32& time, MovingObject* agent, Input& input, Config& config);
void clear(INT_32& time, MovingObject* agent, Input& input, Config& config);
/*
#else
void commands(S32& time, Input& input, Output& output, TcpConnection *connection, ObjectPool& pool, Config& config);
void commands(S32& time, Header type, Input& input, ObjectPool& pool, Config& config);
void load(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config);
void unload(S32& time, MovingObject* agent, Input& input, ObjectPool& pool);
void rescue(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config);
void stretch(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config);
void move(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config);
void clear(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config);
#endif // MISC
*/

/*
#ifdef MISC_CLASS
void step(S32& time, MiscObjectPool& pool, Config& config, Dice& dice, IMOCivilian& imoc);
void step_init(S32& time, MiscObjectPool& pool, Config& config, Dice& dice, IMOCivilian& imoc);

void step(S32& time, ObjectPool& pool, Config& config, Dice& dice, IMOCivilian& imoc);
void step_init(S32& time, ObjectPool& pool, Config& config, Dice& dice, IMOCivilian& imoc);
#endif
*/

void survive(INT_32& time, INT_32& x, Civilian* c);

/*
#ifdef MISC_CLASS
bool testPosition(IMOCivilian& imoc, MovingObject* mo);
void testSelectObject(ObjectPool& pool, IMOCivilian& imoc);
void testJudgeObject(IMOCivilian& imoc, MovingObject* mo);
#endif
*/

//long int polyNum;
//long int pointNum;
//coordinates* polyPtr;
//polyData* pData;

ObjectPool m_pool;
std::map<Id,Objects> m_contents;

int main(int argc, char** argv) {
  try {
	return main2(argc, argv);
  } catch(std::exception& e) {
	fprintf(stderr, "%s\n", (const char*)e.what());
  } catch(std::string e) {
	fprintf(stderr, "error: %s\n", e.c_str());
  } catch(...) {
	fprintf(stderr, "error...\n");
  }
  return 1;
}

int main2(int argc, char** argv) {
  const char* host = "localhost";
  Config config;

  // ��������
  int i;
  int count = 0;
  for(i=1; i<argc; i++) {
	if(argv[i][0] == '-') {
	  if(strcmp(argv[i], "-file") == 0) {
		if(++i < argc) {
		  config.readConfigFile(argv[i]);
		} else {
		  fprintf(stderr, "error: '-file'\n");
		}
	  } else {
		if(++i < argc) {
		  if(!config.setValue(argv[i-1]+1, argv[i]))
			fprintf(stderr, "error: '%s'\n", argv[i]);
		} else {
		  fprintf(stderr, "error: '%s'\n", argv[i-1]);
		}
	  }
	} else {
	  switch(count++) {
	  case 0:
		host = argv[i];
		break;
	  default:
		fprintf(stderr, "error: '%s'\n", argv[i]);
		break;
	  }
	}
  }

#ifdef MISC_DEBUG
  printf("config.misc_random_seed() : %d\n", config.misc_random_seed());
  printf("magnitude_dice() : %d\n", config.magnitude_dice());
  printf("parameter_damage_bury_k() : %f\n", config.parameter_damage_bury_k());
  printf("config.brokenness_partial_collapsed(): %d\n", config.brokenness_partial_collapsed());
  printf("config.brokenness_half_collapsed(): %d\n", config.brokenness_half_collapsed());
  printf("config.brokenness_all_collapsed(): %d\n", config.brokenness_all_collapsed());
  printf("config.buriedness_wood_partial_6seismic() : %d\n", config.buriedness_wood_partial_6seismic());
  printf("config.buriedness_wood_half_6seismic() : %d\n", config.buriedness_wood_half_6seismic());
  printf("config.buriedness_wood_all_6seismic() : %d\n", config.buriedness_wood_all_6seismic());
  printf("config.damage_bury_unhurt(): %d\n", config.damage_bury_unhurt());
  printf("config.damage_bury_slight() : %d\n", config.damage_bury_slight());
  printf("config.damage_bury_serious() : %d\n", config.damage_bury_serious());
  printf("config.damage_bury_dying() : %d\n", config.damage_bury_dying());
  printf("config.prob_bury_slight() : %f\n", config.prob_bury_slight());
  printf("config.prob_bury_serious() : %f\n", config.prob_bury_serious());
  printf("config.prob_bury_dying() : %f\n", config.prob_bury_dying());
  printf("config.damage_broken_unhurt() : %d\n", config.damage_broken_unhurt());
  printf("config.damage_broken_slight() : %d\n", config.damage_broken_slight());
  printf("config.damage_broken_serious() : %d\n", config.damage_broken_serious());
  printf("config.damage_broken_death() : %d\n", config.damage_broken_death());
  printf("config.rate_wood_death_5seismic() : %f\n", config.rate_wood_death_5seismic());
  printf("config.rate_wood_death_6seismic() : %f\n", config.rate_wood_death_6seismic());
  printf("config.rate_wood_death_7seismic() : %f\n", config.rate_wood_death_7seismic());
  printf("config.rate_wood_death_8seismic() : %f\n", config.rate_wood_death_8seismic());
  printf("config.rate_wood_serious_5seismic() : %f\n", config.rate_wood_serious_5seismic());
  printf("config.rate_wood_serious_6seismic() : %f\n", config.rate_wood_serious_6seismic());
  printf("config.rate_wood_serious_7seismic() : %f\n", config.rate_wood_serious_7seismic());
  printf("config.rate_wood_serious_8seismic() : %f\n", config.rate_wood_serious_8seismic());
  printf("config.rate_wood_slight_5seismic() : %f\n", config.rate_wood_slight_5seismic());
  printf("config.rate_wood_slight_6seismic() : %f\n", config.rate_wood_slight_6seismic());
  printf("config.rate_wood_slight_7seismic() : %f\n", config.rate_wood_slight_7seismic());
  printf("config.rate_wood_slight_8seismic() : %f\n", config.rate_wood_slight_8seismic());
  fflush(NULL);
#endif

  // �����åȺ���
  Input input;
  Output output;
	
  Address kernelAddress(host,config.port());
  //  ConnectionManager manager;
  //  manager.sendViaTCP(kernelAddress);
  //  manager.start();
  TcpConnection client(kernelAddress);
  // ��³��å�����������
  printf("connecting...\n");
  output.clear();                                                            //�����ϥХåե�����ˤ���
  output.writeInt32(SK_CONNECT);                                            //�����ϥХåե��� SK_CONNECT ��(4�Х��Ȥ�)���Ϥ���
  Cursor base = output.writeInt32(~(INT_32)0); //��body �Υ������Ȥ��ƤȤꤢ�������ߡ����ͤ���Ϥ��Ƥ����ơ�base �ˤ��ΰ��֤򵭲����롣
  output.writeInt32(0);                                                             //�����ϥХåե��� 0 ����Ϥ���
  output.writeSize(base);                                              //��base �ǵ����������֤ˡ�base ���餳���ޤǤ� put �����Х��ȿ������ꤹ�롣
  output.writeInt32(HEADER_NULL);
  client.send(output);                                       //��output �� put �����Х������ to ���������롣

  // ��å����������롼��
  INT_32 time = 0;

  MiscSimulator* simulator = 0;
  Dice dice(config.misc_random_seed());

  //     Dice dice(config.misc_random_seed());

  //#ifdef MISC
  //    MiscObjectPool pool(config, config.misc_random_seed());
  //#else
  //  ObjectPool pool;
  //#endif

  while(client.isOpen()) {
	while (client.isDataAvailable(-1)) {
	  client.receive(input);   // TODO: ���顼���㳰���֤�     //���ǡ������������input ���ߤ��롣
	  for(;;) {
		Header header = (Header)input.readInt32();        //��input ����(4�Х��Ȥ�)�ǡ�������Ф���header ����������
		if(header == HEADER_NULL)
		  break;

		INT_32 size = input.readInt32();
		Cursor start = input.cursor();       //�������ɤ߽Ф��Ƥ�����֤򵭲�����

		switch(header) {
		default:
		  printf("Unknown header.\n");
		  break;
		case KS_CONNECT_ERROR:
		  printf("Connection failed.\n");
		  return 1;
		case KS_CONNECT_OK:
		  printf("Connect Ok.\n");
		  // ack ���֤�
		  output.clear();
		  output.writeInt32(SK_ACKNOWLEDGE);
		  output.writeInt32(~(INT_32)0);
		  output.writeInt32(HEADER_NULL);
		  client.send(output);
                                
		  m_pool.update(input,0);                    //�����ɥ�ǥ���������롣
		  if (!simulator) simulator = new MiscSimulator(m_pool,config,dice);
		  break;
		case KS_COMMANDS:
		  printf("KS_COMMANDS\n");
		  commands(time, input, output, &client, kernelAddress, config);
		  break;
		case KS_UPDATE:
		  time = input.readInt32();
		  m_pool.update(input,time);

		  printf("time = %ld.\n", (long)time);

		  //#ifdef MISC
		  // by TM ����, ����� commands ��ľ��˹Ԥ���٤�����, ���Τ�����ѹ������ݤ�����
		  // by TM �����Ȥ�, commands ��ľ��� step(time) �Ȥ� step(time +- 1) �Ȥ�������Ǥϥ���ʤ��Ȥ��ǧ����
		  if (simulator) simulator->step(time);
		  //    pool.step(time);
		  //#endif
		  if (time >= 300)
			{
			  client.close();
			  return 0;
			}
		  break;
		}

		input.setCursor(start);
		input.skip(size);                                           //��size �Х��ȥ����åפ���
	  }
	}
  }
       
  return 0;
}

//#ifdef MISC
void commands(INT_32& time, Input& input, Output& output, Connection* client, const Address& kernelAddress, Config& config)
  //#else
  //void commands(S32& time, Input& input, Output& output, TcpConnection *connection, ObjectPool& pool, Config& config)
  //#endif
{
  // KS_COMMANDS ���������
  time = input.readInt32();
  Header type;
  while(type = (Header)input.readInt32(), type != HEADER_NULL) {
	INT_32 size = input.readInt32();
	Cursor start = input.cursor();
	commands(time, type, input, config);
	input.setCursor(start);
	input.skip(size);
  }

  /*
    if (config.tank_quantity_recovery_on_refuge() > 0) {
	Objects::const_iterator it = pool.objects().begin();
	for (; it != pool.objects().end(); it++) {
	Object* o = *it;
	FireBrigade* a = dynamic_cast<FireBrigade*>(o);
	if (a) {
	Object* pos = a->position();
	if (dynamic_cast<const Refuge*>(pos)) {
	S32 waterQuantity = a->waterQuantity();
	waterQuantity += config.tank_quantity_recovery_on_refuge();
	if (waterQuantity > config.tank_quantity_maximum())
	waterQuantity = config.tank_quantity_maximum();
	a->setWaterQuantity(time, waterQuantity);
	}
	}
	}
    }
  */

  // ���ߥ�졼������̤���������
  output.clear();
  output.writeInt32(SK_UPDATE);
  Cursor base = output.writeInt32(~(S32)0);
  m_pool.write(output, time);
  output.writeSize(base);
  output.writeInt32(HEADER_NULL);
  client->send(output);
}
//#ifdef MISC
void commands(INT_32& time, Header type, Input& input, Config& config)
  //#else
  //void commands(S32& time, Header type, Input& input, ObjectPool& pool, Config& config)
  //#endif
{
  Id sender;
  while(sender = input.readInt32(), sender != 0) {
	INT_32 size = input.readInt32();
	Cursor start = input.cursor();

	RescueObject* o = m_pool.getObject(sender); //�����ɥ�ǥ뤫�顢sender �� ID �˻��ĥ��֥������Ȥ����ĥ��Ф���
	MovingObject* agent = dynamic_cast<MovingObject*>(o);
	if(agent != 0) {
	  switch(type) {
	  case AK_LOAD:
		load(time, agent, input, config);
		break;
	  case AK_UNLOAD:
		unload(time, agent, input);
		break;
	  case AK_RESCUE:
		rescue(time, agent, input, config);
		break;
	  case AK_STRETCH:
		stretch(time, agent, input, config);
		break;
	  case AK_MOVE:
		move(time, agent, input, config);
		break;
	  case AK_CLEAR:
		clear(time, agent, input, config);
		break;
	  default:
		break;
	  }
	}
             
	input.setCursor(start);
	input.skip(size);
  }
}

static bool isNear(RescueObject* a, RescueObject* b, Config& config) {
  if (config.near_agents_rescuable()) {
	Vertex* nodeA = dynamic_cast<Vertex*>(a);
	Vertex* nodeB = dynamic_cast<Vertex*>(b);
	Edge* edgeA = dynamic_cast<Edge*>(a);
	Edge* edgeB = dynamic_cast<Edge*>(b);
	if (nodeA != NULL && edgeB != NULL) {
	  if (edgeB->getHead() == nodeA->id() || edgeB->getTail() == nodeA->id())
		return true;
	} else if (nodeB != NULL && edgeA != NULL) {
	  if (edgeA->getHead() == nodeB->id() || edgeA->getTail() == nodeB->id())
		return true;
	}
  }
  return a == b;
}

//#ifdef MISC
void load(INT_32& time, MovingObject* agent, Input& input, Config& config)
  //#else
  //void load(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config)
  //#endif
{
  if (!config.miscsimulator_supports_load())
	return;
    
  AmbulanceTeam* a = dynamic_cast<AmbulanceTeam*>(agent);
  if(a != 0) {
	if(m_contents[agent->id()].empty() && a->getBuriedness() == 0) {
	  Id id = input.readInt32();
	  MovingObject* target = dynamic_cast<MovingObject*>(m_pool.getObject(id));
	  if(target != 0) {
		Humanoid* h = dynamic_cast<Humanoid*>(target);
		Car* car = dynamic_cast<Car*>(target);
		if(h != 0 && car == 0){
		  if(h->getBuriedness() == 0 && isNear(m_pool.getObject(target->getPosition()), m_pool.getObject(agent->getPosition()), config)){
			target->setPosition(agent->id(),time);
			target->setPositionExtra(0,time);
			m_contents[agent->id()].push_back(target);
			//                            printf("load %ld by %ld\n", (long)target->id(), (long)agent->id());
			printf("id%ld load id%ld\n", (long)agent->id(), (long)target->id());
			return ;
		  }
		}
	  }
	  //             printf("load failed %ld by %ld\n", (long)target->id(), (long)agent->id());
	  printf("id%ld failed load id%ld\n", (long)agent->id(), (long)target->id());
	}
  }
}

//#ifdef MISC
void unload(INT_32& time, MovingObject* agent, Input& input)
  //#else
  //void unload(S32& time, MovingObject* agent, Input& input, ObjectPool& pool)
  //#endif
{
  AmbulanceTeam* a = dynamic_cast<AmbulanceTeam*>(agent);
  if(a != 0) {
	Objects& contents = m_contents[agent->id()];
	if(!contents.empty() && a->getBuriedness() == 0) {
	  RescueObject* target = contents.front();
	  //		  ASSERT(dynamic_cast<MovingObject*>(target) != 0);
	  MovingObject* mo = (MovingObject*)target;
	  mo->setPosition(agent->getPosition(),time);
	  mo->setPositionExtra(agent->getPositionExtra(),time);
	  contents.clear();
	  printf("id%ld unload %ld\n", (long)agent->id(), (long)mo->id());
	}
  }
}

//#ifdef MISC
void rescue(INT_32& time, MovingObject* agent, Input& input, Config& config)
  //#else
  //void rescue(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config)
  //#endif
{
  AmbulanceTeam* a = dynamic_cast<AmbulanceTeam*>(agent);
  if(a != 0 && a->getBuriedness() == 0) {
	Id id = input.readInt32();
	Humanoid* target = dynamic_cast<Humanoid*>(m_pool.getObject(id));
	if(target != 0) {
	  if(isNear(m_pool.getObject(target->getPosition()), m_pool.getObject(agent->getPosition()), config)) {
		if(target->getBuriedness() > 0) {
		  target->setBuriedness(target->getBuriedness() - 1,time);
		  printf("id%ld rescue id%ld : buriedness %ld\n", (long)agent->id(), (long)target->id(), (long)target->getBuriedness());
		}
		else{
		  target->setBuriedness(0,time);
		  printf("id%ld failed rescue id%ld : buriedness already 0\n", (long)agent->id(), (long)target->id());
		}
	  }
	}
  }
}

//#ifdef MISC
void stretch(INT_32& time, MovingObject* agent, Input& input, Config& config)
  //#else
  //void stretch(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config)
  //#endif
{
  FireBrigade* brigade = dynamic_cast<FireBrigade*>(agent);
  if(brigade != 0 && brigade->getBuriedness() == 0) {
	brigade->setStretchedLength(brigade->getStretchedLength() + config.stretch_length(),time);
	printf("id%ld stretch\n", (long)agent->id());
  }

}

//#ifdef MISC
void move(INT_32& time, MovingObject* agent, Input& input, Config& config)
  //#else
  //void move(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config)
  //#endif
{
  FireBrigade* brigade = dynamic_cast<FireBrigade*>(agent);
  if(brigade != 0 && brigade->getStretchedLength() > 1)
	brigade->setStretchedLength(0,time);
}


//#ifdef MISC
void clear(INT_32& time, MovingObject* agent, Input& input, Config& config)
  //#else
  //void clear(S32& time, MovingObject* agent, Input& input, ObjectPool& pool, Config& config)
  //#endif
{
  PoliceForce* police = dynamic_cast<PoliceForce*>(agent);
  if(police != 0 && police->getBuriedness() == 0) {
	Id id = input.readInt32();
	Road* target = dynamic_cast<Road*>(m_pool.getObject(id));
	if(target != 0) {
	  if(target->id() != agent->getPosition()   && target->getHead() != agent->getPosition() && target->getTail() != agent->getPosition()) {
		printf("id%ld failed clear id%ld : not appropriate position\n", (long)agent->id(), (long)target->id());
		return;
	  }
	  INT_32 block = target->getBlock();
	  INT_32 repairCost = target->getRepairCost();
	  if(repairCost <= 0) {
		block = 0;
	  }
	  else {
		block = block * (repairCost - 1) / repairCost;
		repairCost--;
		target->setRepairCost(repairCost,time);
	  }
	  target->setBlock(block,time);
	  printf("id%ld clear id%ld : block %ld , repairCost %ld\n", (long)agent->id(), (long)target->id(), (long)target->getBlock(), (long)target->getRepairCost());
	}
  }
}
