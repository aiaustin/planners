/*
 * Copyright (c) 2005, The Black Sheep, Department of Computer Science, The University of Auckland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of The Black Sheep, The Department of Computer Science or The University of Auckland nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 Contributors and list of changes:

 Cameron Skinner
*/

#include "error.h"
#include <iostream>

namespace Librescue {
  char errorBuffer[BUFFER_LENGTH];

  void logError(const char* msg) {
	std::cerr << msg << std::endl;
	fflush(stderr);
  }

  void logWarning(const char* msg) {
	std::cout << msg << std::endl;
	fflush(stdout);
  }

  void logDebug(const char* msg) {
	std::cout << msg << std::endl;
	fflush(stdout);
  }

  void logInfo(const char* msg) {
	std::cout << msg << std::endl;
	fflush(stdout);
  }

  void dumpBytes(const char* bytes, int size) {
	char msg[128];
	for (int i=0;i<size;i+=4) {
	  snprintf(msg,128,"%d\t%02x\t%02x\t%02x\t%02x",i,bytes[i],bytes[i+1],bytes[i+2],bytes[i+3]);
	  std::cout << msg << std::endl;
	}
	fflush(stdout);
  }

  void dumpBytes(const Byte* bytes, int size) {
	char msg[128];
	for (int i=0;i<size;i+=4) {
	  snprintf(msg,128,"%d\t%02x\t%02x\t%02x\t%02x",i,bytes[i],bytes[i+1],bytes[i+2],bytes[i+3]);
	  std::cout << msg << std::endl;
	}
	fflush(stdout);
  }

  void dumpBytes(const Bytes& bytes) {
	char msg[128];
	int size = bytes.size();
	for (int i=0;i<size;i+=4) {
	  snprintf(msg,128,"%d\t%02x\t%02x\t%02x\t%02x",i,bytes[i],bytes[i+1],bytes[i+2],bytes[i+3]);
	  std::cout << msg << std::endl;
	}
	fflush(stdout);
  }

  void dumpBytes(Input& input) {
	Cursor start = input.cursor();
	Cursor current = start;
	char msg[128];
	while (current<(Cursor)input.size()) {
	  INT_32 next = input.readInt32();
	  snprintf(msg,128,"%d\t%02x\t%02x\t%02x\t%02x",current,(next>>24)&0xFF,(next>>16)&0xFF,(next>>8)&0xFF,next&0xFF);
	  std::cout << msg << std::endl;
	  current = input.cursor();
	}
	input.setCursor(start);
	fflush(stdout);
  }
}
