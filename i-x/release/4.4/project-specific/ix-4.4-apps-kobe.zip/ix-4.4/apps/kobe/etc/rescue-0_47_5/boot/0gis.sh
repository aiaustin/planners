#! /bin/sh
DIR=`dirname $0`
$DIR/../program/gis/gis -file $DIR/config.txt $*
