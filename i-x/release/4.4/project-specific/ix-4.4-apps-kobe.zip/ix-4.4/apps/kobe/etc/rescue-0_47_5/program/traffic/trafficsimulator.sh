#! /bin/sh
java -classpath .. traffic.Main $*
