/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

// RescueSystem.cxx
//
/////////////////////////////////////////////////////////////////////////////

#include "../librescue/common.h"
#include "../librescue/objects.h"
#include "../librescue/input.h"
#include "../librescue/output.h"
#include "../librescue/error.h"
#include "Agent.hxx"
#include "RescueSystem.hxx"


using namespace Librescue;

namespace Rescue
{
  /////////////////////////////////////////////////////////////////////////
  // RescueSystem
    
  RescueSystem::RescueSystem() : System(std::vector<TypeId>(agentTypes,agentTypes+numAgentTypes))
  {
  }

  RescueSystem::~RescueSystem()
  {
  }
    
  void RescueSystem::loop()
  {
	System::loop();
  }

  void RescueSystem::step() {
	System::step();
	// Update ignition
	for (Objects::const_iterator it = m_objectPool.objects().begin();it!=m_objectPool.objects().end();++it) {
	  const Building* next = dynamic_cast<const Building*>(*it);
	  if (next) {
		if (next->getFieryness()>0 && next->getFierynessUpdate()==m_time && ignition[next->id()]==0) ignition[next->id()]=m_time;
	  }
	}
  }

  void RescueSystem::outputObjectForAgentAtStart(Agent* agent, const RescueObject* o, Output& buffer)
  {
	if(o->type() == TYPE_BUILDING) {
	  buffer.writeInt32(o->type());
	  buffer.writeInt32(o->id());
	  o->writeProperty(buffer, PROPERTY_X);
	  o->writeProperty(buffer, PROPERTY_Y);
	  o->writeProperty(buffer, PROPERTY_FLOORS);
	  o->writeProperty(buffer, PROPERTY_BUILDING_ATTRIBUTES);
	  //o->output(buffer, PROPERTY_IGNITION);
	  o->writeProperty(buffer, PROPERTY_FIERYNESS);
	  o->writeProperty(buffer, PROPERTY_BROKENNESS);
	  o->writeProperty(buffer, PROPERTY_ENTRANCES);
	  o->writeProperty(buffer, PROPERTY_BUILDING_CODE);
	  o->writeProperty(buffer, PROPERTY_BUILDING_AREA_GROUND);
	  o->writeProperty(buffer, PROPERTY_BUILDING_AREA_TOTAL);
	  o->writeProperty(buffer, PROPERTY_BUILDING_APEXES);
	  buffer.writeInt32(PROPERTY_NULL);
	} else if(dynamic_cast<const Humanoid*>(o) != 0) {
	  if (config().send_civilians_at_start() || o->type()!=TYPE_CIVILIAN) {
		buffer.writeInt32(o->type());
		buffer.writeInt32(o->id());
            
		if (config().notify_initial_position()) {
		  o->writeProperty(buffer, PROPERTY_POSITION);
		  o->writeProperty(buffer, PROPERTY_POSITION_EXTRA);
		}
		o->writeProperty(buffer, PROPERTY_DIRECTION);
		if (config().notify_position_history()) {
		  o->writeProperty(buffer, PROPERTY_POSITION_HISTORY);
		}
		o->writeProperty(buffer, PROPERTY_STAMINA);
		o->writeProperty(buffer, PROPERTY_HP);
		o->writeProperty(buffer, PROPERTY_DAMAGE);
		o->writeProperty(buffer, PROPERTY_BURIEDNESS);
            
		if(dynamic_cast<const FireBrigade*>(o) != 0) {
		  o->writeProperty(buffer, PROPERTY_WATER_QUANTITY);
		  o->writeProperty(buffer, PROPERTY_STRETCHED_LENGTH);
		}
		buffer.writeInt32(PROPERTY_NULL);
	  }
	} else {
	  o->write(buffer);
	}
  }
  //static int looked = 0;
  //static int unlooked = 0;
  void RescueSystem::outputObjectForAgent(Agent* agent, const RescueObject* o, Output& buffer)
  {
	if (config().notify_unchangeable_informaion()) {
	  if(o->type() == TYPE_BUILDING) {
		buffer.writeInt32(o->type());
		buffer.writeInt32(o->id());
		o->writeProperty(buffer, PROPERTY_X);
		o->writeProperty(buffer, PROPERTY_Y);
		o->writeProperty(buffer, PROPERTY_FLOORS);
		o->writeProperty(buffer, PROPERTY_BUILDING_ATTRIBUTES);
		//o->output(buffer, PROPERTY_IGNITION);
		o->writeProperty(buffer, PROPERTY_FIERYNESS);
		if (config().notify_only_fire_for_far_buildings())
		  agent->m_farFireBuildingIDToSent[o->id()] = ((const Building*) o)->getFieryness();
		o->writeProperty(buffer, PROPERTY_BROKENNESS);
		o->writeProperty(buffer, PROPERTY_ENTRANCES);
		o->writeProperty(buffer, PROPERTY_BUILDING_CODE);
		o->writeProperty(buffer, PROPERTY_BUILDING_AREA_GROUND);
		o->writeProperty(buffer, PROPERTY_BUILDING_AREA_TOTAL);
		o->writeProperty(buffer, PROPERTY_BUILDING_APEXES);
		buffer.writeInt32(PROPERTY_NULL);
	  } else if(dynamic_cast<const Humanoid*>(o) != 0) {
		buffer.writeInt32(o->type());
		buffer.writeInt32(o->id());
                
		o->writeProperty(buffer, PROPERTY_POSITION);
		o->writeProperty(buffer, PROPERTY_POSITION_EXTRA);
		o->writeProperty(buffer, PROPERTY_DIRECTION);
		if (config().notify_position_history()) {
		  o->writeProperty(buffer, PROPERTY_POSITION_HISTORY);
		}
		o->writeProperty(buffer, PROPERTY_STAMINA);
		o->writeProperty(buffer, PROPERTY_HP);
		o->writeProperty(buffer, PROPERTY_DAMAGE);
		o->writeProperty(buffer, PROPERTY_BURIEDNESS);
                
		if(dynamic_cast<const FireBrigade*>(o) != 0) {
		  o->writeProperty(buffer, PROPERTY_WATER_QUANTITY);
		  o->writeProperty(buffer, PROPERTY_STRETCHED_LENGTH);
		}
                
		buffer.writeInt32(PROPERTY_NULL);
	  } else {
		o->write(buffer);
	  }
	} else {
	  buffer.writeInt32(o->type());
	  buffer.writeInt32(o->id());
	  if(dynamic_cast<const MotionlessObject*>(o) != 0) {
		// not changed, but notify for look-time notification.
		o->writeProperty(buffer, PROPERTY_X);
		o->writeProperty(buffer, PROPERTY_Y);
	  }
	  if(dynamic_cast<const MovingObject*>(o) != 0) {
		o->writeProperty(buffer, PROPERTY_POSITION);
		o->writeProperty(buffer, PROPERTY_POSITION_EXTRA);
	  }
            
	  if(dynamic_cast<const Road*>(o) != 0) {
		o->writeProperty(buffer, PROPERTY_BLOCK);
		o->writeProperty(buffer, PROPERTY_REPAIR_COST);
	  } else if(dynamic_cast<const Building*>(o) != 0) {
		o->writeProperty(buffer, PROPERTY_FIERYNESS);
		if (config().notify_only_fire_for_far_buildings())
		  agent->m_farFireBuildingIDToSent[o->id()] = ((const Building*) o)->getFieryness();
		o->writeProperty(buffer, PROPERTY_BROKENNESS);
	  } else if(dynamic_cast<const Humanoid*>(o) != 0) {
		o->writeProperty(buffer, PROPERTY_STAMINA);
		o->writeProperty(buffer, PROPERTY_HP);
		o->writeProperty(buffer, PROPERTY_DAMAGE);
		o->writeProperty(buffer, PROPERTY_BURIEDNESS);
                
		o->writeProperty(buffer, PROPERTY_DIRECTION);
		o->writeProperty(buffer, PROPERTY_POSITION_HISTORY);
                
		if(dynamic_cast<const FireBrigade*>(o) != 0) {
		  o->writeProperty(buffer, PROPERTY_WATER_QUANTITY);
		}
	  }
	  buffer.writeInt32(PROPERTY_NULL);
	}
  }
  bool RescueSystem::outputFarBuildingForAgent(Agent* agent, const Building* o, Output& buffer)
  {
	if (config().notify_only_fire_for_far_buildings()) {
	  if (config().send_far_fire_changed_only()) {
		std::map<Id,INT_32>::iterator it = agent->m_farFireBuildingIDToSent.find(o->id());
		if (it != agent->m_farFireBuildingIDToSent.end()) {
		  if (it->second == o->getFieryness()) {
			//unlooked++;
			return false;
		  }
		  it->second = o->getFieryness();
		} else {
		  agent->m_farFireBuildingIDToSent[o->id()] = o->getFieryness();
		}
	  }
            
	  buffer.writeInt32(o->type());
	  buffer.writeInt32(o->id());
	  o->writeProperty(buffer, PROPERTY_FIERYNESS);
	  //looked++;
	  buffer.writeInt32(PROPERTY_NULL);
	} else {
	  outputObjectForAgent(agent, o, buffer);
	}
	return true;
  }
  void RescueSystem::sendToAgents()
  {
	//long theTime = ::timeGetTime();
        
	// TODO: ��®��
	// TODO: ����������֤ϥ����ब˾�ޤ�����
	const double squaredVision = (double)config().vision() * config().vision();
	for(unsigned int i=0; i < m_agentTypes.size(); i++) {
#if 0   // ����
	  receiveMessages(agentSocket());
#endif
	  Agents::iterator it = m_pConnectedAgents[i].begin();
	  for(; it != m_pConnectedAgents[i].end(); it++) {
		Agent* agent = *it;
		if (agent->isDefunct()) {
		  LOG_INFO("Not sending to agent %d because it is defunct",agent->asObject()->id());
		  continue;
		}
		//looked = unlooked = 0;
		if(agent->needsSensoryInformation()) {
		  m_outputBuffer.clear();
		  m_outputBuffer.writeInt32(KA_SENSE);
		  Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
		  //		  ASSERT(dynamic_cast<RealObject*>(agent->asObject()) != 0);
		  RealObject* self = (RealObject*)agent->asObject();
		  m_outputBuffer.writeInt32(self->id());
		  m_outputBuffer.writeInt32(m_time);
		  // self
		  outputObjectForAgent(agent, self, m_outputBuffer);
		  // map (near)
		  std::list<RescueObject*> near;
		  int selfX;
		  int selfY;
		  m_objectPool.locate(self,&selfX,&selfY);
		  m_objectPool.getObjectsInRange(selfX,selfY,config().vision(),near);
		  int objectCount = 0;
		  for (std::list<RescueObject*>::const_iterator it = near.begin();it!=near.end();++it) {
			const RescueObject* next = *it;
			outputObjectForAgent(agent, next, m_outputBuffer);
			++objectCount;
		  }
		  //		  LOG_DEBUG("Sending %d objects with vision distance",objectCount);
		  // map��far fire��
		  objectCount = 0;
		  if (m_time <= config().steps_far_fire_invisible()) {
			// invisible.
		  } else if (m_time > config().steps_far_fire_invisible()) {
			//			logDebug("Checking for far buildings");
			Objects::const_iterator it2 = m_objectPool.objects().begin();
			for(; it2 != m_objectPool.objects().end(); it2++) {
			  Building* b = dynamic_cast<Building*>(*it2);
			  if(b != 0) {
				double x = (double)b->getX() - selfX;
				double y = (double)b->getY() - selfY;
				if(x * x + y * y > squaredVision) {
				  if (config().fire_cognition_spredding_speed() < 0) {
					if (outputFarBuildingForAgent(agent, b, m_outputBuffer))
					  ++objectCount;
				  } else {
					if (ignition[b->id()] > 0) {
					  //					  LOG_DEBUG("Building %d caught fire at time %d (current time %d)",b->id(),ignition[b->id()],m_time);
					  double z = (double)(m_time - ignition[b->id()]) * config().fire_cognition_spredding_speed();
					  //					  LOG_DEBUG("Squared distance = %f, squared vision = %f",x*x + y*y,z*z);
					  if (x * x + y * y <= z * z) {
						//						LOG_DEBUG("Close enough to see fire");
						if (outputFarBuildingForAgent(agent, b, m_outputBuffer))
						  ++objectCount;
					  }
					}
				  }
				}
			  }
			}
			//			LOG_DEBUG("Sending %d far buildings",objectCount);
		  }
		  m_outputBuffer.writeInt32(TYPE_NULL);
		  m_outputBuffer.writeSize(base);
		  m_outputBuffer.writeInt32(HEADER_NULL);
		  if (!m_connectionManager.send(m_outputBuffer, agent->clientAddress())) {
			// Mark this agent as defunct
			LOG_INFO("Marking agent %d as defunct",agent->asObject()->id());
			agent->defunct();
		  }
		}
	  }
	}
  }
    
  void RescueSystem::processCommand(Agent* agent, Header header, INT_32 size, Input& input/*, const LongUDPConnection& from*/)
  {
	//	LOG_DEBUG("Processing command 0x%x from agent %d",header,agent->asObject()->id());
	Humanoid* h = dynamic_cast<Humanoid*>(agent->asObject());
	if(h == 0 || h->getHP() > 0) { // �����ʤɿͤǤʤ������ͤǻ��Ǥ��ʤ���
	  if(h != 0) {
		int denominator = config().block_stamina_denominator();
		if(denominator) {
		  if((double)rand() / ((double)RAND_MAX + 1) >= (double)h->getStamina() / denominator) {
			reportRejection(agent, "the action was blocked because of the low stamina.");
			return; // blocking by low stamina.
		  }
		}
	  }
	  if(header != AK_SAY && header != AK_TELL) {
		bool block = false; // block the command ?
		if(header != AK_REST && h != 0 && h->getBuriedness() > 0) {
		  reportRejection(agent, "can only say/tell/rest because he/she is buried.");
		  block = true;
		}
		switch(header) {
		case AK_MOVE:
		  if(h == 0) {
			reportRejection(agent, "can not move because he/she is not a movable agent.");
			block = true;
		  }
		  break;
		case AK_EXTINGUISH:
		  {
			FireBrigade* f = dynamic_cast<FireBrigade*>(agent->asObject());
			if(f == 0) {
			  reportRejection(agent, "can not extinguish it because he/she is not a fire brigade.");
			  block = true;
			} else {
			  INT_32 sumOfWater = 0;
			  INT_32 numberOfNozzles = 0;
			  Cursor cursor = m_inputBuffer.cursor();
			  Id target;
			  while(target = m_inputBuffer.readInt32(), target != 0) {
				/*INT_32 direction =*/ m_inputBuffer.readInt32();
				INT_32 positionX = m_inputBuffer.readInt32();
				INT_32 positionY = m_inputBuffer.readInt32();
				INT_32 quantity = m_inputBuffer.readInt32();
                                
				if (!config().ignore_nozzle_position()) {
				  int x;
				  int y;
				  if (m_objectPool.locate(f,&x,&y)) {
					double xx = x - positionX;
					double yy = y - positionY;
					double zz = xx * xx + yy * yy;
					if(zz > (double)config().max_fire_hose_length() * config().max_fire_hose_length()) {
					  reportRejection(agent, "can not stretch the fire hose. (2001 competion rule)");
					  block = true;
					}
				  }
				  else {
					reportRejection(agent,"Cannot locate agent!");
					block = true;
				  }
				}
                                
				Building* building = dynamic_cast<Building*>(m_objectPool.getObject(target));
				if(building == 0) {
				  reportRejection(agent, "can extinguish only a building.");
				  block = true;
				} else {
				  double xx = positionX - building->getX();
				  double yy = positionY - building->getY();
				  double zz = xx * xx + yy * yy;
				  if(zz > (double)config().max_extinguish_length() * config().max_extinguish_length()) {
					reportRejection(agent, "can not extinguish such a far building.");
					block = true;
				  }

				  if(building->getIgnition() > 0 && building->getFieryness() <= 0) {
					reportRejection(agent, "can not extinguish an unburned building.");
					block = true;
				  }
				}
                                
				if(quantity < 0) {
				  reportRejection(agent, "can not extinguish it with <0 power.");
				  block = true;
				} else if(config().max_extinguish_power() >= 0 && quantity > config().max_extinguish_power()) {
				  char buffer[1024];
				  sprintf(buffer, "can not extinguish it with >%ld power.", (long)config().max_extinguish_power());
				  reportRejection(agent, buffer);
				  block = true;
				}
				sumOfWater += quantity;
				numberOfNozzles++;
			  }
			  if (config().max_extinguish_power_sum() >= 0 && sumOfWater > config().max_extinguish_power_sum()) {
				reportRejection(agent, "can not extinguish with biger power than max_extinguish_power_sum.");
				block = true;
			  }
			  if (config().max_nozzles() >= 0 && numberOfNozzles > config().max_nozzles()) {
				reportRejection(agent, "can not extinguish with more nozzles than max_nozzles.");
				block = true;
			  }
			  m_inputBuffer.setCursor(cursor);
			}
		  }
		  break;
		case AK_LOAD:
		  {
			AmbulanceTeam* f = dynamic_cast<AmbulanceTeam*>(agent->asObject());
			if(f == 0) {
			  reportRejection(agent, "can not load anything because he/she is not a ambulance team.");
			  block = true;
			} else {
			  Cursor cursor = m_inputBuffer.cursor();
			  Id target = m_inputBuffer.readInt32();
			  Humanoid* humanoid = dynamic_cast<Humanoid*>(m_objectPool.getObject(target));
			  if(humanoid == 0) {
				reportRejection(agent, "can load only a humanoid.");
				block = true;
			  } else {
				if(humanoid->getBuriedness() > 0) {
				  reportRejection(agent, "can not load the buried agent.");
				  block = true;
				}
			  }
			  m_inputBuffer.setCursor(cursor);
			}
		  }
		  break;
		case AK_UNLOAD:
		case AK_CLEAR:
		case AK_RESCUE:
		case AK_REST:
		  break;
		default:
		  // Ignore
		  reportRejection(agent,"Ignoring unknown command");
		  block = true;
		}
		if(!block) {
		  System::processCommand(agent, header, size, input/*, from*/);
		}
	  } else {
		INT_32 size = m_inputBuffer.readInt32();
		char* buffer = new char[size];
		m_inputBuffer.readString(buffer,size);
		if(size > config().say_max_bytes()) {
		  reportRejection(agent, "can not say/tell such a long message.");
		} else {
		  Id sender = agent->asObject()->id();
		  if(header == AK_SAY) {
			//S32 target = m_inputBuffer.get();
			say(sender, buffer, size); // TODO: ̵����ꥭ�㥹�Ȥ��Ƥ��뤬�����Ȥ����롣
		  } else {
			tell(sender, buffer, size);    // TODO: ̵����ꥭ�㥹�Ȥ��Ƥ��뤬�����Ȥ����롣
		  }
		}
	  }
	}
  }
    
  void RescueSystem::resetAgents()
  {
	for(int i=0; i<AGENTTYPE_MAX; i++) {
	  Agents::const_iterator it = m_pConnectedAgents[i].begin();
	  for(; it != m_pConnectedAgents[i].end(); it++) {
		Agent* a = *it;
		//		LOG_DEBUG("Resetting agent %p",a);
		RealObject* ro = dynamic_cast<RealObject*>(a->asObject());
		if(ro != 0) {
		  a->resetCacheForVoices();
		}
	  }
	}
  }
  void RescueSystem::buildCacheForVoices(Agent* a, int radius)
  {
	a->m_radiusOfCacheForVoices = radius;
	const double squaredRadius = (double)radius * radius;
        
	RealObject* center = dynamic_cast<RealObject*>(a->asObject());
	if(center) {
	  int centerX;
	  int centerY;
	  if (m_objectPool.locate(center,&centerX,&centerY)) {
		for(int i=0; i<AGENTTYPE_MAX; i++) {
		  Agents::const_iterator it = m_pConnectedAgents[i].begin();
		  for(; it != m_pConnectedAgents[i].end(); it++) {
			RealObject* candidate = dynamic_cast<RealObject*>((*it)->asObject());
			int candidateX;
			int candidateY;
			if(candidate != 0 & m_objectPool.locate(candidate,&candidateX,&candidateY)) {
			  double dx = candidateX - centerX;
			  double dy = candidateY - centerY;
			  if(dx*dx + dy*dy <= squaredRadius)
				a->m_cacheForVoices.push_back(candidate);
			}
		  }
		}
	  }
	}
  }
  void RescueSystem::say(Id from, const char* message, INT_32 size)
  {
	int radius = config().voice();
	RealObject* agent = dynamic_cast<RealObject*>(m_objectPool.getObject(from));
	Agent* a = findAgent(agent);
	if(!agent) {
	  reportRejection(from, "can not say because he/she is virtual (not real) agent.");
	} else {
	  if(a->m_radiusOfCacheForVoices != radius)
		buildCacheForVoices(a, radius);
            
	  const Objects& targets = a->m_cacheForVoices;
	  Objects::const_iterator it = targets.begin();
	  for(; it != targets.end(); it++) {
		RescueObject* target = *it;
		Agent* targetAsAgent = findAgent(target);
		if(targetAsAgent && !targetAsAgent->isDefunct()) {
		  m_outputBuffer.clear();
		  m_outputBuffer.writeInt32(KA_HEAR);
		  Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
		  m_outputBuffer.writeInt32(target->id());
		  m_outputBuffer.writeInt32(from);
		  m_outputBuffer.writeString(message, size);
		  m_outputBuffer.writeSize(base);
		  m_outputBuffer.writeInt32(HEADER_NULL);
		  //printf("say %s\n", message);
		  if (!m_connectionManager.send(m_outputBuffer, targetAsAgent->clientAddress())) {
			// Mark this agent as defunct
			LOG_INFO("Marking agent %d as defunct",targetAsAgent->asObject()->id());
			targetAsAgent->defunct();
		  }
                    
		  if (config().additional_hearing()) {
			m_outputBuffer.clear();
			m_outputBuffer.writeInt32(KA_HEAR_SAY);
			Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
			m_outputBuffer.writeInt32(target->id());
			m_outputBuffer.writeInt32(from);
			m_outputBuffer.writeString(message, size);
			m_outputBuffer.writeSize(base);
			m_outputBuffer.writeInt32(HEADER_NULL);
			//printf("say %s\n", message);
			if (!m_connectionManager.send(m_outputBuffer, targetAsAgent->clientAddress())) {
			  // Mark this agent as defunct
			  LOG_INFO("Marking agent %d as defunct",targetAsAgent->asObject()->id());
			  targetAsAgent->defunct();
			}
		  }
		}
	  }
	}
  }
    
  void RescueSystem::tell(Id from, const char* message, INT_32 size)
  {
	RealObject* agent = dynamic_cast<RealObject*>(m_objectPool.getObject(from));
	if(agent == 0) {
	  reportRejection(from, "can not tell because he/she is virtual (not real) agent.");
	  return;
	}
        
	TypeId agentType = agent->type();
	int recepients[4] = {AGENTTYPE_MAX, AGENTTYPE_MAX, AGENTTYPE_MAX, AGENTTYPE_MAX};
	switch (agentType){
	case TYPE_CIVILIAN:
	  return;
	case TYPE_FIRE_BRIGADE:
	  recepients[0]=AGENTTYPE_FIRE_BRIGADE;
	  recepients[1]=AGENTTYPE_FIRE_STATION;
	  break;
	case TYPE_FIRE_STATION:
	  recepients[0]=AGENTTYPE_FIRE_BRIGADE;
	  recepients[1]=AGENTTYPE_FIRE_STATION;
	  recepients[2]=AGENTTYPE_AMBULANCE_CENTER;
	  recepients[3]=AGENTTYPE_POLICE_OFFICE;
	  break;
	case TYPE_AMBULANCE_TEAM:
	  recepients[0]=AGENTTYPE_AMBULANCE_TEAM;
	  recepients[1]=AGENTTYPE_AMBULANCE_CENTER;
	  break;
	case TYPE_AMBULANCE_CENTER:
	  recepients[0]=AGENTTYPE_AMBULANCE_TEAM;
	  recepients[1]=AGENTTYPE_FIRE_STATION;
	  recepients[2]=AGENTTYPE_AMBULANCE_CENTER;
	  recepients[3]=AGENTTYPE_POLICE_OFFICE;
	  break;
	case TYPE_POLICE_FORCE:
	  recepients[0]=AGENTTYPE_POLICE_FORCE;
	  recepients[1]=AGENTTYPE_POLICE_OFFICE;
	  break;
	case TYPE_POLICE_OFFICE:
	  recepients[0]=AGENTTYPE_POLICE_FORCE;
	  recepients[1]=AGENTTYPE_FIRE_STATION;
	  recepients[2]=AGENTTYPE_AMBULANCE_CENTER;
	  recepients[3]=AGENTTYPE_POLICE_OFFICE;
	  break;
	default:
	  return;
	}
        
	for (int i=0; i<4; i++){
	  if (recepients[i] != AGENTTYPE_MAX) {
		Agents::const_iterator it = m_pConnectedAgents[recepients[i]].begin();
		for(; it != m_pConnectedAgents[recepients[i]].end(); it++) {
		  Agent* a = *it;
		  if (a->isDefunct()) continue;
		  m_outputBuffer.clear();
		  m_outputBuffer.writeInt32(KA_HEAR);
		  Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
		  m_outputBuffer.writeInt32(a->asObject()->id());
		  m_outputBuffer.writeInt32(from);
		  m_outputBuffer.writeString(message, size);
		  m_outputBuffer.writeSize(base);
		  m_outputBuffer.writeInt32(HEADER_NULL);
		  //printf("tell %s\n", message);
		  if (!m_connectionManager.send(m_outputBuffer, a->clientAddress())) {
			// Mark this agent as defunct
			LOG_INFO("Marking agent %d as defunct",a->asObject()->id());
			a->defunct();
		  }
                    
		  if (config().additional_hearing()) {
			m_outputBuffer.clear();
			m_outputBuffer.writeInt32(KA_HEAR_TELL);
			Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
			m_outputBuffer.writeInt32(a->asObject()->id());
			m_outputBuffer.writeInt32(from);
			m_outputBuffer.writeString(message, size);
			m_outputBuffer.writeSize(base);
			m_outputBuffer.writeInt32(HEADER_NULL);
			//printf("tell %s\n", message);
			if (!m_connectionManager.send(m_outputBuffer, a->clientAddress())) {
			  // Mark this agent as defunct
			  LOG_INFO("Marking agent %d as defunct",a->asObject()->id());
			  a->defunct();
			}
		  }
		}
	  }
	}
  }
    
  void RescueSystem::reportRejection(Agent* agent, const char* why) {
	reportRejection(agent->asObject()->id(), why);
  }
  void RescueSystem::reportRejection(Id agentId, const char* why) {
	LOG_INFO("reject: step=%ld agentID=%ld  %s\n", (long)m_time, (long)agentId, why);
  }
    
    
  /////////////////////////////////////////////////////////////////////////
} // namespace Rescue
