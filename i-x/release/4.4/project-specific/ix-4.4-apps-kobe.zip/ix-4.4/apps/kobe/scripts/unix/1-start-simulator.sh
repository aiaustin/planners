#! /bin/sh

cd ../../etc/rescue-0_47_5/boot
./all.sh
