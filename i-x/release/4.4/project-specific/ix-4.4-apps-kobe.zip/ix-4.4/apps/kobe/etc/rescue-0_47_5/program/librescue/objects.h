/*
 * Copyright (c) 2005, The Black Sheep, Department of Computer Science, The University of Auckland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of The Black Sheep, The Department of Computer Science or The University of Auckland nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 Contributors and list of changes:

 Cameron Skinner
   Converted original Robocup Rescue software into librescue
*/

#ifndef RESCUE_OBJECTS_H
#define RESCUE_OBJECTS_H

#include "common.h"
#include "input.h"
#include "output.h"

namespace Librescue {
  RescueObject* newRescueObject(TypeId type);

  class Property {
  private:
	PropertyId m_type;
	// For integer value properties
	INT_32 m_value;
	// For list of integer value properties
	INT_32* m_values;
	INT_32 m_numValues;
	INT_32 m_valuesLength;
	// The last update time
	INT_32 m_lastUpdate;

	void resizeValues(int size);

  public:
	Property(PropertyId type);
	~Property();

	PropertyId type() const;
	INT_32 getIntValue() const;
	INT_32* getIntValues() const;
	INT_32 lastUpdate() const;

	void setIntValue(INT_32 value);
	void setIntValues(INT_32* values);
	void appendIntValue(INT_32 value);
	void clearIntValues();
	void setLastUpdate(INT_32 time);

	void read(Input& buffer);
	void write(Output& buffer) const;
  };

  class RescueObject {
  private:
	Id m_id;

  protected:
	virtual Property* getProperty(PropertyId type);
	const Property* getProperty(PropertyId type) const;

  public:
	RescueObject();
	virtual ~RescueObject();
	
	virtual void read(Input& buffer, int time);
	// Write this object to a buffer.
	virtual void write(Output& buffer) const;
	// Write this object to a buffer, but only write properties that have been updated at "time" or later.
	virtual void write(Output& buffer, INT_32 time) const;
	virtual void readProperty(Input& buffer, PropertyId property, INT_32 length, int time);
	// Write a particular property to a buffer.
	virtual void writeProperty(Output& buffer, PropertyId property) const;

	virtual TypeId type() const = 0;

	Id id() const;
	void setId(Id newId);
  };

  class VirtualObject: public RescueObject {
  public:
	VirtualObject();
	virtual ~VirtualObject();
  };

  class World: public VirtualObject {
  private:
	Property m_startTime;
	Property m_longitude;
	Property m_latitude;
	Property m_windForce;
	Property m_windDirection;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	World();
	virtual ~World();

	virtual TypeId type() const;

	INT_32 getStartTime() const;
	INT_32 getLongitude() const;
	INT_32 getLatitude() const;
	INT_32 getWindForce() const;
	INT_32 getWindDirection() const;

	void setStartTime(INT_32 value, INT_32 time);
	void setLongitude(INT_32 value, INT_32 time);
	void setLatitude(INT_32 value, INT_32 time);
	void setWindForce(INT_32 value, INT_32 time);
	void setWindDirection(INT_32 value, INT_32 time);

	INT_32 getStartTimeUpdate() const;
	INT_32 getLongitudeUpdate() const;
	INT_32 getLatitudeUpdate() const;
	INT_32 getWindForceUpdate() const;
	INT_32 getWindDirectionUpdate() const;
  };

  class RealObject: public RescueObject {
  public:
	RealObject();
	virtual ~RealObject();
  };

  class MovingObject: public RealObject {
  private:
	Property m_position;
	Property m_positionExtra;
	Property m_direction;
	Property m_positionHistory;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	MovingObject();
	virtual ~MovingObject();

	INT_32 getPosition() const;
	INT_32 getPositionExtra() const;
	INT_32 getDirection() const;
	INT_32* getPositionHistory() const;

	void setPosition(INT_32 value, INT_32 time);
	void setPositionExtra(INT_32 value, INT_32 time);
	void setDirection(INT_32 value, INT_32 time);
	void setPositionHistory(INT_32* values, INT_32 time);
	void appendPositionHistory(INT_32 value, INT_32 time);
	void clearPositionHistory(INT_32 time);

	INT_32 getPositionUpdate() const;
	INT_32 getPositionExtraUpdate() const;
	INT_32 getDirectionUpdate() const;
	INT_32 getPositionHistoryUpdate() const;
  };

  class Humanoid: public MovingObject {
  private:
	Property m_stamina;
	Property m_hp;
	Property m_damage;
	Property m_buriedness;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	Humanoid();
	virtual ~Humanoid();

	INT_32 getStamina() const;
	INT_32 getHP() const;
	INT_32 getDamage() const;
	INT_32 getBuriedness() const;

	void setStamina(INT_32 value, INT_32 time);
	void setHP(INT_32 value, INT_32 time);
	void setDamage(INT_32 value, INT_32 time);
	void setBuriedness(INT_32 value, INT_32 time);

	INT_32 getStaminaUpdate() const;
	INT_32 getHPUpdate() const;
	INT_32 getDamageUpdate() const;
	INT_32 getBuriednessUpdate() const;
  };

  class Civilian: public Humanoid {
  public:
	Civilian();
	virtual ~Civilian();

	virtual TypeId type() const;
  };

  class Car: public Humanoid {
  public:
	Car();
	virtual ~Car();

	virtual TypeId type() const;
  };

  class FireBrigade: public Humanoid {
  private:
	Property m_water;
	Property m_stretchedLength;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	FireBrigade();
	virtual ~FireBrigade();

	virtual TypeId type() const;

	INT_32 getWater() const;
	INT_32 getStretchedLength() const;

	void setWater(INT_32 value, INT_32 time);
	void setStretchedLength(INT_32 value, INT_32 time);

	INT_32 getWaterUpdate() const;
	INT_32 getStretchedLengthUpdate() const;
  };

  class AmbulanceTeam: public Humanoid {
  public:
	AmbulanceTeam();
	virtual ~AmbulanceTeam();

	virtual TypeId type() const;
  };

  class PoliceForce: public Humanoid {
  public:
	PoliceForce();
	virtual ~PoliceForce();

	virtual TypeId type() const;
  };

  class MotionlessObject: public RealObject {
  private:
	Property m_x;
	Property m_y;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	MotionlessObject();
	virtual ~MotionlessObject();

	INT_32 getX() const;
	INT_32 getY() const;

	void setX(INT_32 value, INT_32 time);
	void setY(INT_32 value, INT_32 time);

	INT_32 getXUpdate() const;
	INT_32 getYUpdate() const;
  };

  class Building: public MotionlessObject {
  private:
	Property m_floors;
	Property m_attributes;
	Property m_ignition;
	Property m_fieryness;
	Property m_brokenness;
	Property m_entrances;
	Property m_buildingCode;
	Property m_groundArea;
	Property m_totalArea;
	Property m_apexes;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	Building();
	virtual ~Building();

	virtual TypeId type() const;

	INT_32 getFloors() const;
	INT_32 getAttributes() const;
	INT_32 getIgnition() const;
	INT_32 getFieryness() const;
	INT_32 getBrokenness() const;
	INT_32* getEntrances() const;
	INT_32 getBuildingCode() const;
	INT_32 getGroundArea() const;
	INT_32 getTotalArea() const;
	INT_32* getApexes() const;

	void setFloors(INT_32 value, INT_32 time);
	void setAttributes(INT_32 value, INT_32 time);
	void setIgnition(INT_32 value, INT_32 time);
	void setFieryness(INT_32 value, INT_32 time);
	void setBrokenness(INT_32 value, INT_32 time);
	void setBuildingCode(INT_32 value, INT_32 time);
	void setGroundArea(INT_32 value, INT_32 time);
	void setTotalArea(INT_32 value, INT_32 time);
	void setEntrances(INT_32* values, INT_32 time);
	void appendEntrance(INT_32 value, INT_32 time);
	void clearEntrances(INT_32 time);
	void setApexes(INT_32* values, INT_32 time);
	void appendApex(INT_32 value, INT_32 time);
	void clearApexes(INT_32 time);

	INT_32 getFloorsUpdate() const;
	INT_32 getAttributesUpdate() const;
	INT_32 getIgnitionUpdate() const;
	INT_32 getFierynessUpdate() const;
	INT_32 getBrokennessUpdate() const;
	INT_32 getBuildingCodeUpdate() const;
	INT_32 getGroundAreaUpdate() const;
	INT_32 getTotalAreaUpdate() const;
	INT_32 getEntrancesUpdate() const;
	INT_32 getApexesUpdate() const;
  };

  class Refuge: public Building {
  public:
	Refuge();
	virtual ~Refuge();

	virtual TypeId type() const;
  };

  class FireStation: public Building {
  public:
	FireStation();
	virtual ~FireStation();

	virtual TypeId type() const;
  };

  class AmbulanceCenter: public Building {
  public:
	AmbulanceCenter();
	virtual ~AmbulanceCenter();

	virtual TypeId type() const;
  };

  class PoliceOffice: public Building {
  public:
	PoliceOffice();
	virtual ~PoliceOffice();

	virtual TypeId type() const;
  };

  class Edge: public RealObject {
  private:
	Property m_head;
	Property m_tail;
	Property m_length;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	Edge();
	virtual ~Edge();

	INT_32 getHead() const;
	INT_32 getTail() const;
	INT_32 getLength() const;

	void setHead(INT_32 value, INT_32 time);
	void setTail(INT_32 value, INT_32 time);
	void setLength(INT_32 value, INT_32 time);

	INT_32 getHeadUpdate() const;
	INT_32 getTailUpdate() const;
	INT_32 getLengthUpdate() const;
  };

  class Road: public Edge {
  private:
	Property m_roadKind;
	Property m_carsPassToHead;
	Property m_carsPassToTail;
	Property m_humansPassToHead;
	Property m_humansPassToTail;
	Property m_width;
	Property m_block;
	Property m_repairCost;
	Property m_medianStrip;
	Property m_linesToHead;
	Property m_linesToTail;
	Property m_widthForWalkers;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	Road();
	virtual ~Road();

	virtual TypeId type() const;

	INT_32 getRoadKind() const;
	INT_32 getCarsPassToHead() const;
	INT_32 getCarsPassToTail() const;
	INT_32 getHumansPassToHead() const;
	INT_32 getHumansPassToTail() const;
	INT_32 getWidth() const;
	INT_32 getBlock() const;
	INT_32 getRepairCost() const;
	INT_32 getMedianStrip() const;
	INT_32 getLinesToHead() const;
	INT_32 getLinesToTail() const;
	INT_32 getWidthForWalkers() const;

	void setRoadKind(INT_32 value, INT_32 time);
	void setCarsPassToHead(INT_32 value, INT_32 time);
	void setCarsPassToTail(INT_32 value, INT_32 time);
	void setHumansPassToHead(INT_32 value, INT_32 time);
	void setHumansPassToTail(INT_32 value, INT_32 time);
	void setWidth(INT_32 value, INT_32 time);
	void setBlock(INT_32 value, INT_32 time);
	void setRepairCost(INT_32 value, INT_32 time);
	void setMedianStrip(INT_32 value, INT_32 time);
	void setLinesToHead(INT_32 value, INT_32 time);
	void setLinesToTail(INT_32 value, INT_32 time);
	void setWidthForWalkers(INT_32 value, INT_32 time);
	
	INT_32 getRoadKindUpdate() const;
	INT_32 getCarsPassToHeadUpdate() const;
	INT_32 getCarsPassToTailUpdate() const;
	INT_32 getHumansPassToHeadUpdate() const;
	INT_32 getHumansPassToTailUpdate() const;
	INT_32 getWidthUpdate() const;
	INT_32 getBlockUpdate() const;
	INT_32 getRepairCostUpdate() const;
	INT_32 getMedianStripUpdate() const;
	INT_32 getLinesToHeadUpdate() const;
	INT_32 getLinesToTailUpdate() const;
	INT_32 getWidthForWalkersUpdate() const;
  };

  class River: public Edge {
  public:
	River();
	virtual ~River();

	virtual TypeId type() const;
  };

  class Vertex: public MotionlessObject {
  private:
	Property m_edges;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	Vertex();
	virtual ~Vertex();

	INT_32* getEdges() const;

	void setEdges(INT_32* values, INT_32 time);
	void appendEdge(INT_32 value, INT_32 time);
	void clearEdges(INT_32 time);

	INT_32 getEdgesUpdate() const;
  };

  class Node: public Vertex {
  private:
	Property m_signals;
	Property m_shortcutToTurn;
	Property m_pocketToTurnAcross;
	Property m_signalTiming;

  protected:
	virtual Property* getProperty(PropertyId type) ;

  public:
	Node();
	virtual ~Node();

	virtual TypeId type() const;

	INT_32 getSignals() const;
	INT_32* getShortcutToTurn() const;
	INT_32* getPocketToTurnAcross() const;
	INT_32* getSignalTiming() const;

	void setSignals(INT_32 value, INT_32 time);
	void setShortcutToTurn(INT_32* values, INT_32 time);
	void appendShortcutToTurn(INT_32 value, INT_32 time);
	void clearShortcutToTurn(INT_32 time);
	void setPocketToTurnAcross(INT_32* values, INT_32 time);
	void appendPocketToTurnAcross(INT_32 value, INT_32 time);
	void clearPocketToTurnAcross(INT_32 time);
	void setSignalTiming(INT_32* values, INT_32 time);
	void appendSignalTiming(INT_32 value, INT_32 time);
	void clearSignalTiming(INT_32 time);

	INT_32 getSignalsUpdate() const;
	INT_32 getShortcutToTurnUpdate() const;
	INT_32 getPocketToTurnAcrossUpdate() const;
	INT_32 getSignalTimingUpdate() const;
  };

  class RiverNode: public Vertex {
  public:
	RiverNode();
	virtual ~RiverNode();

	virtual TypeId type() const;
  };
}
#endif
