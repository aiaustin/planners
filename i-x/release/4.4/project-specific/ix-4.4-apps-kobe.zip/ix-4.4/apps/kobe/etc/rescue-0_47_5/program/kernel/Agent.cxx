/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

// Agent.cxx
//
/////////////////////////////////////////////////////////////////////////////

#include "../librescue/common.h"
#include "../librescue/objects.h"
#include "Agent.hxx"

namespace Rescue
{
  /////////////////////////////////////////////////////////////////////////
  // Agent
	
  Agent::Agent(/*LongUDPConnection* connection, */RescueObject* object) {
	//	m_connection = connection;
	m_object = object;
	m_needsSensoryInformation = false;
	m_commandType = HEADER_NULL;
	m_commandSize = 0;
	m_commandBuffer = 0;
	m_radiusOfCacheForVoices = 0;
	m_defunct = false;
  }
	
  Agent::~Agent() {
	if(m_commandBuffer)
	  delete[] m_commandBuffer;
  }

  /*
  LongUDPConnection& Agent::getConnection() const {
	return *m_connection;
  }
  */
	
  void Agent::setClientAddress(const Address& address) {
	m_clientAddress = address;
  }

  const Address& Agent::clientAddress() const {
	return m_clientAddress;
  }

  void Agent::setNeedsSensoryInformation(bool needsSensoryInformation) {
	m_needsSensoryInformation = needsSensoryInformation;
  }

  bool Agent::needsSensoryInformation() const {
	return m_needsSensoryInformation;
  }

  RescueObject* Agent::asObject() const {
	return m_object;
  }

  void Agent::inputCommand(Header type, int size, Input& buffer) {
	if(size > m_commandSize) {
	  if(m_commandBuffer) {
		m_commandType = HEADER_NULL;
		m_commandSize = 0;
		delete[] m_commandBuffer;
	  }
	  m_commandBuffer = new Byte[size];
	}
	m_commandType = type;
	m_commandSize = size;
	buffer.read(size, m_commandBuffer);
  }

  void Agent::resetCommand() {
	m_commandType = HEADER_NULL;
  }

  Header Agent::getCommandType() const {
	return m_commandType;
  }

  void Agent::outputCommand(Output& buffer) const {
	buffer.writeInt32(m_commandSize);
	buffer.write(m_commandSize, m_commandBuffer);
  }

  void Agent::resetCacheForVoices() {
	m_radiusOfCacheForVoices = 0;
	m_cacheForVoices.clear();
  }

  void Agent::defunct() {
	m_defunct = true;
  }

  bool Agent::isDefunct() const {
	return m_defunct;
  }

  Agent::Agent(const Agent& source)
	 {
	 }
  Agent& Agent::operator= (const Agent& rhs)
  {
	if(this == &rhs)
	  return *this;
	return *this;
  }
  bool Agent::operator== (const Agent& rhs) const
  {
	return (this == &rhs);
  }
  /////////////////////////////////////////////////////////////////////////
} // namespace Rescue
