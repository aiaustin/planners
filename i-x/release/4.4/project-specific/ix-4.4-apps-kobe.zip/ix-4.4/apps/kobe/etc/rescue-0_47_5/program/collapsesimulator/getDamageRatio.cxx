#include <cstdlib>
#include <cmath>

using namespace std;

//prototypes
double Phi(double x);

double P(double pga, double lambda, double zeta){
  return ( Phi((log(pga)-lambda)/zeta) );
}






