#! /bin/sh
DIR=`dirname $0`
java -Xmx128m -cp $DIR/../program/viewer/ viewer.Main -p 7000
