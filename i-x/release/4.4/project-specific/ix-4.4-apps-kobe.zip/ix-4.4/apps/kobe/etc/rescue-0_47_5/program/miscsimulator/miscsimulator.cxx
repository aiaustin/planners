/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#include "miscsimulator.h"
#include "error.h"
#include <math.h>

namespace Rescue {

MiscSimulator::MiscSimulator(ObjectPool& pool, const Config& config, Dice& dice) : m_pool(pool), cfg(&config), prmt(config), m_dice(dice) {
  // Create a MiscProperties object for every humanoid
  Objects::const_iterator it = m_pool.objects().begin();
  Objects::const_iterator end = m_pool.objects().end();
  for (; it != end;++it) {
	const Humanoid* h = dynamic_cast<const Humanoid*>(*it);
	if (h) {
	  properties[h->id()] = AutoPtr<MiscProperty>(new MiscProperty());
	}
  }
}

MiscSimulator::~MiscSimulator() {}

void MiscSimulator::step(INT_32 time){
  // ���֥������Ȥ�ʬ��
  classifyObjects(time);
  // �Ͽ�ȯ�������������ˤʤ륨��������Ȥ��꿶��
  // ��ʪ��¤�ȿ��٤��Ȥ˷���
  if(time == 1){
	setBuried(time);
  }
  // �����װ��˴�Ť��ƥ��᡼����Ϳ����
  setDamages(time);
  // ���ߥ�졼�����ʹ� (���᡼���ʹ�)
  progressDamages(time);
  // Update last block
  Objects::const_iterator it = m_pool.objects().begin();
  Objects::const_iterator end = m_pool.objects().end();
  for (;it != end;++it) {
	const Road* road = dynamic_cast<const Road*>(*it);
	if (road) {
	  lastBlock[road->id()] = road->getBlock();
	}
  }
}

// ���֥������Ȥ�ʬ��
void MiscSimulator::classifyObjects(INT_32 time){
  // �����
  m_agent.clear();
  m_injury.clear();
  m_treatedInRefuge.clear();
  m_onRoadBlock.clear();
  for(int i = 0; i <= ATTB_MAX; i++){  
	m_indoor[i].clear(); // ����ˤ��륨���������
	for(int j = 0; j <= SEISMIC_MAX; j++){
	  m_inCivils[i][j].clear();  // ����ο���, ��¤�ͼ���ʬ�ष�������������
	  m_inCivilsBroken[i][j].clear();  
	  m_inCivilsFiery[i][j].clear();
	  for(int k = 0; k <= BROKEN_MAX; k++){
		m_victimBroken[i][j][k].clear();
	  }
	}
  }

  // ���֥������Ȥ�ʬ��
  //  logDebug("Classifying objects");
  Objects::const_iterator it = m_pool.objects().begin();
  for(int count = 0; it != m_pool.objects().end(); it++, count++){
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Next object: type=%d, id=%d",(*it)->type(),(*it)->id());
	//	logDebug(errorBuffer);
	//	       Civilian* mc = dynamic_cast<Civilian*>(*it);
	Humanoid* h = dynamic_cast<Humanoid*>(*it);
	if(h != 0) {
	  classifyAgents(time, h);
	}
	Building* b = dynamic_cast<Building*>(*it);
	if(b != 0) {
	  classifyBuilding(time, b);
	}
  }
}

     // ��ʪ��ʬ��
void MiscSimulator::classifyBuilding(INT_32 time, Building* b){
#if MISC_DEBUG
  // �ݲ���η�ʪ
  if(b->brokenness() > 0 && time == b->getTimeBrokennessUpdated())
	m_buildingBroken.push_back(b);
  // ǳ���Ƥ����ʪ
  if(b->fieryness() >= 1 && b->fieryness() <= 3)
	m_buildingFiery.push_back(b);
#endif 
}

     // ����������Ȥ�ʬ��
void MiscSimulator::classifyAgents(INT_32 time, Humanoid* h){
  //  Humanoid* mc = dynamic_cast<Humanoid*>(h);
  Car* car = dynamic_cast<Car*>(h);
  if(h != 0 && car == 0)
	classifyCivils(time, h);
}

void MiscSimulator::classifyCivils(INT_32 time, Humanoid* mc){
  // �͸��Υ������
  // ����͸��������
  // ��¤�Ȳ���͸��������
  // ����¤�Ȳ���͸��������
  // ǳ���Ƥ����ʪ����ˤ���͸��������

  m_agent.push_back(mc);
  //  snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Humanoid %d is in m_agent. HP=%d, damage=%d, buriedness=%d",mc->id(),mc->getHP(),mc->getDamage(),mc->getBuriedness());
  //  logDebug(errorBuffer);
	  
  // ϩ��ˤ���
  Road* r = dynamic_cast<Road*>(m_pool.getObject(mc->getPosition()));
  if(r != 0){
	// ƻϩ�����줿
	// by TM
	if(r->getBlock() > lastBlock[r->id()] && time == r->getBlockUpdate()){
	  //	if(r->getBlock() > r->previousBlock() && time == r->getTimeBlockUpdated()){
	  m_onRoadBlock.push_back(mc);
#ifdef MISC_DEBUG
	  printf("getTimeBlockUpdated(): %ld\n", r->getBlockUpdate());
	  fflush(NULL);
#endif
	}
  }

  Building* b = dynamic_cast<Building*>(m_pool.getObject(mc->getPosition()));
  // ����ˤ���
  if(b != 0) {
	// ��ʪ��ǳ���Ƥ���
	if(b->getFieryness() >= 1 && b->getFieryness() <= 3){
	  m_inBuildingFiery.push_back(mc);
	}

	// ���٤ȹ�¤�ͼ���Ĵ�٤�ʬ��
	GradeSeismic Sgrade = prmt.pData.getSeismic(b->getX(), b->getY());
	AttBuilding Abuild = (AttBuilding)b->getAttributes();
	m_indoor[Abuild].push_back(mc);
	m_inCivils[Abuild][Sgrade].push_back(mc);
	m_inCivils[ATTB_MAX][Sgrade].push_back(mc);
	m_inCivils[Abuild][SEISMIC_MAX].push_back(mc);
	m_inCivils[ATTB_MAX][SEISMIC_MAX].push_back(mc);

	// ��¤�ͼ��ȿ��٤��ݲ��٤�Ĵ�٤�ʬ��
	if(b->getBrokenness() > 0 && time == b->getBrokennessUpdate()){
	  // ��¤�ͼ��ȿ��٤��ݲ��٤ˤ��ʬ��
	  GradeBroken Bgrade = prmt.getBrokenGrade(b->getBrokenness());
	  m_victimBroken[Abuild][Sgrade][Bgrade].push_back(mc);
	  m_victimBroken[ATTB_MAX][Sgrade][Bgrade].push_back(mc);
	  m_victimBroken[Abuild][SEISMIC_MAX][Bgrade].push_back(mc);
	  m_victimBroken[ATTB_MAX][SEISMIC_MAX][Bgrade].push_back(mc);
	  m_victimBroken[Abuild][Sgrade][BROKEN_MAX].push_back(mc);
	  m_victimBroken[ATTB_MAX][Sgrade][BROKEN_MAX].push_back(mc);
	  m_victimBroken[Abuild][SEISMIC_MAX][BROKEN_MAX].push_back(mc);
	  m_victimBroken[ATTB_MAX][SEISMIC_MAX][BROKEN_MAX].push_back(mc);

	  // ��¤�ͼ��ȿ��٤ˤ��ʬ��
	  m_inCivilsBroken[Abuild][Sgrade].push_back(mc);
	  m_inCivilsBroken[ATTB_MAX][Sgrade].push_back(mc);
	  m_inCivilsBroken[Abuild][SEISMIC_MAX].push_back(mc);
	  m_inCivilsBroken[ATTB_MAX][SEISMIC_MAX].push_back(mc);

	}

	// TODO: ������٤ˤ��ʬ����ѹ�
	if(b->getFieryness() >= 1 && b->getFieryness() <= 3){
	  m_inCivilsFiery[Abuild][Sgrade].push_back(mc);
	  m_inCivilsFiery[ATTB_MAX][Sgrade].push_back(mc);
	  m_inCivilsFiery[Abuild][SEISMIC_MAX].push_back(mc);
	  m_inCivilsFiery[ATTB_MAX][SEISMIC_MAX].push_back(mc);
	}
  }
}

     //////////////////////////////////////////////////////////////
     // �������Ԥ����� (�Ȳ���¤, ���٤ˤ��)
void MiscSimulator::setBuried(INT_32 time){
  // ��¤�ͼ��ȿ��٤˱����������٤����ꤹ��
  for(int i = 0; i < ATTB_MAX; i++){
	for(int j = 0; j < SEISMIC_MAX; j++){
	  setBuried(time, AttBuilding(i), GradeSeismic(j));
	}
  }
}

void MiscSimulator::setBuried(INT_32 time, AttBuilding ABuild, GradeSeismic SGrade){
  // �Ȳ��ݲ�������ʪ����ˤ��륨���������
  MCivils mc = m_inCivilsBroken[ABuild][SGrade]; 
  // �������ˤʤ��Ψ
  double rate = prmt.rateBury[ABuild][SGrade];
  // �������Ԥδ�����
  INT_32 expectBuried = static_cast<INT_32>(mc.size() * rate);

#ifdef MISC_DEBUG
  printf("Agents in Broken Building: %ld rate: %f\n", (long)mc.size(), rate);
  printf("Expectation of Buried Agent: %ld\n", (long)expectBuried);
  fflush(NULL);
#endif
  // ������ʬ���������ˤ���
  int count = 0;


  for(; count < expectBuried; ){
	int order = m_dice.cast(0, mc.size() - 1);
	Humanoid* target = mc[order];
	if(time + 1 > target->getBuriednessUpdate()){
	  Building* b = dynamic_cast<Building*>(m_pool.getObject(target->getPosition()));
	  GradeBroken BGrade = prmt.getBrokenGrade(b->getBrokenness());
	  // buriedness��¤�ͼ�, ����, �ݲ����̤��Ѱդ���
	  INT_32 buriedness = prmt.buriedness[ABuild][BGrade][SGrade];
	  // damage��¤�ͼ�, ����, �ݲ����̤��Ѱդ���
	  INT_32 damageBury = cfg->damage_bury_unhurt();
	  // �����Ψ�ǥ��᡼����Ϳ���� (̵��, �ڽ�, �Ž�, �λ�)
	  long mag = cfg->magnitude_dice();
	  long pip = m_dice.cast(1, mag);
	  long pip1 = long(cfg->prob_bury_dying() * mag);
	  long pip2 = long((cfg->prob_bury_dying() + cfg->prob_bury_serious()) * mag);
	  long pip3 = long((cfg->prob_bury_dying() + cfg->prob_bury_serious() + cfg->prob_bury_slight()) * mag);
	  // �λ�
	  if(pip >= 1 && pip <= pip1){
		damageBury = cfg->damage_bury_dying();
	  }
	  // �Ž�
	  else if(pip >= pip1 && pip <= pip2){
		damageBury = cfg->damage_bury_serious();
	  }
	  // �ڽ�
	  else if(pip >= pip2 && pip <= pip3){
		damageBury = cfg->damage_bury_slight();
	  }
	  // ̵��
	  else {
		damageBury = cfg->damage_bury_unhurt();
	  }

	  target->setBuriedness(buriedness,time + 1);
	  (properties[target->id()])->setDamageBury(time + 1, damageBury);
	  count++;

#ifdef MISC_DEBUG
	  printf("id: %ld Buriedness: %ld DamageBury: %ld timeUpdated: %ld\n",
			 (long)target->id(), (long)target->getBuriedness(),
			 (long)(properties[target->id()])->damageBury(),
			 (long)target->getBuriednessUpdate());
	  fflush(NULL);
#endif
	}
  }
}

     //////////////////////////////////////////////////////////////
     // ���᡼�������� (�ƿ�̿�����װ��ˤ��)
void MiscSimulator::setDamages(INT_32 time){
  setDamageBroken(time);
  setDamageFiery(time);
  setDamageBlock(time);  

#ifdef MISC_TMP
  setDamageFieryRoad(time);
#endif
}

     //////////////////////////////////////////////////////////////
     // �Ȳ��ݲ��ˤ����᡼��������
void MiscSimulator::setDamageBroken(INT_32 time){
  for(int i = 0; i < ATTB_MAX; i++){
	for(int j = 0; j < SEISMIC_MAX; j++){
	  for(int k = (int)BROKEN_25; k < BROKEN_MAX; k++){
		MCivils mc = m_victimBroken[i][j][k];
		INT_32 upper = mc.size();
		if(upper > 0){
#ifdef MISC_DEBUG	  
		  printf("############ time                         = %ld\n", (long)time);
		  printf("############ getTimeDamageBrokenUpdated() = %ld\n", (long)properties[mc[mc.size()-1]->id()].getTimeDamageBrokenUpdated());
		  fflush(NULL);
#endif

		  double rateDeath= prmt.rateDeathBroken[i][k][j];
		  double rateSerious = prmt.rateSeriousBroken[i][k][j];
		  double rateSlight = prmt.rateSlightBroken[i][k][j];
		  INT_32 expDeath = static_cast<INT_32>(m_indoor[i].size() * rateDeath);
		  INT_32 expSerious = static_cast<INT_32>(m_indoor[i].size() * rateSerious);
		  INT_32 expSlight = static_cast<INT_32>(m_indoor[i].size() * rateSlight);
		  INT_32 upper = mc.size();
#ifdef MISC_DEBUG
		  printf("m_indoor[%d].size() = %d\n", i, m_indoor[i].size());
		  printf("rateDeath = %f\n", rateDeath);
		  printf("rateSerious = %f\n", rateSerious);
		  printf("rateSlight = %f\n", rateSlight);
		  printf("expDeath = %ld\n", (long)expDeath);
		  printf("expSerious = %ld\n", (long)expSerious);
		  printf("expSlight = %ld\n", (long)expSlight);
		  printf("\n");
		  fflush(NULL);
#endif
		  // ������ʬ������˴
		  int m;
		  for(m = 0; m< expDeath && m <= upper; ){
			INT_32 order = m_dice.cast(0, mc.size() -1);
			Humanoid* target = mc[order];
			if(time + 1 > (properties[target->id()])->getTimeDamageBrokenUpdated()){
			  INT_32 damageBroken = cfg->damage_broken_death();
			  // Civilian�ʳ��ξ����᡼������Ψ�򤫤���
			  damageBroken = magnificationDamageBroken(time, target, damageBroken);
			  double oldDmg = (properties[target->id()])->damageBroken();
			  (properties[target->id()])->setDamageBroken(time, (double)(oldDmg + damageBroken));
			  m++;
			}
		  }
		  // ������ʬ�����Ž�
		  for(m = 0; m < expSerious && m <= upper; ){
			INT_32 order = m_dice.cast(0, mc.size() -1);
			Humanoid* target = mc[order];
			if(time + 1 > (properties[target->id()])->getTimeDamageBrokenUpdated()){
			  INT_32 damageBroken = cfg->damage_broken_serious();
			  damageBroken = magnificationDamageBroken(time, target, damageBroken);
			  double oldDmg = (properties[target->id()])->damageBroken();
			  (properties[target->id()])->setDamageBroken(time, (double)(oldDmg + damageBroken));
			  m++;
			}
		  }
		  // ������ʬ�����ڽ�
		  for(m = 0; m < expSlight && m <= upper; ){
			INT_32 order = m_dice.cast(0, mc.size() -1);
			Humanoid* target = mc[order];
			if(time + 1 > (properties[target->id()])->getTimeDamageBrokenUpdated()){
			  INT_32 damageBroken = cfg->damage_broken_slight();
			  damageBroken = magnificationDamageBroken(time, target, damageBroken);
			  double oldDmg = (properties[target->id()])->damageBroken();
			  (properties[target->id()])->setDamageBroken(time, (double)(oldDmg + damageBroken));
			  m++;
			}
		  }
		}
	  }
	}
  }
}

     //////////////////////////////////////////////////////////////
     // Civilian �ʳ��Υ���������ȤΥ��᡼������Ψ�򤫤���
INT_32 MiscSimulator::magnificationDamageBroken(INT_32 time, Humanoid* h, INT_32 damage){

  if(dynamic_cast<AmbulanceTeam*>(h) != 0)
	damage = long(damage * cfg->magnification_damage_broken_ambulance());
  if(dynamic_cast<PoliceForce*>(h) != 0)
	damage = long(damage * cfg->magnification_damage_broken_police());
  if(dynamic_cast<FireBrigade*>(h) != 0)
	damage = long(damage * cfg->magnification_damage_broken_firebrigade());	  

  return damage;
}

INT_32 MiscSimulator::magnificationDamageFiery(INT_32 time, Humanoid* h, INT_32 damage){

  if(dynamic_cast<AmbulanceTeam*>(h) != 0)
	damage = long(damage * cfg->magnification_damage_fiery_ambulance());
  if(dynamic_cast<PoliceForce*>(h) != 0)
	damage = long(damage * cfg->magnification_damage_fiery_police());
  if(dynamic_cast<FireBrigade*>(h) != 0)
	damage = long(damage * cfg->magnification_damage_fiery_firebrigade());	  

  return damage;
}

INT_32 MiscSimulator::magnificationDamageBlock(INT_32 time, Humanoid* h, INT_32 damage){

  if(dynamic_cast<AmbulanceTeam*>(h) != 0)
	damage = long(damage * cfg->magnification_damage_block_ambulance());
  if(dynamic_cast<PoliceForce*>(h) != 0)
	damage = long(damage * cfg->magnification_damage_block_police());
  if(dynamic_cast<FireBrigade*>(h) != 0)
	damage = long(damage * cfg->magnification_damage_block_firebrigade());	  

  return damage;
}

     //////////////////////////////////////////////////////////////
     // �Ȳ��кҤˤ����᡼��������
     // void MiscSimulator::setDamageFiery(INT_32 time, Humanoid* mc){
void MiscSimulator::setDamageFiery(INT_32 time){
  // ��Ƥ��Ƥ����ʪ�ˤ��륨��������Ȥ˥��᡼����Ϳ����
  MCivils::const_iterator it = m_inBuildingFiery.begin();
  for(; it != m_inBuildingFiery.end(); it++){
	Humanoid* mc = dynamic_cast<Humanoid*>(*it);
	if(mc != 0 && mc->getHP() > 0){
	  INT_32 damageFiery = cfg->damage_fiery_serious();
	  INT_32 mag = cfg->magnitude_dice();
	  mysrand(mc, time);  // by TM
	  long pip = m_dice.cast(1, mag);
	  long pip1 = long(cfg->prob_fiery_dying() * mag);
	  long pip2 = long(cfg->prob_fiery_dying() * mag + cfg->prob_fiery_serious() * mag);
	  long pip3 = long(cfg->prob_fiery_dying() * mag + cfg->prob_fiery_serious() * mag + cfg->prob_fiery_slight() * mag);
#ifdef MISC_DEBUG
	  printf("pip  (m_dice.cast(1, mag))               = %ld\n", pip);
	  printf("pip1 (cfg->prob_fiery_dying() * mag)   = %ld\n", pip1);
	  printf("pip2 (cfg->prob_fiery_serious() * mag) = %ld\n", pip2);
	  printf("pip1 (cfg->prob_fiery_slight() * mag)  = %ld\n", pip3);
	  printf("\n");
	  fflush(NULL);
#endif
	  // �λ�
	  if(pip >= 1 && pip <= pip1){
		damageFiery = cfg->damage_fiery_dying();
	  }
	  // �Ž�
	  else if(pip > pip1 && pip <= pip2){
		damageFiery = cfg->damage_fiery_serious();
	  }
	  // �ڽ�
	  else if(pip > pip2 && pip <= pip3){
		damageFiery = cfg->damage_fiery_slight();
	  }
	  else{
		damageFiery = cfg->damage_fiery_unhurt();;
	  }

	  // Civilian�ʳ��ξ����᡼������Ψ�򤫤���
	  damageFiery = magnificationDamageFiery(time, mc, damageFiery);
	  double oldDmg = (properties[mc->id()])->damageFiery();
	  (properties[mc->id()])->setDamageFiery(time + 1 , (double)(oldDmg + damageFiery));
	}
  }
}

     //////////////////////////////////////////////////////////////
     // TODO: ϩ��Ǥμ��ϤβȲ��кҤˤ����᡼��������
void MiscSimulator::setDamageFieryRoad(INT_32 time){
}

     //////////////////////////////////////////////////////////////
     // ƻϩ�ĺɤˤ����᡼��������
void MiscSimulator::setDamageBlock(INT_32 time){
  if(m_onRoadBlock.size() == 0)
	return;

#ifdef MISC_DEBUG
  printf("*********** damage by block ***********\n");
  fflush(NULL);
#endif
  MCivils::const_iterator it = m_onRoadBlock.begin();
  for(; it != m_onRoadBlock.end(); it++){
	Humanoid* mc = dynamic_cast<Humanoid*>(*it);
	if(mc != 0){
	  INT_32 damageBlock = cfg->damage_block_serious();
	  INT_32 mag = cfg->magnitude_dice();
	  long pip = m_dice.cast(1, mag);
	  long pip1 = long(cfg->prob_block_dying() * mag);
	  long pip2 = long(cfg->prob_block_dying() * mag + cfg->prob_block_serious() * mag);
	  long pip3 = long(cfg->prob_block_dying() * mag + cfg->prob_block_serious() * mag + cfg->prob_block_slight() * mag);
#ifdef MISC_DEBUG
	  printf("pip  (m_dice.cast(1, mag))               = %ld\n", pip);
	  printf("pip1 (cfg->prob_block_dying() * mag)   = %ld\n", pip1);
	  printf("pip2 (cfg->prob_block_serious() * mag) = %ld\n", pip2);
	  printf("pip1 (cfg->prob_block_slight() * mag)  = %ld\n", pip3);
	  printf("\n");
	  fflush(NULL);
#endif

	  // �λ�
	  if(pip >= 1 && pip <= pip1){
		damageBlock = cfg->damage_block_dying();
	  }
	  // �Ž�
	  else if(pip > pip1 && pip <= pip2){
		damageBlock = cfg->damage_block_serious();
	  }
	  // �ڽ�
	  else if(pip > pip2 && pip <= pip3){
		damageBlock = cfg->damage_block_slight();
	  }
	  else{
		damageBlock = cfg->damage_block_unhurt();;

	  }

	  // Civilian�ʳ��ξ����᡼������Ψ�򤫤���
	  damageBlock = magnificationDamageBlock(time, mc, damageBlock);
	  double oldDmg = (properties[mc->id()])->damageBlock();
	  (properties[mc->id()])->setDamageBlock(time + 1 , (double)(oldDmg + damageBlock));
	}
  }
}

     //////////////////////////////////////////////////////////////
     // ���ߥ�졼�����ʹ� (���᡼���ʹ�)
void MiscSimulator::progressDamages(INT_32 time){
#ifdef MISC_DEBUG
  printf("m_agent.size() = %ld\n", (long)m_agent.size());
  fflush(NULL);
#endif

#ifdef MISC_STATUS
  printf("agents damaged or buried are following... (hp > 0 only)\n");
  printf("  id  |  hp  |damage| Bury |Broken|Fiery |Block |buriedness\n");
  fflush(NULL);
#endif
  MCivils::const_iterator it = m_agent.begin();
  for(; it != m_agent.end(); it++){
	Humanoid* mc = dynamic_cast<Humanoid*>(*it);
	Car* car = dynamic_cast<Car*>(*it);
	if(mc != 0 && car == 0){
	  progressDamages(time, mc);
	  mergeDamages(time, mc);
	  updateHp(time, mc);
	  treatDamage(time, mc);
#ifdef MISC_STATUS
	  if((mc->getDamage() > 0 || mc->getBuriedness() > 0) && mc->getHP() != 0){
		m_injury.push_back(mc);
		printf(" %5ld| %5ld| %5ld| %5ld| %5ld| %5ld| %5ld| %5ld\n", (long)mc->id(), (long)mc->getHP(), (long)mc->getDamage(), (long)(properties[mc->id()])->damageBury(), (long)(properties[mc->id()])->damageBroken(), (long)(properties[mc->id()])->damageFiery(), (long)(properties[mc->id()])->damageBlock(), (long)mc->getBuriedness());
		//			 printf("id %ld | hp %5ld | damage %5ld | Bury %5ld | Broken %5ld | Fiery %5ld | Block %5ld | buriedness %5ld\n", (long)mc->id(), (long)mc->hp(), (long)mc->damage(), (long)mc->property()->damageBury(), (long)mc->property()->damageBroken(), (long)mc->property()->damageFiery(), (long)mc->property()->damageBlock(), (long)mc->buriedness());
		fflush(NULL);
	  }
#endif
	}
  }
#ifdef MISC_DEBUG
  printf("m_death.size()            = %d\n", m_death.size());
  printf("m_injury.size()          = %d\n", m_injury.size());
  printf("m_inBuildingFiery.size() = %d\n", m_inBuildingFiery.size());
  printf("m_onRoadBlock.size()     = %d\n", m_onRoadBlock.size());
  printf("m_treatedInRefuge.size() = %d\n", m_treatedInRefuge.size());
  printf("\n");
  fflush(NULL);
#endif	  

}
     //////////////////////////////////////////////////////////////
     // ���᡼���οʹ�
void MiscSimulator::progressDamages(INT_32 time, Humanoid* mc){
  if(mc->getHP() == 0 || mc->getDamage() == 0)
	return;

  // DamageBury�οʹ�
  progressDamageBury(time, mc);
  // DamageBury�οʹ�
  progressDamageBroken(time, mc);
  // DamageFiery�οʹ�
  progressDamageFiery(time, mc);
  // DamageBlock�οʹ�
  progressDamageBlock(time, mc);
}

     //////////////////////////////////////////////////////////////
     // ���᡼���οʹ� DamageBury
void MiscSimulator::progressDamageBury(INT_32 time, Humanoid* mc){
  if(mc->getHP() == 0 || (properties[mc->id()])->damageBury() == 0)
	return;

  double k = cfg->parameter_damage_bury_k();
  double l = cfg->parameter_damage_bury_l();

  // damage �ι���
  // TODO: ���᡼���ʹԤδؿ��η���
  //       ��餮���� U(P) �η���
  long mag = cfg->magnitude_dice();
  mysrand(mc, time);  // by TM
  long cast = m_dice.cast(1, mag);
  double mutation = 0.0;
  if(cast % 100 < 100 * cfg->probability_mutation_damage_bury()){
	mutation = (double)cast / mag / 10;
  }
  ///////////////  ���᡼���ʹ�  /////////////////////
  double dmg = (properties[mc->id()])->damageBury();
  double newDamage = dmg + k * dmg * dmg + l + mutation;

  ////////////////////////////////////////////////////
  if(newDamage > 10000)
	newDamage = 10000.0;
  (properties[mc->id()])->setDamageBury(time+1, newDamage);
}

     //////////////////////////////////////////////////////////////
     // ���᡼���οʹ� DamageBroken
void MiscSimulator::progressDamageBroken(INT_32 time, Humanoid* mc){
  if(mc->getHP() == 0 || (properties[mc->id()])->damageBroken() == 0)
	return;

  double k = cfg->parameter_damage_broken_k();
  double l = cfg->parameter_damage_broken_l();

  // damage �ι���
  // TODO: ���᡼���ʹԤδؿ��η���
  //       ��餮���� U(P) �η���
  long mag = cfg->magnitude_dice();
  mysrand(mc, time);  // by TM
  long cast = m_dice.cast(1, mag);
  double mutation = 0.0;
  if(cast % 100 < 100 * cfg->probability_mutation_damage_broken()){
	mutation = (double)cast / mag / 10;
  }
  ///////////////  ���᡼���ʹ�  /////////////////////
  double dmg = (properties[mc->id()])->damageBroken();
  double newDamage = dmg + k * dmg * dmg + l + mutation;

  ////////////////////////////////////////////////////
  if(newDamage > 10000)
	newDamage = 10000.0;
  (properties[mc->id()])->setDamageBroken(time+1, newDamage);
}

     //////////////////////////////////////////////////////////////
     // ���᡼���οʹ� DamageFiery
void MiscSimulator::progressDamageFiery(INT_32 time, Humanoid* mc){
  if(mc->getHP() == 0 || (properties[mc->id()])->damageFiery() == 0)
	return;
	  
  double k = cfg->parameter_damage_fiery_k();
  double l = cfg->parameter_damage_fiery_l();

  // damage �ι���
  // TODO: ���᡼���ʹԤδؿ��η���
  //       ��餮���� U(P) �η���
  long mag = cfg->magnitude_dice();
  mysrand(mc, time);  // by TM
  long cast = m_dice.cast(1, mag);
  double mutation = 0.0;
  if(cast % 100 < 100 * cfg->probability_mutation_damage_fiery()){
	mutation = (double)cast / mag / 10;
  }
  ///////////////  ���᡼���ʹ�  /////////////////////
  double dmg = (properties[mc->id()])->damageFiery();
  double newDamage = dmg + k * dmg * dmg + l + mutation;

  ////////////////////////////////////////////////////
  if(newDamage > 10000)
	newDamage = 10000.0;
  (properties[mc->id()])->setDamageFiery(time+1, newDamage);
}

void MiscSimulator::progressDamageBlock(INT_32 time, Humanoid* mc){
  if(mc->getHP() == 0 || (properties[mc->id()])->damageBlock() == 0)
	return;
	  
  double k = cfg->parameter_damage_block_k();
  double l = cfg->parameter_damage_block_l();

  // damage �ι���
  // TODO: ���᡼���ʹԤδؿ��η���
  //       ��餮���� U(P) �η���
  long mag = cfg->magnitude_dice();
  mysrand(mc, time);  // by TM
  long cast = m_dice.cast(1, mag);
  double mutation = 0.0;
  if(cast % 100 < 100 * cfg->probability_mutation_damage_block()){
	mutation = (double)cast / mag / 10;
  }
  ///////////////  ���᡼���ʹ�  /////////////////////
  double dmg = (properties[mc->id()])->damageBlock();
  double newDamage = dmg + k * dmg * dmg + l + mutation;

  ////////////////////////////////////////////////////
  if(newDamage > 10000)
	newDamage = 10000.0;
  (properties[mc->id()])->setDamageBlock(time+1, newDamage);
}

     //////////////////////////////////////////////////////////////
     // ���᡼���Υޡ���
void MiscSimulator::mergeDamages(INT_32 time, Humanoid* mc){
  double dmg = 0.0;
  dmg += (properties[mc->id()])->damageBury();
  dmg += (properties[mc->id()])->damageBroken();
  dmg += (properties[mc->id()])->damageFiery();
  dmg += (properties[mc->id()])->damageBlock();
  (properties[mc->id()])->setDamage(time+1, dmg);
  mc->setDamage((INT_32)floor(dmg),time+1);
}

     //////////////////////////////////////////////////////////////
     // Hp �ι���
void MiscSimulator::updateHp(INT_32 time, Humanoid* mc){
  if(mc->getHP() > 0){
	INT_32 newDamage = mc->getDamage();
	INT_32 newHp = mc->getHP() - newDamage;
	if(newHp <= 0){
	  newHp = 0;
	  m_death.push_back(mc);
	}

	mc->setHP(newHp,time+1);
  }
}

     //////////////////////////////////////////////////////////////
     // ���᡼���μ���
     //       Refuge �����ä��� damage �� 0 �ˤ���
void MiscSimulator::treatDamage(INT_32 time, Humanoid* mc){
  if(mc->getHP() > 0 && mc->getDamage() > 0){
	if(dynamic_cast<Refuge*>(m_pool.getObject(mc->getPosition())) != 0){
	  (properties[mc->id()])->setDamageBroken(time+1, 0);
	  (properties[mc->id()])->setDamageBury(time+1, 0);
	  (properties[mc->id()])->setDamageFiery(time+1, 0);
	  (properties[mc->id()])->setDamageBlock(time+1, 0);
	  mc->setDamage(0,time+1);
	  if(dynamic_cast<Civilian*>(mc) != 0)
		m_treatedInRefuge.push_back(mc);
	}
  }
}

}
