/*
 * Copyright (c) 2005, The Black Sheep, Department of Computer Science, The University of Auckland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of The Black Sheep, The Department of Computer Science or The University of Auckland nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 Contributors and list of changes:

 Cameron Skinner
   Converted original Robocup Rescue software into librescue
*/

#include "objectpool.h"
#include "error.h"
#include <math.h>
#include <algorithm>

namespace Librescue {
  ObjectPool::ObjectPool() : data(), allData() {
  }

  ObjectPool::~ObjectPool() {
	for (Objects::iterator it = allData.begin();it!=allData.end();++it) {
	  RescueObject* next = *it;
	  delete next;
	}
  }

  void ObjectPool::addObject(RescueObject* o) {
	data[o->id()] = o;
	allData.push_back(o);
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Adding object of type %d: %p, now have %d/%d objects",o->type(),o,data.size(),allData.size());
	//	logDebug(errorBuffer);
  }

  void ObjectPool::removeObject(RescueObject* o) {
	data[o->id()] = NULL;
	remove(allData.begin(),allData.end(),o);
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Removing object %p of type %d",o,o->type());
	//	logDebug(errorBuffer);
  }

  RescueObject* ObjectPool::getObject(Id id) {
	return data[id];
  }

  const RescueObject* ObjectPool::getObject(Id id) const {
	ObjectPool* nonconstThis = const_cast<ObjectPool*>(this);
	return nonconstThis->getObject(id);
  }

  Objects ObjectPool::getNeighbours(Id id) {
	const RescueObject* object = getObject(id);
	if (object) return getNeighbours(object);
	else {
	  Objects o;
	  return o;
	}
  }

  Objects ObjectPool::getNeighbours(const RescueObject* object) {
	Objects result;
	const Building* b = dynamic_cast<const Building*>(object);
	if (b) {
	  INT_32* entrances = b->getEntrances();
	  for (int i=0;entrances[i]!=0;++i) {
		RescueObject* o = getObject(entrances[i]);
		if (o) result.push_back(o);
	  }
	}
	const Vertex* v = dynamic_cast<const Vertex*>(object);
	if (v) {
	  INT_32* edges = v->getEdges();
	  for (int i=0;edges[i]!=0;++i) {
		RescueObject* o = getObject(edges[i]);
		if (o) result.push_back(o);
	  }
	}
	const Edge* e = dynamic_cast<const Edge*>(object);
	if (e) {
	  RescueObject* head = getObject(e->getHead());
	  RescueObject* tail = getObject(e->getTail());
	  if (head) result.push_back(head);
	  if (tail) result.push_back(tail);
	}
	return result;
  }

  const Objects& ObjectPool::objects() const {
	return allData;
  }

  int ObjectPool::getObjectsInRange(int x, int y, int maxRange, std::list<RescueObject*>& result) const {
	int count = 0;
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Finding objects within %d of %d,%d",maxRange,x,y);
	//	logDebug(errorBuffer);	
	for (IdToRescueObject::const_iterator it = data.begin();it!=data.end();++it) {
	  int x1,y1;
	  RescueObject* o = it->second;
	  if (locate(o,&x1,&y1)) {
		//		snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Next object: Type %d at %d,%d. Range = %d",o->type(),x1,y1,range(x,y,x1,y1));
		//		logDebug(errorBuffer);		  
		if (range(x,y,x1,y1) <= maxRange) {
		  //		  logDebug("In range");
		  result.push_back(o);
		  ++count;
		}
	  }
	  else {
		//		snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Couldn't locate object of type %d",o->type());
		//		logDebug(errorBuffer);
	  }
	}
	return count;
  }

  int ObjectPool::range(int x1, int y1, int x2, int y2) const {
	double dx = x2-x1;
	double dy = y2-y1;
	return (int)sqrt(dx*dx + dy*dy);
  }

  int ObjectPool::range(const RescueObject* o1, const RescueObject* o2) const {
	int x1, x2, y1, y2;
	if (!locate(o1,&x1,&y1)) return -1;
	if (!locate(o2,&x2,&y2)) return -1;
	return range(x1,y1,x2,y2);
  }

  int ObjectPool::range(Id o1, Id o2) const {
	return range(getObject(o1),getObject(o2));
  }

  int ObjectPool::range(const RescueObject* o1, Id o2) const {
	return range(o1,getObject(o2));
  }

  int ObjectPool::range(Id o1, const RescueObject* o2) const {
	return range(getObject(o1),o2);
  }

  bool ObjectPool::locate(const RescueObject* o, int* x, int* y) const {
	const MotionlessObject* position = dynamic_cast<const MotionlessObject*>(o);
	if (position) {
	  // Just get the x and y values out of the motionless object
	  *x = position->getX();
	  *y = position->getY();
	  return true;
	}
	const Edge* edge = dynamic_cast<const Edge*>(o);
	if (edge) {
	  const RescueObject* head = getObject(edge->getHead());
	  const RescueObject* tail = getObject(edge->getTail());
	  int headX, headY, tailX, tailY;
	  if (locate(head,&headX,&headY) && locate(tail,&tailX,&tailY)) {
		*x = (headX+tailX)/2;
		*y = (headY+tailY)/2;
		return true;
	  }
	  return false;
	}
	const MovingObject* moving = dynamic_cast<const MovingObject*>(o);
	if (moving) {
	  // Find it's position
	  const RescueObject* positionObject = getObject(moving->getPosition());
	  if (positionObject) {
		// Check whether we are on an Edge (road or river)
		const Edge* edge = dynamic_cast<const Edge*>(positionObject);
		if (edge) {
		  // First find the edge's head and tail locations
		  const Node* head = dynamic_cast<const Node*>(getObject(edge->getHead()));
		  const Node* tail = dynamic_cast<const Node*>(getObject(edge->getTail()));
		  int headX, headY, tailX, tailY;
		  if (!locate(head,&headX,&headY)) return false;
		  if (!locate(tail,&tailX,&tailY)) return false;
		  double positionExtra = moving->getPositionExtra(); // Store positionExtra as a double so we can calculate the proportion correctly (look down two lines).
		  // Now work out what our real position is
		  double proportion = positionExtra/edge->getLength();
		  int dx = tailX-headX;
		  int dy = tailY-headY;
		  *x = headX + (int)(proportion*dx);
		  *y = headY + (int)(proportion*dy);
		  return true;
		}
		else {
		  // Just find the positionObjects location
		  return locate(positionObject,x,y);
		}
	  }
	}
	return false;
  }

  void ObjectPool::write(Output& out) const {
	for (Objects::const_iterator it = allData.begin();it!=allData.end();++it) {
	  const RescueObject* next = *it;
	  next->write(out);
	}
	out.writeInt32(TYPE_NULL);
  }

  void ObjectPool::write(Output& out, int time) const {
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Sending update at time %d",time);
	//	logDebug(errorBuffer);
	for (Objects::const_iterator it = allData.begin();it!=allData.end();++it) {
	  RescueObject* next = *it;
	  next->write(out,time);
	}
	out.writeInt32(TYPE_NULL);
  }

  bool ObjectPool::update(Input& buffer, int time) {
	TypeId type;
	//	logDebug("Updating objectpool");
	do {
	  type = (TypeId)buffer.readInt32();
	  //	  snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Type: 0x%x",type);
	  //	  logDebug(errorBuffer);
	  if (type!=TYPE_NULL) {
		Id id = (Id)buffer.peekInt32();
		//		snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Id: %d",id);
		//		logDebug(errorBuffer);
		// Look up the object
		RescueObject* object = getObject(id);
		bool add = false;
		if (!object) {
		  //		  logDebug("New object");
		  object = newRescueObject(type);
		  add = true;
		  if (!object) {
			LOG_DEBUG("Couldn't read update message!");
			return false;
		  }
		}
		object->read(buffer,time);
		if (add) addObject(object);
	  }
	} while (type!=TYPE_NULL);
	return true;
  }
}
