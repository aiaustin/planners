/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

// main.cxx
//
/////////////////////////////////////////////////////////////////////////////

//#include "common.hxx"

#include "RescueSystem.hxx"

/////////////////////////////////////////////////////////////////////////
// main
namespace Rescue
{
	
	int kernel(int argc, char const* const* argv)
	{
		try {
			RescueSystem system;
			system.main(argc, argv);
			return 0;
		} catch(std::exception& e) {
			fprintf(stderr, "exception: %s\n", (const char*)e.what());
		} catch(...) {
			fprintf(stderr, "Unknown Exception\n");
		}
		return 1;
	}
	
} // namespace Rescue

int main(int argc, char** argv)
{
	//try {
		return Rescue::kernel(argc, argv);
	/*} catch(...) {
		fprintf(stderr, "error...\n");
		return 1;
	}*/
}

