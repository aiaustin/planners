#!/bin/bash

# The directory to store logs.  The default is the working directory.
LOGDIR=""


function canonicalname {
    program="$0"
    
    while [ -h "$program" ] ; do
        cd `dirname "$program"`
        program=`basename "$program"`
        program=`ls -l "$program"`
        program=${program##*-> }
    done
    
    cd `dirname "$program"`
    echo $PWD/`basename $program`
}

DIR=`dirname \`canonicalname "$0"\``
MAP="$1"
TEAM="$2"

if [ -z "$MAP" ] ; then
  MAP=Kobe
fi
if [ ! -d "$MAP" ] ; then
  MAP="$DIR/../maps/$MAP"
fi

LOG="rescue.log"
if [ ! -z $TEAM ] ; then
  LOG="`date +%m%d-%H%M%S`-$TEAM-`basename "$MAP"`.log"
fi
if [ ! -z $LOGDIR ] ; then
  LOG="$LOGDIR/$LOG"
fi

OPTIONS="-logname $LOG -shindopolydata $MAP/shindopolydata.dat -galpolydata $MAP/galpolydata.dat"

xterm -e $DIR/0gis.sh $OPTIONS -mapdir $MAP/ -gisini $MAP/gisini1.txt&
sleep 5
#sleep 2
xterm -e $DIR/1kernel.sh $OPTIONS &
sleep 10
xterm -e $DIR/2kuwataviewer.sh -l 300 &
#if [ ! -z $TEAM ] ; then
#    xterm -e $DIR/2viewer.sh -T "$TEAM" &
#else
#    xterm -e $DIR/2viewer.sh &
#fi
xterm -e $DIR/3miscsimulator.sh $OPTIONS &
xterm -e $DIR/4morimototrafficsimulator.sh &
xterm -e $DIR/5firesimulator.sh $OPTIONS &
xterm -e $DIR/6blockadessimulator.sh $OPTIONS &
xterm -e $DIR/7collapsesimulator.sh $OPTIONS &
sleep 5

# xterm -e $DIR/8civilian.sh &

sleep 10

echo "start agents: experiment1-coalition-A.sh OR experiment1-coalition-B.sh "