package viewer;

import java.io.*;
import java.net.*;
import java.util.*;
import viewer.object.*;

public abstract class IO implements Runnable, Constants {
	protected abstract byte[] receive();
	protected abstract void send(int header, byte[] body);

	protected final ArrayList updateDataList   = new ArrayList();
	protected final ArrayList commandsDataList = new ArrayList();

	public IO() {
		commandsDataList.add(null);  // Dummy, because KS_COMMANDS is not sent by kernel at time 0
	}

	public void connect() {
		System.out.print("connecting ... ");
		send(SK_CONNECT, new byte[] {0, 0, 0, 0});  // version must be 0
		byte[] data = receive();
		System.out.println("done");

		System.out.print("initializing ... ");
		storeData(updateDataList, data, 0);
		WORLD.playback(0);
		WORLD.setWorldRange();
		System.out.println("done");

		send(SK_ACKNOWLEDGE, new byte[0]);
		System.out.println("start\n");
	}

	public void run() {
		int lastTime = WORLD.time();
		while (true) {
			byte[] data = receive();
			if (data == null)
				return;
			DataInputStream dis = new DataInputStream(new ByteArrayInputStream(data));
			try {
				int header = dis.readInt();
				System.out.println(header);
				System.out.println("Length: "+dis.readInt());
				int time = dis.readInt();
				System.out.println(time);
				switch (header) {
				case KS_COMMANDS:
					storeData(commandsDataList, data, lastTime + 1);

					//DEBUG
					/* System.out.println("");
					   System.out.println("******************************");
					   System.out.println("Time = " + time);
					   while(dis.available() >= 4)
					   {
					   System.out.print(dis.readInt());
					   System.out.print(", ");
					   }*/
					//END DEBUG

					break;
				case KS_UPDATE:
					Util.myassert(time == lastTime + 1, "received a Long UDP packet having wrong simulation time");
					lastTime = time;
					storeData(updateDataList, data, time);
					// VIEWER.timeSlider.setMaximum(time);
					break;
				default: Util.myassert(false);
				}

			} catch (IOException e) { Util.myassert(false, e); }
		}
	}

	private void storeData(List list, byte[] data, int time) {
		synchronized (list) {
			if (list.size() > time)
				return;
			Util.myassert(list.size() == time, "Some datas was skipped or lost.");
			list.add(data);
		}
	}

	public DataInputStream updateData(int time)   { return getData(time, updateDataList,  (time == 0) ? 2 : 3); }
	public DataInputStream commandsData(int time) { return getData(time, commandsDataList, 3); }
	private DataInputStream getData(int time, List list, int skip) {
		byte[] data;
		synchronized (list) { data = (byte[]) list.get(time); }
		DataInputStream dis = new DataInputStream(new ByteArrayInputStream(data));
		try { dis.skip(4 * skip); } catch (IOException e) { Util.myassert(false); }
		return dis;
	}

	public boolean hasUpdateData(int time)   { synchronized (updateDataList)   { return time < updateDataList.size();   } }
	public boolean hasCommandsData(int time) { synchronized (commandsDataList) { return time < commandsDataList.size(); } }
}
