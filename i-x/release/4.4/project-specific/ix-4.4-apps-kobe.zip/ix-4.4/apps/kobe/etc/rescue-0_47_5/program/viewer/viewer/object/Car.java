package viewer.object;

public class Car extends Humanoid {
  public Car(int id) { super(id); }
  public int type() { return TYPE_CAR; }
}
