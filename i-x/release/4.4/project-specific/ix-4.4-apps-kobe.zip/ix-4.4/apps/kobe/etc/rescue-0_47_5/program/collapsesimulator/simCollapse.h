/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#ifndef SIMCOLLAPSE_H__
#define SIMCOLLAPSE_H__

#include <vector>
#include "objects.h"

using namespace Librescue;

#define COLLAPSE 100
#define MODERATE 50
#define SLIGHT 25
#define NODAMAGE 0

enum bAttributes{
  WOOD,
  S,
  RC
};

enum accellerations{
  AC100,
  AC200,
  AC300,
  AC400,
  AC500,
  AC600,
  AC700,
  AC800,
  AC900
};

typedef std::vector<Building*> Buildings;
  
////////////////
//polygon stuff
struct coordinates{
  long int polyx;
  long int polyy;
};
enum judgePolygon{
  OUT_SIDE,
  IN_SIDE
};

//prototypes
enum judgePolygon polygonIn(long int ptTx, long int ptTy, coordinates* polyPtr, long int polySize);
coordinates* getPoly(long int *plyNum, long int *pntNum, coordinates *polyPtr);
//void getPoly(long int *plyNum, long int *pntNum, coordinates *polyPtr);
int collapse_check(Building* bPtr, int accel);
int getAccel(long int tx, long int ty, long int polyNum, coordinates* polyPtr);

#endif // FUNCITON_H__
