#! /bin/sh
DIR=`dirname $0`
$DIR/../program/blockadessimulator/blockadessimulator 1000 -file $DIR/config.txt $*
