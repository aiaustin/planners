#! /bin/sh
DIR=`dirname $0`
DIR2=$DIR/../program/civilian/Civilian
$DIR2/civilian -file $DIR/config.txt -rulefile $DIR2/test2.txt $*
