http://ne.cs.uec.ac.jp/~morimoto/rescue/viewer/index.html
