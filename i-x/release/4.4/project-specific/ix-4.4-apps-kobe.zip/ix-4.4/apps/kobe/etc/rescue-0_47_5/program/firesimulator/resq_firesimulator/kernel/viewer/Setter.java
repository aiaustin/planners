package kernel.viewer;

/**
 * @author tn
 *
 */
public interface Setter {
	
	public void setControll();

}
