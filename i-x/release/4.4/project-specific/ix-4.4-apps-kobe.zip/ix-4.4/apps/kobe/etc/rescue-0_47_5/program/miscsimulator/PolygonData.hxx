#if !defined POLYGON_DATA_HXX_INCLUDED
#define POLYGON_DATA_HXX_INCLUDED

#include "common.h"
#include "MISC_ENUM.hxx"
#include <string>

namespace Rescue{
/////////////////////////////////////////////////////////////////////////////////////////

     enum judgePolygon{
	  OUT_SIDE,
	  IN_SIDE
     };

     class Coordinates{
     public:
	  long int polyx; //����ʬ�ۿޤΥݥꥴ��ι�������x��ɸ
	  long int polyy; //����ʬ�ۿޤΥݥꥴ��ι�������y��ɸ
     public:
	  Coordinates(){
	       polyx = 0;
	       polyy = 0;
	  }
	  ~Coordinates(){
	  }

     };

     class PolygonData{
     public:
     private:	  
	  Coordinates* polyPtr;
	  long int pntNum;
	  long int plyNum;

     public:
	  PolygonData(){
	  }
	  PolygonData(const std::string datafile){
	       readPolygonData(datafile);
	  }
	  ~PolygonData(){
	  }
	  bool readPolygonData(const std::string datafile);
	  enum judgePolygon polygonIn(long int ptTx, long int ptTy, long int polySize);
	  GradeSeismic getSeismic(long int tx, long int ty);

     private:

#ifdef MISC_DEBUG_1
	  PolygonData& operator= (const PolygonData& rhs);
	  bool operator== (const PolygonData& rhs) const;
#endif
     };

#define MIN(x,y)	( ( (x) < (y) ) ? (x) : (y) )

/////////////////////////////////////////////////////////////////////////////////////////
} // namespace Rescue

#endif // POLYGON_DATA_HXX_INCLUDED
