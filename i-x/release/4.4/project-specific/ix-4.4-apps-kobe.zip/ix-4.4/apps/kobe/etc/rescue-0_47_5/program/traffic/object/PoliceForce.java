package traffic.object;

public class PoliceForce extends Humanoid {
  public PoliceForce(int id) { super(id); }
  public int type() { return TYPE_POLICE_FORCE; }
}
