
#if !defined(MISC_HXX_INCLUDED) //{
#define MISC_HXX_INCLUDED

#include "misc_property.h"
#include "misc_parameter.h"

namespace Rescue{
//////////////////////////////////////////////////////////////////////////////////////

     ////////////////////////////////////////////////////////////////////////////////
     // class Dice // {
     // �������
     class Dice {
     private:
	  S32 m_seed;

     public:
	  // ���󥹥ȥ饯��
	  Dice::Dice() {
	       setSeed(time(NULL));
	       initRandom();
	       outputSeed();
//	       seed = time(NULL);
//	       srand(m_seed);
	  }
	  // ���󥹥ȥ饯��
	  Dice::Dice(S32 s) {
	       if(s < 0)
		    Dice();
	       else{
		    setSeed(s);
		    initRandom();
		    outputSeed();
	       }
//	       m_seed = s;
//	       srand(m_seed);
	  }

	  S32 Dice::seed() {
	       return m_seed;
	  }
	  void Dice::setSeed(S32 s) {
	       m_seed = s;
	  }
	  void Dice::initRandom() {
	       srand(m_seed);
	  }
	  // begin ���� end �ޤǤ��ϰϤ����������
	  S32 Dice::cast(S32 begin, S32 end) {
	       S32 range = end - begin + 1;
//	       S32 pip = begin + rand() / ( RAND_MAX / range + 1);
	       S32 pip = begin + (int)((double)rand() / ((double)RAND_MAX + 1) * range);
	       return (pip);
	  }
	  void Dice::outputSeed(){
	       printf("seed for random number is %ld\n", (long)seed());
	       fflush(NULL);
	  }
     };
     // } class Dice
     ////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////
} // namespace Rescue

#endif // } !defined(MISC_HXX_INCLUDED)
