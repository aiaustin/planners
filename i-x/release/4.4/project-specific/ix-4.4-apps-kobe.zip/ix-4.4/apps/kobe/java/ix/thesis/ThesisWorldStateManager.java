/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Aug 25 04:43:34 2004 by Jeff Dalton
 * Copyright: (c) 2001 - 2004, AIAI, University of Edinburgh
 */

package ix.thesis;

import java.util.*;

import ix.icore.*;
import ix.icore.process.*;
import ix.icore.domain.*;
import ix.util.*;
import ix.util.lisp.*;
import ix.util.match.*;
// import ix.util.context.*;

// /\/: The division of labour between this and the model manager
// still isn't right.

/**
 * Stores the current world state and certain things about it.
 */
public class ThesisWorldStateManager {

    public static final Symbol
	S_WORLD_STATE = Symbol.intern("world-state"),
	S_CONDITION   = Symbol.intern("condition"),
	S_EFFECT      = Symbol.intern("effect");

    protected ThesisModelManager modelManager;

    // /\/: Not yet context-dependent for I-P2 but can be in subclasses
    // by redefining the factory methods that create the maps.

    protected MultiMap nodeToConditions = makeNodeConstraintsMap();
    protected MultiMap nodeToEffects = makeNodeConstraintsMap();
    protected Map worldStateMap = makeWorldStateMap(); // p -> v

    public ThesisWorldStateManager(ThesisModelManager modelManager) {
	this.modelManager = modelManager;
    }

    public void reset() {
	nodeToConditions.clear();
	nodeToEffects.clear();
	worldStateMap.clear();
    }

    protected Map makeWorldStateMap() {
	// return new HashMap();
	return new StableHashMap();
    }

    protected MultiMap makeNodeConstraintsMap() {
	return new MultiHashMap();
    }

    public List getNodeConditions(PNode node) {
	return (List)nodeToConditions.get(node);
    }

    public List getNodeEffects(PNode node) {
	return (List)nodeToEffects.get(node);
    }

    public Map getWorldStateMap() {	// for PlanMaker /\/
	return worldStateMap;
    }

    public Object getPatternValue(LList pattern) {
	return worldStateMap.get(pattern);
    }

    public void addConstraint(PNode node, Constraint c) {
	Symbol type = c.getType();
	Symbol relation = c.getRelation();
	Debug.expect(type == S_WORLD_STATE);
	PatternAssignment pv = (PatternAssignment)c.getParameter(0);
	if (relation == S_CONDITION) {
	    nodeToConditions.addValue(node, pv);
	}
	else if (relation == S_EFFECT) {
	    nodeToEffects.addValue(node, pv);
	}
	else {
	    throw new ConsistencyException
		("Unexpected constraint " + c);
	}
    }

    public Map handleEffects(PNode node, List effects) {
	// N.B. All Variables in the effects must be bound.
	// /\/: Takes a list of PatternAssignments, NOT a list of Constraints.
	Map delta = new StableHashMap();
	for (Iterator i = effects.iterator(); i.hasNext();) {
	    PatternAssignment pv = (PatternAssignment)i.next();
	    Debug.noteln("Effect", pv);
	    LList pattern = pv.getPattern();
	    Object value = pv.getValue();
	    Debug.expect(Variable.isFullyBound(pattern));
	    Debug.expect(Variable.isFullyBound(value));
	    LList p = (LList)Variable.removeVars(pattern);
	    Object v = Variable.removeVars(value);
	    delta.put(p, v);
	    assign(p, v, node);
	}
	return delta;
    }

    public Map handleEffects(List effects) {
	return handleEffects(null, effects);
    }

    public void deleteEffect(PatternAssignment pv) {
	Set vars = Variable.varsAnywhereIn(pv);
	Set unbound = Variable.unboundVarsIn(vars);
	if (!unbound.isEmpty())
	    throw new IllegalArgumentException
		("Can't delete effect that is not fully bound: " + pv);
	Object currentValue = getPatternValue(pv.getPattern());
	if (!pv.getValue().equals(currentValue))
	    throw new IllegalArgumentException
		("Can't delete effect " + pv + " when the current " +
		 "value of the pattern, " + currentValue + ", is " +
		 "different.");
	worldStateMap.remove(pv.getPattern());
	Debug.expect(getPatternValue(pv.getPattern()) == null);
    }

    protected void assign(LList p, Object v, PNode at) {
	worldStateMap.put(p, v);
    }

}
