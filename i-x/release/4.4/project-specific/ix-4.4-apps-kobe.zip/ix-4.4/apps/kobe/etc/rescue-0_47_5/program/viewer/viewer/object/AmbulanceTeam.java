package viewer.object;

public class AmbulanceTeam extends Humanoid {
  public AmbulanceTeam(int id) { super(id); }
  public int type() { return TYPE_AMBULANCE_TEAM; }
}
