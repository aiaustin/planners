/*
 Author: Cameron Skinner
 May 2005: Modified IO.java to implement TCP communication instead of TCP.
*/

package traffic;

import java.io.*;
import java.net.*;
import java.util.*;
import traffic.object.*;

public class TCPIO implements Constants {
	private Socket socket;
	private DataInputStream in;
	private DataOutputStream out;

	public TCPIO(InetAddress kernelAddress, int kernelPort) {
		try{
			socket  = new Socket(kernelAddress, kernelPort);
			in = new DataInputStream(socket.getInputStream());
			out = new DataOutputStream(socket.getOutputStream());
		} catch (Exception e) { e.printStackTrace();  System.exit(1); }
	}

	public int[] receive() {
		try {
			//		  int length = in.readInt();
			int length = in.read();
			length = length<<8 | in.read();
			length = length<<8 | in.read();
			length = length<<8 | in.read();
			int total = 0;
			byte[] result = new byte[length];
			while (total < length) {
				total += in.read(result,total,length-total);
			}
			return getIntArray(result);  
		} catch (Exception e) { e.printStackTrace();  System.exit(1); }
		return null;
	}

	/** @return int[] casted from src[from..to] */
	private int[] getIntArray(byte[] src) {
		int[] result = new int[src.length / 4];
		for (int i = 0, b = 0;  i < result.length;   i ++, b += 4)
			result[i] = (int) ((src[b  ] & 0xff) << (8 * 3))
                + (int) ((src[b+1] & 0xff) << (8 * 2))
                + (int) ((src[b+2] & 0xff) <<  8     )
                + (int)  (src[b+3] & 0xff);
		return result;
	}

	private void send(int header, byte[] body) {
		try {
			int len = body.length + 12;
			System.out.print("dataToSend length: ");
			System.out.println(len);
			out.writeByte((byte)(len>>24)&0xFF);
			out.writeByte((byte)(len>>16)&0xFF);
			out.writeByte((byte)(len>>8)&0xFF);
			out.writeByte((byte)len&0xFF);
			//			out.writeInt(len);
			out.writeInt(header);
			out.writeInt(body.length);
			out.write(body);
			out.writeInt(HEADER_NULL);
			out.flush();
			System.out.println("sending complete");
		} catch (Exception e) { e.printStackTrace();  System.exit(1); }
	}

	public void sendConnect() {
		System.out.println("connecting");
		byte[] b = new byte[4];
		for (int i = 0; i < 4; i++)
			b[i] = 0;
		send(SK_CONNECT, b);  // version must be 0
	}

	public void receiveConnectOk() {
		int[] data = receive();
		if(ASSERT)Util.myassert(data[0] == KS_CONNECT_OK, "received Long UDP packet isn't KS_CONNECT_OK");
		System.out.println("initializing");
		WORLD.update(data, 2, INITIALIZING_TIME);  // data[2..]: body
		WORLD.initialize();
	}

	public void sendAcknowledge() {
		byte[] b = new byte[0];
		send(SK_ACKNOWLEDGE, b);
	}

	public void receiveCommands() {
		int[] data = receive();
		if(ASSERT)Util.myassert(data[0] == KS_COMMANDS, "received Long UDP packet isn't KS_COMMANDS");
		if(ASSERT)Util.myassert(data[2] == WORLD.time() + 1  ||  WORLD.time() == INITIALIZING_TIME, "wrong simulation time; lost UDP packet of KS_COMMANDS");
		WORLD.parseCommands(data);
	}

	public void sendUpdate() {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		for (int i = WORLD.movingObjectArray().length - 1;  i >= 0;  i --)
			WORLD.movingObjectArray()[i].output(dos);
		try {
			dos.writeInt(TYPE_NULL);
			dos.close();
			send(SK_UPDATE, baos.toByteArray());
			baos.close();
		} catch (IOException e) { e.printStackTrace();  System.exit(1); }
	}

	public void receiveUpdate() {
		int[] data = receive();
		if(ASSERT)Util.myassert(data[0] == KS_UPDATE, "received Long UDP packet isn't KS_UPDATE");
		if(ASSERT)Util.myassert(data[2] == WORLD.time(), "wrong simulation time; lost UDP packet of KS_UPDATE");
		WORLD.update(data, 3, data[2]);  // data[2]: time, data[3..]: body
	}
  
	public void close() {
		try
			{
				in.close();
				out.close();
				socket.close();
			}
		catch (IOException e)
			{
				e.printStackTrace(); System.exit(1);
			}
	}
}
