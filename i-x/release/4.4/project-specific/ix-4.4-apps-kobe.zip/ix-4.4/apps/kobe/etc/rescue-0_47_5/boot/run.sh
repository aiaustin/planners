#! /bin/sh

# The directory to store logs.
LOGDIR=""

DIR=`dirname $0`
MAP="$1"
if [ -z $MAP ] ; then
  MAP=Kobe
fi
if [ ! -d $MAP ] ; then
  MAP="$DIR/../maps/$MAP"
fi

LOG="rescue.log"
if [ ! -z $2 ] ; then
  LOG="`date +%m%d-%H%M%S`-$2-`basename $MAP`.log"
fi
if [ ! -z $LOGDIR ] ; then
  LOG="$LOGDIR/$LOG"
fi

OPTIONS="-logname $LOG -shindopolydata $MAP/shindopolydata.dat -galpolydata $MAP/galpolydata.dat"

xterm -e $DIR/0gis.sh $OPTIONS -mapdir $MAP/ -gisini $MAP/gisini.txt&
sleep 5
xterm -e $DIR/1kernel.sh $OPTIONS &
sleep 10
#xterm -e ./kuwataviewer.sh -l 300 &
xterm -e $DIR/3miscsimulator.sh $OPTIONS &
xterm -e $DIR/4morimototrafficsimulator.sh &
xterm -e $DIR/5firesimulator.sh $OPTIONS &
xterm -e $DIR/6blockadessimulator.sh $OPTIONS &
xterm -e $DIR/7collapsesimulator.sh $OPTIONS &
sleep 5

xterm -e $DIR/8civilian.sh &

sleep 10

echo "start your agents (or sampleagent.sh)"

