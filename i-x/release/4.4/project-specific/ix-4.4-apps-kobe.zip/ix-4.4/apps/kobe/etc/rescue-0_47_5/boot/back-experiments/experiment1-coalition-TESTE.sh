#!/bin/bash

function canonicalname {
    program="$0"
    
    while [ -h "$program" ] ; do
        cd `dirname "$program"`
        program=`basename "$program"`
        program=`ls -l "$program"`
        program=${program##*-> }
    done
    
    cd `dirname "$program"`
    echo $PWD/`basename $program`
}

DIR=`dirname \`canonicalname "$0"\``
DIR=$DIR/../program/yabapi

# [<cv> <fb> <fs> <at> <ac> <pf> <po> [<host> [<port>]]]

# Start the 10 fire brigades
echo "Starting the 10 fire brigades..."
xterm -e java -cp "$DIR/yab.jar:$DIR/sample.jar" sample.Main 0 10 1 0 1 9 0 $* &

# Start the IX police office
sleep 5
cd /home/s0125683/ix-4.x/apps/irescue/scripts/unix
echo "Starting the police office...."
xterm -e ./PoliceOffice.sh &
sleep 12

# Start the 1 IX police forces

cd /home/s0125683/ix-4.x/apps/irescue/java
echo "Starting the IX police force 1"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce1 -superiors=PoliceOffice -peers=PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &

cd /home/s0125683/RoboCupRescue/rescue-0_45-unix/boot

