package viewer.object;

public class River extends Edge {
  public River(int id) { super(id); }
  public int type() { return TYPE_RIVER; }
}
