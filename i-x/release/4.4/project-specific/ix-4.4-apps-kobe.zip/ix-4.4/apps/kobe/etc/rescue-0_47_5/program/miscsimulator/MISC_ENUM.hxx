#if !defined MISC_ENUM_HXX_INCLUDED // {
#define MISC_ENUM_HXX_INCLUDED

namespace Rescue{
//////////////////////////////////////////////////////////////////////////////////////

     // ��¤����
     // Building Attribute
     enum AttBuilding{
	  WOOD,
	  STEEL,
	  RC,
	  ATTB_MAX,
     };
     
     // �ݲ�������
     enum GradeBroken{
	  BROKEN_0,    
	  BROKEN_25,
	  BROKEN_50,
	  BROKEN_100,
	  BROKEN_MAX,
     };

     // ���٤�����
     enum GradeSeismic{
//	  SEISMIC_0,  // dummy
//	  SEISMIC_1,  // dummy
//	  SEISMIC_2,  // dummy
//	  SEISMIC_3,  // dummy
//	  SEISMIC_4,  // dummy
	  SEISMIC_5,  // less than equal 5 seismic
	  SEISMIC_6,  // 6 seismic
	  SEISMIC_7,  // 7 seismic
	  SEISMIC_8,  // more than 7 seismic
  	  SEISMIC_MAX,
     };

     // �򹯾���
     enum HealthState{
	  UNHURT,
	  SLIGHT,
	  SERIOUS,
	  HSTATE_MAX,
     };
} // namespace Rescue
#endif // } MISC_ENUM_HXX_INCLUDED
