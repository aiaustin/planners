package traffic.object;

public class FireStation extends Building {
  public FireStation(int id) { super(id); }
  public int type() { return TYPE_FIRE_STATION; }
}
