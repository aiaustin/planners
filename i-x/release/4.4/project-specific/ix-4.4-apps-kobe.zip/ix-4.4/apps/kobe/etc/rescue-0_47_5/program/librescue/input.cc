/*
 * Copyright (c) 2005, The Black Sheep, Department of Computer Science, The University of Auckland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of The Black Sheep, The Department of Computer Science or The University of Auckland nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 Contributors and list of changes:

 Cameron Skinner
   Converted original Robocup Rescue software into librescue
*/

#include "input.h"
#include "objects.h"
#include "error.h"

namespace Librescue {
  RescueObject* readObject(Input& input, int time) {
	TypeId type;
	type=(TypeId)input.readInt32();
	RescueObject* result = newRescueObject(type);
	if (result) {
	  result->read(input,time);
	}
	return result;
  }

  void readObjects(Input& input, int time, Objects& result) {
	RescueObject* next = 0;
	do {
	  next = readObject(input,time);
	  if (next) result.push_back(next);
	} while (next);
  }

  Overrun::Overrun() {
	message = "Buffer overrun";
  }

  Overrun::~Overrun() {
  }

  Input::Input() {
	m_index = 0;
	m_bytes.clear();
  }

  Input::~Input() {
  }

  void Input::reset(const Bytes &source) {
	m_index = 0;
	m_bytes = source;
  }

  int Input::size() const {
	return m_bytes.size();
  }

  Cursor Input::cursor() const {
	return m_index;
  }

  void Input::setCursor(Cursor c) {
	m_index = c;
  }

  void Input::skip(INT_32 size) {
	m_index += size;
	if (unsigned(m_index) > m_bytes.size())
	  throw Overrun();
  }

  INT_32 Input::readInt32() {
	if ((unsigned)m_index + 4 > m_bytes.size())
	  throw Overrun();
	INT_32 result = m_bytes[m_index]<<24 | m_bytes[m_index+1]<<16 | m_bytes[m_index+2]<<8 | m_bytes[m_index+3];
	m_index+=4;
	return result;
  }

  INT_32 Input::peekInt32() {
	if ((unsigned)m_index + 4 > m_bytes.size())
	  throw Overrun();
	INT_32 result = m_bytes[m_index]<<24 | m_bytes[m_index+1]<<16 | m_bytes[m_index+2]<<8 | m_bytes[m_index+3];
	return result;
  }

  void Input::readString(char* result) {
	INT_32 size = readInt32();
	if ((unsigned)m_index+size > m_bytes.size()) throw Overrun();
	for (int i=0;i<size;++i) result[i] = m_bytes[m_index++];
  }

  void Input::readString(char* result, int size) {
	if ((unsigned)m_index+size > m_bytes.size()) throw Overrun();
	for (int i=0;i<size;++i) result[i] = m_bytes[m_index++];
  }

  std::string Input::readString() {
	INT_32 size = readInt32();
	if ((unsigned)m_index+size > m_bytes.size()) throw Overrun();
	std::string result;
	for (int i=0;i<size;++i) result += m_bytes[m_index++]; // This is probably inefficient but I don't have a good book on STL handy. I'll fix it later.
	return result;
  }

  void Input::read(int size, Bytes& buffer) {
	for (int i=0;i<size;++i) {
	  buffer.push_back(m_bytes[m_index+i]);
	}
	m_index += size;
  }

  void Input::read(int size, Byte* buffer) {
	for (int i=0;i<size;++i) {
	  buffer[i] = m_bytes[m_index+i];
	}
	m_index += size;
  }
}
