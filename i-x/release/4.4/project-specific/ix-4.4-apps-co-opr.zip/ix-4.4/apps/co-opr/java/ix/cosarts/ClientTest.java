/* SAR resources lookup test.
 * Uses code from Andrzej Uszok <auszok@ai.uwf.edu>.
 * I-X code by Jeff Dalton and Copyright (c) 2003,
 *    AIAI, University of Edinburgh
 * Updated: Mon Apr  7 19:19:13 2003 by Jeff Dalton
 */

package ix.cosarts;

import cosarts.matchmaker.MatchMakerProxy;
import cosarts.query.QueryMMRescueResources;

import EDU.cmu.softagents.DAML.soap.*;

import java.io.*;
import java.util.*;
import java.net.*;

import ix.icore.*;
import ix.util.*;
import ix.util.lisp.*;

/**
 * Simple prints information rather than acting as an I-X agent.
 * Compare {@link MMClient}.
 */
public class ClientTest {

    public static void main(String[] args) throws Exception {

	Parameters.processCommandLineArguments(args);

        String url = Parameters.getParameter("url");
	boolean debug = true;

	MatchMakerProxy mmc = new MatchMakerProxy(url,debug);

	QueryMMRescueResources query = new QueryMMRescueResources(mmc);

        Vector results = query.getRescueResourceDesc("sea", "arabello");

        for(int i = 0; i < results.size(); i++)
        {
	    System.out.println(results.get(i));
//              MMResult mmr = (MMResult)results.get(i);
//              System.out.println("score   = "   + mmr.getScore());
//              System.out.println("ad_name = "   + mmr.getAdName());
//              System.out.println("ad_txt  = \n" + mmr.getAdText());
//              System.out.println("uddi_id = "   + mmr.getUddiId());
//              System.out.println("uddi_tm = \n" + mmr.getUddiTm());
        }

    }

}
