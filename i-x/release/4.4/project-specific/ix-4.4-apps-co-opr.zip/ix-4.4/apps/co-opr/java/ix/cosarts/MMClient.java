/* SAR resources lookup agent.
 * Uses code from Andrzej Uszok <auszok@ai.uwf.edu>.
 * I-X agent wrapper by Jeff Dalton and Copyright (c) 2003,
 *    AIAI, University of Edinburgh
 * Updated: Wed Oct  1 15:03:37 2003 by Jeff Dalton
 */

package ix.cosarts;

import cosarts.matchmaker.MatchMakerProxy;
import cosarts.query.QueryMMRescueResources;

import EDU.cmu.softagents.DAML.soap.*;

import java.io.*;
import java.util.*;
import java.net.*;

import ix.iface.util.Reporting;

import ix.icore.*;
import ix.icore.domain.Constraint;
import ix.util.*;
import ix.util.lisp.*;

/**
 * Identify SAR resources using the CMU DAML Matchmaker.
 *
 * <p>Handles activities with verb <code>lookup-sar-resources</code>.
 * It handles the activity by sending a series of reports that each
 * contain information about a resource, followed by a completion
 * report.  Some other reports may also also sent.
 */
public class MMClient extends InfosourceAgent {

    static final Symbol S_LOOKUP_SAR_RESOURCES =
	Symbol.intern("lookup-sar-resources");

    // /\/: Because there's a new instance of MMClient for each
    // lookup, common data is static.  This will change at some point.

    protected static boolean simulateLookup = true;
    protected static int initialDelay = 5;  // seconds
    protected static int delayBetween = 3;  // seconds

    protected static MatchMakerProxy mmc;
    protected static String url;

    protected static QueryMMRescueResources query;

    public MMClient() {
	super();
    }

    /**
     * Runs an I-X agent that provides information about sar resources.
     */
    public static void main(String[] argv) {
	Util.printGreeting("I-X Resources Agent");
	new MMClient().mainStartup(argv);
    }

    /**
     * Command-line argument processing.
     */
    protected void processCommandLineArguments() {
	super.processCommandLineArguments();
	Debug.noteln("Processing command-line arguments " +
		     "as MMClient in", this);

	url = Parameters.getParameter("url");

	simulateLookup = Parameters.getBoolean("simulate-lookup", false);
	initialDelay = Parameters.getInt("initial-delay", initialDelay);
	delayBetween = Parameters.getInt("delay-between", delayBetween);
	
	Debug.noteln("simulateLookup=" + simulateLookup + ", " +
		     "initialDelay=" + initialDelay + ", " +
		     "delayBetween=" + delayBetween);
    }

    // Unfortunate globals
    protected Activity theActivity;

    protected boolean isLookupActivity(Activity activity) {
	LList pattern = activity.getPattern();
	return pattern.size() > 0
	    && pattern.get(0) == S_LOOKUP_SAR_RESOURCES;
    }

    protected void handleLookup(Activity activity) {
	// N.B. Runs in separate thread and in separate instance of MMClient.
	theActivity = activity;
	LList pattern = activity.getPattern();
	String origin = pattern.get(1).toString().toLowerCase();
	String country = Strings.capitalize(pattern.get(2).toString());
	if (simulateLookup)
	    reportSimulatedResults(origin, country);
	else
	    reportResults(origin, country);
    }

    protected void sendNoResultsReport() {
	sendReport(theActivity, ReportType.FAILURE, "Cannot find any data");
    }

    protected void reportResults(String origin, String country) {

	transcript("Will use QueryMMRescueResources.");

	Vector results = null;

	boolean useFallback = 
	    Parameters.getBoolean("use-fallmack-mm-query", false);

	try {
	    if (mmc == null) {
		boolean debug = true;
		mmc = new MatchMakerProxy(url, debug);
		if (useFallback)
		    query = new FallbackQueryMMRescueResources(mmc);
		else
		    query = new QueryMMRescueResources(mmc);
	    }
		
	    results = query.getRescueResourceDesc(origin, country);

	}
	catch (Throwable t) {
	    Debug.noteln("Exception during setup or query");
	    Debug.noteException(t);
	    sendReport(theActivity, ReportType.FAILURE,
		       "Cannot find any data because " +
		       Debug.describeException(t));
	    throw new RethrownException(t);
	}

	if (results == null) {
	    transcript("Null results");
	    sendNoResultsReport();
	    return;
	}

	for(int i = 0; i < results.size(); i++) {

	    String damlDescr = (String)results.get(i);

	    // Just report the name for now.
	    String nameLine = findLineContaining("serviceName", damlDescr);
	    if (nameLine == null)
		// If we can't find the line, just send the whole decription
		nameLine = damlDescr;

	    sendReport(theActivity, ReportType.PROGRESS,
		       "Found resource " + nameLine);
		       
        }
	sendReport(theActivity, ReportType.SUCCESS,
		   "Finished -- " + results.size() + " resources found.");
    }

    String findLineContaining(String target, String lines) {
	for (Iterator i = Strings.breakIntoLines(lines).iterator();
	     i.hasNext();) {
	    String line = (String)i.next();
	    if (line.indexOf(target) >= 0)
		return line;
	}
	return null;
    }

    protected LList countries =	Lisp.list("Arabello", "Binni");
    protected LList origins = Lisp.list("sea", "land");

    protected void reportSimulatedResults(String origin, String country) {
	String simInfo = "Simulating lookup, " +
	    "initialDelay=" + initialDelay + ", " +
	    "delayBetween=" + delayBetween;
	Debug.noteln(simInfo);
	transcript(simInfo);
	sleepSeconds(initialDelay);

	TwoKeyHashMap map = buildSimulatedResultTable();
	List results = (List)map.get(origin, country);
	if (results == null || results.isEmpty()) {
	    sendNoResultsReport();
	    return;
	}
	for (Iterator r = results.iterator(); r.hasNext();) {
	    String result = (String)r.next();
	    LList pattern =
		Lisp.list(Symbol.intern("sar-resource"),
			  result);
	    Constraint con = makeStateConstraint(pattern);
	    sendReport(theActivity, ReportType.PROGRESS,
		       "Found resource " + result,
		       Lisp.list(con));
	    sleepSeconds(delayBetween);
	}
	sendReport(theActivity, ReportType.SUCCESS,
		   "Finished -- " + results.size() + " resources found.");
    }

    protected TwoKeyHashMap buildSimulatedResultTable() {
	TwoKeyHashMap map = new TwoKeyHashMap();
	map.put("sea", "Arabello",
		Lisp.list("USMarineHelicopter",
			  "ArabelloCoastguardCutter"));
	map.put("sea", "Binni",
		Lisp.list("USMarineHelicopter",
			  "ArabelloCoastguardCutter",
			  "GaoMarineHelicopter"));
	map.put("land", "Arabello",
		Lisp.list("USArmyHelicopter"));
	map.put("land", "Binni",
		Lisp.list("GaoMarineHelicopter",
			  "USArmyHelicopter"));
	return map;
    }

}
