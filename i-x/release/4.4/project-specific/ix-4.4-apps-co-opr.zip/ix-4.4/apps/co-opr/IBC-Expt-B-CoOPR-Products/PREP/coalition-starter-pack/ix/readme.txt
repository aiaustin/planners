I-X Version 4.0 31-Aug-2004

ix.zip is the main 31-Aug-2004 I-X release.  Download current relewase from
http://www.aiai.ed.ac.uk/project/ix/release/current/


I-X 23-Oct-2002 version 2.3 release was used in the CoAX Binni 2002 Demonstration.

Download from http://www.aiai.ed.ac.uk/project/coax/demo/2002/coalition-starter-pack/ix/






