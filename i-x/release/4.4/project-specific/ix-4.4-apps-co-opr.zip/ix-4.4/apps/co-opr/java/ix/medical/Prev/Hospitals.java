/* Hospital lookup agent.
 * Uses code from Mike Dean <mdean@bbn.com>
 * I-X agent wrapper by Jeff Dalton and Copyright (c) 2003,
 *    AIAI, University of Edinburgh
 * Converted to Jena 2 by Jeff Dalton, Dec 10, 2003.
 * Updated: Wed Dec 10 22:06:16 2003 by Jeff Dalton
 */

package ix.medical;

import com.hp.hpl.jena.rdf.model.RDFException;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;

import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;

import java.io.*;
import java.awt.event.*;
import java.net.URL;		// for saved-model loading /\/
import java.util.*;
import javax.swing.*;

import ix.iquery.*;

import ix.iface.util.Reporting;

import ix.icore.*;
import ix.iface.util.IFUtil;
import ix.util.*;
import ix.util.lisp.*;
import ix.util.xml.XMLLoader;	// toURL used in saved-model loading /\/

/**
 * Identify hospitals and their associated capabilities in Arabello
 * and neighboring countries.
 *
 * <p>Handles activities with verb <code>lookup-hospitals</code>.
 * It handles the activity by sending a series of reports that each
 * contain information about a hospital, followed by a completion
 * report.  Some other progress reports are also sent.
 *
 * <p>Syntax:
 * <pre>
 *    lookup-hospitals
 *    lookup-hospitals <i>medical-capability</i>
 * </pre>
 *
 * <p>The capability we usually care about is BurnCare.
 *
 * <p>The "countries" paprameter can be used to give a list of countries
 * For example, <code>countries=arabello,binni,agadez,gao</code>
 *
 * @see ix.util.Parameters.getList(String)
 */
public class Hospitals extends IQuery {

    static final Symbol S_LOOKUP_HOSPITALS =
	Symbol.intern("lookup-hospitals");

    Model model = ModelFactory.createDefaultModel(); // a Jena RDF model
    Set readURIs = new HashSet(); // URIs we've read into it, as Strings

    String savedModelURI = null;

    public Hospitals() {
	super();
    }

    /**
     * Runs an I-X agent that provides hosital data.
     */
    public static void main(String[] argv) {
	Util.printGreeting("I-X Hospitals");
	new Hospitals().mainStartup(argv);
    }

    /**
     * Command-line argument processing.
     */
    protected void processCommandLineArguments() {
	super.processCommandLineArguments();
	String saved = Parameters.getParameter("model");
	if (saved != null) {
	    readSavedModel(saved);
	}
    }

    /**
     * Determines whether the activity is one that should be handled
     * by a {@link LookupHandler}.
     */
    protected boolean isLookupActivity(Activity activity) {
	return activity.getPattern().get(0) == S_LOOKUP_HOSPITALS;
    }

    protected LookupHandler
	      makeLookupHandler(IQuery queryAgent,
				Activity lookupActivity) {
	return new HospitalLookupHandler(queryAgent, lookupActivity);
    }


    /*
     * GUI additions
     */

    protected void setupGUI() {
	super.setupGUI();
	JFrame frame = textFrame.getFrame();
	JMenu fileMenu = IFUtil.ensureMenuBarMenu(frame, "File");

	fileMenu
	    .add(IFUtil.makeMenuItem("Load Model From", new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    readSavedModel();
		}
	    }));

	fileMenu
	    .add(IFUtil.makeMenuItem("Save Model As", new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    saveModelAs();
		}
	    }));

	fileMenu.add(IFUtil.makeMenuItem("Reset", new ActionListener() {
	    public void actionPerformed(ActionEvent e) {
		reset();
	    }
	}));

    }


    /*
     * Model management
     */

    // Replaces calls to model.read(uri).
    synchronized void model_read(String uri) {
	if (readURIs.contains(uri)) {
	    Debug.noteln("Skipping read of", uri);
	    return;
	}
	if (savedModelURI != null) {
	    Debug.noteln("Using saved model rather than reading", uri);
	    return;
	}
	model.read(uri);
	readURIs.add(uri);
    }

    synchronized void reset() {
	readURIs.clear();
	model = ModelFactory.createDefaultModel();
	savedModelURI = null;
    }

    synchronized void saveModelAs() {
	File libDir = ix.iface.domain.DomainParser.getLibraryDirectory();
	JFileChooser fileChooser = new JFileChooser(libDir);
	int option = fileChooser.showSaveDialog(textFrame);
	if (option == JFileChooser.APPROVE_OPTION) {
	    try {
		File file = fileChooser.getSelectedFile();
		Writer w = new FileWriter(file);
		model.write(w, "RDF/XML-ABBREV");
		w.close();
	    }
	    catch (Throwable t) {
		Debug.displayException("Prolem while saving model", t);
	    }
	}
    }

    synchronized void readSavedModel() {
	File libDir = ix.iface.domain.DomainParser.getLibraryDirectory();
	JFileChooser fileChooser = new JFileChooser(libDir);
	int option = fileChooser.showOpenDialog(textFrame);
	if (option == JFileChooser.APPROVE_OPTION)
	    readSavedModel(fileChooser.getSelectedFile().toString());
    }

    synchronized void readSavedModel(String uri) {
	savedModelURI = uri;
	try {
	    Debug.noteln("Reading saved model", savedModelURI);
	    URL url = new XMLLoader(null).toURL(savedModelURI);
	    model.read(url.toString());
	}
	catch (Throwable t) {
	    Debug.displayException
		("Problem reading saved model " + savedModelURI, t);
	}
    }

    /**
     * Hander for hospital lookup.
     */
    class HospitalLookupHandler extends LookupHandler {

	// /\/: Not a static class so that it can call model_read.

	// Some unfortunate globals
	String desiredCapability;
	int hospCount;		// number considered
	int goodCount;		// number with desired capability

	HospitalLookupHandler(IQuery agent, Activity activity) {
	    super(agent, activity);
	}

	protected void handleLookup() {

	    // Syntax is: (lookup-hospitals)
	    // or: (lookup-hospitals <medical capability>)
	    desiredCapability = null;
	    hospCount = 0;
	    goodCount = 0;
	    List pattern = lookupActivity.getPattern();
	    if (pattern.size() > 1)
		desiredCapability = pattern.get(1).toString().toLowerCase();
	    try {
		lookupHospitals();
		sendReport(ReportType.SUCCESS,
			   "Finished -- " + hospCount + 
			   " hospitals considered, " +
			   goodCount + " matches.");
	    }
	    catch (RDFException e) {
		Debug.displayException("Problem during lookup", e);
		sendReport(ReportType.FAILURE,
			   "Cannot find further data because: " +
			   Debug.describeException(e));
	    }
	    catch (Throwable t) {
		Debug.displayException("Problem during lookup", t);
		sendReport(ReportType.FAILURE,
			   "Cannot find further data because: " +
			   Debug.describeException(t));
	    }
	}

	boolean isDesiredCapability(String resource) {
	    // /\/: This is a hack, because I don't get know enough about
	    // Jena and RDF to do it right.
	    return desiredCapability != null
		&& resource.toLowerCase().endsWith(desiredCapability);
	}

	/*
	 * Medical database lookup
	 */

	public void lookupHospitals()  {
	    List countries = 
		Parameters.getList("countries", Lisp.list("arabello"));
	    // Model model = new ModelMem();
	    for (Iterator i = countries.iterator(); i.hasNext();) {
		String countryName = ((String)i.next()).toUpperCase();
		Debug.noteln("Adding model info for", countryName);
		sendReport(ReportType.PROGRESS,
			   "Getting data about " + countryName);
		model_read("http://sonat.daml.org/DAMLdemo/instances/enp/nc-" +
			   countryName + ".owl");
	    }
	    model_read("http://www.daml.org/experiment/ontology/infrastructure-elements-ont");
	    Resource Medical = model.createResource("http://www.daml.org/experiment/ontology/infrastructure-elements-ont#Medical");
	    processInstances(model, Medical);
	    
	}

	void processInstances(Model model, Resource type) {

	    Debug.noteln("Type:", type);

	    // process instances
	    ResIterator hospitals = 
		model.listSubjectsWithProperty(RDF.type, type);
	    while (hospitals.hasNext()) {
		Resource hospital = hospitals.nextResource();
		try {
		    processHospital(model, type, hospital);
		}
		catch (Throwable t) {
		    String label = Strings.afterLast("/", hospital.toString());
		    String prefix = "Problem with hospital " + label;
		    Debug.displayException(prefix, t);
		    sendReport(ReportType.PROGRESS,
			       "Problem with data from hospital "
			       + label + ": " + Debug.describeException(t));
		}
	    }

	    // process subclasses
	    ResIterator subclasses =
//  		model.listSubjectsWithProperty(DAML_OIL.subClassOf, type);
		model.listSubjectsWithProperty(RDFS.subClassOf, type);
	    while (subclasses.hasNext()) {
		Resource subclass = subclasses.nextResource();
		processInstances(model, subclass);
	    }

	}

	void processHospital(Model model, Resource type, Resource hospital)
	     
	{
	    hospCount++;

	    Debug.noteln("Hospital:", hospital);

	    // load statements about this instance
	    Debug.noteln("--- Reading " + hospital.getURI());
	    model_read(hospital.getURI());

	    boolean hasCapability = false;
	    List lines = new LinkedList();

	    // print rdfs:label and capabilities
	    String label = getLabel(hospital);
	    Debug.noteln("  " + label);
	    lines.add("Found hospital " + label);
	    lines.add(label);
	    lines.add("  " + Strings.afterLast("/", hospital.toString()));

	    String typeName = Strings.afterLast("#", type.toString());
	    lines.add("  Type: " + typeName);

	    // If a hospital has no data, this won't work.
	    // And there is one such in Gao.
	    Location loc = tryLocation(model, hospital);
	    Debug.noteln("   Location: " + loc);
	    lines.add("   Location: " + loc);

	    List capNames = new LinkedList();
	    StmtIterator capabilities =
		hospital.listProperties(model.createProperty("http://www.daml.org/2003/03/medical/medical-ont#medicalCapability"));
	    while (capabilities.hasNext()) {
		Statement capability = capabilities.nextStatement();
		String cap = capability.getObject().toString();
		Debug.noteln("    " + cap);
		capNames.add(Strings.afterLast("#", cap));
		if (!hasCapability)
		    hasCapability =
			isDesiredCapability
			(capability.getObject().toString());
	    }
	    if (hasCapability || desiredCapability == null) {
		goodCount++;
		lines.add("  Capabilities: " + 
			  Strings.joinWith(", ", capNames));
		Report report =
		    makeReport(ReportType.PROGRESS,
			       Strings.joinLines(lines));
		addHospitalConstraints
		    (report, label, typeName, loc, capNames);
		Debug.noteln("Constraints", report.getConstraints());
		sendReply(report);
	    }
	}

	String getLabel(Resource r) {
	    try {
		return r.getProperty(RDFS.label).getString();
	    }
	    catch (RDFException rdfe) {
		return r.getLocalName();
	    }
	}

	void addHospitalConstraints(Report r, String label, String typeName,
				    Location loc, List capNames) {
	    r.addConstraint(makeStateConstraint(prop("hospital", label)));
	    r.addConstraint(makeStateConstraint(prop("type", label), typeName));
	    r.addConstraint(makeStateConstraint(prop("country", label),
						loc.getCountry()));
	    r.addConstraint(makeStateConstraint(prop("latitude", label),
						loc.getLatitude()));
	    r.addConstraint(makeStateConstraint(prop("longitude", label),
						loc.getLongitude()));
//  	    r.addConstraint(makeStateConstraint(prop("capabilities", label),
//  						LList.newLList(capNames)));
	    for (Iterator i = capNames.iterator(); i.hasNext();) {
		String capName = (String)i.next();
		LList pattern =
		    Lisp.list(Symbol.intern("medical-capability"),
			      label,
			      capName);
		r.addConstraint(makeStateConstraint(pattern));
	    }
	}

	LList prop(String propName, String item) {
	    return Lisp.list(Symbol.intern(propName), item);
	}

	Location tryLocation(Model model, Resource hospital) {
	    try {
		return getLocation(model, hospital);
	    }
	    catch (Exception e) {
		Debug.noteException(e);
		throw new IllegalArgumentException
		    ("Cannot get location of " + getLabel(hospital));
	    }
	}

	Location getLocation(Model model, Resource hospital) {
	    Property loc_p = model.createProperty("http://www.daml.org/experiment/ontology/location-ont#location");
	    Property lat_p = model.createProperty("http://www.daml.org/experiment/ontology/location-ont#latitude");
	    Property lon_p = model.createProperty("http://www.daml.org/experiment/ontology/location-ont#longitude");
	    // Latitude and Longitude
	    Resource loc = (Resource)hospital.getProperty(loc_p).getObject();
	    Literal lat = (Literal)loc.getProperty(lat_p).getObject();
	    Literal lon = (Literal)loc.getProperty(lon_p).getObject();
	    // Country
	    Property country_p = model.createProperty("http://www.daml.org/experiment/ontology/elements-ont#country");
	    Resource country = (Resource)hospital.getProperty(country_p).getObject();
	    // Can't do this, because it has no such property.
	    // String countryName = country.getProperty(RDFS.label).getString();
	    // Arabello is something like this:
	    // "http://sonat.daml.org/DAMLdemo/instances/enp/nc-ARABELLO.daml#
	    //  notionalcountry660aa589-364a-46e2-bc78-8867c61ba4af"
	    String countryURI = country.toString();
	    String countryName =
		Strings.beforeFirst(".", 	// don't know it's .daml
		    Strings.afterLast("nc-",
		        Strings.beforeFirst("#", countryURI)));
	    countryName = Strings.capitalize(countryName.toLowerCase());
	    return new Location(countryName, lat.toString(), lon.toString());
	}

    }

    static class Location {
	String country;
	Double latitude;
	Double longitude;

	Location(String country, String latitude, String longitude) {
	    this.country = country;
	    this.latitude = doubleValue(latitude);
	    this.longitude = doubleValue(longitude);
	}

	String getCountry() { return country; }
	Double getLatitude() { return latitude; }
	Double getLongitude() { return longitude; }

	Double doubleValue(String d) {
	    try {
		return Double.valueOf(d);
	    }
	    catch (NumberFormatException e) {
		throw new IllegalArgumentException
		    ("Position " + d + " is not a valid number");
	    }
	}

	public String toString() {
	    return "country = " + country
		+ ", latitude = " + latitude
		+ ", longitude = " + longitude;
	}
    }

}
