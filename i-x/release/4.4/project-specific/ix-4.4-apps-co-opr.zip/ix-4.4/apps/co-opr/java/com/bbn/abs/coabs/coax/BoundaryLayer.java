//-----------------------------------------------------------------------------
// Copyright (C) 2002 by BBNT Solutions, LLC
// All Rights Reserved.
//-----------------------------------------------------------------------------

package com.bbn.abs.coabs.coax;

//-----------------------------------------------------------------------------

import java.awt.Color;
import java.awt.Graphics;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.StreamTokenizer;

import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JOptionPane;

import com.bbn.openmap.Layer;
import com.bbn.openmap.event.ProjectionEvent;
import com.bbn.openmap.omGraphics.OMGraphicList;
import com.bbn.openmap.omGraphics.OMPoly;
import com.bbn.openmap.proj.Projection;
import com.bbn.openmap.util.ColorFactory;

import com.bbn.abs.util.StringHelper;

//-----------------------------------------------------------------------------
/** An OpenMap layer for displaying boundaries. The boundaries are specified
 * by text files that contain a latitude and a longitude on each line,
 * separated by white space. Optionally, a line color may be specified for each
 * file. The files to display are specified in the OpenMap
 * properties file as follows:
 *   <layer-marker>.files = <file-marker-1> ... <file-marker-n>
 *   <layer-marker>.<file-marker-1>.path = ...
 *     ...
 *   <layer-marker>.<file-marker-n>.path = ...
 *   <layer-marker>.<file-marker-n>.lineColor=FF00FF99 */

public class BoundaryLayer
extends Layer
{
    protected Projection _projection;
    protected OMGraphicList _boundaries = new OMGraphicList();

    //-------------------------------------------------------------------------

    public BoundaryLayer ()
    {
	super();
    }


    //-------------------------------------------------------------------------

    public void setProperties (String prefix, Properties properties)
    {
	super.setProperties(prefix, properties);

	String files_property = properties.getProperty(prefix + ".files");

	if (files_property != null)
	{
	    ArrayList file_markers = StringHelper.parsePropertyListValue
		(files_property);

	    for (int i = 0; i < file_markers.size(); i++)
	    {
		String marker = (String)file_markers.get(i);
		String path = properties.getProperty
		    (prefix + "." + marker + ".path");

		if (path != null)
		{
		    String line_color_property = properties.getProperty
			(prefix + "." + marker + ".lineColor");
		    Color line_color = (line_color_property == null) ?
			Color.lightGray :
			ColorFactory.parseColor(line_color_property);
		    this.createBoundary(path, line_color);
		}
	    }
	}
    }

    //-------------------------------------------------------------------------

    private void createBoundary (String path, Color line_color)
    {
	try
	{	
	    StreamTokenizer tokenizer = new StreamTokenizer
		(new BufferedReader(new FileReader(new File(path))));
	    ArrayList locations = new ArrayList();
	    int token_type;

	    while ((token_type = tokenizer.nextToken()) != tokenizer.TT_EOF)
		if (token_type == tokenizer.TT_NUMBER)
		    locations.add(new Float(tokenizer.nval));
		
	    float lat_lons[] = new float[locations.size()];

	    for (int i = 0; i < lat_lons.length; i++)
		lat_lons[i] = ((Float)locations.get(i)).floatValue();

	    OMPoly boundary = new OMPoly
		(lat_lons, OMPoly.DECIMAL_DEGREES, OMPoly.LINETYPE_RHUMB);
	    boundary.setIsPolygon(false);
	    boundary.setLinePaint(line_color);
	    _boundaries.add(boundary);
	}
	catch (Exception e)
	{
	    JOptionPane.showMessageDialog
		(this,
		 "Error occurred with boundary file '" + path + "'.\n" + e);
	}
    }

    //-------------------------------------------------------------------------
    /** Implement ProjectionListener method inherited from Layer. */

    public void projectionChanged (ProjectionEvent event)
    {
	_projection = event.getProjection();
	_boundaries.generate(_projection);
    }

    //-------------------------------------------------------------------------
    // override Component method

    public void paint (Graphics grapher) 
    {
	_boundaries.render(grapher);

    }

    //-------------------------------------------------------------------------
}
