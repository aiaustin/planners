/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Mon Sep 29 22:22:36 2003 by Jeff Dalton
 * Copyright: (c) 2001, AIAI, University of Edinburgh
 */

package ix.cosarts;

// New imports from Shri:
import cosarts.enforcer.*;

import ix.kaos.KaosCommunicationStrategy;

import ix.util.*;

/**
 * A class that encapsulates the KAoS knowledge needed for
 * sending and receiving our messages.
 *
 * It uses KAoSAgentRegistrationHelper(String name)
 */
public class SoapEnforcerKaosCS extends KaosCommunicationStrategy {

    public SoapEnforcerKaosCS() {
    }

    /**
     * Register as an agent and set up for receiving messages.
     */
    public void setupServer(Object destination, 
			    IPC.MessageListener listener) {

	super.setupServer(destination, listener);

	//Shri:
	KAoSSoapEnforcer.setAgentDescription(kdesc);
            
    }

}
