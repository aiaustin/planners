I-Plan
Jeff Dalton 5-May-2004

To use I-Plan, use main program class ix.iplan.IPlan.


Although it looks like I-P2, the functionality is very
different.  For instance, the only action you can apply
to an activity is to expand it (if there's a suitable
refinement).


In I-Plan, you can set up a planning problem by adding
activities, changing the world-state, and (if you want)
expanding activities using refinements in the domain or
using the "details" editor.


The "Plan" entry in the menu bar can be used to run the
automatic planner, to replan, and to run the plan-checking
simulator.


It doesn't yet have the ability to display more than one
plan, so if you replan the current plan is lost unless you
save it to a file first.


You can use the "Send plan" entry in the "File" menu to send
the plan to another agent.


You can also use that menu entry in another agent to send a
plan to I-Plan.


If you send I-Plan a plan, a dialog asking "Load plan?" will
pop up.  If you say yes, it will discard its current plan and
load the one it was sent.


(This I-Plan should be thought of as a planning service rather
than as a general agent.)


Domains and initial plans that correspond to the O-Plan/I-Plan
demos on the web can be found in 


/group/aiai/ix/development/jeff/ix-3.x/test-domains/wsp-*


The wsp-*.lsp files are the domains, and the .xml ones are the
initial plans.


The other files in test-domains are just to test the planner.


The output-objects annotation is part of the current
implementation of outputs.  It's what tells the planner
to generate a new object as the value of a variable.
(With O-Plan we do that using a compute condition.)


Apart from that, domain definitions are no more expressive than
before, so many things familiar from O-Plan are missing.
