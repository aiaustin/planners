To run demo on Unix systems:

  etc/ip2 -external-capabilities=hospitals:lookup-hospitals \
      -ipc -ipc-name=foo -run-name-server&

  etc/hospitals -ipc -ipc-name=hospitals

or

  etc/hospitals -ipc -ipc-name=hospitals \
      -countries=arabello,binni,agadez,gao &

The most general case:

  etc/ip2 -external-capabilities=hospitals:lookup-hospitals \
      -ipc -ipc-name=foo -run-name-server \
      -plan-state-to-save=\* &

  etc/hospitals -ipc -ipc-name=hospitals \
      -countries=arabello,binni,agadez,gao &

To use a saved model, use command-line arguyment / parameter saved=URI.
It will then use the contents of that URI rather than performing its
normal lookup.

To save a model containing all the triples that have been loaded
into the agent, use "Save Model As" in the "File" menu.  Another
"File" menu entry, "Load Model From" can be used as an alternative
to the "model" parameter.

To compile on Unix:

  etc/jena2-javac apps/medical/java/ix/medical/Hospitals.java

Activity to try:

  lookup-hospitals BurnCare
