CoSAR-TS Domain to show use of OWL-S primitives in Use
Jeff Dalton 24-May-2004

* It has "nice" replans (ie all are visible and make sense --
  they all change the pickup service).


* It uses the CoSAR-TS OWL-S for the primitives.


* It's all expansion, no achieve.  Just put in an activity
  with pattern example, and everything expands from there.


* There's a setup-initial-state refinement that sets up
  the initial world state.


* You can manually step part of the way.  I have tried only
  some cases.  For a demo, it's probably best to get to the
  point where the initial state is in place.


* *** DO NOT try to do it all manually. *** You should be able to
  do everything but the last, gao-hospital-service, step.
  If you try that one, you will hit a bug, and it will look bad.


  There is also an underlying problem (in addition to the bug):
  outputs work properly only in the automatic planner.  It needs
  to generate object names, and that's been implemented only in
  the automatic planner.


* There is no OWL-S output in I-P2.


You will need:


* cosar-ts-services-example.lsp


  That's the higher-level part, minus the primitives.


* cosar-ts-services.lsp


  That's the pre-translated OWL-S in case you need it.


* import-cosar-ts-services.owls


  That's a very simple file that imports from
  "http://ontology.ihmc.us/CoSAR-TS/CoSAR-TS-ServiceOntology.owl
  You need it because its name ends ".owls".


  Something whose name ends ".owl" will be read as if it
  described one of our objests (Plan, Domain, Issue, etc)
  in RDF (which won't work).


  This is correct behaviour and not a bug.


I will attach the files and also put them on the web.


When running I-P2, you must specify both cosar-ts-services-example.lsp
and one of import-cosar-ts-services.owls or cosar-ts-services.lsp
as domain=commaSeparatedList.


I have a directory called "services" in which I put files
such as import-cosar-ts-services.owls and cosar-ts-services.lsp


I put cosar-ts-services-example.lsp in domain-library.