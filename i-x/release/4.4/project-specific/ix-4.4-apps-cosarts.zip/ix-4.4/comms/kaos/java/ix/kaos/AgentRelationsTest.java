package ix.kaos;

// KAoS imports
import edu.uwf.kaos.coabsgrid.KAoSAgentRegistrationHelper;
import edu.uwf.kaos.coabsgrid.KAoSAgentRep;

import kaos.core.service.directory.KAoSAgentDirectoryServiceProxy;
import kaos.core.service.directory.KAoSAgentDescription;
import kaos.core.service.directory.query.AgentRelations;

import java.util.*;

public class AgentRelationsTest {

    KAoSAgentDirectoryServiceProxy _proxy;
    KAoSAgentDescription desc;

    public void justToCompile() {

	try {
	    AgentRelations myAgentRelations = new AgentRelations(_proxy);

	    System.out.println("----- Relations of agent: - " +
			       desc.getEntityNameAsString() + " -----");

	    System.out.println("It has the following peers:");
	    Vector myPeers =
		myAgentRelations.getPeers(desc.getEntityNameAsString());
	    for (Iterator myPeersIT = myPeers.iterator();
		 myPeersIT.hasNext();) {
		KAoSAgentDescription currentPeer =
		    (KAoSAgentDescription)myPeersIT.next();
		System.out.println(currentPeer.getEntityNameAsString());
	    }

	    System.out.println("It has the following superiors:");
	    Vector mySuperiors =
		myAgentRelations.getSuperiors(desc.getEntityNameAsString());
	    for (Iterator mySuperiorsIT = mySuperiors.iterator();
		 mySuperiorsIT.hasNext();) {
		KAoSAgentDescription currentSuperior =
		    (KAoSAgentDescription)mySuperiorsIT.next();
             
		System.out.println
		    (currentSuperior.getEntityNameAsString());
	    }

	    System.out.println("It has the following subordinates:");
	    Vector mySubordinates =
		myAgentRelations.getSubordinates(desc.getEntityNameAsString());
	    for (Iterator mySubordinatesIT = mySubordinates.iterator();
		 mySubordinatesIT.hasNext();) {
		KAoSAgentDescription currentSubordinate =
		    (KAoSAgentDescription)mySubordinatesIT.next();
		System.out.println
		    (currentSubordinate.getEntityNameAsString());
	    }

	    System.out.println("----- END Relations of agent: - " +
			       desc.getEntityNameAsString() + " -----");
	}
	catch (Exception xcp) {
	    xcp.printStackTrace();
	}
    }

}


