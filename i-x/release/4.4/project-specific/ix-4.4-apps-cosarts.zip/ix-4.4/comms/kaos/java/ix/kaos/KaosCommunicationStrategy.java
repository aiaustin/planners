/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Tue Sep 30 16:19:59 2003 by Jeff Dalton
 * Copyright: (c) 2001, AIAI, University of Edinburgh
 */

package ix.kaos;

// KAoS imports
import edu.uwf.kaos.coabsgrid.KAoSAgentRegistrationHelper;
import edu.uwf.kaos.coabsgrid.KAoSAgentRep;
import com.globalinfotek.coabsgrid.entry.CoABSAgentDescription;
import net.jini.core.entry.Entry;

// KAoS imports for agent relationships
import kaos.core.service.directory.KAoSAgentDirectoryServiceProxy;
import kaos.core.service.directory.KAoSAgentDescription;
import kaos.core.service.directory.query.AgentRelations;
import kaos.core.service.transport.grid.GridKAoSServiceRootImpl;

// Grid imports
import com.globalinfotek.coabsgrid.AgentRegistrationHelper;
import com.globalinfotek.coabsgrid.MessageListener;
import com.globalinfotek.coabsgrid.Message;
import com.globalinfotek.coabsgrid.BasicMessage;
import com.globalinfotek.coabsgrid.AgentRep;
import com.globalinfotek.coabsgrid.entry.AgentRepUIDescriptor;

import java.io.IOException;
import java.awt.event.*;
import javax.swing.*;

import java.util.*;

import ix.grid.GridCommunicationStrategy;

import ix.iface.util.CatchingActionListener;
import ix.iface.util.IFUtil;
import ix.ispace.*;
import ix.icore.IXAgent;
import ix.ip2.Ip2;
import ix.util.*;

/**
 * A class that encapsulates the KAoS knowledge needed for
 * sending and receiving our messages.
 *
 * It uses KAoSAgentRegistrationHelper(String name)
 */
public class KaosCommunicationStrategy extends GridCommunicationStrategy {

    protected KAoSAgentRegistrationHelper reg;

    // Needed for getting agent relationships
    protected KAoSAgentDirectoryServiceProxy dirProxy;
    protected KAoSAgentDescription kdesc;

    public KaosCommunicationStrategy() {
    }

    /**
     * Register as an agent and set up for receiving messages.
     */
    public void setupServer(Object destination, 
			    IPC.MessageListener listener) {

	ipcName = (String)destination; // our name for registering as agent
	ipcListener = listener;
	messageHandler = new IPC.BufferedMessageListener(ipcListener);

        Debug.noteln("Registering KAoS agent", ipcName);
        try {
            reg = new KAoSAgentRegistrationHelper(ipcName);

	    // Needed for getting agent relationships
	    GridKAoSServiceRootImpl sr = new GridKAoSServiceRootImpl();
	    dirProxy = sr.getDirectoryProxy();

            CoABSAgentDescription desc = new CoABSAgentDescription(ipcName);

	    // Set things visible in the CoABS Grid Manager
	    String host = System.getProperty
		("com.globalinfotek.coabsgrid.class.server.machine");
	    String port = System.getProperty
		("com.globalinfotek.coabsgrid.class.server.port");
	    Debug.noteln("Grid class.server is " + host + ":" + port);

	    desc.displayIconURL = "http://" + host + ":" + port + 
		"/ix/resources/images/ip2-logo.gif";
	    desc.documentationURL = "http://www.aiai.ed.ac.uk/project/ix/";
	    desc.architecture = "I-X";
	    desc.description = "I-X Process Panel for "
		+ Util.getUserName() + " at "
		+ getLocalHostName() + " using KAoS";
	    desc.organization = "AIAI, University of Edinburgh";

            Entry[] attributes_ = new Entry[1];
            attributes_[0] = desc;
   
            reg.addAdvertisedCapabilities(attributes_);

	    // /\/: Not sure about the order from here

            reg.registerAgent();

	    kdesc = reg.getAgentDescription();
	    Debug.expect(kdesc != null, "No KAoSAgentDescription");

	    synchronized (this) {
		// Make reg helper known even to other threads.
		setRegistrationHelper(reg);
		reg.addMessageListener(this);
	    }

	    // Setup I-Space functionality
	    ispaceSetup();
        }
        catch (IOException e) {
	    setupFailure(e);
        }
        catch (ClassNotFoundException cnfe) {
            setupFailure(cnfe);
        }
	catch (Throwable t) {
	    setupFailure(t);
	}
    }

    protected void ispaceSetup() {
	// Best to do this in the AWT event thread, because
	// the I-Space tool may call its frame's pack() method
	// then the tool is created, and then we're supposed
	// to change the frame only in the event thread.
	Util.swingAndWait(new Runnable() {
	    public void run() {
		do_ispaceSetup();
	    }
	});
    }

    protected void do_ispaceSetup() {
	// Add an I-Space Tool menu
	IXAgent agent = IXAgent.getAgent();
	ISpaceTool ispace = null;
	try {
	    ispace = (ISpaceTool)agent.ensureTool("I-Space");
	}
	catch (UnsupportedOperationException e) {
	    // No way to get an I-Space tool, so forget about the menu.
	    return;
	}
	JMenu kaosMenu = new JMenu("KAoS");
	ispace.addMenu(kaosMenu);
	kaosMenu.add(IFUtil.makeMenuItem("Update agent relationships",
					 new ActionListener() {
	    public void actionPerformed(ActionEvent event) {
		try {
		    updateAgentRelationships();
		}
		catch (Exception e) {
		    Debug.noteException(e);
		    throw new RethrownException(e);
		}
	    }
	}));
    }

    protected void updateAgentRelationships()
              throws javax.agent.service.directory.NotRegisteredException
    {
	Debug.noteln("Updating agent relationships from KAoS");
	ContactManager contacts = IXAgent.getAgent().getContactManager();
	AgentRelations relations = new AgentRelations(dirProxy);
	String ourName = kdesc.getEntityNameAsString();
	updateAgentRelationships(contacts, AgentRelationship.PEER,
				 relations.getPeers(ourName));
	updateAgentRelationships(contacts, AgentRelationship.SUPERIOR,
				 relations.getSuperiors(ourName));
	updateAgentRelationships(contacts, AgentRelationship.SUBORDINATE,
				 relations.getSubordinates(ourName));
    }

    protected void updateAgentRelationships
                       (ContactManager contacts,
			AgentRelationship rel,
			Vector names) {
	for (Iterator i = names.iterator(); i.hasNext();) {
	    // Agent that is currently in rel.
	    KAoSAgentDescription agentDescr =
		(KAoSAgentDescription)i.next();
	    String agentName = agentDescr.getAgentNickname();
	    Debug.noteln("KAoS says " + agentName + " is a " + rel);
	    contacts.ensureAgent(agentName, rel);
	}
    }

}
