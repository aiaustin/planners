ActionPublisher - a readme for the ActionPublisher handler.

Stephen Potter, AIAI
stephenp@inf.ed.ac.uk
Updated: Tue May 25 17:20:38 2004

ActionPublisher
---------------

The purpose of this code is to write an RDF description of
an "Action Item" (which is actually an (usually, but not 
necessarily atomic) activity on the I-X panel, plus an 
additional RDF file that describes both this action item 
and the event of its creation within the context of some 
meeting. (While it stands in its own right, it is intended 
that this file would be incorporated within a larger 
description of the meeting, describing other meeting events 
etc.)

This description uses the following OWL ontology:
http://i-me.info/resources/coakting/ontology/ix-meeting-support.owl
(also in the local ontology directory), in which the various 
new classes and properties are defined, as well as other AKT
and CoAKTinG ontologies.

The presence of certain keys in the annotations field of the 
activity is used to populate some of the RDF properties, viz:
	 "on: <placee>[;|EOL]"
	 "when: <due>[;|EOL]"
	 "re: <about>[;|EOL]"
So, eg, an activity annotation as follows:
  "on: Edinburgh; re: KRAFT-IX; when: next week"
would result in the terms "Edinburgh", "KRAFT-IX" and "next 
week" being extracted and used to fill the action item 
properties "is-placed-on", "in-regard-to" and "has-target-date" 
respectively.

The file local-properties/action-publisher.props is used to 
provide some additional information; this is an XML file with 
the following structure:

<properties>
	<local-dir>[directory, relative to apps/coakting into dummy Wed Mar 31 11:12:16 2004
which files will be written]</local-dir>
	<base-uri>[the uri to be used as a base for the RDF 
files; hence the root of the target URIs if these files are to 
be published on the web]</base-uri>
        <participant> 
	     <name>[Name of person/organisation participating 
in the meeting]</name>
	     <uri>[the unique uri reference to this person/
organisation in, for example, a Triple Store]</uri>
	</participant>
	<participant>
        ...
        </participant>
<properties>


The <participant> elements are used to replace recognised 
entities in the "on:" field with their URI 'names' for 
automated reasoning purposes.


Use:
----

Add the following line to your .props file:
    additional-handlers=ix.coakting.ActionPublisher

This should have the effect of adding an addition action
"publish this action item" to the menu for each activity
item.
When selected, this has the effect of generating two new
files in the directory <local-dir>:
      action-[longnumber].rdf
and   action-[longnumber]-support.rdf
(the [longnumber] is actually the UNIX time of the files'
creation, here used to make their names unique.)

The first of these files is the actual I-X representation
of the action-item activity.
The second is the supporting description of this action 
item and the event of its creation.      