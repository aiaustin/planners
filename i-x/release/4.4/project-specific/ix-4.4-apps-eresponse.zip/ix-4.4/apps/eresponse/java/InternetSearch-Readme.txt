InternetSearch.txt - a readme for the InternetSearch handler.

Stephen Potter, AIAI, 
stephenp@inf.ed.ac.uk
Updated: Tue May 25 16:52:14 2004

InternetSearch
--------------

As the name suggests, this is a simple handler that invokes a
search engine in an internet browser, using the content of the 
current AgendaItem as the search term.

See/edit local-properties/internet-search.props for details of 
the set-up.



