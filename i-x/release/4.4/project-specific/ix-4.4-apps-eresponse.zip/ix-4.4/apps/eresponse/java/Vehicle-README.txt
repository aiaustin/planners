Vehicle-README.txt
Stephen Potter stephenp@inf.ed.ac.uk
Updated: Thu May 26 20:19:39 2005

This README describes how to invoke a "Vehicle" I-X agent
(ix.eresponse.Vehicle). By generating and sending repeated 
lat-long world state constraints, this agent simulates a 
mobile agent for display on the map tool.

Since a Vehicle is an I-X agent like any other (actually an
extension of IXAgent), then it is invoked in the same manner
as for any I-X agent, but now referring invoking the 
ix.eresponse.Vehicle class, and ensuring that this is on the
classpath (see, for example, scripts\win\run-ix-vehicle.bat).

In addition to the normal I-X parameters, there a number of
additional ones that govern the behaviour of the vehicle:

  -message-target=<agent-id>
	this specifies the destination of the constraint 
messages that the agent sends; <agent-id> might be, for 
example, the jabber id of the 'command' agent which is
monitoring these vehicles.
 
  -begin-lon, -end-lon, -begin-lat, -end-lat
	these specify the begin and end lat-long coordinates
of the vehicle's motion; specified in 'digital' degree format, 
eg. 50.90, rather than 50deg 54min.

  -motion=line|area
	this specifies the type of motion that the vehicle
follows: either along a straight line between the begin and
end points, or else within a rectangular area bounded by the
coordinates.

  -speed
	a number which governs the 'speed' at which the vehicle
covers distance; the value of this parameter will depend, to 
differing extents, on the type of vehicle being simulated, the 
scale of the map and the distance that the vehicle has to
cover (ie. too great a speed, and it will reach the limits of
its motion in one 'step'). Trial and error will be needed, but
lowish values (0.01) recommended for typical applications.


