/* Author: Stephen Potter <stephenp@inf.ed.ac.uk>
 * Updated: Mon Sep 27 16:10:43 2004
 * Copyright: (c) 2004, AIAI, University of Edinburgh
 */

package ix.eresponse;


import java.util.*;
import java.io.IOException;
import java.io.*;
import java.net.*;


public class Weather {

    public Weather() {
	

    }

 


    public static void main(String[] args){
	try{


	    //WeatherServiceCall.getReport("LHR");

	    //Process wp = (Runtime.getRuntime()).exec("C:\\Perl\\bin\\perl.exe D:\\ix-3.2\\apps\\eresponse\\java\\ix\\eresponse\\weather.pl");
       	    Process wp = (Runtime.getRuntime()).exec("C:\\Perl\\bin\\perl.exe -IC:\\Perl\\site\\lib\\SOAP D:\\ix-3.2\\apps\\eresponse\\java\\ix\\eresponse\\test.pl");

	    BufferedReader stdInput = new BufferedReader(new InputStreamReader(wp.getInputStream()));
	    BufferedReader stdError = new BufferedReader(new InputStreamReader(wp.getErrorStream()));

	    System.out.println("Here is the standard output of the command:\n");
	    String s;
	    while ((s = stdInput.readLine()) != null) {
		System.out.println(s);
	    }

  	    System.out.println("Here is the standard error of the command (if any):\n");
  	    while ((s = stdError.readLine()) != null) {
  		System.out.println(s);
  	    }

	    // wp.waitFor();
	}

	catch (Exception e){
	    e.printStackTrace();
	}
    }

    

}
