To run on Unix a lookup test that just prints results

  apps/cosarts/scripts/unix/soap-java ix.cosarts.ClientTest \
      -url=http://charites.cimds.ri.cmu.edu:80/soap/servlet/rpcrouter

or (much simpler)

  apps/cosarts/scripts/unix/client-test
     

To run demo on Unix systems:

  etc/ip2 -external-capabilities=mm-client:lookup-sar-resources \
      -ipc -ipc-name=foo -run-name-server&

  apps/cosarts/scripts/unix/mm-client -ipc -ipc-name=mm-client &

    That script adds a parameter (so you don't need to):

      -url=http://charites.cimds.ri.cmu.edu:80/soap/servlet/rpcrouter

    To run the lookup mm-client using the revised KAoS strategy,
    add a parameter
        -ipc=ix.cosarts.SoapEnforcerKaosCS

  To run with similated lookup:

      apps/cosarts/scripts/unix/mm-client -ipc -ipc-name=mm-client \
          -simulate-lookup &

To compile on Unix:

  apps/cosarts/scripts/unix/soap-javac \
     apps/cosarts/java/ix/cosarts/MMClient.java

To compile the revised KAoS strategy:

  apps/cosarts/scripts/unix/soap-javac \
     apps/cosarts/java/ix/cosarts/SoapEnforcerKaosCS.java


The activity pattern:

  lookup-sar-resources <origin-type> <destination-country>

e.g. the specific pattern for us would be

  lookup-sar-resources sea Arabello


MMClient parameters:

   url    The URL to use for querying the MM.
          This should be set to the following URL by the .bat
          script or the relevant .props file:
          http://charites.cimds.ri.cmu.edu:80/soap/servlet/rpcrouter

   simulate-lookup=true/false, defaults to false
          True to completely simulate the results, not using any
          QueryMMRescueResources class, fallback or otherwise

   initialDelay=seconds, defaults to 5
   delayBetween=seconds, defaults to 3

          The delay parameters have an effect only when
          simulate-lookup=true

   use-fallmack-mm-query=true/false, defaults to false
          instantiate ix.cosarts.FallbackQueryMMRescueResources(mmc)
          instead of cosarts.query.QueryMMRescueResources(mmc)
          where mmc = new MatchMakerProxy(url, debug);


