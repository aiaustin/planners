Simple test of I-Serve communications running on a local Windows machine.

Configuration

1. edit the file scripts/win/run-demo-iroom-comm-server.bat
   - modify the hostname and port parameters to those of the local machine.
NB this host/port needs to be accessible through the firewall!


Running

1. start scripts/win/run-demo-iroom-comm-server.bat
2. start scripts/win/run-demo-iroom-ip2.bat
3. in Ip2, select Tools > I-Serve Communications and "Register"
4. check http://<hostname>:<port>/ipc/status
5. [point SL objects at http://<hostname>:<port>/files/comm-server-url.txt]