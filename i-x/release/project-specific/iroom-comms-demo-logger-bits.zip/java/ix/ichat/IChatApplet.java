/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Tue Dec  1 15:23:01 2009 by Jeff Dalton
 * Copyright: (c) 2009, AIAI, University of Edinburgh
 */

package ix.ichat;

import java.util.*;
import java.util.List;          // resolve conflict with java.awt. /\/
import java.util.concurrent.*;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import ix.iserve.ipc.*;

import ix.iface.util.TranscriptTextPane;
import ix.iface.util.ToolController;
import ix.iface.util.ToolManager;
import ix.iface.util.Reporting;
import ix.iface.util.IFUtil;

import ix.util.*;
import ix.util.http.*;
import ix.util.xml.*;
import ix.util.reflect.*;

/**
 * Basic I-Chat applet.
 */
public class IChatApplet extends JApplet {

    String appletVersion = "I-Chat Applet version 0.2m";

    int textWidth = 85; // used for line-wrapping /\/

    String chatServiceName = "chat-service";

    Transcript transcript;

    InputLine input;

    JLabel whoWhereLabel;

    String locationName;

    AppletCommStrategy ipc = new AppletCommStrategy();

    SendThread<Object> sendThread = null;

    ToolManager toolManager = new ToolManager();

    HttpUtilities httpUtil = new HttpUtilities();

    SimpleDateFormat chatDateFormat = new SimpleDateFormat("HH':'mm':'ss");
    {
	// chatDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
    }

    SimpleDateFormat dayDateFormat =
        new SimpleDateFormat("EEEE, dd MMMM yyyy z");

    int lastNotedDay = 0; // day of year

    // We use the code base rather than the doc base.
    // URL docBase;
    URL codeBase;

    String userName = null;

    volatile boolean needToRegister = true;

    public IChatApplet() {
        Debug.off();            // off, but we'll still note some exceptions
        Debug.noteThreads = true;
        Debug.recordMainFrame(this);
        Debug.setExceptionDescriber(new ExceptionDescriber());
        Parameters.setApplet(this);
        Parameters.setParameter("font-increment", "2");
        ix.iface.util.IFUtil.adjustLookAndFeel();
        // Attempts to get applet parameters throw NullPointerException
        // if we're run from 'main'.
    }

    public static void main(String argv[]) {
	// This more-or-less replicates what happens when we
        // are run as an applet.
        final JFrame frame = new JFrame("Chat Applet");
        final IChatApplet ichat = new IChatApplet();

        Debug.on();
        Parameters.setApplet(null); // no parameters from the applet
        Parameters.processCommandLineArguments(argv);
        String pointer = Parameters.requireParameter("ipc-server-pointer");
        try {
            ichat.codeBase =
                ichat.httpUtil.followServerPointer(pointer)
                     .toURL();
	}
	catch(Exception e) {
	    throw new RethrownException(e);
	}

	// Make sure a "close" doesn't just leave it running in the
	// background...
	frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	frame.addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
		if (Util.dialogConfirms(frame,
		       "Are you sure you want to exit?"))
		    ichat.mainExit();
	    }
	});

        ichat.setPreferredSize(new Dimension(600, 300));
	ichat.init();
	ichat.start();

        frame.setLayout(new BorderLayout());
        frame.add(ichat, BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);

    }

    private void mainExit() {
        System.exit(0);
    }

    @Override
    public void init() {
        try {
            javax.swing.SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    do_init();
                }
            });
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void do_init() {

        appletHistory("init()");

        setJMenuBar(makeMenuBar());

        whoWhereLabel = new JLabel(" " + getLocationName(),
                                   SwingConstants.CENTER);

        transcript = new Transcript();

        input  = new InputLine(textWidth, new InputListener());

        add(whoWhereLabel, BorderLayout.NORTH);

	// transcript.setPreferredSize(new Dimension(400, 150));
        add(new JScrollPane(transcript), BorderLayout.CENTER);

	add(input, BorderLayout.SOUTH);

        if (codeBase == null)	// it's preassigned if we're not an applet /\/
            codeBase = getDocumentBase();

    }

    String getLocationName() {
        if (locationName == null || locationName.equals(""))
            locationName = Parameters.getParameter("location-name", "");
        return locationName;
    }

    @Override
    public void start() {
	appletHistory("start()");
    }

    @Override
    public void stop() {
	appletHistory("stop()");
    }

    @Override
    public void destroy() {
        appletHistory("destroy()");
        ipc.stopReceiving();
        if (sendThread != null)
            sendThread.stopRunning();
    }

    void appletHistory(String methodCalled) {
        Debug.noteln("Applet " + methodCalled + " called.");
    }

    private JMenuBar makeMenuBar() {
	JMenuBar bar = new JMenuBar();

// 	JMenu fileMenu = new JMenu("File");
//	bar.add(fileMenu);

// 	JMenu styleMenu = new JMenu("Style");
// 	bar.add(styleMenu);

        bar.add(toolManager.getToolsMenu());

//      JMenu helpMenu = new JMenu("Help");
// 	bar.add(helpMenu);
//      helpMenu.add(IFUtil.makeMenuItem("About I-Chat Applet", actions);

        return bar;
    }

    void addTool(ToolController tc) {
        toolManager.addTool(tc);
    }

    class InputListener implements InputLineListener {
        public void lineInput(String in) {
            sendChat(in);
        }
    }

    void sendChat(String contents) {
        if (sendThread == null) {
            sendThread = new SendThread<Object>();
            sendThread.start();
        }
        try {
            ensureRegistered();
        }
        catch (Throwable t) {
            ipc.reportProblem("Problem while trying to register", t);
            return;
        }
        if (userName != null) {
            // record.appendLine(userName + ": ", contents);
            // // record.appendLine(userName + ": " + contents);
            /*
            try {
                ipc.transcript("Sending: " + contents);
                ipc.sendObject(chatServiceName,
                               new ChatMessage(contents,
                                               userName));
                input.setText("");
            }
            catch (Throwable t) {
                ipc.reportProblem("Problem while sending", t);
            }
            */
            sendThread.send(new ChatMessage(contents, userName));
        }
    }

    class SendThread<E> extends Thread {

        private volatile boolean keepRunning = true;
        private final BlockingQueue<E> queue = new LinkedBlockingQueue<E>();

        SendThread() {
            setDaemon(true);
        }

        void stopRunning() {
            keepRunning = false;
            this.interrupt();
        }

        void send(E message) {
            try {
                queue.put(message);
            }
            catch (InterruptedException e) {
                ipc.reportProblem("Problem when sending", e);
            }
        }

        public void run() {
            while (keepRunning) {
                try {
                    handle(queue.take());
                }
                catch (InterruptedException e) {
                }
                catch (ThreadDeath t) {
                    throw t;
                }
                catch (Throwable t) {
                    ipc.reportProblem("Problem while sending", t);
                }
            }
        }

        public void handle(E messageContents) {
            // ipc.transcript("Sending: " + messageContents);
            ipc.sendObject(chatServiceName, messageContents);
            Util.swingAndWait(new Runnable() {
                    public void run() {
                        input.setText("");
                    }
                });
        }

    }

    void ensureRegistered() {
        if (!needToRegister) {
            return;
        }
        boolean isFirstTime = userName == null;
        String defaultName = userName == null ? "" : userName;
        String name = Util.showInputDialog(null, "Enter your name",
                                           defaultName);
        if (name == null)
            return;
        name = name.trim();
        if (name.equals(""))
            return;
        setUserName(name);
        if (isFirstTime)
            startCommunicationStrategy(); // will also register
        else {
            ipc.register(name);
            sendChat(userName + " is again available for chat via I-Say.");
        }
    }

    void setUserName(String name) {
        userName = name;
        getLocationName(); // /\/
        whoWhereLabel.setText
            (name + (locationName.equals("") ? ""
                     : " - " + locationName));
    }

    class ExceptionDescriber implements Fn1<Throwable,String> {
        public String funcall(Throwable t) {
            String result = Debug.defaultDescribeException(t);
            return Strings.replace("Exception:", " problem:", result);
        }
    }

    class MessageListener implements IPC.MessageListener {

	public void messageReceived(final IPC.InputMessage message) {
            Util.swingAndWait(new Runnable() {
                public void run() {
                    Object contents = message.getContents();
                    if (contents instanceof ChatMessage)
                        newChatMessage((ChatMessage)contents);
                    else
                        newMessage(message);
                }
            });
        }

        private void newMessage(IPC.InputMessage message) {
            transcript.appendLine(Reporting.messageDescription(message));
        }

    }

    private void newChatMessage(ChatMessage chat) {
//      transcript.appendLine(chat.getSenderId() + ": ",
//                            chat.getText());
        Date sendDate = (Date)chat.getAnnotation(ipc.SEND_DATE);
        String prefix = sendDate == null
            ? ""
            : chatDateFormat.format(sendDate);
        String sender = chat.getSenderId().toString();
        String text = chat.getText();
        Color senderColor = Color.darkGray;
        Color textColor = Color.blue;
        // Adjust for relayed chat.
        if (agentIsRelayer(sender) && text.indexOf(":") > 0) {
            sender = Strings.beforeFirst(":", text).trim();
            text = Strings.afterFirst(":", text).trim();
            // sender = "(" + sender + ")";
            senderColor = Color.gray;
        }
        if (sendDate != null)
            noteIfNewDay(sendDate);
        transcript.appendChat(prefix, sender, senderColor, text, textColor);
    }

    private void noteIfNewDay(Date now) {
        Calendar cal = dayDateFormat.getCalendar();
        cal.setTime(now);
        int day = cal.get(Calendar.DAY_OF_YEAR);
        // Will work across year boundaries if messages are frequent enough.
        if (day > lastNotedDay || day < (lastNotedDay - 300)) {
            lastNotedDay = day;
            transcript.append(dayDateFormat.format(now) + "\n");
        }
    }

    private boolean agentIsRelayer(String agentName) {
        return agentName.indexOf("Relay") > -1
            || agentName.indexOf("relay") > -1;
    }

    static interface InputLineListener {
        public void lineInput(String input);
    }

    static class InputLine extends JTextField {

        InputLineListener listener;

        InputLine(int width, InputLineListener listener) {
            // super(width);
            super();
            this.listener = listener;
            addActionListener(new EnterListener());
        }

        class EnterListener implements ActionListener {
            public void actionPerformed(ActionEvent event) {
                String in = getText();
                listener.lineInput(in);
                // setText("");
            }
        }
    
    }

    class Transcript extends TranscriptTextPane {

        private String indent = "     ";

        Transcript() {
            super();
            setEditable(false);
        }

        @Override
        public void append(String text) {
            append(Color.black, text);
        }

        @Override
        public void append(Color c, String text) {
            super.append(c, text);
            // Try to make it show the end of the text and hence the
            // stuff we just appended.  /\/: Why isn't this necessary
            // in the Messenger?
            setCaretPosition(getStyledDocument().getLength());
        }

        public void appendChat(String prefix, 
                               String sender, Color senderColor,
                               String text, Color textColor) {
            text = text.trim();
            append(Color.lightGray, prefix + " ");
            append(senderColor, sender + ": ");
            int maxLen = textWidth - (prefix.length() + 1 +
                                      sender.length() + 2);
            while (true) {
                if (text.length() <= maxLen) {
                    append(textColor, text + "\n");
                    return;
                }
                int i = text.lastIndexOf(' ', maxLen);
                if (i == -1) {
                    append(textColor, text + "\n");
                    return;
                }
                String start = text.substring(0, i);
                String rest = text.substring(i+1);
                append(textColor, start + "\n");
                text = rest;
                append(indent);
                maxLen = textWidth - indent.length();
            }
        }

        /*
        public void appendLine(String prefix, String line) {
            // int maxLen = getColumns() - prefix.length() - 1;
            int maxLen = textWidth - prefix.length() - 1;
            if (line.length() <= maxLen)
                append(prefix + line + "\n");
            else {
                int i = line.lastIndexOf(' ', maxLen);
                if (i == -1)				// no space
                    append(prefix + line + "\n");
                else {
                    String start = line.substring(0, i);
                    String rest = line.substring(i+1);
                    append(prefix + start + "\n");
                    appendLine("     ", rest);
                }
            }
        }
        */

    }

    /*
     * Comm strategy
     */

    protected void startCommunicationStrategy() {
        Debug.expect(userName != null,
                     "Trying to start comms without a user name.");
//         Debug.expect(ipc == null,
//                      "Trying to start comms twice.");
//         ipc = new AppletCommStrategy();
//         try {
            ipc.setupServer(userName,
                            new MessageListener());
            ipc.register(userName); // will also start receiving
            sendChat(userName + " is available for chat via I-Say.");
//         }
//         catch (Exception e) {
//             Debug.displayException
//                 ("Problem while trying to start commmunications", e);
//         }
    }

    class AppletCommStrategy extends XIServeCommStrategy {

        // /\/: The IServeCommStrategy transcript(String) method
        // writes to the comm tool's transcript area, not the main one.

        AppletCommStrategy() {
            super();
            this.ableToSend = false;
        }

        @Override
        public void setupServer(Object destination, 
                                IPC.MessageListener listener) {
            super.setupServer(destination, listener);
            // register((String)destination); // destination == userName.
        }

        @Override
        protected String getAgentName() {
            Debug.expect(userName != null, "no user name");
            return userName;
        }

        @Override
        protected void installCommTool() {
            String title = getAgentName() 
                            + " I-Serve Communications";
            ToolController tc =
                new XIServeCommTool.Controller(this, title);
            IChatApplet.this.addTool(tc);
            tc.ensureTool();
            Debug.expect(tool != null);
            /*
            Util.swingAndWait(new Runnable() {
                public void run() {
                    tool.register();
                }
            });
            */
        }

        @Override
        protected void initialCommToolTranscript() {
            super.initialCommToolTranscript();
            tool.transcript(appletVersion);
            // tool.transcript("Send client " + sendClient);
        }

        @Override
        protected URI determineServerBase() {
            int serverPort = codeBase.getPort(); // -1 == no port
            if (serverPort > 80) {
                return URI.create
                    ("http://" + codeBase.getHost() +
                     ":" + serverPort +
                     "/");
            }
            else {
                // throw new RuntimeException("Can't determine server base");
                return makeForwardingServerBase();
            }
        }

        URI makeForwardingServerBase() {
            try {
                URI base = codeBase.toURI();
                return base.resolve("ipc.php/");
            }
            catch (URISyntaxException e) {
                throw new RethrownException(e);
            }
        }

        @Override
        protected HttpObjectClient makeSendClient() {
            return new AppletHttpClient();
        }

        @Override
        protected HttpObjectClient makeReceiveClient() {
            return new AppletHttpClient();
        }

        class AppletHttpClient extends HttpObjectClient {

            private final XMLTranslator appletXmlt = makeAppletXMLTranslator();

            @Override
            protected Object decodeReceived(String contents) {
                // We have to catch exceptions and also make sure we
                // use our own XML translator rather than the one in
                // HttpUtilities.
                try {
                    // return super.decodeReceived(contents);
                    if (contents == null)
                        return null;
                    else
                        return appletXmlt.objectFromXML(contents);
                }
                catch (Exception e) {
                    Debug.forceln("Problem parsing " +
                                  Strings.quote(contents));
                    throw new RethrownException(e);
                }
            }

            XMLTranslator makeAppletXMLTranslator() {
                XMLConfig config = new ix.ip2.Ip2XMLConfig();
                ClassSyntax syntax = config.defaultClassSyntax();
                ClassFinder finder = syntax.getClassFinder();
                finder.preLoad(config.xmlSyntaxClasses(syntax, Object.class));
                finder.preLoad(Arrays.asList(List.class, Map.class));
                return new CompactXMLTranslator(syntax);
            }

        }

        @Override
        public void register(String password) {
            try {
                super.register(password);
                needToRegister = false;
            }
            catch (Throwable t) {
                // reportProblem("Problem while trying to register", t);
                needToRegister = true;
                throw new RethrownException
                    ("Problem while trying to register:", t);
            }
        }

        @Override
        protected synchronized void startReceiving() {
            super.startReceiving();
        }

        @Override
        protected synchronized void stoppedReceiving() {
            super.stoppedReceiving();
            needToRegister = true;
        }

        @Override
        public void reportProblem(String prefix, Throwable t) {
            transcript(prefix + ": " + Debug.describeException(t));
            Debug.displayException(prefix, t);
        }

        @Override
        protected void reportIdentityCheckFailure(HttpRequestException e) {
            String[] message = new String[] {
                "Request refused because it had the wrong host or uuid.",
                "This can happen if you have changed machines of it someone",
                "else is trying to use the same name."
            };
            needToRegister = true;
            transcript(Strings.joinLines(message));
            Util.displayAndWait(IChatApplet.this, message);
        }

    }

}
