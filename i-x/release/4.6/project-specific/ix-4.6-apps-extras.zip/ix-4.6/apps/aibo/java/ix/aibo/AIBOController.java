/* Author: Stephen Potter <stephenp@inf.ed.ac.uk> and Jeff Dalton
 * Updated: Thu Mar 02 16:01:21 2006
 * Copyright: (c) 2004, AIAI, University of Edinburgh
 */

package ix.aibo;
import ix.util.*;
import ix.util.lisp.*;
import ix.icore.*;
import ix.icore.domain.*;
import ix.iface.util.*;
import ix.ichat.*;

import java.util.*;

import liburbi.UClient;

public class AIBOController extends IXAgent {

    static public UClient client = null;

    static public String address = null;

    public AIBOController() {
	super(); 
    }

    // Next few methods copied from JD's IQuery code:

    /**
     * Command-line argument processing.
     */
    protected void processCommandLineArguments() {
  	if(Parameters.haveParameter("aibo-address"))
  	    address = Parameters.getParameter("aibo-address");
  	else{ 
	    address = "localhost";
  	}
	super.processCommandLineArguments();
    }

    /**
     * Agent setup and initialization.
     * The method supplied by the IQuery class just
     * calls {@link #setupGUI()} in the AWT event thread.
     *
     * @see IXAgent#startup()
     */
    protected void startup() {
	Util.swingAndWait(new Runnable() {
	    public void run() {
		setupGUI();
	    }
	});
    }

    /**
     * Creates a "transcript" frame for this agent, including
     * an "Exit" button.
     */
    protected void setupGUI() {
	// This is optional.  We could just let the first incoming message
	// cause the text frame to be created.  But this way we can make it
	// appear right away and can add an "Exit" button.


	String framename = ipcName;
//  	if(Parameters.haveParameter("jabber-resource"))
//  	    framename = Parameters.getParameter("jabber-resource");
//  	else{ // if no jabber-resource use symbol-name instead?
//  	    if(Parameters.haveParameter("symbol-name"))
//  		vehiclename = Parameters.getParameter("symbol-name");
//  	}

	textFrame = new TextAreaFrame("Messages for " + framename,
				      new String[] { "Exit" } );
	textFrame.setFoldLongLines(0);
	textFrame.addToolManager();
	textFrame.addListener(new TextAreaFrame.TListener() {
	    public void buttonPressed(String action) {
		if (action.equals("Exit"))
		    if (Util.dialogConfirms
			    (textFrame, "Are you sure you want to exit?"))
			exit();
	    }
	});
    }

    /**
     * Called when the agent should cease execution.
     */
    public void exit() {
	System.exit(0);
    }

    public void addTool(ToolController tc) {
	textFrame.addTool(tc);
    }


    
//      public static double abs(double ent){
//  	if(ent<0) return -ent;
//  	else return ent;
//      }

//      public static void sendConstraint(String att, Object val){
//  	    LListCollector pattern = new LListCollector();
//  	    pattern.add(Symbol.intern(att));
//  	    pattern.add(Symbol.intern(vehiclename));
//  	    PatternAssignment pa = new PatternAssignment(pattern.contents(),val);
//  	    LListCollector lonp = new LListCollector();
//  	    lonp.add(pa);

//  	    try{
//  		//JabberCommunicationStrategy.getTheStrategy().sendObject(target, new Constraint("world-state", "effect",lonp.contents()));
//  		IPC.getCommunicationStrategy().sendObject(target, new Constraint("world-state", "effect",lonp.contents()));

//  	    }
//  	    catch (Exception e){
//  		e.printStackTrace();
//  	    }
//      }

//      public static double round(double val){
//  	// rounds val to dp decimal places
//  	double dp = 4;
//  	double mult = Math.pow(10,dp);
//  	return (double) (Math.round(val*mult))/mult;
//      }

    public static void main(String[] args){
	new AIBOController().mainStartup(args);

	// would want to replace this with the actual location of the bot:
	Debug.noteln("Initiating client connection to "+address); 
	client = new UClient(address);
	//super.processCommandLineArguments();
	//try{
	    //  client.send("speaker.play(\"client.wav\");");
	//}
	//catch(Exception e){
	//   Debug.noteln(e.toString());
	//}
    }

    public void handleNewActivity(Activity activity){

	Debug.noteln("Received activity");
	String verb =  (activity.getVerb()).toString();
	Debug.noteln("Verb:"+verb);
	// this assumes only a single parameter:
	String parameter = ((activity.getParameters()).elementAt(0)).toString();
	Debug.noteln("Parameter:"+ parameter);

	try{
	    Debug.noteln("Trying to "+verb+"...");
	    if(verb.equalsIgnoreCase("walk"))
	       client.send("robot.walk("+parameter+");");
	    else if(verb.equalsIgnoreCase("stopwalk"))
		client.send("robot.stopwalk();");
	    else if(verb.equalsIgnoreCase("turn"))
		client.send("robot.turn("+parameter+");");
	    else if(verb.equalsIgnoreCase("stopturn"))
		client.send("robot.stopturn();");
	    else if(verb.equalsIgnoreCase("sit"))
		client.send("robot.sit();");
	    else if(verb.equalsIgnoreCase("beg"))
		client.send("robot.beg();");
	    else if(verb.equalsIgnoreCase("stand"))
		client.send("robot.stand();");
	    else if(verb.equalsIgnoreCase("initiate"))
		client.send("robot.initial();");
	    else if(verb.equalsIgnoreCase("lie"))
		client.send("robot.lay();");
	    else if(verb.equalsIgnoreCase("stretch"))
		client.send("robot.stretch();");
	    else if(verb.equalsIgnoreCase("urbi-execute"))
		client.send(parameter);
	    else 
		Debug.noteln("Don't recognise verb "+verb);
	    
	    // else ignore!
	}
	catch(Exception e){
	    Debug.noteln(e.toString());
	}
    }


    public void handleNewIssue(Issue issue){

	Debug.noteln("Received issue");
	try{
	    //client.send("robot.turn(2s)");
	}
	catch(Exception e){
	    Debug.noteln(e.toString());
	}
    }


    public void handleNewConstraint(Constraint constraint){
	Debug.noteln("Received constraint");
    }

    public void handleNewReport(Report report){
	Debug.noteln("Received report");
    }

    public void handleNewChatMessage(ChatMessage message){
	Debug.noteln("Received chat message");
    }
}
