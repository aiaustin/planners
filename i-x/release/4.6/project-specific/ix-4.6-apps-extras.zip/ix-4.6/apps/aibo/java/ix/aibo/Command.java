/*! \file Command.java
 *******************************************************************************

 File: Command.java
 Implementation of the Command class.

 This file is part of 
 liburbi
 (c) Bastien Saltel, 2004.

 Permission to use, copy, modify, and redistribute this software for
 non-commercial use is hereby granted.

 This software is provided "as is" without warranty of any kind,
 either expressed or implied, including but not limited to the
 implied warranties of fitness for a particular purpose.

 For more information, comments, bug reports: http://urbi.sourceforge.net

 **************************************************************************** */

package ix.aibo;

import java.io.IOException;

import liburbi.call.URBIEvent;
import liburbi.call.UCallbackListener;

import liburbi.UClient;

public class	Command implements UCallbackListener
{
	public Command()
	{
	}

	public void		actionPerformed(URBIEvent event)
	{
		try
			{
				URBIaiai.d.effectiveSend(event.getTag() + ".val = " + event.getCmd() + ";");
			}
		catch (IOException e)
			{
				System.err.println("Exception while sending " + e.getMessage());
				System.exit(1);
			}
	}
}
