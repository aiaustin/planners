%% README.txt by Stephen Potter
%% Updated: Mon Jan 05 18:28:55 2004


INFORMATION:
------------

This directory contains the code for an I-X notification agent,
which, acting as a jabber client, listens for particular I-X 
messages and responds appropriately. These messages are of the
form:

pilot notification:

  notify SAR-Mission-1 USMarineHelicopter-1 "AustinTate" 18.0 40.0 GawhadEl Arabello

hospital administrator notification:

  notify SAR-Mission-1 USMarineHelicopter-1 GawhadEl "AustinTate" burns

(It can take symbols or strings for most parameters.) 

The main class, IXNotification.class, is initiated with 5 
parameters, which are, in order:

- the filename of the XML stylesheet (used to convert incoming 
  messages into Jess facts). See XML2Jess.xls in the current 
  directory.
- the filename of the initial Jess knowledge base. See KB.clp
  in the current directory. The contents of this knowledge 
  base govern the responses of the agent, including the 
  destination of its messages. (Near the top of this file,
  some names are associated through Jess facts with 'live' 
  jabber ids for messaging: this list can be altered, as 
  appropriate. Also, two additional facts new-default-pilot-id
  and new-default-hospital-id are used for determining the
  destination of pilot messages and hospital messages, 
  respectively, when the supplied name fails to match a known
  id.)
- a jabber username for running this agent.
- the jabber server with which the username is registered.
- the password for this jabber account.

The agent is given the resource name "Home" when logged onto
the server.

The following account has been created expressly for use with 
this agent (and is hardwired into the batch file):
  username: CMUNotifier
  server: jabber.org 
  password: jabber



RUNNING:
--------

To run under Windows using the above-mentioned options, simply
double-click on runNotifier.bat




