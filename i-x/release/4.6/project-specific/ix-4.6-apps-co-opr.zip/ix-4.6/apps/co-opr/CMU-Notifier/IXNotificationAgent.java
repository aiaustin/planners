// *************************************************************************************************
// * IXNotificationAgent.java
// *
// * Copyright (c) 2002 , M-Commerce Lab @ Carnegie Mellon University
// *           MyCampus Project All rights reserved.
// *
// * Title:				IXNotificationAgent
// * @author			Fabien L. Gandon
// * @version 			1.0 
// * @last modified		04/17/03
// *
// *************************************************************************************************
import java.io.*;

/**
 * IXNotificationAgent
 *
 * Shallow agent to show how to extend CMUNotificationAgent
 *
 * @author <A HREF="mailto:Fabien.Gandon@cs.cmu.edu">Fabien GANDON</A>, <A href="http://www-2.cs.cmu.edu/~sadeh/Mobile%20Commerce%20Lab.htm">Mobile Lab.</A>, <A href="http://www.cmu.edu/">CMU</A>, 17 April 2003
 * @version 1.0
 * @since JDK1.4
 */
public class IXNotificationAgent extends CMUNotificationAgent
{

  /* Start agent and initialize stylesheet for XML to CLIPS translation
   * and Knowledge Base with logical rules.
   * <BR />
   * @param p_XSLTPath paths for XSLT stylesheet.
   * @param p_KBPath paths for initial knowledge base.
   * @param p_JabberID Jabber account ID for the agent.
   * @param p_JabberPassword Jabber account password for the agent.
   */ 
  public IXNotificationAgent(String p_XSLTPath, String p_KBPath, String p_JabberID, String p_JabberServer, String p_JabberPassword)
  {
    super(p_XSLTPath,p_KBPath,p_JabberID,p_JabberServer,p_JabberPassword);
  }

  // Overwritte to send reports
  public void report(String p_Recipient, String p_Activity, String p_Status, String p_Comment)
  {
    String l_msg= "<message xmlns='jabber:client' from='"+getID()+"' type='normal' to='"+p_Recipient+"'>\n" +
      "<body>&lt;?xml version='1.0' encoding='UTF-8'?&gt;\n"+
      "  &lt;report xmlns='http://www.aiai.ed.ac.uk/project/ix/' report-type='"+p_Status+"' priority='normal'"+
      "   sender-id='"+getID()+"' ref='"+p_Activity+"'&gt;\n"+
      "   &lt;text&gt;\n"+
      "    &lt;string&gt;"+p_Comment+"&lt;/string&gt;\n"+
      "   &lt;/text&gt;\n"+
      "  &lt;/report&gt;\n"+
      " </body>\n</message>\n";
    sendMessage(new StringReader(l_msg));
    System.out.println(l_msg);
  }

  // Testing
  public static void main(String[] arg)
  {
    IXNotificationAgent Agent = new IXNotificationAgent(arg[0],arg[1],arg[2],arg[3],arg[4]);
  }

}
