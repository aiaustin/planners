/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Sat Feb 23 00:17:16 2008 by Jeff Dalton
 * Copyright: (c) 2001, 2008, AIAI, University of Edinburgh
 */

// Edited 21 Feb 2008 by JD to remove KAoS references.

package ix.cosarts;

// New imports from Shri:
import cosarts.enforcer.*;

// import ix.kaos.KaosCommunicationStrategy;

import ix.util.*;

/**
 * A class that encapsulates the KAoS knowledge needed for
 * sending and receiving our messages.
 *
 * It uses KAoSAgentRegistrationHelper(String name)
 */
public class SoapEnforcerKaosCS /* extends KaosCommunicationStrategy */ {

    public SoapEnforcerKaosCS() {
    }

    /**
     * Register as an agent and set up for receiving messages.
     */
    public void setupServer(Object destination, 
			    IPC.MessageListener listener) {

	/*
	super.setupServer(destination, listener);

	//Shri:
	KAoSSoapEnforcer.setAgentDescription(kdesc);
	*/

    }

}
