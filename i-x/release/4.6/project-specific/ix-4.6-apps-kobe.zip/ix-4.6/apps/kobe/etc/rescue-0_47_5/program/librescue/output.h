/*
 * Copyright (c) 2005, The Black Sheep, Department of Computer Science, The University of Auckland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of The Black Sheep, The Department of Computer Science or The University of Auckland nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 Contributors and list of changes:

 Cameron Skinner
   Converted original Robocup Rescue software into librescue
*/

#ifndef RESCUE_OUTPUT_H
#define RESCUE_OUTPUT_H

#include "common.h"
#include <string>
#include <stdio.h>

namespace Librescue
{
	class Output {
	protected:
	  Bytes m_bytes;
	  int m_index;

	public:
		Output();
		~Output();
		
		void clear();
		
		Cursor cursor() const;
		void setCursor(Cursor cursor);

		Cursor writeInt32(INT_32 value);
		Cursor writeInt32(INT_32 value, Cursor position);
		// Write some bytes from a buffer
		Cursor write(int size, Bytes& bytes);
		Cursor write(int size, Byte* bytes);
		Cursor write(Bytes& bytes);
		Cursor write(Output& output);
		// Write a null-terminated string.
		Cursor writeString(const char* string);
		// Write a string.
		Cursor writeString(std::string string);
		// Write exactly "size" bytes from "string".
		Cursor writeString(const char* string, INT_32 size);
		// Fill in the "size" field - this writes the value of cursor()-base at location base, then sets the cursor back to where it was.
		Cursor writeSize(Cursor base);

		const Bytes& buffer() const;
		int size() const;
		void log(FILE* file) const;
	};

	void writeGK_CONNECT_OK(Output& output, Objects objects);
	void writeGK_CONNECT_ERROR(Output& output, char* reason);
	void writeGK_CONNECT_ERROR(Output& output, std::string reason);
	void writeKG_CONNECT(Output& output, INT_32 version);
	void writeKG_ACKNOWLEDGE(Output& output);
	void writeKG_UPDATE(Output& output, INT_32 time, Objects update);
	void writeSK_CONNECT(Output& output, INT_32 version);
	void writeSK_ACKNOWLEDGE(Output& output);
	void writeSK_UPDATE(Output& output, Objects update);
	void writeKS_CONNECT_OK(Output& output, Objects objects);
	void writeKS_CONNECT_ERROR(Output& output, char* reason);
	void writeKS_CONNECT_ERROR(Output& output, std::string reason);
	void writeKS_COMMANDS(Output& output, INT_32 time, Commands commands);
	void writeKS_UPDATE(Output& output, INT_32 time, Objects update);
	void writeVK_CONNECT(Output& output, INT_32 version);
	void writeVK_ACKNOWLEDGE(Output& output);
	void writeKV_CONNECT_OK(Output& output, Objects objects);
	void writeKV_CONNECT_ERROR(Output& output, char* reason);
	void writeKV_CONNECT_ERROR(Output& output, std::string reason);
	void writeKV_UPDATE(Output& output, INT_32 time, Objects update);
	void writeAK_CONNECT(Output& output, INT_32 version, INT_32 tempID, AgentType type);
	void writeAK_ACKNOWLEDGE(Output& output, Id id);
	void writeKA_CONNECT_OK(Output& output, INT_32 tempID, Id id, RescueObject& self, Objects knowledge);
	void writeKA_CONNECT_ERROR(Output& output, char* reason);
	void writeKA_CONNECT_ERROR(Output& output, std::string reason);
	void writeKA_SENSE(Output& output, Id id, INT_32 time, RescueObject& self, Objects update);
	void writeKA_HEAR(Output& output, Id to, Id from, INT_32 length, char* data);
	void writeKA_HEAR_SAY(Output& output, Id to, Id from, INT_32 length, char* data);
	void writeKA_HEAR_TELL(Output& output, Id to, Id from, INT_32 length, char* data);
	void writeAK_REST(Output& output, Id id);
	void writeAK_MOVE(Output& output, Id id, Ids route);
	void writeAK_SAY(Output& output, char* message, INT_32 length, Id sender);
	void writeAK_TELL(Output& output, char* message, INT_32 length, Id sender);
	void writeAK_EXTINGUISH(Output& output, Id id, Id target, INT_32 direction, INT_32 nozzleX, INT_32 nozzleY, INT_32 water);
	void writeAK_EXTINGUISH(Output& output, Id id, Id target, INT_32 water);
	void writeAK_RESCUE(Output& output, Id id, Id target);
	void writeAK_LOAD(Output& output, Id id, Id target);
	void writeAK_UNLOAD(Output& output, Id id);
	void writeAK_CLEAR(Output& output, Id id, Id target);
} //namespace rescue;

#endif // !defined ...
