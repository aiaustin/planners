#include "simBlockage.h"

 /*************************************************
 |����    | �ĺ���ʿ���� dbar | �ĺ���ɸ���к� Sd |
 |-------------------------------------------------
 |5�ʲ�   | 0 mm              | 0 mm              |
 |6       | -820              | 1570              |
 |7       | 1270              | 3140              |
 |Ķ����7 | 4480              | 3290              |
 *************************************************/

#define  AVRFIX5  0  
#define  AVRFIX6  -0.9
#define  AVRFIX7  -3
#define  AVRFIX8  -4.3

void initArea(areaProperty *areaPtr){

  areaPtr->areaRNum = 0 + AVRFIX5;
  areaPtr->avrBlock = 0;
  areaPtr->hhBlock = 0;
  areaPtr->sumBroken = 0;
  areaPtr->avrBroken = 0;
  areaPtr->hhBroken = 0;

  (areaPtr+1)->avrBlock = -820.0 + AVRFIX6;;
  (areaPtr+1)->hhBlock = 1570.0;
  (areaPtr+1)->areaRNum = 0;
  (areaPtr+1)->sumBroken = 0;
  (areaPtr+1)->avrBroken = 0;
  (areaPtr+1)->hhBroken = 0;

  (areaPtr+2)->avrBlock = 1270.0 + AVRFIX7;
  (areaPtr+2)->hhBlock = 3140.0;
  (areaPtr+2)->areaRNum = 0;
  (areaPtr+2)->sumBroken = 0;
  (areaPtr+2)->avrBroken = 0;
  (areaPtr+2)->hhBroken = 0;

  (areaPtr+3)->avrBlock = 4480.0 + AVRFIX8;
  (areaPtr+3)->hhBlock = 3290.0;
  (areaPtr+3)->areaRNum = 0;
  (areaPtr+3)->sumBroken = 0;
  (areaPtr+3)->avrBroken = 0;
  (areaPtr+3)->hhBroken = 0;
}
