package viewer.object;

public class PoliceOffice extends Building {
  public PoliceOffice(int id) { super(id); }
  public int type() { return TYPE_POLICE_OFFICE; }
}
