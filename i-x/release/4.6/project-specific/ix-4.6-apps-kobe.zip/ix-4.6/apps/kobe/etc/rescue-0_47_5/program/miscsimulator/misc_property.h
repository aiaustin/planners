/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#ifndef MISC_HUMANOID_DATA_H
#define MISC_HUMANOID_DATA_H

#include <iostream>
#include "common.h"

using namespace std;
using namespace Librescue;

namespace Rescue{
  //////////////////////////////////////////////////////////////////////////////////////

  ////////////////////////////////////////////////////////////////////////////////
  // class MiscProperty // {
  // Humanoid ���饹���ɲä��������ץ��ѥƥ�
  class MiscProperty
	{
	public:
	  double m_damageBury;
	  INT_32 m_timeDamageBuryUpdated;
	  double m_damageBroken;
	  INT_32 m_timeDamageBrokenUpdated;
	  double m_damageFiery;
	  INT_32 m_timeDamageFieryUpdated;
	  double m_damageBlock;
	  INT_32 m_timeDamageBlockUpdated;
	  double m_damage;
	  INT_32 m_timeDamageUpdated;
	  INT_32 m_hpShrinkage;
	  INT_32 m_timeHpShrinkageUpdated;

	public:
	  double damageBury() const { return m_damageBury; }
	  void setDamageBury(INT_32 time, double value) {
		m_damageBury = value; m_timeDamageBuryUpdated = time; }
	  INT_32 getTimeDamageBuryUpdated() { return m_timeDamageBuryUpdated; }
	  double damageBroken() const { return m_damageBroken; }
	  void setDamageBroken(INT_32 time, double value) {
		m_damageBroken = value; m_timeDamageBrokenUpdated = time; }
	  INT_32 getTimeDamageBrokenUpdated() { return m_timeDamageBrokenUpdated; }
	  double damageFiery() const { return m_damageFiery; }
	  void setDamageFiery(INT_32 time, double value) {
		m_damageFiery = value; m_timeDamageFieryUpdated = time; }
	  INT_32 getTimeDamageFieryUpdated() { return m_timeDamageFieryUpdated; }
	  double damageBlock() const { return m_damageBlock; }
	  void setDamageBlock(INT_32 time, double value) {
		m_damageBlock = value; m_timeDamageBlockUpdated = time; }
	  INT_32 getTimeDamageBlockUpdated() { return m_timeDamageBlockUpdated; }
	  double damage() const { return m_damage; }
	  void setDamage(INT_32 time, double value) {
		m_damage = value; m_timeDamageUpdated = time; }
	  INT_32 getTimeDamageUpdated() { return m_timeDamageUpdated; }
	  INT_32 hpShrinkage() const { return m_hpShrinkage; }
	  void setHpShrinkage(INT_32 time, INT_32 value) {
		m_hpShrinkage = value; m_timeHpShrinkageUpdated = time; }
	  INT_32 getTimeHpShrinkageUpdated() { return m_timeHpShrinkageUpdated; }

	public:
	  MiscProperty(){
#ifdef MISC_DEBUG_1 // {
		cout << "## MiscProperty() constructor\n";
		cout << "## before constructor\n";
		outputLog();
#endif // } (MISC_DEBUG_1)

		init_value();
	  }

	  void init_value(){
		m_damageBury = 0;
		m_damageBroken = 0;
		m_timeDamageBuryUpdated = 0;
		m_damageFiery = 0;
		m_timeDamageFieryUpdated = 0;
		m_damageBlock = 0;
		m_timeDamageBlockUpdated = 0;
		m_damage = 0;
		m_timeDamageUpdated = 0;
		m_hpShrinkage = 0;
		m_timeHpShrinkageUpdated = 0;
	  }

	  ~MiscProperty() { }

	  void outputLog(){
		cout << "damageBury: " << damageBury() << "\n"
			 << "damageBroken: " << damageBroken() << "\n"
			 << "damageFiepry: " << damageFiery() << "\n"
			 << "damage: " << damage() << "\n"
			 << "hpShrinkage: " << hpShrinkage() << "\n";
		fflush(stdout);
	  }

	  void outputLog2(){
		cout << "damageBury: " << m_damageBury << "\n"
			 << "damageBroken: " << m_damageBroken << "\n"
			 << "damageFiepry: " << m_damageFiery << "\n"
			 << "damage: " << m_damage << "\n"
			 << "hpShrinkage: " << m_hpShrinkage << "\n";
		fflush(stdout);
	  }
	private:
	  MiscProperty(const MiscProperty&);
	  MiscProperty& operator=(const MiscProperty&);
	  bool operator==(const MiscProperty&) const;
	};
  // } class MiscProperty
  ////////////////////////////////////////////////////////////////////////////////

} // namespace Rescue

#endif // } !defined(MISCPROPERTY_HXX_INCLUDED)
