/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

// RescueSystem.hxx
//
/////////////////////////////////////////////////////////////////////////////

#ifndef RESCUESYSTEM_H
#define RESCUESYSTEM_H

#include "System.hxx"
#include "../librescue/objects.h"
#include "../librescue/common.h"

using namespace Librescue;

namespace Rescue
{
  /////////////////////////////////////////////////////////////////////////
  // RescueSystem
  const TypeId agentTypes[] = {
	TYPE_CIVILIAN,
	TYPE_FIRE_BRIGADE,
	TYPE_FIRE_STATION,
	TYPE_AMBULANCE_TEAM,
	TYPE_AMBULANCE_CENTER,
	TYPE_POLICE_FORCE,
	TYPE_POLICE_OFFICE
  };
  enum {
	AGENTTYPE_CIVILIAN,
	AGENTTYPE_FIRE_BRIGADE,
	AGENTTYPE_FIRE_STATION,
	AGENTTYPE_AMBULANCE_TEAM,
	AGENTTYPE_AMBULANCE_CENTER,
	AGENTTYPE_POLICE_FORCE,
	AGENTTYPE_POLICE_OFFICE,
	AGENTTYPE_MAX,	// max+1
  };
  const int numAgentTypes = AGENTTYPE_MAX;
    
  /** kernel �Υ��� */
  class RescueSystem : public System
  {
  private:
	typedef std::map<Id,INT_32> IdToIgnitionTime;
	IdToIgnitionTime ignition;
        
  protected:
  public:
	virtual ~RescueSystem();
	RescueSystem();
        
	virtual void loop();
	virtual void step();
	virtual void resetAgents();
	virtual void outputObjectForAgentAtStart(Agent* agent, const RescueObject* o, Output& buffer);
	virtual void outputObjectForAgent(Agent* agent, const RescueObject* o, Output& buffer);
	virtual bool outputFarBuildingForAgent(Agent* agent, const Building* o, Output& buffer);
	virtual void sendToAgents();
	virtual void processCommand(Agent* agent, Header header, S32 size, Input& input/*, const LongUDPConnection& from*/);
	void say(Id from, const char* message, S32 size);
	void buildCacheForVoices(Agent* a, int radius);
	void tell(Id from, const char* message, S32 size);
        
	void reportRejection(Agent* agent, const char* why);
	void reportRejection(Id agentId, const char* why);
        
  private:
	RescueSystem(const RescueSystem& source);
	RescueSystem& operator= (const RescueSystem& rhs);
	bool operator== (const RescueSystem& rhs) const;
  };
    
  /////////////////////////////////////////////////////////////////////////
} // namespace Rescue

#endif // } !defined(RESCUESYSTEM_HXX__INCLUDED)
