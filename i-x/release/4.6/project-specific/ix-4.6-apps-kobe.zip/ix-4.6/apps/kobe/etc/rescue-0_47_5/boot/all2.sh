#! /bin/sh

# The directory to store logs.
LOGDIR=""

DIR=`dirname $0`
MAP="$1"
if [ -z $MAP ] ; then
  MAP=Kobe
fi
if [ ! -d $MAP ] ; then
  MAP="$DIR/../maps/$MAP"
fi

LOG="rescue.log"
if [ ! -z $2 ] ; then
  LOG="`date +%m%d-%H%M%S`-$2-`basename $MAP`.log"
fi
if [ ! -z $LOGDIR ] ; then
  LOG="$LOGDIR/$LOG"
fi

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$DIR/../program/librescue:$DIR/../program/civilian/lib

OPTIONS="-logname $LOG -shindopolydata $MAP/shindopolydata.dat -galpolydata $MAP/galpolydata.dat"

PIDS=

$DIR/0gis.sh $OPTIONS -mapdir $MAP/ -gisini $MAP/gisini.txt >& gis.log &
sleep 2
#xterm -e $DIR/1kernel.sh $OPTIONS &
$DIR/1kernel.sh $OPTIONS >& kernel.log &
sleep 2
#xterm -e ./kuwataviewer.sh -l 300 &
$DIR/2viewer.sh >& viewer.log &
$DIR/3miscsimulator.sh $OPTIONS >& misc.log &
$DIR/4morimototrafficsimulator.sh >& traffic.log &
$DIR/5firesimulator.sh $OPTIONS >& fire.log &
$DIR/6blockadessimulator.sh $OPTIONS >& blockade.log &
$DIR/7collapsesimulator.sh $OPTIONS >& collapse.log &
sleep 2

$DIR/8civilian.sh >& civilian.log &
sleep 2
echo "Start your agents"
echo "Press enter to end simulation"

read
killall gis kernel blockadessimulator collapsesimulator civilian miscsimulator