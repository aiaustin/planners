/* Author: Clauirton Siebra <c.siebra@ed.ac.uk>
 * Updated: Sun Feb 24 11:24:26 2008 by Jeff Dalton
 * Original last updated: Mon Dec 13 09:16:14 2004 by Clauirton Siebra
 * Copyright: (c) 2001 - 2005, 2008, AIAI, University of Edinburgh
 */

package ix.rcragents;

import java.net.InetAddress;
import java.util.List;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.ArrayList;

import ix.icore.IXAgent;
import ix.icore.Activity;
import ix.icore.Status;
import ix.ip2.*;
import ix.util.Util;
import ix.util.Parameters;

import yab.agent.*;
import yab.agent.object.*;

import ix.icore.domain.Constraint;
import ix.iface.domain.SyntaxException;
import ix.iface.domain.LTF_Parser;
import ix.util.IPC;
import ix.util.Name;
import ix.util.lisp.LList;
import ix.util.lisp.Lisp;

// import ix.thesis.ThesisModelManager;
import ix.thesis.ThesisIp2;

public class PoliceForce extends IXAgent {

    static LTF_Parser constraintParser = new LTF_Parser();
    static String superior = "PoliceOffice";    
    private IxPoliceForce pf;
    private PanelController controller;

    private String hostname = "localhost";
    private int port = 8000;
    private int actionTime = 20;

    // protected ThesisModelManager modelManager;

    private ArrayList m_reportedBlockades = new ArrayList(); 
    protected static final Condition HAS_NOT_BEEN_SEEN_CND
        = Property.get("RealObject", "hasBeenSeen").equal(Boolean.FALSE);

    public PoliceForce(String[] argv) {
	super();
	mainStartup(argv);
	InetAddress ad = null;

	if (Parameters.haveParameter("rcr-hostname")) {
	    hostname = Parameters.getParameter("rcr-hostname");
	}
	if (Parameters.haveParameter("rcr-port")) {
	    port = (new Integer(Parameters.getParameter("rcr-port"))).intValue();
	}
	if (Parameters.haveParameter("action-message-time")) {
	    actionTime = (new Integer(Parameters.getParameter("action-message-time"))).intValue();
	}

	try {
	    //ad = InetAddress.getByName("localhost");
	    ad = InetAddress.getByName(hostname);
	} catch (Exception e){} 

	// JD, 24 Feb 2008:
	// This class used to use some Ip2 components, but since the class wasn't
	// a subclass of Ip2, it couldn't use them as-is; so slightly modified
	// versions of I-X 4.0 components were created.  Since they weren't
	// compatible with I-X 4.5, a different approach was taken: using a
	// GUI-less Ip2 subclass to hold the components.
	// So, instead of this:

// 	modelManager = new ThesisModelManager(this);
// 	controller = new PanelController(this);
// 	controller.connectTo(modelManager);

	// we now do this:
	Ip2 ip2 = ThesisIp2.makeInstance();
	controller = ip2.getController();

	pf = new IxPoliceForce(ad,port,this);

	// Need to review this part here.....

	yab.io.RCRSSProtocolSocket.clearUpAfterInitialization();
	while(true){
	    try{
		pf.run();
	    } catch(Error e) {}
	}
    }    

    public void handleNewActivity(Activity activity) {
	controller.addActivity(activity);
    }

    public static void main(String[] argv) {
	Util.printGreeting("I-P2");
	new PoliceForce(argv);
    }

    public yab.agent.object.PoliceForce getSelf(){
	return pf.getSelf();
    }


   class IxPoliceForce extends AbstractPoliceForceAgent {

       ix.rcragents.PoliceForce pf;

       Agenda agenda; 
       AgendaItem current;  

       int search = 0;
       int clear = 0;
       int move = 0;

       public IxPoliceForce(InetAddress address, int port, PoliceForce pf) {
	   super(address, port);
	   this.pf = pf;
	   Iterator refuges = (world.refuges).iterator();	   
	   IPC.sendObject(superior,prepareConstraint("rcrId",getAgentIPCName().toString(),new Integer(self().id)));
	   IPC.sendObject(superior,prepareConstraint("type",(new Integer(self().id)).toString(),"PoliceForce"));
	   sendPosition();
       }

       public void act() throws Agent.ActionCommandException {
 	   sendPosition();
	   agenda = controller.getActivityAgenda();

	   try {
	       if((agenda.getItems()).isEmpty() || allCompleted(agenda.getItems())) {
		   clearHere();
		   searchBlockades();
	       }
	       else {
		   current = getActivityInExecution(agenda.getItems());
		   if(current == null) current = chooseActivity(agenda.getItems()); 
		   current.setStatus(Status.EXECUTING);
		   int target = (new Integer(((current.getPattern()).get(1)).toString())).intValue();
		   MotionlessObject pos = ((self().world).get(target)).motionlessPosition();

		   if( self().motionlessPosition() == pos) {
		       if( ((Road)pos).passableLines() != 0) {
			   current.setStatus(Status.COMPLETE); 
			   IPC.sendObject(superior,prepareConstraint("type",((current.getPattern()).get(1)).toString(),"Cleared"));
			   searchBlockades();
		       }
		       else {
			   try {
			       clearHere();
			   }catch(Exception e) {
			       if( ((Road)pos).passableLines() != 0) {
				   current.setStatus(Status.COMPLETE);
				   IPC.sendObject(superior,prepareConstraint("type",((current.getPattern()).get(1)).toString(),"Cleared"));
			       }
			       throw new ActionCommandException();
			   }
		       }
		   }
		   else {
		       clearHere();
                       m_reportedBlockades.clear();
		       m_reportedBlockades.add(world.get(target));
		       moveReportedBlockades();
		   }
	 
	       }

		   //ClearingHandler ch = new ClearingHandler(pf);
		   //HandlerAction ha = ch.makeClearingAction(current);
		   //(controller.getActivityAgenda()).handleItem(current,ha);

	   }catch(Exception e){
	       if( (world.time()%actionTime) == 0 ){
		   System.out.println("<<<<<<<<<<<<<<<<<<<<"+ getAgentIPCName() +" / "+ self().id +">>>>>>>>>>>>>>>>>>>>");
		   System.out.println("World time: "+world.time());
		   System.out.println("Number of SEARCH actions: "+search);
		   System.out.println("Number of CLEAR actions : "+clear);
		   System.out.println("Number of MOVE actions  : "+move);
		   System.out.println(" ");
	       }
	       throw new ActionCommandException();
	   }
       }
	      
       protected AgendaItem getActivityInExecution(List items) {

	   AgendaItem result = null;
	   Iterator i = items.iterator();
	   while(i.hasNext()) {
	       result = (AgendaItem) i.next();
	       if (result.getStatus() == Status.EXECUTING) return result;
	   }		 
	   return null;
       }

       protected AgendaItem chooseActivity(List items) {

	   AgendaItem item = null;
	   AgendaItem result = null;
	   float cost;
	   float currentCost = Float.MAX_VALUE;
	   Iterator i = items.iterator();
	   while(i.hasNext()) {
	       item = (AgendaItem) i.next();
	       if(item.getStatus() == Status.POSSIBLE) {
		   MotionlessObject end = (MotionlessObject) world.get((new Integer(((item.getPattern()).get(1)).toString())).intValue());
		   cost = (new Route(end)).cost;
		   if (cost < currentCost) {
		       currentCost = cost;
		       result = item;
		   }
	       }
	   }
	   return result;
       }

       protected boolean allCompleted(List items) {
	   Iterator i = items.iterator();
	   while(i.hasNext())
	       if ( ((AgendaItem) i.next()).getStatus() != Status.COMPLETE) return false;
	   return true;
       }

       protected void clearHere() throws ActionCommandException {
	   MotionlessObject pos = self().motionlessPosition();
	   if (!(pos instanceof Road))
	       return;
	   Road road = (Road) pos;
	   if (road.passableLines() == 0){
	       clear = clear + 1;
	       clear(road);
	   }
       }

       protected void moveReportedBlockades() throws ActionCommandException {
	   //correctReportedBlockade();
	   if (!m_reportedBlockades.isEmpty()) {
	       move = move + 1;
	       move(m_reportedBlockades);
	   }
       }

       protected void correctReportedBlockade() {
	   for (Iterator it = m_reportedBlockades.iterator();  it.hasNext();  ) {
	       Road road = (Road) it.next();
	       if (road.hasBeenSeen()  &&  road.passableLines() > 0)
		   it.remove();
	   }
       }

       protected void searchBlockades() throws ActionCommandException {
	   List uncheckedRoads = HAS_NOT_BEEN_SEEN_CND.extract(world.roads);
	   if (!uncheckedRoads.isEmpty()) {
	       search = search + 1;
	       move(uncheckedRoads);
	   }
       }

       protected void hear(RealObject sender, String message) {
	   if (!(sender instanceof yab.agent.object.PoliceOffice))
	       return;
	   StringTokenizer st = new StringTokenizer(message);
	   String command = st.nextToken();
	   RealObject target = world.get(Integer.parseInt(st.nextToken()));
	   if (command.equals("clear"))
	       m_reportedBlockades.add(target);
       }

       protected void sendPosition() {
	   //IPC.sendObject(superior,prepareConstraint("latitude",(new Integer(self().id)).toString(),convertLatitude(self().y())));
	   //IPC.sendObject(superior,prepareConstraint("longitude",(new Integer(self().id)).toString(),convertLongitude(self().x())));
	   IPC.sendObject(superior,prepareConstraint("position",(new Integer(self().id)).toString(),new Integer((self().motionlessPosition()).id)));
       } 

       public Constraint prepareConstraint(String attribute,String object, Object value){
	   String source = "(world-state effect (" + attribute + " " + object + ") = " + value + ")";
	   LList spec = (LList)Lisp.readFromString(source);
	   Constraint constraint = constraintParser.parseConstraint(spec);
	   if (constraint == null)
	       throw new SyntaxException("Invalid constraint: ");
	   constraint.setSenderId(Name.valueOf(getAgentIPCName()));
	   return constraint;
       }

       public Double convertLatitude(int y){
	   double m = 6.92170305;
	   double b = -42.87611188;
	   double tmp = Math.log(38020.0000+(y/100));
	   return new Double(m*tmp+b);
       }

       public Double convertLongitude(int y){
	   double m = 19.34925050;
	   double b = -98.09317156;
	   double tmp = Math.log(-58793.0708+(y/100));
	   return new Double(m*tmp+b);
       }

       public yab.agent.object.PoliceForce getSelf() {
	   return self();
       }
   }
}

//javac -classpath ../../../ix-normal.jar:../imports/yab.jar:. ix/rcragents/PoliceForce.java
