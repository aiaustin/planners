/*
 * Header    :
 * File      : Controller.hxx
 * Auther    : Kosuke Shinoda
 * Since     : 2001/11/16
 * LastUpdate: 2001/11/16
 * Comment   :
 * End       :
 */
/*
 * Copyright (C) 2001 SHINODA, Kosuke. Jaist,Japan & CARC, AIST, JAPAN
 * Copyright (C) 2001 NODA, Itsuki, CARC, AIST, JAPAN
 */

/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#ifndef __Controller_hxx__
#define __Controller_hxx__

#include "../itk/itk.h"
#include "../rescuelang/EvalEngine.h"
#include "connection.h"
#include "input.h"
#include "output.h"
#include "objects.h"

using namespace Librescue;
using namespace Itk;
using namespace Rescue;

namespace RescueCivilian {
  
  typedef std::list<RescueObject*> Path;

  class Controller {
  public:
    INT_32     m_time;
    ITK_DEF_ACCESS(INT_32 time(), { return m_time; });
    Id      m_selfId;
    ITK_DEF_ACCESS(Id selfid(), { return m_selfId; });

  protected:
    Address m_to;
    ITK_DEF_ACCESS(Address& to(), { return m_to; });
  
    Connection* m_socket;
    ITK_DEF_ACCESS(Connection& socket(), { return *m_socket; });
    ITK_DEF_ACCESS3(Connection*, &_socket(), { return m_socket; });

    Input*  m_input;
    ITK_DEF_ACCESS(Input& input(), { return *m_input; });
    ITK_DEF_ACCESS3(Input*, &_input(), { return m_input; });

    Output* m_output;
    ITK_DEF_ACCESS(Output& output(), { return *m_output; });
    ITK_DEF_ACCESS3(Output*, &_output(), { return m_output; });    

  public:
    virtual ~Controller() {}
    //--------------------------------------------------
    // Controller :: constructor
    Controller(Id selfId, const Address& to, 
               Connection& socket, Input& in, Output& out){
      m_selfId = selfId;
      m_to     = to;
      _socket() = &socket;
      _input()  = &in;
      _output() = &out;
      m_time = 0;
    };
  
    //--------------------------------------------------
    // Controller InputSensor
    virtual void sensed(INT_32 time, 
                        Connection& socket, 
                        Input& input,Output& output) = 0;
    virtual void heard(Connection& socket, Id speaker, 
                       const char* message,
                       Input& input, Output& output) = 0;
  public:
    virtual Bool needToCycle() = 0;
    virtual void needToCycle2(Sexp* result) = 0;
    virtual Sexp* cycle() = 0;
    virtual void nextstep() = 0;
    //--------------------------------------------------
    // Controller :: agent command
    void move(Connection& socket, Path& path, Output& output);
    void say(Connection& socket,const char* message, Output& output);
    void tell(Connection& socket,const char* message,  Output& output);
    void extinguish(Connection& socket, Id id, 
                    INT_32 x, INT_32 y, 
                    INT_32 amount_of_water, 
                    Output& output);
    
  private:
    Controller(const Controller& source);
    Controller& operator=(const Controller& rhs);
    bool operator== (const Controller& rhs) const;
  };
};
#endif
