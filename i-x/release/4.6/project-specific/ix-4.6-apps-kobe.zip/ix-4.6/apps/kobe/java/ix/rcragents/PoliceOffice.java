/* Author: Clauirton Siebra <c.siebra@ed.ac.uk>
 * Updated: Mon Dec 13 09:16:14 2004 by Clauirton Siebra
 * Copyright: (c) 2001 - 2004, AIAI, University of Edinburgh
 */

package ix.rcragents;

import java.io.*;
import java.net.InetAddress;
import java.lang.Math;
import java.util.Iterator;
import java.util.Collection;
import java.util.StringTokenizer;
import java.util.Vector;
import yab.agent.*;
import yab.agent.object.*;
import ix.util.Util;
import ix.ip2.Ip2;
import ix.ip2.AgendaItem;

import ix.icore.domain.Constraint;
import ix.icore.domain.PatternAssignment;
import ix.icore.Variable;
import ix.iface.domain.SyntaxException;
import ix.iface.domain.LTF_Parser;
import ix.util.lisp.LList;
import ix.util.lisp.Lisp;
import ix.util.lisp.Symbol;
import ix.util.Name;
import ix.util.PatternParser;
import ix.util.Parameters;

public class PoliceOffice extends Ip2 {

    static LTF_Parser constraintParser = new LTF_Parser();
    private IxPoliceOffice po;
    private yab.agent.object.PoliceOffice rcrPO = null;  

    private String hostname = "localhost";
    private int port = 8000;

    public PoliceOffice(String[] argv) {
	super();
	mainStartup(argv);
 	InetAddress ad = null;	

	if (Parameters.haveParameter("rcr-hostname")) {
	    hostname = Parameters.getParameter("rcr-hostname");
	}
	if (Parameters.haveParameter("rcr-port")) {
	    port = (new Integer(Parameters.getParameter("rcr-port"))).intValue();
	}

	try {
	    ad = InetAddress.getByName(hostname);
	    //ad = InetAddress.getByName("soay.inf.ed.ac.uk");
	    
	} catch (Exception e){} 
	po = new IxPoliceOffice(ad,port,this);
	rcrPO = po.getSelf();

	// Need to review this part here.....

	yab.io.RCRSSProtocolSocket.clearUpAfterInitialization();
	while(true){
	    try{
		po.run();	   
	    } catch(Error e) {}
	}
    }

    public RealObject getWorldObject(int id) {
	return po.getWorldOb(id);
    }

    public static void main(String[] argv) {
	Util.printGreeting("I-P2");
	new PoliceOffice(argv);
    }

    public Constraint prepareConstraint(String attribute,String object, Object value){
	String source = "(world-state effect (" + attribute + " " + object + ") = " + value + ")";
	LList spec = (LList)Lisp.readFromString(source);
	Constraint constraint = constraintParser.parseConstraint(spec);
	if (constraint == null)
	    throw new SyntaxException("Invalid constraint: ");
	constraint.setSenderId(Name.valueOf(getAgentIPCName()));
	return constraint;
    }

    public Double convertLatitude(int y){
	double m = 6.92170305;
	double b = -42.87611188;
	double tmp = Math.log(38020.0000+(y/100));
	return new Double(m*tmp+b);
    }

    public Double convertLongitude(int y){
	double m = 19.34925050;
	double b = -98.09317156;
	double tmp = Math.log(-58793.0708+(y/100));
	return new Double(m*tmp+b);
    }

    public void handleNewConstraint(Constraint constraint) {
	super.handleNewConstraint(constraint);

	PatternAssignment pv = (PatternAssignment)constraint.getParameter(0);
	String at = ((pv.getPattern()).get(0)).toString();

	if(at.equals("position")) {	
	    String ob = ((pv.getPattern()).get(1)).toString();
	    int va = (new Integer((pv.getValue()).toString())).intValue();
	    RealObject target = getWorldObject(va);		    
	    getModelManager().addConstraint(prepareConstraint("latitude",ob,convertLatitude(target.y())));
	    getModelManager().addConstraint(prepareConstraint("longitude",ob,convertLongitude(target.x())));
	}
    }

    class IxPoliceOffice extends AbstractPoliceOfficeAgent{

	ix.rcragents.PoliceOffice po;
	private Vector activities = new Vector();

	public IxPoliceOffice(InetAddress address, int port, PoliceOffice po) {
	     super(address, port);
	     this.po = po;		    
	     getModelManager().addConstraint(prepareConstraint("latitude",getAgentIPCName().toString(),convertLatitude(self().y())));
	     getModelManager().addConstraint(prepareConstraint("longitude",getAgentIPCName().toString(),convertLongitude(self().x())));
	}

	public yab.agent.object.PoliceOffice getSelf(){
	    return self();
	}

	public RealObject getWorldOb(int id) {
	    return world.get(id);
	}

	public void act() throws Agent.ActionCommandException{
	    rest();
	}
	
	protected void hear(RealObject sender, String message) {

	    if (sender==null || message==null) return;
	    System.out.println("Police Office>>>>> "+sender.toString()+" : "+message);

	    if (sender instanceof yab.agent.object.FireStation) {
		//tell(message);

		StringTokenizer st = new StringTokenizer(message);
		String command = st.nextToken();
		RealObject target = world.get(Integer.parseInt(st.nextToken()));
		String targetS = (new Integer(target.id)).toString();
		if (command.equals("clear")) {

		    po.getModelManager().addConstraint(prepareConstraint("type",targetS,"Blocked"));
		    po.getModelManager().addConstraint(prepareConstraint("latitude",targetS,convertLatitude(target.y())));
		    po.getModelManager().addConstraint(prepareConstraint("longitude",targetS,convertLongitude(target.x())));

		    if(!activities.contains(targetS)) {
			activities.add(targetS);
			LList ac1 = PatternParser.parse("Clear"+" "+targetS);
			AgendaItem ai = activityViewer.makeItem(ac1);
			activityViewer.addItem(ai);
		    }
		}
	    }
	}
    }
}

//javac -classpath ../../../ix-normal.jar:../imports/yab.jar:. ix/rcragents/PoliceOffice.java
