#!/bin/bash

function canonicalname {
    program="$0"
    
    while [ -h "$program" ] ; do
        cd `dirname "$program"`
        program=`basename "$program"`
        program=`ls -l "$program"`
        program=${program##*-> }
    done
    
    cd `dirname "$program"`
    echo $PWD/`basename $program`
}

DIR=`dirname \`canonicalname "$0"\``
DIR=$DIR/../program/yabapi

# [<cv> <fb> <fs> <at> <ac> <pf> <po> [<host> [<port>]]]

# Start the 10 fire brigades
echo "Starting the 10 fire brigades..."
xterm -e java -cp "$DIR/yab.jar:$DIR/sample.jar" sample.Main 0 10 1 0 1 0 0 $* &

# Start the IX police office
sleep 5
cd /home/s0125683/ix-4.x/apps/irescue/scripts/unix
echo "Starting the police office...."
xterm -e ./PoliceOffice.sh &
sleep 10

# Start the 10 IX police forces

cd /home/s0125683/ix-4.x/apps/irescue/java
echo "Starting the IX police force 1"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce1 -superiors=PoliceOffice -peers=PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 2"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce2 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 3"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce3 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 4"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce4 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 5"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce5 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 6"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce6 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 7"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce7 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 8"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce8 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 9"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce9 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce10 &

sleep 4
echo "Starting the IX police force 10"
xterm -e java -classpath ../../../ix-normal.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:. ix/rcragents/PoliceForce -ipc=xml -ipc-name=PoliceForce10 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9 &

cd /home/s0125683/RoboCupRescue/rescue-0_45-unix/boot

