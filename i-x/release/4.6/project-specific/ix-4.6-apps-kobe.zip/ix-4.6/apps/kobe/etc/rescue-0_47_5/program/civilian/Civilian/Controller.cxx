/*
 * Header    :
 * File      : Controller.cxx
 * Auther    : Kosuke Shinoda
 * Since     : 2001/11/19
 * Time-stamp: "2001-12-10 16:47:14 kshinoda"
 * Comment   :
 * End       :
 */
/*
 * Copyright (C) 2001 SHINODA, Kosuke. Jaist,Japan & CARC, AIST, JAPAN
 * Copyright (C) 2001 NODA, Itsuki, CARC, AIST, JAPAN
 */

/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#include "Controller.hxx"
#include "error.h"

using namespace Librescue;
using namespace RescueCivilian;

void Controller::move(Connection& socket, 
		      Path& path,
		      Output& output){
  output.clear();
  output.writeInt32(AK_MOVE);
  Cursor base = output.writeInt32(~(INT_32)0);
  output.writeInt32(m_selfId);
  Path::const_iterator it = path.begin();
  //  LOG_DEBUG("Civilian %d moving",m_selfId);
  for(; it != path.end(); it++){
	//	LOG_DEBUG("\tNext object: type = %d, ID = %d",(*it)->type(),(*it)->id());
	/*
    Road* road = dynamic_cast<Road*>(*it);
    if(road){
      it++;
      if(it != path.end()){
		Node* node = dynamic_cast<Node*>(*it);
		if(node){
		  output.writeInt32(road->id());
		  output.writeInt32(node->id());
		} else {
		  Building* building = dynamic_cast<Building*>(*it);
		  output.writeInt32(building->id());
		  break;
		}
      } else {
		break;
      }
    } else {
	*/
      RescueObject* obj = *it;
      output.writeInt32(obj->id());
	  //    }
  }
  output.writeInt32(0);
  output.writeSize(base);
  output.writeInt32(HEADER_NULL);
  socket.send(output);
};

void Controller::say(Connection& socket, 
		     const char* message,
		     Output& output){
  output.clear();
  output.writeInt32(AK_SAY);
  Cursor base = output.writeInt32(~(INT_32)0);
  output.writeInt32(m_selfId);
  output.writeString(message);
  output.writeSize(base);
  output.writeInt32(HEADER_NULL);
  socket.send(output);
};

void Controller::tell(Connection& socket,
		      const char* message,
		      Output& output){
  output.clear();
  output.writeInt32(AK_TELL);
  Cursor base = output.writeInt32(~(INT_32)0);
  output.writeInt32(m_selfId);
  output.writeString(message);
  output.writeSize(base);
  output.writeInt32(HEADER_NULL);
  socket.send(output);
};

void Controller::extinguish(Connection& socket,
			    Id id,
			    S32 x,
			    S32 y,
			    S32 amount_of_water,
			    Output& output){
  output.clear();
  output.writeInt32(AK_EXTINGUISH);
  Cursor base = output.writeInt32(~(INT_32)0);
  output.writeInt32(m_selfId);
  output.writeInt32(id);
  output.writeInt32(0);
  output.writeInt32(x);
  output.writeInt32(y);
  output.writeInt32(amount_of_water); // amount of water per min.
  output.writeSize(base);
  output.writeInt32(HEADER_NULL);
  socket.send(output);
};
