package viewer.object;

public class Civilian extends Humanoid {
  public Civilian(int id) { super(id); }
  public int type() { return TYPE_CIVILIAN; }
}
