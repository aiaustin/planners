/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

// System.cxx
//
/////////////////////////////////////////////////////////////////////////////

#include "../librescue/common.h"
#include "../librescue/objects.h"
#include "../librescue/error.h"
#include "../librescue/handy.h"
#include "System.hxx"
#include "Agent.hxx"

#include <iostream>
#include <signal.h>
#include <sys/time.h>

using namespace std;
using namespace Librescue;


namespace Rescue
{
  /////////////////////////////////////////////////////////////////////////
  // System
    
  System::System(const std::vector<TypeId>& agentTypes)
  {
	m_agentTypes = agentTypes;
	m_pFreeAgents = new Agents[agentTypes.size()];
	m_pConnectedAgents = new Agents[agentTypes.size()];

	m_logFile = 0;

	//	m_publicSocket = 0;
	//	m_agentSocket = 0;
	//	m_simulatorSocket = 0;
	//	m_gisSocket = 0;

	m_time = 0;
	m_systemTime = 0;

	m_gisConnected = false;

  }

  System::~System()
  {
	delete[] m_pFreeAgents;
	delete[] m_pConnectedAgents;

	if(m_logFile != 0)
	  fclose(m_logFile);

	//	delete m_publicSocket;
	//	delete m_agentSocket;
	//	delete m_simulatorSocket;
	//	delete m_gisSocket;
	m_connectionManager.stop();
  }

  /*
    LongUDPConnection& System::publicSocket()
	{
	//	ASSERT(m_publicSocket);
	return *m_publicSocket;
	}
	LongUDPConnection& System::agentSocket()
	{
	//	ASSERT(m_agentSocket);
	return *m_agentSocket;
	}
	LongUDPConnection& System::simulatorSocket()
	{
	//	ASSERT(m_simulatorSocket);
	return *m_simulatorSocket;
	}
	LongUDPConnection& System::gisSocket()
	{
	//	ASSERT(m_gisSocket);
	return *m_gisSocket;
	}
  */
  Config& System::config()
  {
	return m_config;
  }
  ObjectPool& System::objectPool()
  {
	return m_objectPool;
  }
	
  Bytes intToBytes(int value)
  {
	Bytes b(4);
	b[0] = (value >> 24) & 0xFF;
	b[1] = (value >> 16) & 0xFF;
	b[2] = (value >> 8) & 0xFF;
	b[3] = value & 0xFF;
	return b;
  }
	
  class Accumulator {
  public:
	int nCiv;
	int nFB;
	int nAT;
	int nPF;
	int nFS;
	int nAC;
	int nPO;
	int m_number;
	std::list<Agent*> agents;

	Accumulator(int number) {
	  nCiv = nFB = nAT = nPF = nFS = nAC = nPO = 0;
	  m_number = number;
	}

	~Accumulator() {}

	void operator()(RescueObject* o) {
	  if (m_number==0) return;
	  Agent* a = NULL;
	  switch (o->type()) {
	  case TYPE_CIVILIAN:
		++nCiv;
		//		logDebug("Civilian");
		break;
	  case TYPE_FIRE_BRIGADE:
		++nFB;
		//		logDebug("Fire brigade");
		break;
	  case TYPE_AMBULANCE_TEAM:
		++nAT;
		//		logDebug("Ambulance team");
		break;
	  case TYPE_POLICE_FORCE:
		++nPF;
		//		logDebug("Police force");
		break;
	  case TYPE_FIRE_STATION:
		++nFS;
		//		logDebug("Fire station");
		break;
	  case TYPE_AMBULANCE_CENTER:
		++nAC;
		//		logDebug("Ambulance center");
		break;
	  case TYPE_POLICE_OFFICE:
		++nPO;
		//		logDebug("Police office");
		break;
	  default:
		break;
	  }
	  switch (o->type()) {
	  case TYPE_CIVILIAN:
	  case TYPE_FIRE_BRIGADE:
	  case TYPE_AMBULANCE_TEAM:
	  case TYPE_POLICE_FORCE:
	  case TYPE_FIRE_STATION:
	  case TYPE_AMBULANCE_CENTER:
	  case TYPE_POLICE_OFFICE:
		a = new Agent(o);
		agents.push_back(a);
		m_number--;
		break;
	  default:
		break;
	  }
	}
  };

#include <exception>

  void System::main(int argc, char const* const* argv)
  {
	std::set_terminate (__gnu_cxx::__verbose_terminate_handler);

	// TODO: server.conf ���ɤ߹���
        
	//m_outputBuffer.initialize(config().buffer_size());
	//m_inputBuffer.initialize(config().buffer_size());
    
	const char* host = "localhost";
	int number = -1;
        
	int i;
	int count = 0;
	m_config.readConfigFile("config.txt");
	for(i=1; i<argc; i++) {
	  if(argv[i][0] == '-') {
		if(strcmp(argv[i], "-file") == 0) {
		  if(++i < argc) {
			m_config.readConfigFile(argv[i]);
		  } else {
			fprintf(stderr, "error: '-file'\n");
		  }
		} else if(strcmp(argv[i], "-n") == 0) {
		  if(++i < argc) {
			number = atoi(argv[i]);
		  } else {
			fprintf(stderr, "error: '-file'\n");
		  }
		} else if(strcmp(argv[i], "-nogis") == 0) {
		  host = 0;
		} else {
		  if(++i < argc) {
			if(!m_config.setValue(argv[i-1]+1, argv[i]))
			  fprintf(stderr, "error: '%s'\n", argv[i]);
		  } else {
			fprintf(stderr, "error: '%s'\n", argv[i-1]);
		  }
		}
	  } else {
		switch(count++) {
		case 0:
		  host = argv[i];
		  break;
		default:
		  fprintf(stderr, "error: '%s'\n", argv[i]);
		  break;
		}
	  }
	}
        

	//        m_outputBuffer.resetFrameSize(config().send_udp_size());
	//        m_outputBuffer.setWait(config().send_udp_wait());

	//        m_publicSocket = new LongUDPConnection(Address(INADDR_ANY, (S16)config().port(), true), config().textlogname_kernel_publicsock());
	//        m_agentSocket = new LongUDPConnection(config().textlogname_kernel_agentsock());
	//        m_simulatorSocket = new LongUDPConnection(config().textlogname_kernel_simulatorsock());

	m_connectionManager.setUDPWait(config().send_udp_wait());
	m_connectionManager.setUDPSize(config().send_udp_size());
	m_connectionManager.listenTCP(config().port());

	if (config().kernel_udp_port()>0) m_connectionManager.listenUDP(config().kernel_udp_port());

	m_connectionManager.start();

	if(!config().logname().empty()) {
	  m_logFile = fopen(config().logname().c_str(), "w");
	  if(m_logFile == 0) {
		fprintf(stderr, "error: can not open file '%s'\n", config().logname().c_str());
	  } else {
		const char header[] = "RoboCup-Rescue Prototype Log 01";
		fwrite(header, sizeof(header[0]), strlen(header)+1, m_logFile);
		fflush(m_logFile);
	  }
			
	  Output paramSection;
	  paramSection.writeInt32(config().random_IDs());
	  paramSection.writeInt32(config().additional_hearing());
	  paramSection.writeInt32(config().max_extinguish_power_sum());
	  paramSection.writeInt32(config().max_extinguish_power());
	  paramSection.writeInt32(config().max_nozzles());
	  paramSection.writeInt32(config().step());
	  paramSection.writeInt32(config().notify_unchangeable_informaion());
	  paramSection.writeInt32(config().use_gettimeofday());
	  paramSection.writeInt32(config().fire_cognition_spredding_speed());
	  paramSection.writeInt32(config().simulate_tank_quantity());
	  paramSection.writeInt32(config().tank_quantity_maximum());
	  paramSection.writeInt32(config().say_max_bytes());
	  paramSection.writeInt32(config().ignore_nozzle_position());
	  paramSection.writeInt32(config().area_per_repair_cost());
	  paramSection.writeInt32(config().round_down_quantity());
	  paramSection.writeInt32(config().accept_multiple_nozzles());
	  paramSection.writeInt32(config().near_agents_rescuable());
	  paramSection.writeInt32(config().steps_far_fire_invisible());
	  paramSection.writeInt32(config().steps_agents_freezed());
	  paramSection.writeInt32(config().notify_initial_position());
	  paramSection.writeInt32(config().notify_position_history());
	  paramSection.writeInt32(config().miscsimulator_supports_load());
	  paramSection.writeInt32(config().notify_only_fire_for_far_buildings());
	  paramSection.writeInt32(config().port());
	  paramSection.writeInt32(config().gis_port());
	  paramSection.writeInt32(config().period());
	  paramSection.writeInt32(config().vision());
	  paramSection.writeInt32(config().voice());
	  paramSection.writeInt32(config().misc_random_seed());
			
	  paramSection.log(m_logFile);
	}

	// GIS ����³
	if(number<0)
	  number = INT_MAX;
	//	Address g((int)INADDR_ANY, 0);
	//	m_gisSocket = new LongUDPConnection(g, config().send_udp_size(), config().send_udp_wait());
	m_gis = Address(host, config().gis_port());
	// ��³��å�����������
	LOG_INFO("Connecting to gis: %s",m_gis.toString());
	m_outputBuffer.clear();
	m_outputBuffer.writeInt32(KG_CONNECT);
	Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
	m_outputBuffer.writeInt32(0); // Version is alwaysz zero
	m_outputBuffer.writeSize(base);
	m_outputBuffer.writeInt32(HEADER_NULL);
	//	dumpBytes(m_outputBuffer.buffer());
	//	gisSocket().send(m_outputBuffer, m_gis);
	//	if (config().gis_tcp()) m_connectionManager.sendViaTCP(m_gis);
	//	else m_connectionManager.sendViaUDP(m_gis);
	m_connectionManager.sendViaTCP(m_gis);
	if (!m_connectionManager.send(m_outputBuffer, m_gis)) {
	  logError("Couldn't contact GIS");
	  exit(0);
	}

	m_gisConnected = false;
	while(!m_gisConnected)
	  receiveMessages(10000/*gisSocket()*/);

	Accumulator acc(number);
	const Objects objects = m_objectPool.objects();
	Objects::const_iterator start = objects.begin();
	Objects::const_iterator end = objects.end();
	acc = for_each(start,end,acc);

	LOG_INFO("Civ: %d, FB %d, AT %d, PF %d, FS %d, AC %d, PO %d",acc.nCiv,acc.nFB,acc.nAT,acc.nPF,acc.nFS,acc.nAC,acc.nPO);

	// Add all the free agents
	for (std::list<Agent*>::iterator it = acc.agents.begin();it!=acc.agents.end();++it) {
	  addFreeAgent(*it);
	}
        
	setUp();
	LOG_INFO("setUp() done.");
	// Turn off the udp wait
	//	m_gisSocket->setWait(0);
	//	m_simulatorSocket->setWait(0);
	//	m_agentSocket->setWait(0);
	//	m_publicSocket->setWait(0);
	if(config().wait_before_start()) {
	  char buffer[102];
	  printf("push the enter key to start.\n");
	  fgets(buffer, 100, stdin);
	}
	loop();
  }
    
  static void dummy(int) {
	// do nothing
  }
   
  bool System::startOk()
  {
	if(m_addressToAckWaiter.empty() && m_idToAckWaiter.empty()) {
	  unsigned int i;
	  for(i=0; i<m_agentTypes.size(); i++) {
		if(!m_pFreeAgents[i].empty())
		  return false;
	  }
	  return true;
	}
	return false;

  }

  void System::setUp() {
	/*
	  typedef std::vector<Connection*> Sockets;
	  Sockets sockets;
	  sockets.push_back(&publicSocket());
	  sockets.push_back(&simulatorSocket());
	  sockets.push_back(&agentSocket());
	*/

	while(!startOk()) {
	  printf("free agents = %ld", (long)m_pFreeAgents[0].size());
	  for(int i=1; i<(int)m_agentTypes.size(); i++)
		printf(", %ld", (long)m_pFreeAgents[i].size());
	  printf("  no ack=%ld\n", (long)(m_addressToAckWaiter.size() + m_idToAckWaiter.size()));
	  //	  logDebug("Checking for available messages...");
	  bool available = m_connectionManager.isDataAvailable(5*config().step());//!Connection::isDataAvailable(sockets, 5 * config().step());
	  if(available) {
		// ����
		/*
		  receiveMessages(publicSocket());
		  receiveMessages(simulatorSocket());
		  receiveMessages(agentSocket());
		*/
		receiveMessages(0);
	  } else {
		//		logDebug("Nothing available");
		// Ack ���֤äƤ��ʤ��Τǡ��������롣
		if(!m_addressToAckWaiter.empty()) {
		  LOG_INFO("addressAck");
		  AckWaiter* aw = m_addressToAckWaiter.begin()->second.get();
		  aw->send();
		} else if(!m_idToAckWaiter.empty()) {
		  LOG_INFO("idAck");
		  AckWaiter* aw = m_idToAckWaiter.begin()->second.get();
		  aw->send();
		}
	  }
	  // ����������Ȥ���³���֤�ɽ��
	}

	if(m_logFile != 0) {
	  m_outputBuffer.clear();
	  m_outputBuffer.writeInt32(KS_CONNECT_OK);
	  Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
	  objectPool().write(m_outputBuffer);
	  m_outputBuffer.writeSize(base);
	  m_outputBuffer.writeInt32(HEADER_NULL);

	  m_outputBuffer.log(m_logFile);
	}
  }

  void System::addFreeAgent(Agent* agent)
  {
	TypeId type = agent->asObject()->type();
	int i=-1;
	do {
	  i++;
	  //	  ASSERT(i < (int)m_agentTypes.size());
	  if (i>(int)m_agentTypes.size()) {
		delete agent;
		return;
	  }
	} while(type != m_agentTypes[i]);
	m_pFreeAgents[i].push_back(agent);
  }

  bool kbhit() {
	fd_set fds;
	FD_ZERO(&fds);
	const int STDIN = 0;
	FD_SET(STDIN, &fds);
	timeval timeout = { 0 };
	int result = select(STDIN + 1, &fds, NULL, NULL, &timeout);
	//	ASSERT(result != SOCKET_ERROR);
	return (bool)result;
  }
  long timeGetTime() {
	timeval tv = { 0 };
	gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000000 + tv.tv_usec;
  }
  void System::loop() {
	const int division = 2;
	long count = 0;

	m_time = 1;
	const int timeDelta = config().step() / division;
        
	if (config().use_gettimeofday()) {
	  long nextTime = timeGetTime() + timeDelta * 1000;
	  int lostContinually = 0;
	  while(!(config().interactive_stop() && kbhit()) && m_time <= config().period()) {
		// ���濫�碌
		long now = timeGetTime();
		if(now < nextTime) {
		  usleep(nextTime - now);
		  nextTime += timeDelta * 1000;
		  lostContinually = 0;
		} else {
		  if(lostContinually++ < 5) {
			nextTime += timeDelta * 1000;
		  } else {
			nextTime = now + timeDelta * 1000;
			fprintf(stderr, "busy. %d %ld\n", (int)lostContinually, (long)now);
		  }
		}
		//printf("time: +%ld\n", (long) (now - m_systemTime));
		m_systemTime = (long)now;
		// ��������
		loopCore(count, division);
	  }
	} else {
	  class AutoCast {
	  public:
		typedef void (*type1)(int);
		typedef void (*type2)(...);
		type1 m_fp;
		AutoCast(type1 fp) {
		  m_fp = fp;
		}
		operator type1 () {
		  return m_fp;
		}
		operator type2 () {
		  return (type2)m_fp;
		}
	  } autoCast(dummy);
	  struct sigaction sa = { 0 };
	  sa.sa_handler = autoCast;
	  //sa.sa_flags &= (~SA_RESETHAND);
	  sigaction(SIGALRM, &sa, NULL);
	  struct itimerval itv = { { 0 } };
	  itv.it_interval.tv_sec = timeDelta / 1000;
	  itv.it_interval.tv_usec = (timeDelta % 1000) * 1000;
	  itv.it_value.tv_sec = timeDelta / 1000;
	  itv.it_value.tv_usec = (timeDelta % 1000) * 1000;
	  setitimer(ITIMER_REAL, &itv, NULL);
	  while(!(config().interactive_stop() && kbhit()) && m_time <= config().period()) {
		// ���濫�碌
		sigpause(SIGUSR1);
		m_systemTime += timeDelta;
		// ��������
		loopCore(count, division);
	  }
	}

  }
  void System::loopCore(long& count, int division)
  {
	//printf("system time %ld\n", (long)m_systemTime);

	//	ASSERT(division == 2);
	switch(count++ % division) {
	default:
	  logError("ERROR: count % division = something weird");
	  //	  ASSERT(false);
	case 0:
	  {
		cerr << "Division #1" << endl;
		resetAgents();
		receiveMessages(0/*agentSocket()*/);
		sendToSimulators();
		if(m_logFile != 0)
		  fflush(m_logFile);
		resetSimulators();
	  }
	  break;
	case 1:
	  cerr << "Division #2" << endl;
	  receiveMessages(0/*simulatorSocket()*/);
	  step();
	  m_time++;
	  sendToAgents();
	  sendUpdate(m_time - 1);
	  LOG_INFO("time=%ld", (long)m_time);
	  break;
	}
  }
  void System::resetAgents()
  {
  }
  void System::resetSimulators()
  {
  }
    
  void System::receiveMessages(int timeout/*LongUDPConnection& from*/)
  {
	//	while(from.isDataAvailable()) {
	Address from;
	//	logDebug("Reading messages...");
	if (m_connectionManager.isDataAvailable(timeout)) {
	  //	  from.receive(m_inputBuffer);
	  while (m_connectionManager.receive(m_inputBuffer,&from)) {
		//	  LOG_DEBUG("Input from %s, size = %ld",from.toString(), (long)m_inputBuffer.size());
		//	  dumpBytes(m_inputBuffer);
		try {
		  while(processMessage(from));
		} catch(Overrun) {
		  LOG_WARNING("WARNING: Illegal message from %s",from.toString());
		  dumpBytes(m_inputBuffer);
		}
	  }
	}
  }

  bool System::processMessage(const Address& from) {
	// TODO: from �μ���ˤ�äƤϼ������ݤ���

	Header header = (Header)m_inputBuffer.readInt32();
	if(header == HEADER_NULL)
	  return false;

	INT_32 size = m_inputBuffer.readInt32();
	Cursor start = m_inputBuffer.cursor();

	if(Librescue::isAgentCommand(header)) {
	  Id sender = m_inputBuffer.readInt32();
	  Agent* agent = findAgent(m_objectPool.getObject(sender));
	  if(agent == 0) {
		LOG_WARNING("WARNING: Illegal Sender ID=%ld", (long)sender);
	  } else {
		if(m_time > config().steps_agents_freezed())
		  processCommand(agent, header, size - sizeof(sender), m_inputBuffer/*, from*/);
	  }
	} else {
	  switch(header) {
	  default:
		LOG_WARNING("Unknown header: 0x%X.",header);
		break;
	  case GK_CONNECT_OK:
		LOG_INFO("GK_CONNECT_OK");
		gisConnectOk(from);
		break;
	  case AK_CONNECT:
		LOG_INFO("AK_CONNECT");
		agentConnect(from);
		break;
	  case AK_ACKNOWLEDGE:
		LOG_INFO("AK_ACKNOWLEDGE");
		agentAcknowledge(/*from*/);
		break;
	  case SK_CONNECT:
		LOG_INFO("SK_CONNECT");
		simulatorConnect(from);
		break;
		//	  case VK_CONNECT:
		//		printf("VK_CONNECT\n");
		//		simulatorConnect(from);
		//		break;
	  case SK_ACKNOWLEDGE:
		LOG_INFO("SK_ACKNOWLEDGE");
		simulatorAcknowledge(from);
	  case SK_UPDATE:
		LOG_INFO("SK_UPDATE");
		simulatorUpdate(from);
		break;
	  }
	}

	m_inputBuffer.setCursor(start);
	if(size == ~(INT_32)0)
	  return false;
	m_inputBuffer.skip(size);
	return true;
  }

  void System::processCommand(Agent* agent, Header header, INT_32 size, Input& input/*, const LongUDPConnection& from*/)
  {
  	agent->inputCommand(header, size, input);
  	m_commandToAngents[header].push_back(agent);
  }

    
  void System::gisConnectOk(const Address& from/*const LongUDPConnection& from*/)
  {
	LOG_INFO("Ok.");
        
	// ack ���֤�
	m_outputBuffer.clear();
	m_outputBuffer.writeInt32(KG_ACKNOWLEDGE);
	Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
	m_outputBuffer.writeSize(base);
	m_outputBuffer.writeInt32(HEADER_NULL);
	//	gisSocket().send(m_outputBuffer, m_gis);
	m_connectionManager.send(m_outputBuffer,m_gis);
        
        
	LOG_INFO("Initializing...");
	m_gis = from;//.addressReceivedFrom();
	if (m_objectPool.update(m_inputBuffer,m_time)) {
	  m_gisConnected = true;
	  //	m_objectPool.restructure(0, m_inputBuffer);
	  //	m_objectPool.setUpMesh(config().mesh_size(), config().mesh_size());
	  LOG_INFO("Ok.");
	}
	else {
	  LOG_WARNING("WARNING: Initialisation failed");
	}
  }
  void System::agentConnectError(const Address& from,/*const LongUDPConnection& from,*/ INT_32 temporaryId, const char* message)
  {
	m_outputBuffer.clear();
	m_outputBuffer.writeInt32(KA_CONNECT_ERROR);
	Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
	m_outputBuffer.writeInt32(temporaryId);
	//m_outputBuffer.put(~(S32)0);
	m_outputBuffer.writeString(message);
	m_outputBuffer.writeSize(base);
	m_outputBuffer.writeInt32(HEADER_NULL);
	//	agentSocket().send(m_outputBuffer, from.addressReceivedFrom());
	m_connectionManager.send(m_outputBuffer,from);
	return;
  }
    
  class AgentAckWaiter : public System::AckWaiter {
  public:
	ConnectionManager* manager;
	System* system;
	Address address;
	Id temporaryId;
	Agent* agent;
	bool sendMap;
	virtual void send() {
	  Output outputBuffer;
	  //            outputBuffer.setWait(system->config().send_udp_wait());
	  //            outputBuffer.resetFrameSize(system->config().send_udp_size());
	  //outputBuffer.initialize(system->config().buffer_size());
            
	  outputBuffer.clear();
	  outputBuffer.writeInt32(KA_CONNECT_OK);
	  Cursor base = outputBuffer.writeInt32(~(INT_32)0);
	  outputBuffer.writeInt32(temporaryId);
	  outputBuffer.writeInt32(agent->asObject()->id());
	  {
		// self
		// TODO: ��ʬ��Ƚ�ǤΤĤ�����������������롣
		agent->asObject()->write(outputBuffer);
	  }
	  if(sendMap) {
		// map
		// TODO: ���ʤ�������Τꤨ�����������������롣
		// �Ȥꤢ���������ڹ������äƤ��롣
		const Objects& objects = system->objectPool().objects();
		Objects::const_iterator it = objects.begin();
		for(; it != objects.end(); it++) {
		  const RescueObject& object = **it;
		  system->outputObjectForAgentAtStart(agent, &object, outputBuffer);
		}
		outputBuffer.writeInt32(TYPE_NULL);
	  }
	  outputBuffer.writeSize(base);
	  outputBuffer.writeInt32(HEADER_NULL);
	  //	  dumpBytes(outputBuffer.buffer());
	  //	  system->agentSocket().send(outputBuffer, address);
	  manager->send(outputBuffer,address);
	}
  };
  void System::agentConnect(const Address& from/*const LongUDPConnection& from*/)
  {
	INT_32 temporaryId = m_inputBuffer.readInt32();
	INT_32 version = m_inputBuffer.readInt32();
	if(version < 0 || 2 < version) {
	  agentConnectError(from, temporaryId, "unknown verison");
	  return;
	}
	INT_32 agentType = m_inputBuffer.readInt32();
	unsigned int i=0;
	Agent* agent = NULL;
	for(; i<m_agentTypes.size(); i++, agentType>>=1) {
	  if((agentType & 1) && !m_pFreeAgents[i].empty()) {
		agent = m_pFreeAgents[i].front();
		m_pFreeAgents[i].erase(m_pFreeAgents[i].begin());
		break;
	  }
	}
	if(!agent) {
	  agentConnectError(from, temporaryId, "no more agent");
	  return;
	}

	agent->setClientAddress(from/*.addressReceivedFrom()*/);
	agent->setNeedsSensoryInformation(version != 2);
	m_pConnectedAgents[i].push_back(agent);

	AgentAckWaiter* aaw = new AgentAckWaiter();
	aaw->manager = &m_connectionManager;
	aaw->system = this;
	aaw->address = from/*.addressReceivedFrom()*/;
	aaw->temporaryId = temporaryId;
	aaw->agent = agent;
	aaw->sendMap = (version == 0);
	aaw->send();
	m_idToAckWaiter[agent->asObject()->id()] = AutoPtr<AckWaiter>(aaw);
  }
  void System::agentAcknowledge(/*const LongUDPConnection& from*/)
  {
	Id id = m_inputBuffer.readInt32();
	IdToAckWaiter::iterator it = m_idToAckWaiter.find(id);
	if(it == m_idToAckWaiter.end()) {
	  LOG_WARNING("WARNING: Illegal id");
	  return;
	}
	m_idToAckWaiter.erase(it);
  }
  class SimulatorAckWaiter : public System::AckWaiter {
  public:
	ConnectionManager* manager;
	System* system;
	Address address;
	virtual void send() {
	  Output outputBuffer;
	  //            outputBuffer.setWait(system->config().send_udp_wait());
	  //            outputBuffer.resetFrameSize(system->config().send_udp_size());
	  //outputBuffer.initialize(system->config().buffer_size());

	  outputBuffer.clear();
	  outputBuffer.writeInt32(KS_CONNECT_OK);
	  Cursor base = outputBuffer.writeInt32(~(INT_32)0);
	  system->objectPool().write(outputBuffer);
	  outputBuffer.writeSize(base);
	  outputBuffer.writeInt32(HEADER_NULL);
	  //	  system->simulatorSocket().send(outputBuffer, address);
	  manager->send(outputBuffer,address);
	  //printf("send KS_CONNECT_OK size=%ld\n", (long)outputBuffer.size());
	}
  };
  void System::simulatorConnect(const Address& from/*const LongUDPConnection& from*/)
  {
	m_simulators.push_back(from/*.addressReceivedFrom()*/);
        
	SimulatorAckWaiter* saw = new SimulatorAckWaiter();
	saw->manager = &m_connectionManager;
	saw->system = this;
	saw->address = from/*.addressReceivedFrom()*/;
	//usleep(2000 * 1000);
	saw->send();
	m_addressToAckWaiter[saw->address] = AutoPtr<AckWaiter>(saw);
  }
  void System::simulatorAcknowledge(const Address& from/*const LongUDPConnection& from*/)
  {
	AddressToAckWaiter::iterator it = m_addressToAckWaiter.find(from/*.addressReceivedFrom()*/);
	if(it == m_addressToAckWaiter.end()) {
	  LOG_WARNING("WARNING: Illegal sender");
	  return;
	}
	m_addressToAckWaiter.erase(it);
  }
    
    
  void System::outputObjectForAgentAtStart(Agent* agent, const RescueObject* o, Output& buffer)
  {
	if (config().send_civilians_at_start() || o->type()!=TYPE_CIVILIAN)
	  o->write(buffer);
  }
  void System::outputObjectForAgent(Agent* agent, const RescueObject* o, Output& buffer)
  {
	o->write(buffer);
  }
    
  void System::sendToSimulators() {
	m_outputBuffer.clear();
	m_outputBuffer.writeInt32(KS_COMMANDS);
	Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
	m_outputBuffer.writeInt32(m_time);
	HeaderToAgents::iterator it = m_commandToAngents.begin();
	//	LOG_DEBUG("Sending commands to simulators");
	for(; it != m_commandToAngents.end(); it++) {
	  //	  LOG_DEBUG("Next command: 0x%x",it->first);
	  m_outputBuffer.writeInt32(it->first);
	  Cursor base2 = m_outputBuffer.writeInt32(~(INT_32)0);
	  // TODO: ����������֤ϥ����ब˾�ޤ�����
	  Agents::iterator it2 = it->second.begin();
	  for(; it2 != it->second.end(); it2++) {
		Agent* agent = *it2;
		RescueObject* object = agent->asObject();
		//		LOG_DEBUG("Next agent %d command is 0x%x",agent->asObject()->id(),agent->getCommandType());
		if(agent->getCommandType() == it->first) {
		  m_outputBuffer.writeInt32(object->id());
		  agent->outputCommand(m_outputBuffer);
		  agent->resetCommand();
		}
	  }
	  m_outputBuffer.writeInt32((Id)0);
	  m_outputBuffer.writeSize(base2);
	}
	m_outputBuffer.writeInt32(HEADER_NULL);
	m_outputBuffer.writeSize(base);
	m_outputBuffer.writeInt32(HEADER_NULL);
	m_commandToAngents.clear();

	//	LOG_DEBUG("KS_COMMANDS");
	//	dumpBytes(m_outputBuffer.buffer());
	//	LOG_DEBUG("KS_COMMANDS length: %d",m_outputBuffer.size());

	// TODO: �֥����ɥ��㥹�Ȥ���
	Addresses::const_iterator it2 = m_simulators.begin();
	for(; it2 != m_simulators.end(); it2++) {
	  const Address& simulator = *it2;
	  //	  publicSocket().send(m_outputBuffer, simulator);
	  //	  LOG_DEBUG("Sending KS_COMMANDS to %s",simulator.toString());
	  m_connectionManager.send(m_outputBuffer,simulator);
	}
  }
  void System::sendUpdate(INT_32 time)
  {
	// TODO: ��ʬ��������
	m_outputBuffer.clear();
	m_outputBuffer.writeInt32(KS_UPDATE);
	Cursor base = m_outputBuffer.writeInt32(~(INT_32)0);
	m_outputBuffer.writeInt32(time);
	objectPool().write(m_outputBuffer, time);
	m_outputBuffer.writeSize(base);
	m_outputBuffer.writeInt32(HEADER_NULL);

	//	logDebug("KS_UPDATE");
	//	dumpBytes(m_outputBuffer.buffer());
        
	// TODO: �֥����ɥ��㥹�Ȥ���
	if(m_gisConnected) {
	  //	  ASSERT(KS_UPDATE == KG_UPDATE);
	  //	  gisSocket().send(m_outputBuffer, m_gis);
	  m_connectionManager.send(m_outputBuffer,m_gis);
	}
	Addresses::const_iterator it2 = m_simulators.begin();
	for(; it2 != m_simulators.end(); it2++) {
	  const Address& simulator = *it2;
	  //	  simulatorSocket().send(m_outputBuffer, simulator);
	  m_connectionManager.send(m_outputBuffer,simulator);
	}

	if(m_logFile != 0)
	  m_outputBuffer.log(m_logFile);
  }
    
  void System::step()
  {
  }

  void System::simulatorUpdate(const Address& from) {
	m_objectPool.update(m_inputBuffer,m_time);
  }

  Agent* System::findAgent(RescueObject* object) {
	for (unsigned int i=0;i<m_agentTypes.size();++i) {
	  for (Agents::iterator it = m_pConnectedAgents[i].begin();it!=m_pConnectedAgents[i].end();++it) {
		Agent* next = *it;
		if (next->asObject()->id()==object->id()) {
		  return next;
		}
	  }
	}
	return 0;
  }

  /////////////////////////////////////////////////////////////////////////
} // namespace Rescue
