/* Author: Clauirton Siebra <c.siebra@ed.ac.uk>
 * Updated: Mon Dec 13 09:16:14 2004 by Clauirton Siebra
 * Copyright: (c) 2001 - 2004, AIAI, University of Edinburgh
 */

package ix.thesis;

import java.util.*;

import ix.icore.*;
import ix.icore.process.*;
import ix.icore.plan.*;
import ix.icore.domain.*;
import ix.util.*;
import ix.util.lisp.*;
import ix.util.match.*;
import ix.util.context.*;
import ix.ip2.*;

public class ThesisModelManager extends AbstractPMM {

    public static final Symbol
	S_WORLD_STATE = Symbol.intern("world-state"),
	S_COMMITMENT  = Symbol.intern("commitment"),
	S_CONDITION   = Symbol.intern("condition"),
	S_EFFECT      = Symbol.intern("effect");

    protected IXAgent agent;

    protected LLQueue nodes = new LLQueue();

    protected ContextHashMap varEnv = new ContextHashMap(); // name -> Variable

    protected LLQueue sentinels = new LLQueue();

    protected ThesisVariableManager variableManager = makeVariableManager();

    protected ThesisWorldStateManager worldStateCM = makeWorldStateManager();

    protected LLQueue otherConstraints = new LLQueue();
	// /\/ was a LinkedListOfConstrainer

    protected MultiMap otherNodeConstraints = new ContextMultiHashMap();

    public ThesisModelManager(IXAgent agent) {
	super();
	this.agent = agent;
	Debug.expect(Context.getContext() == Context.rootContext
		     || Context.getContext().getParent()
		           == Context.rootContext);
	Context.pushContext();	// protect root context
    }

    public void reset() {
	nodes.clearCompletely();
	varEnv.clearCompletely();
	sentinels.clearCompletely();
	variableManager.reset();
	worldStateCM.reset();
	otherConstraints.clearCompletely();
	otherNodeConstraints.clear();
	// /\/: Annotations should be handled directly, not inherited
	// from AbstractAnnotatedObject.
	if (annotations != null) annotations.clear();

	Context.clearContexts();
	Context.pushContext();	// protect root context
    }

    public ThesisVariableManager getVariableManager() {
	return variableManager;
    }

    protected ThesisVariableManager makeVariableManager() {
	return new ThesisVariableManager(this);
    }

    protected ThesisWorldStateManager makeWorldStateManager() {
	return new ThesisWorldStateManager(this);
    }

    public void addVariable(Variable v) {
	Debug.expect(varEnv.get(v.getName()) == null,
		     "Variable already exists");
	varEnv.put(v.getName(), v);
    }

    public Variable getVariable(Object name) {
	return (Variable)varEnv.get(name);
    }

    public Map getVarEnv() {	// for ix.ip2.PlanMaker /\/
	return varEnv;
    }

    public void addNode(PNode node) {
	Debug.noteln("PMM adding node", node);
	node.modelManager = this;
	nodes.add(node);
    }

    public void removeNode(PNode node) {
	if (node.isExpanded())
	    throw new IllegalArgumentException
		("Attempt to delete a node that has been expanded " + node);
	Debug.noteln("PMM removing node", node);
	node.unlink();
	nodes.remove(node);
    }

    public void addNodesBefore(PNode at, List addList) {
	// This lets us add some nodes before a given node
	// rather than at the end.  "at" should occur only
	// once.  In any case, we add before the first occurrence.
	Debug.noteln("PMM adding nodes", addList);
	Debug.noteln("before", at);
	for (Iterator i = addList.iterator(); i.hasNext();) {
	    PNode n = (PNode)i.next();
	    n.modelManager = this;
	}
	LList oldNodes = nodes.contents();
	LList newNodes = 
	    (LList)Collect.insertBeforeFirst(at, oldNodes, addList);
	nodes.setContents(newNodes);
    }

    public List getNodes() {
	// Returns a snapshot of the current state
	return nodes.contents();
    }

    public void walkNodes(Proc p) {
	for (Iterator i = getNodes().iterator(); i.hasNext();) {
	    ActivityItem item = (ActivityItem)i.next();
	    p.call(item);
	}
    }

    public void walkNodeEnds(Proc p) {
	for (Iterator i = getNodes().iterator(); i.hasNext();) {
	    ActivityItem item = (ActivityItem)i.next();
	    p.call(item.getBegin());
	    p.call(item.getEnd());
	}
    }

    public List getNodeEnds() {
	// Returns a snapshot of the current state
	List result = new LinkedList();
	for (Iterator i = getNodes().iterator(); i.hasNext();) {
	    ActivityItem item = (ActivityItem)i.next();
	    result.add(item.getBegin());
	    result.add(item.getEnd());
	}
	return result;
    }

    /**
     * Assigns values to {@link Variable}s.  Assignments must
     * go through this method rather than directly calling
     * {@link Variable#setValue(Object)}.
     */
    public void bindVariables(Map bindings) {
	// /\/: It's possible a Variable might have been bound
	// between the time something got a list of unbound vars
	// and the time when this was called.  Should we check
	// all vars before giving any of them a value?
	variableManager.tryBindings(bindings);
	for (Iterator i = bindings.entrySet().iterator(); i.hasNext();) {
	    Map.Entry e = (Map.Entry)i.next();
	    Variable var = (Variable)e.getKey();
	    Object val = e.getValue();
	    var.setValue(val);
	}
	fireNewBindings(bindings);
	runSentinels();
	// We call the variable manager at the end, because this
	// might result in more bindings, and we want the earlier
	// bindings to have already happened.
	variableManager.newBindings(bindings);
    }

    void forcedBindings(MatchEnv forced) {
	// /\/: For now, at least, we want to tell the user,
	// but this class shouldn't be doing UI stuff.
	if (Parameters.isInteractive()) // && agent.isInteractive())
	    Util.displayAndWait(null,
	      Strings.foldLongLine("Discovered necessary bindings " + forced));
	bindVariables(forced);
    }

    public void addConstraint(Constrainer c) {
	addConstraint(null, c);
    }

    public void addConstraint(Map idToItemMap, Constrainer c) {
	Symbol type = c.getType();
	Symbol relation = c.getRelation();
	if (type == S_WORLD_STATE) {
	    if (ObjectWalker.findIf(c, Fn.isInstanceOf(ItemVar.class))
		    != null)
		throw new IllegalArgumentException
		    ("Variables are not allowed in " + c);
	    if (relation == S_EFFECT) {
		// /\/: Now treat as Constraint rather than Constrainer
		Constraint w = (Constraint)c;
		PatternAssignment pv = (PatternAssignment)w.getParameter(0);
		handleEffects(Lisp.list(pv));
		return;
	    }
	}
	if (type == Ordering.S_TEMPORAL) {
	    if (relation == Ordering.S_BEFORE) {
		Debug.expect(idToItemMap != null, "no idToItemMap for", c);
		PNodeEnd.addOrdering(idToItemMap, (Ordering)c);
		return;
	    }
	}
	if (type == MatchChoice.S_VARIABLE) {
	    if (relation == MatchChoice.S_MATCH_CHOICE) {
		Constraint mc = (Constraint)c;
		variableManager.add(new MatchChoice(mc));
		// /\/: Have to recalculate...  However, for now
		// we get here only when loading a plan, and a
		// recalc is done there.
		return;
	    }
	}
	Debug.noteln("Can't handle " + c);
	
	if (!otherConstraints.contains(c)) {
	    // Don't add if already present?  \/\
	    otherConstraints.add(c);
	}
    }

    public void addConstraint(PNode node, Constraint c) {
	Symbol type = c.getType();
	if (type == S_WORLD_STATE) {
	    worldStateCM.addConstraint(node, c);
	    return;
	}	

	Debug.noteln("Can't handle  <thesis> " + c + " at " + node);
	otherNodeConstraints.addValue(node, c);
    }

    public void deleteConstraint(Constraint c) {
	Debug.noteln("Asked to delete", c);
	Symbol type = c.getType();
	Symbol relation = c.getRelation();
	if (type == S_WORLD_STATE) {
	    if (relation == S_EFFECT) {
		PatternAssignment pv = (PatternAssignment)c.getParameter(0);
		deleteEffect(pv);
		return;
	    }
	}
	// /\/: What if constraints contain variables?
	if (otherConstraints.contains(c)) {
	    otherConstraints.remove(c);
	    return;
	}
	throw new IllegalArgumentException
	    ("No matching constraint to delete: " + c);
    }

    public List getNodeConditions(PNode node) {
	return worldStateCM.getNodeConditions(node);
    }

    public List getNodeEffects(PNode node) {
	return worldStateCM.getNodeEffects(node);
    }

    protected List getOtherNodeConstraints(PNode node) {
	return (List)otherNodeConstraints.get(node);
    }

    public List getOtherConstraints() {	// for PlanMaker /\/
	return otherConstraints;
    }

    public Map getWorldStateMap() {	// for PlanMaker and the simulator /\/
	return worldStateCM.getWorldStateMap();
    }

    public void setWorldStateMap(Map m) { // for Slip /\/
	// Not implemented until the IPlanModelManager \/\
	throw new UnsupportedOperationException();
    }

    /*
     * Filters
     */

    public List evalFilters(List conds, MatchEnv env) {
	Map worldStateMap = worldStateCM.getWorldStateMap();
	return variableManager.evalFilters(conds, worldStateMap, env);
    }

    public List reevaluateFilters(List conds) {
	Debug.noteln("");
	Debug.noteln("Re-evaluating filters", conds);
	Map worldStateMap = worldStateCM.getWorldStateMap();
	MatchEnv initialEnv = new MatchEnv();
	List envs = variableManager.evalFilters(conds, worldStateMap,
						initialEnv);
	MatchChoice mc = addMatchChoice(envs);
	Debug.noteln("");
	return mc.getLiveBranches();
    }

    public MatchChoice addMatchChoice(List envs) {
	List branches = Bindings.mapsToBindings(envs);
	MatchChoice mc = new MatchChoice(branches);
	variableManager.add(mc);
	variableManager.recalculate();
	variableManager.showState();
	return mc;
    }

    public void statusChanged(PNode node) {
	Debug.noteln("PMM sees new status of", node);
	if (node.getStatus() == Status.COMPLETE) {
	    handleCompletion(node);
	}
    }

    protected void handleCompletion(PNode node) {
	List effects = getNodeEffects(node);
	if (effects == null)
	    return;
	Set vars = Variable.varsAnywhereIn(effects);
	Set unbound = Variable.unboundVarsIn(vars);
	if (!unbound.isEmpty()) {
	    Debug.noteln("Unbound vars on completion of", node);
	    Debug.noteln("Vars are ", unbound);
	    System.out.println("Unbound vars on completion of " + node +
			       " Vars are: " + unbound);
	    node.setStatus(Status.IMPOSSIBLE);
	    addSentinel(new BindingSentinel(node, unbound));
	}
	else
	    handleEffects(node, effects);
    }

    protected void handleEffects(PNode node, List effects) {
	// N.B. All Variables in the effects must be bound.
	// /\/: Takes a list of PatternAssignments, NOT a list of Constraints.
	Map delta = worldStateCM.handleEffects(node, effects);
	fireStateChange(delta);
	runSentinels();
    }

    protected void handleEffects(List effects) {
	Map delta = worldStateCM.handleEffects(effects);
	fireStateChange(delta);
	runSentinels();
    }

    protected void deleteEffect(PatternAssignment pv) {
	worldStateCM.deleteEffect(pv);
	Map delta = new HashMap();
	delta.put(pv.getPattern(), pv.getValue());
	fireStateDeletion(delta);
    }

    /**
     * A sentinel that lets an activity become complete when all the
     * variables in its effects have values.
     */
    protected class BindingSentinel implements Sentinel {

	PNode node;
	Set unbound;

	BindingSentinel(PNode node, Set unbound) {
	    this.node = node;
	    this.unbound = new HashSet(unbound); // copy
	}

	public boolean isReady() {
	    Debug.noteln("Testing BindingSentinel for", node);
	    Set stillUnbound = Variable.unboundVarsIn(unbound);
	    return stillUnbound.isEmpty();
	}

	public void run() {
	    Debug.noteln("Able to complete", node);
	    Debug.noteln("Because all variables bound.");
	    node.setStatus(Status.COMPLETE);
	}

    }

    /*
     * State
     */
    /*
    public Plan getPlan() {
	return new ThesisPlanMaker(agent).getPlan();
    }

    public void setPlan(Plan plan) {
	// /\/ S.b. called loadPlan, because it adds to whatever
	// plan is already in the MM.
	ThesisPlanInstaller pi = new ThesisPlanInstaller(agent, plan);
	pi.installPlan();
	postProcessInstalledPlan(pi);
    }

    protected void postProcessInstalledPlan(ThesisPlanInstaller pi) {
	pi.walkInstalledPlan(new ThesisPlanInstaller.PlanWalker() {
	    public void visitAgendaItem(AgendaItem item) {
		if (!(item instanceof ActivityItem))
		    return;
		if (item.getStatus() == Status.POSSIBLE
		      && !Collect.isEmpty(item.getChildren())
		      && Collect.isEmpty(getNodeConditions(item))) {
		    item.setStatus(Status.EXECUTING);
		}
	    }
	});
    }
    */

    public Plan getPlan() {return null;}
    public void setPlan(Plan plan) {}

    /*
     * Sentinels
     */

    public void addSentinel(Sentinel r) {
	sentinels.add(r);
    }

    public void removeSentinel(Sentinel r) {
	sentinels.remove(r);
    }

    protected List getSentinels() {
	return sentinels;
    }

}

// javac -classpath ../../../ix-normal.jar:../imports/yab.jar:. ix/thesis/ThesisModelManager.java

// Issues:
// * There's only the singular deleteCondition and deleteEffect.
// * The whole idea of deleting constraints is very questionable.
