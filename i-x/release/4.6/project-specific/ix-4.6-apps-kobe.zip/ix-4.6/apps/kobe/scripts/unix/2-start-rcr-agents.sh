#! /bin/sh

# [<cv> <fb> <fs> <at> <ac> <pf> <po> [<host> [<port>]]]

java -cp ../../imports/yab.jar:../../imports/sample.jar sample.Main 0 10 1 5 1 10 1 127.0.0.0 8000 $*

echo "Start the ix agents (3-start-ix-agents.sh)"