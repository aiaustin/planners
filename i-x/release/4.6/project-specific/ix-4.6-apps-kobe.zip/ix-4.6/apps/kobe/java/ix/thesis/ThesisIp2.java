/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Created: February 2008 for I-X 4.5
 * Updated: Sun Feb 24 11:28:51 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.thesis;

import ix.ip2.*;

/**
 * A GUI-less I-P2 that can be used in agents that don't subclass Ip2.
 * This replaces the original approach of using slightly modified versions
 * of I-X 4.0 Ip2ModelManager and related classes, which became incompatible
 * with later versions.
 */
public class ThesisIp2 extends ix.test.PlainIp2 {

    public ThesisIp2() {
	super(false);		// neither interactive nor the main agent
    }

    public static ThesisIp2 makeInstance() {
	ThesisIp2 ip2 = new ThesisIp2();
	ip2.mainStartup(new String[]{}); // as if no command-line arguments
	return ip2;
    }

    protected void addHandlers() {
	// No handlers
    }

}
