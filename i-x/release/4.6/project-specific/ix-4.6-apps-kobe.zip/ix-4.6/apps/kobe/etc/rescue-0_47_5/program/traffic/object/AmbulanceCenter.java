package traffic.object;

public class AmbulanceCenter extends Building {
  public AmbulanceCenter(int id) { super(id); }
  public int type() { return TYPE_AMBULANCE_CENTER; }
}
