#!/bin/bash

function canonicalname {
    program="$0"
    
    while [ -h "$program" ] ; do
        cd `dirname "$program"`
        program=`basename "$program"`
        program=`ls -l "$program"`
        program=${program##*-> }
    done
    
    cd `dirname "$program"`
    echo $PWD/`basename $program`
}

DIR=`dirname \`canonicalname "$0"\``
DIR=$DIR/../program/yabapi

cd /home/s0125683/RoboCupRescue/rescue-0_45-unix/program/yabapi/sample/src/sample
sleep 1
mv PoliceForceAgent.java PoliceForceAgent-original.java
sleep 1
mv PoliceForceAgent-changed.java PoliceForceAgent.java
sleep 1
javac -classpath ../../../yab.jar PoliceForceAgent.java
sleep 3
mv PoliceForceAgent.java PoliceForceAgent-changed.java
sleep 1
mv PoliceForceAgent-original.java PoliceForceAgent.java
sleep 1
mv PoliceForceAgent.class ../../classes/sample/
sleep 1
cd /home/s0125683/RoboCupRescue/rescue-0_45-unix/program/yabapi/sample/classes
sleep 1
jar cvf sample.jar sample/
sleep 1
mv sample.jar ../..
sleep 1
cd /home/s0125683/RoboCupRescue/rescue-0_45-unix/boot
sleep 1
# versao com 10 police force + fire brigades
java -cp "$DIR/yab.jar:$DIR/sample.jar" sample.Main 0 10 1 0 1 10 1 $*