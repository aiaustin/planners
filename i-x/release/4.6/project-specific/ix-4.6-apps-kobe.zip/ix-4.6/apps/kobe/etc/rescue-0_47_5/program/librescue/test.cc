#include "test.h"
#include "connection.h"
#include "udp.h"
#include "input.h"
#include "output.h"
#include "common.h"
#include "error.h"
#include "objects.h"
#include <stdlib.h>

using namespace Librescue;

int main(int argc, char** argv) {
  // Connect to the kernel
  Output output;
  writeAK_CONNECT(output,0,0,(AgentType)(AGENT_TYPE_FIRE_BRIGADE | AGENT_TYPE_FIRE_STATION | AGENT_TYPE_AMBULANCE_TEAM | AGENT_TYPE_AMBULANCE_CENTER | AGENT_TYPE_POLICE_FORCE | AGENT_TYPE_POLICE_OFFICE));
  //  writeAK_CONNECT(output,0,1,AGENT_TYPE_FIRE_BRIGADE);
  output.writeInt32(HEADER_NULL);
  Address local("localhost",0);
  Address server(argv[1],atoi(argv[2]));
  LongUDPConnection serverConnection(local,2048,30,60);
  serverConnection.setTarget(server);
  logDebug("Sending AK_CONNECT");
  serverConnection.send(output);
  // Wait for a reply
  Input input;
  while (true) {
	serverConnection.receive(input);
	if (input.size()==0) {
	}
	else {
	  // Read the reply
	  Header header = HEADER_NULL;
	  INT_32 length;
	  do {
		header = (Header)input.readInt32();
		if (header!=HEADER_NULL) length = input.readInt32();
		else length = 0;
		char msg[255];
		snprintf(msg,255,"Received: %02x (length %d)",header,length);
		logDebug(msg);
		RescueObject* self;
		Objects knowledge;
		INT_32 tempID;
		INT_32 id;
		switch (header) {
		case KA_CONNECT_OK:
		  // Read the objects
		  tempID = input.readInt32();
		  id = input.readInt32();
		  snprintf(msg,255,"Reading KA_CONNECT_OK. TempID=%d, real id=%d",tempID,id);
		  logDebug(msg);
		  self = readObject(input,0);
		  readObjects(input,0,knowledge);
		  logDebug("Finished reading objects");
		  delete self;
		  for (Objects::iterator it = knowledge.begin();it!=knowledge.end();++it) {
			delete *it;
		  }
		  // Send an acknowledge
		  logDebug("Sending acknowledge");
		  output.clear();
		  writeAK_ACKNOWLEDGE(output,id);
		  output.writeInt32(HEADER_NULL);
		  serverConnection.send(output);
		  break;
		case KA_CONNECT_ERROR:
		  logWarning("Error connecting to kernel");
		  logWarning(input.readString().c_str());
		  break;
		default:
		  input.skip(length);
		  break;
		}
	  } while (header!=HEADER_NULL);
	  break;
	}
  }
  serverConnection.close();
  return 0;
}
