/*
 * Header    :
 * File      : CivilianController.cxx
 * Auther    : Kosuke Shinoda
 * Since     : 2001/11/19
 * Time-stamp: <2002-04-28 01:28:55 kshinoda>
 * Comment   :
 * End       :
 */
/*
 * Copyright (C) 2001 SHINODA, Kosuke. Jaist,Japan & CARC, AIST, JAPAN
 * Copyright (C) 2001 NODA, Itsuki, CARC, AIST, JAPAN
 */

/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#include "../itk/itk.h"
#include "../rescuelang/AgentBase.h"
#include "CivilianController.hxx"
#include "error.h"

#define S32_MAX 0x7FFFFFFF

using namespace std;
using namespace Librescue;
using namespace Itk;
using namespace RescueCivilian;

void CivilianController::needToCycle2(Sexp* result) {
  //if(result->equal(RescueAgentBase::noAction) 
  //|| result->equal(RescueAgentBase::bodyAction))
    needto_cyclep = False;
    //  else
    //needto_cyclep = True;
};

void CivilianController::nextstep(){
  needto_cyclep = True;
};

Sexp* CivilianController::cycle() {
  //env().agentbase().traceOn();
  Sexp* result = env().agentbase().cycle();
  //env().agentbase().traceOff();
  return result;
};

void CivilianController::sensed(INT_32 time,
                                Connection& socket, 
                                Input& input, Output& output){
  // restructure objectpool with new object information
  m_time = time;

  env().setEnvironmentalInformation(m_time, input);
  // get own information
  env()._self() = dynamic_cast<Humanoid*>(env().map().getObject(m_selfId));
};


void CivilianController::heard(Connection& socket,
                               Id speaker,
                               const char* message,
                               Input& input,
                               Output& output){
  //env().addMessageBuffer(message);
  printf("heard %s form %ld\n", message, speaker);
};

//------------------------------------------------------------
//
Path CivilianController::circuitWalk(){
  RescueObject* current = env().current();
  RescueObject* next    = 0;
  Path path;
  INT_32 num_of_visited = m_NumOfVisited[current];
  INT_32 path_length = (num_of_visited < 3)? 2 : ((num_of_visited < 10)? 5 : 1);

  //  logDebug("Doing circuit walk");
  for(; path_length != 0; path_length--){
    next = selectNode(current);
	//	LOG_DEBUG("Next node type %d, id %d",next->type(),next->id());
    path.push_back(next);
    current = next;
  }
  return path;
};

RescueObject* CivilianController::selectNode(RescueObject* current){
  RescueObject* nextPosition = 0;
  INT_32 min = 1000000; // This should be big enough
  
  // search next moving target :: least visited position
  Objects neighbours = env().map().getNeighbours(current);
  //  LOG_DEBUG("Choosing neighbour of %d",current->id());
  for(Objects::const_iterator it = neighbours.begin();
      it != neighbours.end(); it++){
    RescueObject* pos = *it;
    if(pos){
	  //	  LOG_DEBUG("Next neighbour: type %d, id %d",pos->type(),pos->id());
      Building* building = dynamic_cast<Building*>(pos);
      Refuge*   refuge   = dynamic_cast<Refuge*>(pos);
      if(building && !refuge) {
		//		LOG_DEBUG("Ignoring building");
		continue;
	  }
      INT_32 num_of_visit = 0;
      if(m_NumOfVisited.find(pos) != m_NumOfVisited.end()){
        num_of_visit = m_NumOfVisited[pos];
		//		LOG_DEBUG("Visited neighbour %d times already",num_of_visit);
        if(num_of_visit < min){
          min = num_of_visit;
          nextPosition = pos;
		  logDebug("Neighbour is OK");
        }
      } else {
		logDebug("Never visited neighbour");
        num_of_visit = min = 0;
        nextPosition = pos;
        break;
      }     
    }
  }
  // If next position can select
  if(nextPosition){
    if(m_NumOfVisited.find(current) != m_NumOfVisited.end()){
      INT_32 num_of_visit = m_NumOfVisited[current] + 1;
      m_NumOfVisited[current] = num_of_visit;
    } else {
      m_NumOfVisited[current] = 1;
    }
  }
  return nextPosition;
};


//------------------------------------------------------------
// Civilian::setRoadPath
Path CivilianController::setRoadPath(RescueObject* from, 
                                     RescueObject* to){
  Bool success = False;

  Path open;
  Path closed;
  CounterTable cost;
  CounterTable heuristic;
  map<RescueObject*, RescueObject*> solution;

  Path plan;

  cost[from] = 0;
  heuristic[from] = distance(from, to);
  
  open.push_back(from);

  S32 counter = 0;
  S32 counter_max = (S32)(20.0 + fltRand(-10.0,20.0));

  //  LOG_DEBUG("Planning path from type %d, id %d to type %d, id %d",from->type(),from->id(),to->type(),to->id());
  //printf("counter max : %ld  ", counter_max);
  for(; counter < counter_max ; counter++){
    if(open.size() == 0){
      success = False;
      break;
    } else {
      RescueObject* node = open.front();
      open.erase(open.begin());
	  //	  LOG_DEBUG("Next: Type=%d, id=%d",node->type(),node->id());
      if(node->id() == to->id()){
        success = true;
        break;
      } else {
        closed.push_back(node);
        open.remove(node);
		Objects neighbours = env().map().getNeighbours(node);
        for(Objects::const_iterator it = neighbours.begin();
            it != neighbours.end(); it++){
          RescueObject* obj = *it;
          Road* road = dynamic_cast<Road*>(obj);
		  //		  LOG_DEBUG("Neighbour: Type=%d, id=%d",obj->type(),obj->id());
          if(road){
            //S32 update_time = road->getTimeBlockUpdated();
            //if(update_time == 0){
			;//obj = 0;
			//} else {
			int aliveLines = 0;
			if(road->getHead() == node->id()){
			  aliveLines = getAliveLinesToTail(road);
			  if(road->getTail() != 0)
				obj = env().map().getObject(road->getTail());
			  else
				printf(" no tail node-----------\n");
			} 
			else if(road->getTail() == node->id()){
			  aliveLines = getAliveLinesToHead(road);
			  if(road->getHead())
				obj = env().map().getObject(road->getHead());
			  else
				printf(" no head node-----------\n");
                                  
			}
			if(aliveLines == 0)
			  continue;
			//}
          }
          Building* building = dynamic_cast<Building*>(obj);
          if(building != 0){
            if(obj->id() != to->id())
              continue;
          }
          if(obj){
            S32 cost_tmp = cost[node] + distance(node, obj);
            Path::iterator open_it   = find(open.begin(), open.end(),obj);
            Path::iterator closed_it = find(closed.begin(), closed.end(), obj);
            if(open_it == open.end() && closed_it == closed.end()){
              cost[obj] = cost_tmp;
            } else {
              if(cost_tmp < cost[obj])
                cost[obj] = cost_tmp;
            }
            S32 heuristic_tmp = cost_tmp + distance(obj, to);
            if(open_it == open.end() && closed_it == closed.end()){
              heuristic[obj] = heuristic_tmp;
              open.push_back(obj);
              if(road != 0 && obj != road) {
                solution[road] = node;
                solution[obj] = road;
				//				LOG_DEBUG("We get to id %d via road %d from %d",obj->id(),road->id(),node->id());
              } else {
                solution[obj] = node;
				//				LOG_DEBUG("We get to id %d from %d",obj->id(),node->id());
			  }
            }
            if(open_it != open.end() && heuristic_tmp < heuristic[obj]){
              heuristic[obj] = heuristic_tmp;
              if(road) {
                solution[road] = node;
                solution[obj] = road;
				//				LOG_DEBUG("We get to id %d via road %d from %d",obj->id(),road->id(),node->id());
              } else {
                solution[obj] = node;
				//				LOG_DEBUG("We get to id %d from %d",obj->id(),node->id());
			  }
            }
            if(closed_it != closed.end() && heuristic_tmp < heuristic[obj]){
              heuristic[obj] = heuristic_tmp;
              closed.remove(obj);
              open.push_back(obj);
              if(road != 0) {
                solution[road] = node;
                solution[obj] = road;
				//				LOG_DEBUG("We get to id %d via road %d from %d",obj->id(),road->id(),node->id());
              } else {
                solution[obj] = node;
				//				LOG_DEBUG("We get to id %d from %d",obj->id(),node->id());
			  }
            }
          }
        }
      }
    }
    sortByHeuristicValue(open, heuristic);
  }
  //printf("counter %ld\n", counter);

  //  LOG_DEBUG("Building plan from %d to %d",from->id(),to->id());
  if(success){
    RescueObject* node = to;
    for(;;){
      if(node->id() == from->id()) break;
      plan.push_front(node);
      RescueObject* next = solution[node];
	  //	  LOG_DEBUG("We get to id %d from %d",node->id(),next->id());
	  node = next;
    }
  } else {
    if(open.size() > 0){
      S32 min_dist = S32_MAX;
      RescueObject* node = open.front();
      for(Path::const_iterator it = open.begin();
		  it != open.end(); it++){
        S32 dist = distance(*it, to);
        if(dist < min_dist){
          min_dist = dist;
          node = *it;
        }
      }    
	  //	  LOG_DEBUG("Closest open node is type %d, id %d",node->type(),node->id());
      for(;;){
        if(node->id() == from->id()) break;
        plan.push_front(node);
        RescueObject* next = solution[node];
		//		LOG_DEBUG("We get to id %d from %d",node->id(),next->id());
		node = next;
      }
    }
	//	else LOG_DEBUG("Open list is empty");
  }
  //  LOG_DEBUG("Final path: ");
  //  for (Path::iterator it = plan.begin();it!=plan.end();++it) {
	//	LOG_DEBUG("Type %d id %d",(*it)->type(),(*it)->id());
  //  }
  return plan;
};

S32 CivilianController::distance(RescueObject* from, RescueObject* to){
  return env().map().range(from,to); // NOTE: This is different behaviour to the line below. Objectpool.range returns euclidean distance, not manhatten.
  //  return (S32)(fabs((double) from->x() - to->x()) + fabs((double) from->y() - to->y()));
};

S32 CivilianController::getAliveLinesToHead(Road* road){
  double lineWidth =
    ((double)road->getWidth())/((double)(road->getLinesToHead()+road->getLinesToTail()));
  double blockWidth = ((double)road->getBlock())/2.0;
  double linesBlockedRate = blockWidth/lineWidth;
  S32 linesBlocked = (S32)floor(linesBlockedRate + 0.5);
  S32 linesAliveHead = road->getLinesToHead() - linesBlocked;
  if(linesAliveHead < 0) linesAliveHead = 0;
  return linesAliveHead;
};
S32 CivilianController::getAliveLinesToTail(Road* road){
  double lineWidth =
    ((double)road->getWidth())/((double)(road->getLinesToHead()+road->getLinesToTail()));
  double blockWidth = ((double)road->getBlock())/2.0;
  double linesBlockedRate = blockWidth/lineWidth;
  S32 linesBlocked = (S32)floor(linesBlockedRate + 0.5);
  S32 linesAliveTail = road->getLinesToHead() - linesBlocked;
  if(linesAliveTail < 0) linesAliveTail = 0;
  return linesAliveTail;
};

void CivilianController::sortByHeuristicValue(Path open, 
                                              CounterTable heuristic){
  Path newTable;
  RescueObject* min;
  RescueObject* tmp;

  while(open.size() > 0){
    min = open.front();
    for(int i = 1; i < (signed int)open.size();i++){
      Path::iterator it = open.begin();
      advance(it, i);
      tmp = *it;
      if(heuristic[min] > heuristic[tmp])
        min = tmp;
    }
    newTable.push_back(min);
    open.remove(min);
  }
  *&open = *&newTable;
};

//----------------------------------------------------------------------
// CivilianController :: agent action command

//------------------------------------------------------------
// CivilianController::move_to_refuge
//  move to nearest refuge : distance
void CivilianController::move_to_refuge(){
  // set id of nearest refuge from current position
  Refuge* near_refuge = 0;
  double min_dist = (double)S32_MAX;
  for(Objects::const_iterator it = env().pool().objects().begin();
      it != env().pool().objects().end(); it++){
    Refuge* refuge = dynamic_cast<Refuge*>(*it);
    if(refuge){
      double dist = env().distance(refuge);
      if(dist < min_dist){
        min_dist = dist;
        near_refuge = refuge;
      }
    }
  }
  if(near_refuge){
    Path path = setRoadPath(env().current(), near_refuge);
    if(path.size() == 0){
      path = circuitWalk();
    }
    move(socket(), path, output());
  } else {
    Path path = circuitWalk();
    move(socket(), path, output());
  }  
};

//------------------------------------------------------------
//
void CivilianController::move_to_refuge(Id refuge_id){
  RescueObject* refuge = env().pool().getObject(refuge_id);
  if(refuge){
    Path path = setRoadPath(env().current(), refuge);
    if(path.size() == 0)
      path = circuitWalk();
    move(socket(), path, output());
  } else {
    Path path = circuitWalk();
    move(socket(), path, output());
  }
};

void CivilianController::move_to(Id target_id){
  RescueObject* target = env().pool().getObject(target_id);
  if(target){
    Path path = setRoadPath(env().current(), target);
    if(path.size() == 0){
      path = circuitWalk();
    }
    move(socket(), path, output());
  } else {
    Path path = circuitWalk();
    move(socket(), path, output());
  }
};


void CivilianController::say_message(Sexp* message){
  SubString str = message->symVal();
  char msg[str.length()];
  str.copyTo(msg, str.length());
  say(socket(), msg, output());
};
