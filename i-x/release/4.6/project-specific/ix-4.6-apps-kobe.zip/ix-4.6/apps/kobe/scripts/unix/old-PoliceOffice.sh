#!/bin/sh

app_params="-load config/PoliceOffice.props"
app_params="${app_params} -plan-state-to-save=*"
app_params="${app_params} -ipc=xml -run-name-server"

export app_params

cd ../..
app_base=`pwd`
export app_base
app_path=`pwd`/java

cd ..
app_path="${app_path}:`pwd`/addon/map/java"
app_path="${app_path}:`pwd`/addon/map/imports/openmap.jar"
app_path="${app_path}:`pwd`/irescue/imports/yab.jar"

export app_path
cd ..
ix_base=`pwd`
cd ${app_base}
export ix_base
java_params=
export java_params
ipc="xml"
export ipc

#${ix_base}/scripts/unix/run-ix-app ix.ip2.Ip2
${ix_base}/scripts/unix/run-ix-app ix.rcragents.PoliceOffice &
