#! /bin/sh
DIR=`dirname $0`
$DIR/../program/kernel/kernel -file $DIR/config.txt $*
