package ix.rcragents.handlers;

import java.util.Iterator;
import java.util.Hashtable;
import java.util.Vector;
import java.util.List;

import ix.ip2.*;
import ix.ispace.ContactManager;
import ix.ispace.AgentRelationship;
import ix.ispace.AgentData;
import ix.icore.domain.Constraint;
import ix.icore.domain.NodeSpec;
import ix.icore.domain.Refinement;
import ix.icore.domain.PatternAssignment;
import ix.icore.Report;
import ix.icore.Status;
import ix.util.Name;
import ix.util.lisp.*;
import ix.util.Gensym;

//import yab.agent.DisasterSpace;
//import yab.agent.Router;
import yab.agent.*;
import yab.agent.object.*;
import ix.rcragents.PoliceOffice;

public class SimpleAllocatorHandler extends ActivityHandler  {

    private Ip2 ip2;
    private DisasterSpace world;

    private static int MAX_NUM_NODES = 2;
    private static int MAX_ALLOCATION = 1;

    public SimpleAllocatorHandler(Ip2 ip2){
	super("Simple Allocation");
	this.ip2 = ip2;
    }

    public boolean appliesTo(AgendaItem item) {
	LList pattern = item.getPattern();
	if (pattern.get(0) == Symbol.intern("Clear")){
	    return true;
	}
	else
	    return false;
    }

    public void handle(AgendaItem item) {

	List subordinates = (ip2.getContactManager()).getAgentData(AgentRelationship.SUBORDINATE);	
	Hashtable ixrcr = createTable(subordinates);
	List betterAgents = null;
	String ixAgentChosen = null;
	Hashtable allocationTable = createAllocationTable(subordinates);
	Vector nodes = new Vector();

	String [] buffer = new String[subordinates.size()];
	int j=0;

	for(int i=0;ixAgentChosen==null;i++) {
	    betterAgents = getBetterSubordinates(i,allocationTable,subordinates);
	    while( (betterAgents.size()>0) && (nodes.size()<MAX_NUM_NODES) ){
		ixAgentChosen = getClosestAgent(betterAgents,item,ixrcr);
		nodes.add(createNode(ixrcr.get(ixAgentChosen),item));
		betterAgents.remove(ixAgentChosen);
		buffer[j++] = ixAgentChosen;
		if(i >= MAX_ALLOCATION) break;
	    }
	}

	Refinement ref = new Refinement();
	ref.setPattern(item.getPattern());	
	ref.setNodes(nodes);
	((ip2.getController()).getActivityAgenda()).expandItem(item, ref);

	j=0;
	Iterator iii = (((ip2.getController()).getActivityAgenda()).getItems()).iterator();
	AgendaItem child;
	while(iii.hasNext()){
	    child = (AgendaItem) iii.next();
	    if( child.getParent() == item) {
		child.clearActions();
		ForwardingHandler fh = new ForwardingHandler(ip2, "Delegate", AgentRelationship.SUBORDINATE, true);
		HandlerAction ha = fh.makeForwardingAction(buffer[j++],child);
		child.addAction(ha);
		((ip2.getController()).getActivityAgenda()).handleItem(child,ha);
		//break;
	    }
	}
    }

    protected NodeSpec createNode(Object rcrId, AgendaItem item) {
	NodeSpec node = new NodeSpec();
	LList nodeName = Lisp.cons(rcrId,Lisp.NIL);
	//nodeName = Lisp.cons(Symbol.intern("Allocate"),nodeName);
	nodeName = Lisp.cons(Symbol.intern("to"),nodeName);
	nodeName = Lisp.cons(Symbol.intern(((item.getPattern()).get(1)).toString()),nodeName);
	nodeName = Lisp.cons(Symbol.intern("Allocate"),nodeName);
	node.setPattern(nodeName);
	return node;
    }


    protected List getBetterSubordinates(int al,Hashtable allocTable,List subordinates) {
	Vector result = new Vector();
	Iterator i = subordinates.iterator();
	String agentName;
	int nAllc;
	while(i.hasNext()) {
	    agentName = ((AgentData) i.next()).getName();
	    nAllc = ((Integer) allocTable.get(agentName)).intValue();
	    if(nAllc == al) result.add(agentName);
	}
	return result;
    }

    protected Hashtable createAllocationTable(List subordinates) {
	Hashtable result = new Hashtable();
	Iterator i = subordinates.iterator();

	while(i.hasNext()) {
	    result.put(((AgentData) i.next()).getName(),new Integer(0));
	}
	
	Iterator ii = (((ip2.getController()).getActivityAgenda()).getItems()).iterator();
	AgendaItem tempItem;
	String actionName,agentName;
	int tempValue;

	while(ii.hasNext()) {
	    tempItem = (AgendaItem) ii.next();
System.out.println(">>>>>>>> 1");
	    if( tempItem.getStatus()==Status.EXECUTING && (tempItem.getChildren()).size()==0) {
System.out.println(">>>>>>>> 2");
		actionName = (tempItem.getHandledBy()).getActionDescription();
		agentName = actionName.substring((actionName.indexOf("PoliceForce")));
		tempValue = ((Integer)result.get(agentName)).intValue();
		tempValue++;
System.out.println("3>>>>>>>> "+agentName+" "+tempValue);
		result.put(agentName,new Integer(tempValue));
	    }
	}

/*	while(ii.hasNext()) {
	    tempItem = (AgendaItem) ii.next();
	    if(tempItem.getStatus() == Status.EXECUTING) {
		if (tempItem.getChildren() == null) {
		    actionName = (tempItem.getHandledBy()).getActionDescription();
		    agentName = actionName.substring((actionName.indexOf("PoliceForce")));
		    tempValue = ((Integer)result.get(agentName)).intValue();
		    tempValue++;
		    result.put(agentName,new Integer(tempValue));
		}
		else {
		    Iterator subI = (tempItem.getChildren()).iterator();
		    while(subI.hasNext()) {
			tempItem = (AgendaItem) subI.next();
			if (tempItem.getChildren() == null) {
			    actionName = (tempItem.getHandledBy()).getActionDescription();
			    agentName = actionName.substring((actionName.indexOf("PoliceForce")));
			    tempValue = ((Integer)result.get(agentName)).intValue();
			    tempValue++;
			    result.put(agentName,new Integer(tempValue));
			}
		    }
		}
	    }
	}
*/
	return result;
    }

    protected String getClosestAgent(List betterAgents,AgendaItem item,Hashtable ixrcr){

	Iterator i = betterAgents.iterator();
	String ixAgentChosen = null;
	String ixTemp;
	int target;
	float costTemp = Float.MAX_VALUE;
	float currentChosenCost = Float.MAX_VALUE;

	while(i.hasNext()) {

	    ixTemp = (String) i.next();
	    Object rcr = ixrcr.get(ixTemp);

	    if(rcr!=null){
		target = (new Integer(((item.getPattern()).get(1)).toString())).intValue();

		MotionlessObject origin = getMotionlessPosition(rcr.toString());
		Vector destination = new Vector();
		destination.add((((PoliceOffice)ip2).getWorldObject(target)).motionlessPosition());

		if (!(origin instanceof Road)  ||  ((Road) origin).passableLines() >= 1) {
		    try{
			costTemp =  (Router.get(origin, destination, RELIABILITY_COST_FUNCTION)).cost;
		    }catch(Exception e){System.out.println("NO POSSIBLE!!!");}
		}
		else {
		    Road rd = (Road) getMotionlessPosition(rcr.toString());
		    try{
			costTemp = (Router.get(rd.head(), destination,RELIABILITY_COST_FUNCTION)).cost;
			//(self().positionExtra() < rd.length() / 2) ? rd.head() : rd.tail();
		    }catch(Exception e){System.out.println("NO POSSIBLE!!!");}
		}

		if (costTemp < currentChosenCost) {
		    currentChosenCost = costTemp;
		    ixAgentChosen = ixTemp;
		}
	    }
	}
	return ixAgentChosen;
    }	

    private MotionlessObject getMotionlessPosition(String rcr){

	LList pattern;
	Object posO;
	int posI;
	
	pattern = Lisp.cons(new Long(rcr),Lisp.NIL);
	pattern = Lisp.cons(Symbol.intern("position"),pattern);

	posO = (((Ip2ModelManager)ip2.getModelManager()).getWorldStateMap()).get(pattern);	
	posI = (new Integer(posO.toString())).intValue();

	return (((PoliceOffice)ip2).getWorldObject(posI)).motionlessPosition() ;
    }

    private Hashtable createTable(List sub) {
	Hashtable result = new Hashtable();
	LList pattern;
	Object rcr;

	Iterator i = sub.iterator();
	String ix;
	while(i.hasNext()) {
	    ix = ((AgentData) i.next()).getName();
	    pattern = Lisp.cons(Symbol.intern(ix),Lisp.NIL);
	    pattern = Lisp.cons(Symbol.intern("rcrId"),pattern);
	    rcr = (((Ip2ModelManager)ip2.getModelManager()).getWorldStateMap()).get(pattern);
	    if(rcr != null) result.put(ix,rcr);
	}
	return result;
    }

    private static final Router.CostFunction RELIABILITY_COST_FUNCTION = new Router.CostFunction() {
	public float cost(MotionlessObject from, MotionlessObject to) {
	    final int WEIGHT = Integer.MAX_VALUE;
            float c = 1;
            if (!(to instanceof Road))
		return c;
            Road rd = (Road) to;
            PointObject po = (PointObject) from;
            if (rd.passableLinesFrom(po) == 0)
		return c * WEIGHT * WEIGHT;
            return rd.hasBeenSeen() ? c : c * WEIGHT; 
	}
    };
}

//javac -classpath ../../../ix.jar:../imports/yab.jar:. ix/rcragents/handlers/SimpleAllocatorHandler.java

