package io;

import world.WorldConstants;

/**
 * @author tn
 */
public interface IOConstans extends WorldConstants{

	final static int PACKAGE_SIZE 			= 1472;
	
	final static int HEADER_NULL 			= 0x00;
	
	final static int AK_CONNECT 			= 0x10;
	final static int AK_ACKNOWLEDGE 	= 0x11;
	
	final static int SK_CONNECT 			= 0x20;
	final static int SK_ACKNOWLEDGE 	= 0x21;
	final static int SK_UPDATE				= 0x22;
	
	final static int KS_CONNECT_OK 	= 0x60;
	final static int KS_COMMAND 			= 0x62;
	final static int KS_UPDATE				= 0x63;
	
	final static int INIT_TIME 				= 0;

}
