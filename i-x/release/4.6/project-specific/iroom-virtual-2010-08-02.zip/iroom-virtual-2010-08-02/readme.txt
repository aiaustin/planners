I-ROOM DEMONSTRATION
--------------------
Last Updated: Mon Aug 02 09:55:40 2010

Simple demonstration of I-Serve communications and I-X services
running on a local Windows machine, and their links to I-Room
functionality. It can server as a generic application base to be
adapted as required..

There are three I-Room applications included in this demo:
- Meeting Support
- Emergency Response
- Whisky Tasting

The different resources for each of these applications can be used
separately or together to display different aspects of the I-Room
functionality.

The system includes a HTTP-based communications server (I-Serve), a
Process Panel (I-P2), a Chat Logger, and associated services; in
addition, there are LSL scripts provided to construct linked I-Room
objects in Second Life or OpenSim.

CONFIGURATION
-------------

I-Serve Configuration
---------------------

If you do *not* want to run the server on the local machine using port
80 then you must edit the appropriate line(s) in the file:

     scripts/win/1-run-iroom-server.bat

NB to allow external connections (such as those from Second Life or
OpenSim) this combination of host and port needs to be accessible
through your firewall(s).

(If you intend to use an I-Serve server already running on a different
computer, edit the content of the file http-doc-root/comm-server-url.txt
to give the appropriate address and port information and omit step 1
under "RUNNING" below.)

I-P2 Configuration
------------------

To configure the I-P2 according to the demonstration you wish to give,
edit the file win/scripts/2-run-iroom-ip2.bat, and set the value of
the parameters MEETING_SUPPORT, EMERGENCY_RESPONSE and WHISKY_DEMO to
true or false accordingly (default is that only MEETING_SUPPORT is true).

Second Life/OpenSim Configuration
---------------------------------

Also included here are the sources that will allow you to create
virtual world I-Room objects that interact with I-Serve, I-P2 and the
Chat Logger from Second Life and OpenSim.

Note: if you are using OpenSim, XML-RPC remote data port handling must
be enabled in the [XML-RPC] section within Opensim.ini, and you will
need to modify the content of the file config/virtual-worlds.xml to
supply the appropriate values of shard (from Opensim.ini [Network]
section and xml-rpc-url (from OpenSim Host Name and Opensim.ini
[XMLRPC] section XmlRpcPort). Hence, you will need to contact the
OpenSim administrator for these values but typically they will be:

     shard = OpenSim
     xml-rpc-url = http://hostname:20800

I-Room Helper
-------------

In the Second Life/OpenSim region that you are using as the virtual
space for your I-Room you will need to create an object called the
I-Room Helper.  This object acts as a conduit between the activities
in the I-Room and the external support provided by the I-P2, Chat
Logger and associated services.

Once you have created this object, you will need create content for
the object based on the contents of the directory:

     Put in SL or OpenSim Objects/I-Room Helper

Specifically, you will need to create LSL scripts called "I-Room
Helper Script" and "I-X Comms Script" and copy into them the contents
of the corresponding files, and also create three notecards called
"I-Room Setup", "I-X Comms Setup", "I-Room Helper Command Summary" (it
is important that these notecards have these specific names).

Next you will need to edit this content as follows:

- (optional) in the script "I-X Comms Script", change the in-world chat
channel that the Helper object listens on for commands (default 91).

- in the notecard "I-X Comms Setup", you will need to change the value
of the server parameter to include the full domain name of the
computer on which you are running I-Serve.

- in the notecard "I-Room Setup", you can alter the local chat
channels on which various in-world objects (such as display screens -
see below) are listening for commands (the I-Room Helper interacts
with these objects via local chat). New capabilities can also be added.

- (optional) in the script "I-Room Helper", change the in-world chat
channel that the Helper object listens on for commands (default 99).

I-Room Chat Relay
-----------------

Similarly, if you wish to have a Chat Relay/Logger service running in the
virual I-Room, create an in-world object and add to it the contents of the
directory:

     Put in SL or OpenSim Objects/I-Room Chat Relay

Specifically, you will need to create LSL scripts called "I-Room Chat
Relay Script" and "I-X Comms Script" and copy into them the contents
of the corresponding files, and a notecard called "I-X Comms Setup"
(it is important that this notecard has this specific name).

Next you will need to edit this content as follows:

- in the notecard "I-X Comms Setup", you will need to change the value
of the server parameter to include the full domain name of the
computer on which you are running I-Serve.

- (optional) in the script "I-X Comms Script", change the in-world
chat channel that the Helper object listens on for commands (default
92). Note this must be different to the channel used for the "I-Room
Helper" if they are both in the same region.

I-Room Display
--------------

To create one or more image/video stream display screen in the virtual
I-Room, you can use the contents of the directory:

     Put in SL or OpenSim Objects/I-Room Display

For each screen create an in-world display object (you will probably
want a reasonably large object with a vertical face with width:height
dimension in the ratio of roughly 4:3). Next create in this object an
LSL script called "I-Room Display Script" copy into this the contents
of the corresponding file.  You will need to edit this content if you
wish the display object to listen on a channel other than the default
(10). (Note that, if you have more than one display object, you will
probably want them to listen on different channels.) If you change the
channel value(s), you should update the "I-Room Setup" notecard in
I-Room Helper object to reflect these changes.


RUNNING
-------

1. start scripts/win/1-run-iroom-server.bat

2. start scripts/win/2-run-iroom-ip2.bat

3. in the I-P2, select Tools > I-Serve Communications and "Register"

4. if using a chat relayer/logger start
   scripts/win/3-run-iroom-chat-relayer.bat

5. in the chat-service, select Tools > I-Serve Communications and
   "Register" - note that the service name "chat-service" is currently
   hard wired and should not be changed without coresponding changes
   elsewhere.

6. start the I-Room Helper and I-Room Chat Relay objects in Second
   Life/OpenSim, using the touch menu or local chat to register the
   objects with the server.


When running, the status of I-Serve can be checked by visiting the
following URL:

   http://<hostname>:<port>/ipc/status

with control functions over registered agents available here:

   http://<hostname>:<port>/ipc/control

