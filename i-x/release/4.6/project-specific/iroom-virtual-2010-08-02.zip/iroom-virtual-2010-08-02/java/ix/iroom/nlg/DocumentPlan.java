package ix.iroom.nlg;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class DocumentPlan {
	
	private List<Message> messageList = new ArrayList<Message>(7);
	private List<int[]> docStructure = new ArrayList<int[]>();
	private Message distilleryMsg, bottlingMsg, colourMsg, noseMsg, bodyMsg, palateMsg, finishMsg;
	private WhiskyOntologyLookup WOL;
	private String whisky, goal, user, history;
	private boolean hasYear, hasNoGoldColour, isDistClosed;
	private boolean hasDist, hasBtl, hasCol, hasNose, hasPal, hasBody, hasFin;
	private boolean isDistIn, isBtlIn, isColIn, isNoseIn, isPalIn, isBodyIn, isFinIn;
	
	public DocumentPlan(WhiskyOntologyLookup wol, String w, String g, String u, String h){
		WOL=wol;
		whisky=w;
		goal=g;
		user=u;
		history=h;
		//Only implementing Description Messages for now
		if (goal.equalsIgnoreCase("instruct")) {
			createDescrMessages();
			orderMessageList();
			createDocPlan();
		}
		else {
			System.err.print("Error: only description messages can be generated");
//			System.exit(-1);
		}
	}
	
	public List<Message> getMessageList(){
		return messageList;
	}
	
	public List<int[]> getDocStructure(){
		return docStructure;
	}
	
	public void createDocPlan(){
		//Expert document plan
		//Basic rule: Join sentences every two messages
		//Extension 1: If there are no more messages make it a single sentence
		//Extension 2: Always join Body and Finish messages in a single sentence
		
		//Novice document plan
		//Basic rule: One message per sentence.
		//Exception 1: Join the distillery and bottling message into a single sentence
		
		if (user.equalsIgnoreCase("expert")){
			int bodyMsgIndex = messageList.indexOf(bodyMsg);
			int finMsgIndex = messageList.indexOf(finishMsg);
			//Extension 2
			int tmpArr[] = {bodyMsgIndex,finMsgIndex};
			docStructure.add(tmpArr);
			Iterator<Message> it = messageList.listIterator();
			while (it.hasNext()){
				Message tempMsg = it.next();
				if (!tempMsg.equals(bodyMsg)){
					//Extension 1
					if (messageList.indexOf(tempMsg)+1==bodyMsgIndex){
						int tmpArr1[] = {messageList.indexOf(tempMsg)};
						docStructure.add(docStructure.size()-1,tmpArr1);
					}
					//Basic rule
					else {
						int tmpArr2[] = {messageList.indexOf(tempMsg),messageList.indexOf(tempMsg)+1};
						docStructure.add(docStructure.size()-1,tmpArr2);
						tempMsg = it.next();
					}
				}
				else break;
			}
		}
		else {
			int distMsgIndex = messageList.indexOf(distilleryMsg);
			int btlMsgIndex = messageList.indexOf(bottlingMsg);
			int tmpArr[] = {distMsgIndex,btlMsgIndex};
			docStructure.add(tmpArr);
			//Start from the next of the bottling message
			Iterator<Message> it = messageList.listIterator(btlMsgIndex+1);
			while (it.hasNext()){
				Message tempMsg = it.next();
				int tempArr1[] = {messageList.indexOf(tempMsg)}; 
				docStructure.add(tempArr1);
			}
		}
	}
	
	public void orderMessageList(){
		//WARNING: List is zero based
		//Expert ordering rules:
		//1: If the distillery is closed -> 1st=Distillery+"closed"
		//2: If there is a year of bottling -> 1st=Year
		//3: If 1 and 2 fail -> 1st=Distillery
		//4: If the colour is not gold or full gold -> 2nd=Colour
		//5: If there is a matching previous history attribute -> 2nd=That attribute (except body & finish)
		//6: Follow normal ordering with the rest (if the attribute exists)
		//Normal ordering:
		//1st = Distillery
		//2nd = Bottling
		//3rd = Colour
		//4th = Nose
		//5th = Palate
		//6th = Body
		//7th = Finish
		//Novice ordering rules:
		//1st = Distillery
		//2nd = Bottling
		//3rd = Colour
		//6th = Body
		//4th = Nose
		//5th = Palate
		//7th = Finish
		
		if (user.equalsIgnoreCase("expert")){
			//Rule 1
			if (isDistClosed){
				messageList.add(messageList.size(), distilleryMsg);
				isDistIn = true;
			}
			//Rule 2
			if (hasYear) {
				messageList.add(messageList.size(), bottlingMsg);
				isBtlIn = true;
			}
			//Rule 3
			messageList.add(messageList.size(), distilleryMsg);
			isDistIn = true;
			//Rule 4
			if (hasNoGoldColour){
				messageList.add(messageList.size(), colourMsg);
				isColIn = true;
			}
			//Rule 5
			if (distilleryMsg.getCompValues()!=null){
				if (!isDistIn){
					messageList.add(messageList.size(), distilleryMsg);
					isDistIn = true;
				}
			}
			if (bottlingMsg.getCompValues()!=null){
				if (!isBtlIn){
					messageList.add(messageList.size(), bottlingMsg);
					isBtlIn = true;
				}
			}
			if (colourMsg.getCompValues()!=null){
				messageList.add(messageList.size(), colourMsg);
				isColIn = true;
			}
			if (noseMsg.getCompValues()!=null){
				messageList.add(messageList.size(), noseMsg);
				isNoseIn = true;
			}
			if (palateMsg.getCompValues()!=null){
				messageList.add(messageList.size(), palateMsg);
				isPalIn = true;
			}
			//Exception: Body is always with finish
			//Rule 6
			if (!isDistIn) messageList.add(messageList.size(), distilleryMsg);
			if (!isBtlIn) messageList.add(messageList.size(), bottlingMsg);
			if (!isColIn) messageList.add(messageList.size(), colourMsg);
			if (!isNoseIn) messageList.add(messageList.size(), noseMsg);
			if (!isPalIn) messageList.add(messageList.size(), palateMsg);
			if (!isBodyIn) messageList.add(messageList.size(), bodyMsg);
			if (!isFinIn) messageList.add(messageList.size(), finishMsg);
		}
		else {
			//Normal Ordering
			messageList.add(messageList.size(), distilleryMsg);
			messageList.add(messageList.size(), bottlingMsg);
			messageList.add(messageList.size(), colourMsg);
			messageList.add(messageList.size(), bodyMsg);
			messageList.add(messageList.size(), noseMsg);
			messageList.add(messageList.size(), palateMsg);
			messageList.add(messageList.size(), finishMsg);
		}
	}
	
	public void createDescrMessages(){
		boolean novice = false;
		boolean existHistory = false;
		boolean foundHistory = false;
		ArrayList<String> histValues = null;
		ArrayList<String> attValues = null;
		//Check if the user is novice or expert
		novice = user.equalsIgnoreCase("beginner");
		
		//Check if there is a discourse history
		//existHistory = !(history==null);
		existHistory = !(history==null || history.equalsIgnoreCase(whisky));
		
		//Create distillery message
		attValues = WOL.getDistillery(whisky);
		if (attValues.contains("closed")) isDistClosed = true;
		if (!attValues.contains("unknown")) hasDist = true;
		if (existHistory && hasDist){
			histValues = WOL.getDistillery(history);
			if (attValues.equals(histValues)){
				foundHistory = true;
				distilleryMsg = new Message("distillery",attValues,novice,histValues);
			}
			else distilleryMsg = new Message("distillery",attValues,novice,null);
		}
		else distilleryMsg = new Message("distillery",attValues,novice,null);
		
		//Create bottling message
		attValues = new ArrayList<String>();
		String tempBtl = WOL.getBottling(whisky);
		String age = WOL.getAge(tempBtl);
		String year = WOL.getYear(tempBtl);
		if (age!=null) {
			hasBtl=true;
			attValues.add(age);
		}
		else if(year!=null) {
			hasBtl=true;
			hasYear = true;
			attValues.add(year);
		}
		if (existHistory && !foundHistory && hasBtl){
			tempBtl = WOL.getBottling(history);
			String ageHist = WOL.getAge(tempBtl);
			String yearHist = WOL.getYear(tempBtl);
			if (ageHist!=null && yearHist != null && ageHist.equalsIgnoreCase(age) && yearHist.equalsIgnoreCase(year)) {
				foundHistory=true;
				histValues=attValues;
				bottlingMsg = new Message("bottling",attValues,novice,histValues);
			}
			else bottlingMsg = new Message("bottling",attValues,novice,null);
		}
		else bottlingMsg = new Message("bottling",attValues,novice,null);
		//Add the year as a special feature
		if (hasYear) bottlingMsg.setSpecial("Year");
		else bottlingMsg.setSpecial("Age");
		
		//Create colour message
		attValues = WOL.getColour(whisky);
		if (!attValues.contains("unknown")) hasCol = true;
		if (!attValues.contains("gold") && !attValues.contains("full-gold")) hasNoGoldColour = true;
		if (existHistory && !foundHistory && hasCol){
			histValues = WOL.getColour(history);
			Iterator<String> it = attValues.iterator();
			while (it.hasNext()){
				if (histValues.contains(it.next())){
					foundHistory=true;
					colourMsg = new Message("colour",attValues,novice,histValues);
				}
			}
			if (!foundHistory) colourMsg = new Message("colour",attValues,novice,null);
		}
		else colourMsg = new Message("colour",attValues,novice,null);
		
		//Create nose message
		attValues = WOL.getNose(whisky);
		if (!attValues.contains("unknown")) hasNose = true;
		if (existHistory && !foundHistory && hasNose){
			histValues = WOL.getNose(history);
			Iterator<String> it = attValues.iterator();
			while (it.hasNext()){
				if (histValues.contains(it.next())){
					foundHistory=true;
					noseMsg = new Message("nose",attValues,novice,histValues);
				}
			}
			if (!foundHistory) noseMsg = new Message("nose",attValues,novice,null);
		}
		else noseMsg = new Message("nose",attValues,novice,null);
		
		//Create body message
		attValues = WOL.getBody(whisky);
		if (!attValues.contains("unknown")) hasBody = true;
		if (existHistory && !foundHistory && hasBody){
			histValues = WOL.getBody(history);
			Iterator<String> it = attValues.iterator();
			while (it.hasNext()){
				if (histValues.contains(it.next())){
					foundHistory=true;
					bodyMsg = new Message("body",attValues,novice,histValues);
				}
			}
			if (!foundHistory) bodyMsg = new Message("body",attValues,novice,null);
		}
		else bodyMsg = new Message("body",attValues,novice,null);
		
		//Create palate message
		attValues = WOL.getPalate(whisky);
		if (!attValues.contains("unknown")) hasPal = true;
		if (existHistory && !foundHistory && hasPal){
			histValues = WOL.getPalate(history);
			Iterator<String> it = attValues.iterator();
			while (it.hasNext()){
				if (histValues.contains(it.next())){
					foundHistory=true;
					palateMsg = new Message("palate",attValues,novice,histValues);
				}
			}
			if (!foundHistory) palateMsg = new Message("palate",attValues,novice,null);
		}
		else palateMsg = new Message("palate",attValues,novice,null);
		
		//Create finish message
		attValues = WOL.getFinish(whisky);
		if (!attValues.contains("unknown")) hasFin = true;
		if (existHistory && !foundHistory && hasFin){
			histValues = WOL.getFinish(history);
			Iterator<String> it = attValues.iterator();
			while (it.hasNext()){
				if (histValues.contains(it.next())){
					foundHistory=true;
					finishMsg = new Message("finish",attValues,novice,histValues);
				}
			}
			if (!foundHistory) finishMsg = new Message("finish",attValues,novice,null);
		}
		else finishMsg = new Message("finish",attValues,novice,null);
	}
}
