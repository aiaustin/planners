package ix.iroom.nlg;

import java.util.ArrayList;

public class Message {
	private ArrayList<String> attValues;
	private String name = null;
	private String relatedProcess = null;
	private boolean novice;
	private ArrayList<String> compareValues = null;
	private String special = "";
	
	public Message(String nam, ArrayList<String> val, boolean nov, ArrayList<String> cVal){
		name=nam;
		attValues=val;
		novice=nov;
		compareValues=cVal;
	}
	
	public String getName(){
		return name;
	}
	
	public ArrayList<String> getValues(){
		return attValues;
	}
	
	public String getRelProcess(){
		return relatedProcess;
	}
	
	public boolean forNovice(){
		return novice;
	}
	
	public ArrayList<String> getCompValues(){
		return compareValues;
	}
	
	public void setSpecial(String special){
		this.special=special;
	}
	
	public String getSpecial(){
		return special;
	}
	public String generateRelatedProcess(String mesName){
		//Use world knowledge to match the part of the distillery process to the attribute
		if (mesName.equalsIgnoreCase("colour")) relatedProcess = "";
		else if (mesName.equalsIgnoreCase("nose")) relatedProcess = "";
		else if (mesName.equalsIgnoreCase("palate")) relatedProcess = "";
		else if (mesName.equalsIgnoreCase("body")) relatedProcess = "";
		else if (mesName.equalsIgnoreCase("finish")) relatedProcess = "";
		return relatedProcess;
	}
}
