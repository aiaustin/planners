/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 *    and: Stephen Potter <stephenp@inf.ed.ac.uk>
 * Updated: Wed Jun 16 16:26:11 2010
 * Copyright: (c) 2001-2008 AIAI, University of Edinburgh
 */

package ix.iroom.nlg;

import java.util.*;
import java.io.*;
import java.net.*;

import javax.swing.JOptionPane;

import ix.icore.*;
import ix.ip2.*;
import ix.util.*;
import ix.util.lisp.*;

import org.jdom.*;
import org.jdom.input.*;

/**
 * Adds a handler action initiates an NLG mechanism for generating text. 
 */
public class NLGHandler extends ItemHandler {

	private Symbol ACTION_SYMBOL_NAME = Symbol.intern("generate-text");
	private WhiskyOntologyLookup WOL = new WhiskyOntologyLookup();
        private String HISTORY_FILENAME = "history";
    private String MEDIA_FILE = "config/whisky-media.xml";

	protected Ip2 ip2;

	static String[] vowelarray = 
		new String[]{"a", "e", "i", "o", "u"};

	// set of failed thermocouples:
	static Set<String> vowels = new HashSet<String>();

	static {for(int i=0;i<vowelarray.length;i++) vowels.add(vowelarray[i]);};

	public NLGHandler(Ip2 ip2) {
		super("Auto-generate dialogue");
		this.ip2 = ip2;
		File historyFile = new File(HISTORY_FILENAME);
		if(historyFile.exists()) historyFile.delete();
	}
    /*
        protected void finalize(){
	    File historyFile = new File("history");
	    if(historyFile.exists()) historyFile.delete();
	}
    */
	public List getSyntaxList(){
		return Lisp.list(Lisp.list(ACTION_SYMBOL_NAME));
	}

	public boolean appliesTo(AgendaItem item) {
		// We want this handler to apply to all agenda items (issues and
		// activities, so we simply return true here - other handlers may
		// have more specific truth conditions (usually based on the content
		// of the agenda item in question).
		//System.out.println("NLGHander: verb="+(item.getAbout()).getVerb());
		return ((((Symbol)(item.getAbout()).getVerb()).toString())
				.equalsIgnoreCase(ACTION_SYMBOL_NAME.toString()));
		//return true; 
	}

	public void addHandlerActions(AgendaItem item) {
		item.addAction
		(new HandlerAction.Automatic(this));

	}

	public void handle(AgendaItem item) {
		// The handle method specifies what the handler actually does when
		// it is invoked.

		try{

		    //System.out.println("Random:___"+WOL.randomWhisky());

			// AgendaItem is an activity or issue that appears on the
			// process panel (here we assume that it's an activity).

			LList pattern = item.getPattern();
			//Set boundvars = item.getPatternVars();

			String verb = ((Symbol) pattern.elementAt(0)).toString();
			System.out.println("***NLGHandler:should be verb at pos 0:"+verb);

			String avatartype = "";
			//String avatartype = ((Symbol) pattern.elementAt(1)).toString();

			Object avatarob = pattern.elementAt(1);
			if(avatarob instanceof Variable){

			    if(!((Variable)avatarob).isBound()){
				Random rand = new Random(Calendar.getInstance().getTimeInMillis());
				if(rand.nextInt(2)<1)
				    avatartype = "expert";
				else
				    avatartype = "beginner";
				((Variable)avatarob).setValue(Symbol.intern(avatartype));
			    }
			    else
				avatartype = ((Symbol) ((Variable)avatarob).getValue()).toString();
				
			}
			else
			    avatartype = ((Symbol) avatarob).toString();

			System.out.println("***NLGHandler:should be avatar-type at pos 1:"
					+avatartype);

			Object whiskyob = pattern.elementAt(2);
			String whisky = "";
			if(whiskyob instanceof Variable){
			    if(!((Variable)whiskyob).isBound()){
				whisky = WOL.randomWhisky();
				((Variable)whiskyob).setValue(whisky);
			    }
			    else
				whisky = (String) ((Variable)whiskyob).getValue();
			}
			else if(whiskyob instanceof Symbol)
				whisky = ((Symbol) whiskyob).toString();
			else
				whisky = ((String) whiskyob);

			String tmp = "";
			String[] words = whisky.split("\\s+");
			for(int w=0; w<words.length;w++){
			    //System.out.println(words[w]);
			    tmp += (words[w]).substring(0,1).toUpperCase() 
				+ (words[w]).substring(1).toLowerCase() + " ";
			}
			whisky = tmp.trim();
			System.out.println("***NLGHandler:should be whisky-type at pos 2:"
					+whisky);

			String whiskyproperty = "";

			boolean includesproperty = false;

			if(pattern.length()>4) {
				// nb: length includes unbound variable!
				includesproperty = true;
				whiskyproperty = ((Symbol) pattern.elementAt(3)).toString();
				System.out.println("***NLGHandler:optional whisky-property at pos 3:"
						+whiskyproperty);
			}


			/*********************************************************/
			//String autotext = "automatically generated text goes here";
			/*********************************************************/
			String autotext = "";
			if(includesproperty) 
				autotext = generateTextForProperty(whisky,whiskyproperty);
			else{
			    System.out.println("***NLGHandler:passing to DialogueGenerator...");
				DialogueGenerator DG = new DialogueGenerator();
				autotext = DG.generateText(whisky,"instruct",avatartype);
			}

			Set unboundvars = item.getUnboundVars();

			// want to bind unbound var - assume that there is only one variable in pattern:
			Iterator<Variable> viter = unboundvars.iterator();

			// remember, variables come in 'undetermined' order!

			Variable var = viter.next();
			if(viter.hasNext()){
			    // so, have "utterance" and "video", but unsure of order!

			    Variable var2 = viter.next();
 
			    if(var.toString().indexOf("utter")==-1){
				// var is not "utterance"!
				var.setValue(Symbol.intern(getMediaURI(whisky,whiskyproperty)));
				var2.setValue(autotext);
			    }
			    else{
				// then var is "utterance"!
				var2.setValue(Symbol.intern(getMediaURI(whisky,whiskyproperty)));
				var.setValue(autotext);
			    }
			}
			else
			    var.setValue(autotext);

			//System.out.println("Found media: "+getMediaURI(whisky,whiskyproperty));
			//utterance.setValue(autotext);
	


		}
		catch (Exception e){
			//Debug.noteln("Handler error : "+e.toString());
			// Uh, better do something with this exception:
			/*
	    JOptionPane.showMessageDialog(null,
					  "Handler problem:\n"+Debug.foldException(e),
					  "NLG Handler Error",
					  JOptionPane.ERROR_MESSAGE);
			 */
			e.printStackTrace();
		}   

		// don't do anything to the status in this case; in other cases, we
		// may want to set the status of the item to, say, done (COMPLETE)
		// following invocation of this handler:
		item.setStatus(Status.COMPLETE);

	}


	private String getPrefix(String text){

		if(vowels.contains(text.substring(0, 1))){
			// ie begins with a vowel:
			return "n ";
		}
		else return " ";

	}

	private String generateTextForProperty(String whisky, String whiskyproperty) {
		String autotext = whisky +" has a";
		if(whiskyproperty.equalsIgnoreCase("introduction")){
			autotext = "We are going to try tasting "+whisky+". "
			+"Try to use a proper tasting glass - this will enhance the experience. "
			+"First warm the glass a little in your hands.";
		}
		else if (whiskyproperty.equalsIgnoreCase(WhiskyOntologyLookup.body)){
		    ArrayList<String> bos = WOL.getBody(whisky);
		    int num = bos.size();
		    if(num>0){
			for(int i=0;i<num;i++){
			    String bo = bos.get(i);
			    if(i==0)
				autotext += getPrefix(bo);
			    autotext += bo;
			    if(i<num-1){
				if(i<num-2) autotext += ", ";
				else autotext += " and ";
			    } 
			    else autotext += " ";
			}
			autotext += whiskyproperty;
		    }
		}
		
		else if(whiskyproperty.equalsIgnoreCase(WhiskyOntologyLookup.colour)){
		    //String cl = WOL.getColour(whisky);
		    //autotext += getPrefix(cl)+cl+" "+whiskyproperty;
		    ArrayList<String> cls = WOL.getColour(whisky);
		    int num = cls.size();
		    if(num>0){
			for(int i=0;i<num;i++){
			    String cl = cls.get(i);
			    if(i==0)
				autotext += getPrefix(cl);
			    autotext += cl;
			    if(i<num-1){
				if(i<num-2) autotext += ", ";
				else autotext += " and ";
			    } 
			    else autotext += " ";
			}
			autotext += whiskyproperty;
		    }


		}
		else if(whiskyproperty.equalsIgnoreCase(WhiskyOntologyLookup.finish)){
		    //String fi = WOL.getFinish(whisky);
		    //autotext += getPrefix(fi)+fi+" "+whiskyproperty;
		    ArrayList<String> cls = WOL.getFinish(whisky);
		    int num = cls.size();
		    if(num>0){
			for(int i=0;i<num;i++){
			    String cl = cls.get(i);
			    if(i==0)
				autotext += getPrefix(cl);
			    autotext += cl;
			    if(i<num-1){
				if(i<num-2) autotext += ", ";
				else autotext += " and ";
			    } 
			    else autotext += " ";
			}
			autotext += whiskyproperty;
		    }
		}
		else if(whiskyproperty.equalsIgnoreCase(WhiskyOntologyLookup.nose)){
		    //String no = WOL.getNose(whisky);
		    //autotext += getPrefix(no)+no+" "+whiskyproperty;
		    ArrayList<String> cls = WOL.getNose(whisky);
		    int num = cls.size();
		    if(num>0){
			for(int i=0;i<num;i++){
			    String cl = cls.get(i);
			    if(i==0)
				autotext += getPrefix(cl);
			    autotext += cl;
			    if(i<num-1){
				if(i<num-2) autotext += ", ";
				else autotext += " and ";
			    } 
			    else autotext += " ";
			}
			autotext += whiskyproperty;
		    }
		}
		else if(whiskyproperty.equalsIgnoreCase(WhiskyOntologyLookup.palate)){
		    //String pa = WOL.getPalate(whisky);
		    //autotext += getPrefix(pa)+pa+" "+whiskyproperty;
		    ArrayList<String> cls = WOL.getPalate(whisky);
		    int num = cls.size();
		    if(num>0){
			for(int i=0;i<num;i++){
			    String cl = cls.get(i);
			    if(i==0)
				autotext += getPrefix(cl);
			    autotext += cl;
			    if(i<num-1){
				if(i<num-2) autotext += ", ";
				else autotext += " and ";
			    } 
			    else autotext += " ";
			}
			autotext += whiskyproperty;
		    }
		}
		
		else if(whiskyproperty.equalsIgnoreCase(WhiskyOntologyLookup.region)){
		    autotext = whisky +" is distilled at ";

		    //autotext += WOL.getDistillery(whisky);
		    ArrayList<String> cls = WOL.getDistillery(whisky);
		    // assume that this array contains the name of the distillery as the
		    // first element, and then the names of its owners....
		    int num = cls.size();
		    if(num>0){
			for(int i=0;i<num;i++){
			    String cl = cls.get(i);
			    if(i==1)
				autotext += " (owned by ";

			    autotext += cl;

			    if(i>0 && i<num-1){
				if(i<num-2) autotext += ", ";
				else autotext += " and ";
			    } 

			    if(i>0 && i==(num-1)) autotext += ")";
			}
		    }			
		    autotext += " which is located in ";
		    autotext += WOL.getRegion(whisky);
		}
		else return "";
		return autotext;
	}

	private String getMediaURI(String whisky, String whiskyproperty) {
	    String uri = "";
		if(whiskyproperty.equalsIgnoreCase("introduction")){
		    return getURI("introduction");
		}
				
		else if(whiskyproperty.equalsIgnoreCase(WhiskyOntologyLookup.region)){
		    return getURI(WOL.getTypeName(whisky));

		}
		
		return "";
	}


    private String getURI(String about){
	System.out.println("Looking for "+about);
		    // new!
		    // special cases: if this is intro, or region then there is a media uri:
		    // read in local properties:
	try{
		    SAXBuilder builder = new SAXBuilder(); //SAXDriverClass);
		    Document doc = builder.build(MEDIA_FILE);
		    Element root = doc.getRootElement(); // should be <properties>
		    //List medialist = root.getChildren("video");

		    Iterator<Element> mit = root.getChildren("video").iterator();

		    while(mit.hasNext()){
			Element mel = mit.next();
			Iterator<Element> refit = mel.getChildren("refersTo").iterator();
			while(refit.hasNext()){
			    Element rel = refit.next();
			    //System.out.println("in loop: "+ rel.getText());
			    
			    if(rel.getText().equalsIgnoreCase(about))
				return mel.getChild("uri").getText();
			}
		    }
	}
	catch (Exception e){
	    Debug.displayException("Handler error", e);
	    return "";
	}
	return "";

    }

	private String generateText(String whisky, String avatartype){
		/* 
		 * add call to NLG routine here
		 */
		String autotext = whisky +" is...";
		return autotext;
	}

}
