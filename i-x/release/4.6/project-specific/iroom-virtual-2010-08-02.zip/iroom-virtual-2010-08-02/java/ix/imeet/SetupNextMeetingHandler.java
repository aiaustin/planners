/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Fri Jun 11 14:37:44 2010
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet;

import java.util.*;
import java.text.SimpleDateFormat;

import ix.icore.*;
import ix.icore.domain.*;
import ix.icore.log.HistoryEvent;

import ix.ip2.*;

import ix.imeet.meeting.Meeting;

import ix.util.*;
import ix.util.lisp.*;
import ix.util.match.*;
import ix.util.xml.XML;

/**
 * Write a description of the next meeting.
 */
public class SetupNextMeetingHandler extends ActivityHandler {

    private final LList handleableActionPattern =
	Lisp.elementsFromString("setup-next-meeting");

    private final LList syntaxList = Lisp.list(handleableActionPattern);

    private Ip2 ip2;

    public SetupNextMeetingHandler(Ip2 ip2) {
        super("Set up for the next meeting");
        this.ip2 = ip2;
    }

    public List getSyntaxList() {
	return syntaxList;
    }

    public boolean appliesTo(AgendaItem item) {
	return ((((Symbol)(item.getAbout()).getVerb()).toString())
				.equalsIgnoreCase("setup-next-meeting"));

	/** fix this later:
	return SimpleMatcher.matchAnyPattern(syntaxList, item.getPattern())
	    != null;
	*/
    }

    public void addHandlerActions(AgendaItem item) {
        item.addAction
            (new HandlerAction.Automatic(this));
	//            (new HandlerAction.AutomaticWhenBound(item, this));
    }

    public void handle(AgendaItem item) {

	// Find out what happened during the meeting.
	IMeetEventLogger logger =
	    Util.mustBe(IMeetEventLogger.class, ip2.getEventLogger());
	List<HistoryEvent> historyEvents = logger.getEvents();

	// Write minutes.
	MinutesMaker mm = new MinutesMaker(ip2, historyEvents);
	Meeting meeting = mm.makeMeetingDescription();

	String outputdir = "tmp";
	if(Parameters.haveParameter("web-directory")){
	    outputdir = Parameters.getParameter("web-directory");
	}

	String outputurl = "tmp";
	if(Parameters.haveParameter("url-base")){
	    outputurl = Parameters.getParameter("url-base");
	}

	Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

	String basename = dateFormat.format(calendar.getTime());


	//LList pattern = item.getPattern();
	// Set unboundvars = item.getPatternVars();
	//if(!boundvars.isEmpty()) basename = ((Variable) boundvars.iterator().next()).toString();

	MinutesHtmlOutputter out =
	    new MinutesHtmlOutputter(outputdir+"/"+basename+"-minutes.html");
	out.writeMinutes(meeting);

	// Write next-meeting domain.
	NextMeetingPrep prep = new NextMeetingPrep(ip2, meeting);
	Domain dom = prep.makeNextMeetingAgendaDomain();
	XML.writeObject(dom, outputdir+"/"+basename+"-next-meeting-agenda.lsp");

	Iterator<Variable> vit = (item.getUnboundVars()).iterator();
	
	while(vit.hasNext()){
		Variable var = vit.next();
	
		if(var.toString().indexOf("minutes")==-1)
			// var is not "minutes"!
			var.setValue(Symbol.intern(outputurl+basename+"-next-meeting-agenda.lsp"));
		else
			var.setValue(Symbol.intern(outputurl+basename+"-minutes.html"));
	}

	// The activity is now complete.
	item.setStatus(Status.COMPLETE);

    }

}
