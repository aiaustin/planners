/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Mon Apr 27 16:38:01 2009 by Jeff Dalton
 * Copyright: (c) 2008, 2009, AIAI, University of Edinburgh
 */

package ix.imeet;

import java.util.*;

import ix.icore.IXAgentExtension;
import ix.ip2.*;

/**
 * I-Meet's changed to Ip2.
 */
public class IMeetExtensions implements IXAgentExtension {

    private Ip2 ip2;

    public IMeetExtensions(Ip2 ip2) {
	this.ip2 = ip2;
    }

    public void installExtension() {
	addIMeetHandlers();
	addIMeetLogger();
    }

    protected void addIMeetHandlers() {
	PanelController controller = ip2.getController();

	controller
	    .addActivityHandler(new SetupNextMeetingHandler(ip2));

	controller
	    .addActivityHandler(new CarryToNextMeetingHandler(ip2));

    }

    protected void addIMeetLogger() {
	IMeetEventLogger logger = new IMeetEventLogger(ip2);
	logger.processCommandLineArguments();
	ip2.setEventLogger(logger);
    }

}
