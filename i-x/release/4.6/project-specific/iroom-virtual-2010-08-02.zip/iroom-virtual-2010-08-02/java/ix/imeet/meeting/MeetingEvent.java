/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Tue Feb 26 23:27:18 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet.meeting;

/**
 * Abstract class for things that happen in meetings.
 */
public abstract class MeetingEvent {

    public MeetingEvent() {
    }

    public abstract void accept(MeetingEventVisitor visitor);

}
