/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Feb 27 04:06:09 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet;

import ix.icore.log.MessageReceived;
import ix.ip2.*;

import ix.util.*;

/**
 * The I-Meet version of Ip2.  {@link IMeetxtensions} should still
 * be given as an extension class.
 */
public class IMeetIp2 extends Ip2 {

    public IMeetIp2() {
	super();
    }

    public static void main(String[] argv) {
	Util.printGreeting("I-Meet I-P2");
	new IMeetIp2().mainStartup(argv);
    }

    public void handleInputDirectly(IPC.InputMessage message) {
	// Messages from external sources will be logged elsewhere.
	if (message.getAnnotation("is-external") != Boolean.TRUE) {
	    log(new MessageReceived("me", message.getContents()));
	}
	super.handleInputDirectly(message);
    }

}
