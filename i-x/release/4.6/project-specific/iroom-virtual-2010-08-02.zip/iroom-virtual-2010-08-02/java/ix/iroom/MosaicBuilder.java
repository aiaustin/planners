package ix.iroom;


import java.awt.Point;
import java.awt.image.IndexColorModel;
import java.awt.image.Raster;
import java.awt.image.RenderedImage;
import java.awt.image.WritableRaster;
import java.awt.image.renderable.ParameterBlock;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.imageio.ImageIO;
import javax.media.jai.BorderExtender;
import javax.media.jai.LookupTableJAI;
import javax.media.jai.ParameterBlockJAI;
import javax.media.jai.RenderedOp;
import javax.media.jai.operator.FileLoadDescriptor;
import javax.media.jai.operator.LookupDescriptor;
import javax.media.jai.operator.MosaicDescriptor;
import javax.media.jai.operator.RescaleDescriptor;
import javax.media.jai.operator.TranslateDescriptor;
import javax.media.jai.JAI;

public class MosaicBuilder {
	static String imageDirectory = "tmp";
	//static String outputDirectory = "Z:/ix/html/i-room/resources/temp/images";
	static String imageExtension = "jpg";
	static String detailsExtension = "txt";
	static String namePunct = "-";
	static String imageViewerLabel = "Image-Viewer-";
	
	public static void main(String[] args){
		try {
			//createScaledMosaic("octopus");
			createScaledMosaic(imageDirectory, imageDirectory, "SP-Pizzicato");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	public static String generateOutputFilename(String directory, String basename){
		if(!(directory.endsWith(File.separator))) directory += File.separator;
		return directory+Calendar.getInstance().getTimeInMillis()+"-"+basename;//+"."+imageExtension;
	}
	*/
	public static String generateOutputFilename(String basename){
		return Calendar.getInstance().getTimeInMillis()+"-"+basename;//+"."+imageExtension;
	}
	
	public static String[] getImageNames(final String directory, final String baseName){
		// retrieve the list of images in this directory:
		File imdir = new File(directory);
		if(imdir.isDirectory()){
			return imdir.list(new FilenameFilter(){
				@Override
				public boolean accept(File dir, String name) {
					// TODO Auto-generated method stub
					// 
					if(name.startsWith(baseName) 
							&& ((name.endsWith(imageExtension.toLowerCase())) || name.endsWith(imageExtension.toUpperCase())))
						return true;
					else
						return false;
				}
				
			});
		}
		return null;
	}
	
    public static void createMosaic(String agentName) throws FileNotFoundException, IOException {
        int columnTotal = 1, rowTotal = 5;
        int index = 0, col = 0, row  = 0, height = 0, width = 0;
        ArrayList<RenderedOp> renderedOps = new ArrayList<RenderedOp>();
        RenderedOp op;
        //String directory = "N:/tmp/";
        //String[] files = {"test-agent-I-Space.png","test-agent-HTML-Viewer.png","test-agent.png"};
        String[] files = getImageNames(imageDirectory, agentName);
        //columnTotal = files.length;
        //columnTotal =1;
        //rowTotal = files.length;
        
        int maxWidth = 0;
        int maxHeight = 0;
        for(int i=0;i<files.length;i++){
            op = FileLoadDescriptor.create(imageDirectory+files[i],null,null,null);
            if(op.getWidth()>maxWidth)
            	maxWidth = op.getWidth();
            if(op.getHeight()>maxHeight)
            	maxHeight = op.getHeight();
        }

		System.out.println("MaxWidth: "+maxWidth+" MaxHeight: "+maxHeight);
        //width = maxWidth;
        //height = maxHeight;
        
        while(col<columnTotal){
            row=0;
            while(row<files.length){
                System.out.println(index + ":" + files[index]);
                System.out.println("c:" + col + "r:" + row);
                // Load image
                op = FileLoadDescriptor.create(imageDirectory+files[index],null,null,null);
            /*    if (index == 0){
                	// if this is the first image, use store its width and height to
                	// provide the cell size for the rest of the mosaic
                    width = op.getWidth();
                    height = op.getHeight();
                } else {
                */
                    // TRANSLATE
                    // Translate source images to correct places in the mosaic.
                    //op = TranslateDescriptor.create(op,(float)(width * col),(float)(height * row),null,null);
        		//System.out.println("Next: "+files[index]+":"+(op.getHeight()/2));

                // want to try to position the image in the centre vertically and horizontally:
                int renderedHeight=(maxHeight * row);
                int renderedWidth=(maxWidth * col);
        		int thisHeight = op.getHeight();
        		int thisWidth = op.getWidth();
                if(thisHeight<maxHeight)
                	renderedHeight = (maxHeight * row)+(maxHeight/2)-(thisHeight/2);
                if(thisWidth<maxWidth)
                	renderedWidth = (maxWidth * col)+(maxWidth/2)-(thisWidth/2);

        		System.out.println("Next: "+renderedWidth+" x "+renderedHeight);

           		op = TranslateDescriptor.create(op,
        				(float)renderedWidth,
        				(float)renderedHeight,null,null);                
         /*       
                	if(op.getHeight()<maxHeight){
                		int thisHeight = op.getHeight();
                		//System.out.println("Positioning "+files[index]+":"+(height/2));
                		op = TranslateDescriptor.create(op,
                				(float)(maxWidth * col),
                				(float)(maxHeight * row)+(maxHeight/2)-(thisHeight/2),null,null);
                	}
                	else
                		op = TranslateDescriptor.create(op,
                				(float)(maxWidth * col),
                				(float)(maxHeight * row),null,null);
*/
            
                renderedOps.add(convert(op));
                row++;
                index++;
            }
            col++;
        }
        RenderedOp finalImage = MosaicDescriptor.create(
        		(RenderedImage[]) renderedOps.toArray(new RenderedOp[renderedOps.size()]),
                MosaicDescriptor.MOSAIC_TYPE_OVERLAY,null,null,null,null,null
                );
//        ImageIO.write(finalImage, "png", new File(outputDirectory+agentName+"out."+"png"));
        ImageIO.write(finalImage, imageExtension, new File(imageDirectory+agentName+"Mosaic."+imageExtension));
  

        //ImageIO.write(finalImage, imageExtension, new File(outputDirectory+"out."+imageExtension));
    }
    
    public static String[] createScaledMosaic(String directory, String outdirectory, String baseName) 
    															throws FileNotFoundException, IOException {
        int columnTotal = 1, rowTotal = 1;
        //double targeth = 1200, targetw = 1600;
        //double targeth = 1800, targetw = 2400;
	double targeth = 1500, targetw = 2000;
        int col = 0, row  = 0, fixedh = (int)targeth, fixedw = (int)targetw;
        ArrayList<RenderedOp> renderedOps = new ArrayList<RenderedOp>();
        RenderedOp op;
        ParameterBlock pb, pb1, pb2;
        //String directory = "N:/tmp/";
        //String[] files = {"test-agent-I-Space.png","test-agent-HTML-Viewer.png","test-agent.png"};
        
        // LOOK AT THIS!!!:
        //String opfilebase = generateOutputFilename(directory, baseName);
        String opfilebase = generateOutputFilename(baseName);

        String opfile = opfilebase +"."+imageExtension;
        String detailsfile = opfilebase +"."+detailsExtension;
        
        System.out.println("Basename:"+baseName);
        // may need some more sophisticated way of retrieving (names of) files:
        String[] files = getImageNames(directory, baseName);
        
        int nfiles = files.length;
        if(nfiles<=0) return null;
        
        File defile = new File(outdirectory,detailsfile);
        //defile.setReadable(true, false);
        
        FileWriter dfile = new FileWriter(defile,true); 
        BufferedWriter out = new BufferedWriter(dfile);
        String details = "";
        String names = "";
        // now work out dimensions:
        /*
        if(nfiles==1){
        	columnTotal = 1;
        	rowTotal = 1;
        }
        else if(nfiles<=4){
        	columnTotal = 2;
        	rowTotal = 2;
        }
        else if(nfiles<=9){
        	columnTotal = 3;
        	rowTotal = 3;
        }
        */
        // assume square matrix:
        //double sq = Math.sqrt(nfiles);
        columnTotal = (int) Math.ceil(Math.sqrt(nfiles));
        rowTotal = columnTotal;
        System.out.println("Found "+nfiles+" files: target matrix = "+columnTotal+" x "+rowTotal+" cells");
        
        targeth /= rowTotal;
        targetw /= columnTotal;

        // determine both the maximum width and the maximum height:
        int maxWidth = 0;
        int maxHeight = 0;
        File tempf;
        for(int i=0;i<nfiles;i++){
        	tempf = new File(directory,files[i]);
            op = FileLoadDescriptor.create(tempf.getPath(),null,null,null);
            if(op.getWidth()>maxWidth)
            	maxWidth = op.getWidth();
            if(op.getHeight()>maxHeight)
            	maxHeight = op.getHeight();
        }
        
		System.out.println("MaxWidth: "+maxWidth+" MaxHeight: "+maxHeight);
        //width = maxWidth;
        //height = maxHeight;
        
		//StringBuffer details = new StringBuffer();
		//details.append("# "+opfile+"\n# details:");
		out.write("# "+opfile+"\n# name hrepeat vrepeat hoffset voffset\n# details:\n");
		DecimalFormat df = new DecimalFormat(".##");
   		double hoffset = 0.0, voffset = 0.0, hfactor=0.0, vfactor=0.0;
		if(columnTotal==2){
			hfactor = -0.250;
		}
		else if(columnTotal==3){
			hfactor = -0.333;
		}
		else if(columnTotal==4){
			hfactor = -0.380;
		}
		if(rowTotal==2){
			vfactor = 0.250;
		}
		else if(rowTotal==3){
			vfactor = 0.333;
		}
		else if(rowTotal==4){
			vfactor = 0.380;
		}
		
		int index=0;
		double thisheight=0, thiswidth=0, newheight=0, newwidth=0,translatedHeight=0,translatedWidth=0;
		// now: want to loop through the files, determining for each the appropriate size.
		// assumes that the overall resolution dimensions of the (square) matrix are hresDimxvresDim (4x3)?
		// populate matrix row-wise - ie fill row 1 before placing screens in row 2, etc...
        while(row<rowTotal){
            col=0;
            while(col<columnTotal){
            	if(index<nfiles){
                System.out.println(index + ":" + files[index]);
                System.out.println("c:" + col + "r:" + row);
                // Load image
                tempf = new File(directory,files[index]);
                op = FileLoadDescriptor.create(tempf.getPath(),null,null,null);

                thisheight = op.getHeight();
                thiswidth = op.getWidth();
                
                newheight = thisheight;
                newwidth = thiswidth;
                
                // now does either the height or the width exceed the maximums?
                //if((thisheight>=targeth) || (thiswidth>=targetw))
                //{
                	// both height and width exceed targets; does the width ratio exceed the height ratio, or vv?
                	if((thiswidth/fixedw)>=(thisheight/fixedh)){
                		// want to scale according to width:
                		System.out.println("Scale according to width");
                		newwidth = targetw;
                		newheight = thisheight * (newwidth/thiswidth);
                	}
                	else{
                		// want to scale according to height:
                		System.out.println("Scale according to height");
                		newheight = targeth;
                		newwidth = thiswidth * (newheight/thisheight);
                	}
                //}
                System.out.println("New height is: "+newheight+" and new width is: "+newwidth);
                System.out.println("Target height is: "+targeth+" and target width is: "+targetw);

 

                /* first, re-scale the image proportionately so that it fits in its cell:
                 * 
                 */
        		double wscale = newwidth/thiswidth;
        		double hscale = newheight/thisheight;
        		System.out.println("Wscale:"+wscale+" hscale:"+hscale);

        		pb = new ParameterBlock();
        		pb.addSource(op);
        		pb.add((float) wscale);
        		pb.add((float) hscale);
        		pb.add(0.0F);
        		pb.add(0.0F);
        		//pb.add(new InterpolationNearest());
        		// Creates a new, scaled image and uses it on the DisplayJAI component
        		op = JAI.create("scale", pb);
        		
        		/* now want to add a border; assume that the image is to be centred within
        		 * its cell of the matrix. Hence, first we need to work out what border is
        		 * needed on each side:
        		 */
                int hborder = (int) ((targeth/2)-(newheight/2));
                int wborder = (int) ((targetw/2)-(newwidth/2));
                System.out.println("Border: w:"+wborder+" h:"+hborder);
        		pb1 = new ParameterBlock();
        		pb1.addSource(op);
        		pb1.add(wborder);
        		pb1.add(wborder);
        		pb1.add(hborder);
        		pb1.add(hborder);
        		pb1.add(BorderExtender.createInstance(BorderExtender.BORDER_ZERO));
        		op = JAI.create("border", pb1);
        		
        		
        		/* now want to try to position this in the appropriate cell;
                 * do this by translating the image from the top-left origin:
                 * (adding borders because this seems to get munched in the other 
                 * ops):
                 */
                translatedHeight = (targeth * row) + hborder;
                translatedWidth = (targetw * col) + wborder;
        		//int thisHeight = op.getHeight();
        		//int thisWidth = op.getWidth();

                // want to try to position the image in the centre vertically and horizontally:
                
                /*
                if(newheight<targeth)
                	translatedHeight += (targeth/2)-(newheight/2);
                if(newwidth<targetw)
                	translatedWidth += (targetw/2)-(newwidth/2);
                */
 

        		System.out.println("!Translated: "+translatedWidth+" x "+translatedHeight);
        		
        		pb2 = new ParameterBlock();
        		pb2.addSource(op);
        		pb2.add((float)translatedWidth);
        		pb2.add((float)translatedHeight);
        		pb2.add(null);
        		pb2.add(null);
        		
        		op = JAI.create("translate", pb2);
        		/*
           		op = TranslateDescriptor.create(op,
        				(float)translatedWidth,
        				(float)translatedHeight,null,null);        
           		*/

         /*       
                	if(op.getHeight()<maxHeight){
                		int thisHeight = op.getHeight();
                		//System.out.println("Positioning "+files[index]+":"+(height/2));
                		op = TranslateDescriptor.create(op,
                				(float)(maxWidth * col),
                				(float)(maxHeight * row)+(maxHeight/2)-(thisHeight/2),null,null);
                	}
                	else
                		op = TranslateDescriptor.create(op,
                				(float)(maxWidth * col),
                				(float)(maxHeight * row),null,null);
*/
        		renderedOps.add(op);
                //renderedOps.add(convert(op));
        		

        		hoffset = hfactor+((double)col/(double)columnTotal);
        		voffset = vfactor-((double)row/(double)rowTotal);

        		String friendlyName = getFriendlyName(baseName, files[index]);
                out.write(friendlyName+" "
                		+df.format(1.0/(double)columnTotal)+" "+df.format(1.0/(double)rowTotal)+" "
                		+df.format(hoffset)+" "+df.format(voffset)+"\n");
                out.flush();
                details += friendlyName+" "
        			+df.format(1.0/(double)columnTotal)+" "+df.format(1.0/(double)rowTotal)+" "
        			+df.format(hoffset)+" "+df.format(voffset)+":";
                names += friendlyName+" ";
                index++;
            	}
                col++;
            }
            row++;
        }
        RenderedOp finalImage = MosaicDescriptor.create(
        		(RenderedImage[]) renderedOps.toArray(new RenderedOp[renderedOps.size()]),
                MosaicDescriptor.MOSAIC_TYPE_OVERLAY,null,null,null,null,null
                );
//        ImageIO.write(finalImage, "png", new File(outputDirectory+agentName+"out."+"png"));
        
        int fh = finalImage.getHeight();
        int fw = finalImage.getWidth();
        
        pb = new ParameterBlock();
   		pb.addSource(finalImage);
		pb.add(0);
		pb.add(fixedw-fw);
		pb.add(0);
		pb.add(fixedh-fh);
		pb.add(BorderExtender.createInstance(BorderExtender.BORDER_ZERO));
		finalImage = JAI.create("border", pb);
		
        //ImageIO.write(finalImage, imageExtension, new File(outputDirectory+"mosaic-"+agentName+"."+imageExtension));
		
		//String opfile = generateOutputFilename(directory, baseName);
		File mofile = new File(outdirectory,opfile);
		//mofile.setReadable(true, false);
		//mofile.setExecutable(true, false);
        ImageIO.write(finalImage, imageExtension, mofile);
        out.flush();
        out.close();
        
        // send it to second life?
        /*
        String slagent = MosaicBuilderExtension.secondLifeAgent;
        if(slagent!=null){
        	// ie, there's a connection to the SL agent:
        	(MosaicBuilderExtension.ip2.getAgent()).
        }
        */
        return new String[]{opfile.substring(opfile.lastIndexOf(File.separator)+1),details,names};

        //ImageIO.write(finalImage, imageExtension, new File(outputDirectory+"out."+imageExtension));
    }
    
    
    private static String getFriendlyName(String basename, String filename) {
		// want to generate friendly names for the various cells of the matrix:
    	// first strip off the basename:
    	String temp = filename.substring(basename.length(),filename.indexOf("."));
    	if(temp.startsWith(namePunct)) temp = temp.substring(1);
    	if(temp.equals("")){
    		// this is the panel!
    		temp = "panel";
    	}
    	else if(temp.startsWith(imageViewerLabel)){
    		temp = temp.substring(imageViewerLabel.length());
    	}
    		
    	return (temp.trim()).toLowerCase();
	}

	public static RenderedOp convert(RenderedOp image){
        // If the source image is colormapped, convert it to 3-band RGB.
        if(image.getColorModel() instanceof IndexColorModel) {
            // Retrieve the IndexColorModel
            IndexColorModel icm = (IndexColorModel)image.getColorModel();
            // Cache the number of elements in each band of the colormap.
            int mapSize = icm.getMapSize();
            // Allocate an array for the lookup table data.
            byte[][] lutData = new byte[3][mapSize];
            // Load the lookup table data from the IndexColorModel.
            icm.getReds(lutData[0]);
            icm.getGreens(lutData[1]);
            icm.getBlues(lutData[2]);
            // Create the lookup table object.
            LookupTableJAI lut = new LookupTableJAI(lutData);
            // Replace the original image with the 3-band RGB image.
            image = LookupDescriptor.create(image,lut,null);
        }
        return image;

    }
	public static void cleanup(String directory, String basename) {
		// deletes all files starting with agentName in the image directory:
		String[] dfiles = getImageNames(directory, basename);
		for(int i=0; i<dfiles.length; i++){
			new File(directory,dfiles[i]).delete();
		}
	}
}
