/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Tue Feb 26 22:26:22 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet.meeting;

/**
 * Specifies an agenda item for the next meeting.
 */
public class NewAgendaItem extends MeetingEvent {

    public String text;

    public NewAgendaItem() {
    }

    public void accept(MeetingEventVisitor v) {
	v.visitNewAgendaItem(this);
    }

}
