/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Thu Oct 25 13:41:30 2007 by Jeff Dalton
 * Copyright: (c) 2007, AIAI, University of Edinburgh
 */

package ix.ip2;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.imageio.ImageIO;

import java.awt.AWTException;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.Robot;
import java.awt.Rectangle;

import java.awt.image.BufferedImage;
import java.awt.event.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;

import java.util.*;

import ix.icore.IXAgentExtension;

import ix.iface.util.IFUtil;
import ix.iface.util.ToolController;
import ix.util.*;

public class ImageViewerExtension implements IXAgentExtension {

//    private String imageDirectory = "/tmp";
    private String imageDirectory = "tmp";

    private String imageType = "jpg";        // can be png or jpg

    private Ip2 ip2;

    public ImageViewerExtension(Ip2 ip2) {
    	this.ip2 = ip2;
    }

    public void installExtension() {
	ip2.addTool(new ToolController("Image Viewer Tool") {
	    public Object createTool() {
	    	if(Parameters.haveParameter("image-directory")){
	    		imageDirectory = Parameters.getParameter("image-directory");
	    		System.out.println("set image directory to: "+imageDirectory);
	    	}
	    	return new ImageFinderTool();
	    }
	});
    }




    private String imagePathname(Frame f) {
	String slash = System.getProperty("file.separator");
	return imageDirectory + slash + fileName(f) + "."+imageType;
    }

    /** 
     * The file-name, without directory or type, that corresponds
     * to the frame.
     */
    private String fileName(Frame f) {
	// Replace each space by a "-".
	return Strings.replace(" ", "-", f.getTitle());
    }

    /**
     * The GUI that lets the user select an image.
     */
    public class ImageFinderTool {

	private JFileChooser chooser = new JFileChooser(imageDirectory);
	private JFrame frame;
	
	public ImageFinderTool() {
		
	    frame = new ICFrame();
	    //frame.getContentPane().
	    frame.getContentPane()
		     .add(IFUtil.makeButton("Choose Image", new ImageChooser()));
	    frame.pack();
	    
		//frame = new JFrame("Select-a-file");
		
	    //JFileChooser chooser = new JFileChooser(imageDirectory);
	    //frame.add(chooser);
        // Note: source for ExampleFileFilter can be found in FileChooserDemo,
        // under the demo/jfc directory in the JDK.
        //ExampleFileFilter filter = new ExampleFileFilter();
        //filter.addExtension("jpg");
        //filter.addExtension("gif");
        //filter.setDescription("JPG & GIF Images");
	}
	
	public class ICFrame extends JFrame {
	    public ICFrame() {
	    	super(ip2.getAgentDisplayName() + " Image Chooser");
	    }
	}
	
	private class ImageChooser implements ActionListener {
		
		private ImageChooser(){
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			JFileChooser chooser = new JFileChooser(imageDirectory);
		
			/*
			chooser.setFileFilter(new FileFilter(){
				public boolean accept(File dir) {
					// TODO Auto-generated method stub
					// 
					String name = dir.getName();
					if((name.endsWith(imageType.toLowerCase())) || name.endsWith(imageType.toUpperCase()))
						return true;
					else
						return false;
				}
	
				@Override
				public String getDescription() {
					// TODO Auto-generated method stub
					return null;
				}				
			});
			*/
        int returnVal = chooser.showOpenDialog(null);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
           System.out.println("You chose to open this file: " +
                chooser.getSelectedFile().getName());
           new ImageFrame(chooser.getSelectedFile());
        }
        //chooser.setVisible(false);
		}


			
	}
	

	
	public void setVisible(boolean v) {
		//frame.setVisible(v);
		frame.setVisible(v);
	}

    }
    
    public class ImageFrame extends JFrame {
    	public ImageFrame(){
    	}
    	public ImageFrame(File image){
    		String lname = image.getName();
    		//lname.substring(0, lname.indexOf("."));
//    		this.setTitle(ip2.getAgentSymbolName() + " Image Viewer "+image.getName());
    		this.setTitle(ip2.getAgentDisplayName() + " Image Viewer "+lname.substring(0, lname.indexOf(".")));

    		ImageIcon ii = new ImageIcon(image.getPath());
    		this.add(new JLabel(ii));
    		this.setSize(ii.getIconWidth(),ii.getIconHeight());
    		this.setVisible(true);
    	}
    }
	
	
	/*
	private class ImageFinderFrame extends JFrame {
	    private ImageFinderFrame() {
	        
	    }
	}
*/
	/*
	private class SnapListener implements ActionListener {
	    public void actionPerformed(ActionEvent event) {
		// takePictureFromFrame();
	    String basename = (ip2.getAgentSymbolName()).replaceAll(" ", "-");
	    MosaicBuilder.cleanup(imageDirectory,basename); 	
		snapAllFrames();
		try {
			String mosaicName = MosaicBuilder.createScaledMosaic(imageDirectory,basename);
			if(mosaicName!=null){
				JOptionPane.showMessageDialog(null, "Mosaic created: "+mosaicName);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }
	}

	
    }
*/
}
