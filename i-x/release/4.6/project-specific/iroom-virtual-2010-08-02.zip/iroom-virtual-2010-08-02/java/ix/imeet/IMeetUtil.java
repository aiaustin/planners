/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Feb 27 11:18:46 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet;

import java.io.*;
import java.util.*;

import ix.ip2.Ip2;

import ix.iface.util.HtmlWriter;

import ix.icore.log.HistoryEvent;
import ix.icore.log.EventLogReader;

import ix.util.*;
import ix.util.lisp.*;
import ix.util.xml.*;
import ix.util.match.*;

/**
 * Utility methods.
 */
public class IMeetUtil {

    public IMeetUtil() {}

    public HtmlWriter openHtmlWriter(String fileName) {
	try {
	    return new HtmlWriter
		(new BufferedWriter
		     (new FileWriter(fileName)));
	}
	catch (Throwable t) {
	    throw new RethrownException
		("Can't create " + fileName + " because", t);
	}
    }

    public List<HistoryEvent> readHistoryEvents(String logName) {
	return new EventLogReader().readLog(logName);
    }

}
