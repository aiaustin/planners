package ix.iroom.nlg;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Reader {
	private String subclass = "";
	private String name = "";
	private String bottling = "";
	private String distillery = "";
	private Collection<String> nose = new ArrayList<String>();
	private Collection<String> body = new ArrayList<String>();
	private Collection<String> palate = new ArrayList<String>();
	private Collection<String> colour = new ArrayList<String>();
	private Collection<String> finish = new ArrayList<String>();
	private Scanner malts;

	private String temp = "";
//	private Collection<String> tempCol;

	public Reader(){
		try{
			File maltsFile = new File("C:\\Documents and Settings\\Chris\\workspace\\name.txt");
			malts = new Scanner(maltsFile);
			malts.useDelimiter("\n");
			while (malts.hasNext()){
				temp=getDistillery(malts.next());
				if (!temp.isEmpty()){
				}
			}
		}
		catch (FileNotFoundException e){
			e.printStackTrace();
		}
	}

	public String getName(String line){
		if (line.indexOf(":name")>0){
			name = line.substring(9,line.length()-1);
		}
		else name="";
		return name;
	}

	public String getSubclass(String line){
		if (line.indexOf(":subclass")>0){
			subclass = fixSub(line.substring(12));
		}
		else subclass="";
		return subclass;
	}

	public String getBottling(String line){
		if (line.indexOf(":bottling")>0){
			bottling = line.substring(13,line.length()-1);
		}
		else bottling="";
		return bottling;
	}

	public String getDistillery(String line){
		if (line.indexOf(":distillery")>0){
			distillery = line.substring(14);
		}
		else distillery="";
		return distillery;
	}

	public Collection<String> getNose(String line){
		if (line.indexOf(":nose")>0){
			Scanner sc = new Scanner(line.substring(9,line.length()-1));
			sc.useDelimiter("\\s");
			while (sc.hasNext()){
				nose.add(sc.next());
			}
		}
		else nose.clear();
		return nose;
	}

	public Collection<String> getBody(String line){
		if (line.indexOf(":body")>0){
			Scanner sc = new Scanner(line.substring(9,line.length()-1));
			sc.useDelimiter("\\s");
			while (sc.hasNext()){
				body.add(sc.next());
			}
		}
		else body.clear();
		return body;
	}

	public Collection<String> getPalate(String line){
		if (line.indexOf(":palate")>0){
			Scanner sc = new Scanner(line.substring(11,line.length()-1));
			sc.useDelimiter("\\s");
			while (sc.hasNext()){
				palate.add(sc.next());
			}
		}
		else palate.clear();
		return palate;
	}

	public Collection<String> getColour(String line){
		if (line.indexOf(":colour")>0){
			Scanner sc = new Scanner(line.substring(11,line.length()-1));
			sc.useDelimiter("\\s");
			while (sc.hasNext()){
				colour.add(sc.next());
			}
		}
		else colour.clear();
		return colour;
	}

	public Collection<String> getFinish(String line){
		if (line.indexOf(":finish")>0){
			Scanner sc = new Scanner(line.substring(11,line.length()-1));
			sc.useDelimiter("\\s");
			while (sc.hasNext()){
				finish.add(sc.next());
			}
		}
		else finish.clear();
		return finish;
	}

	public String fixSub(String sub){
		String newSub = "";
		//Capitalise
		newSub=sub.replace("-", " ");
		newSub = toTitleCase(newSub);
		newSub=newSub.replace(" ", "");
		return newSub;
	}

	public String toTitleCase(String str){
		StringBuffer sb = new StringBuffer();     
		str = str.toLowerCase();
		StringTokenizer strTitleCase = new StringTokenizer(str);
		while(strTitleCase.hasMoreTokens()){
			String s = strTitleCase.nextToken();
			sb.append(s.replaceFirst(s.substring(0,1),s.substring(0,1).toUpperCase()) + " ");
		}

		return sb.toString();
	}

	public static void main(String[] args) {
		new Reader();
	}
}
