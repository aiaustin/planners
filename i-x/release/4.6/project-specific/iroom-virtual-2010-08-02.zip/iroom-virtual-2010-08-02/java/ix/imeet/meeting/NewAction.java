/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Tue Feb 26 22:27:14 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet.meeting;

/**
 * Specifies an action and who is responsible for doing it.
 */
public class NewAction extends MeetingEvent {

    public String responsibleAgent;
    public String actionText;

    public NewAction() {
    }

    public void accept(MeetingEventVisitor v) {
	v.visitNewAction(this);
    }

}
