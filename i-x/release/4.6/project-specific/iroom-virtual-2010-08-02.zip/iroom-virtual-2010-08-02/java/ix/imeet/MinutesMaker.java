/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Feb 27 17:59:09 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet;

import java.util.*;

import ix.icore.*;
import ix.icore.log.*;

import ix.ip2.*;
import ix.ip2.log.*;

import ix.imeet.meeting.*;

import ix.util.*;
import ix.util.lisp.*;
import ix.util.xml.*;

/**
 * Makes a description of a meeting.
 */
public class MinutesMaker {

    protected static IMeetUtil util = new IMeetUtil();

    protected static final Symbol
	DISCUSS = Symbol.intern("discuss"),
	DISCUSS_ACTION = Symbol.intern("discuss-action");

    protected static final MeetingEvent NO_MINUTE = new MeetingEvent() {
	public void accept(MeetingEventVisitor v) {
	    throw new UnsupportedOperationException();
	}
	public String toString() {
	    return "NO_MINUTE";
	}
    };

    protected Ip2 ip2;
    protected List<HistoryEvent> historyEvents;

    /**
     * Create a MinutesMaker for the given Ip2 and event list.
     * The Ip2 is used only as a plan-holder.  The event list
     * can be one read from an Ip2 log file.
     */
    public MinutesMaker(Ip2 ip2, List<HistoryEvent> events) {
	this.ip2 = ip2;
	this.historyEvents = events;
    }

    public Meeting makeMeetingDescription() {
	// ActivityHandledEvents in the event history let us see when
	// items finished, but there are no events that mark item starts.
	// However, by assuming items are handled sequentially, we can
	// put ItemStarts in the meetingEvents and work out what items
	// they belong to.
	LinkedList<MeetingEvent> meetingEvents =
	    new LinkedList<MeetingEvent>();
	// Add an ItemStart that we'll fix up when we see an ItemFinish.
	ItemStart mostRecentStart = new ItemStart(); // to be patched
	meetingEvents.add(mostRecentStart);
	for (HistoryEvent h: historyEvents) {
	    MeetingEvent m = makeMeetingEvent(h);
	    if (m == NO_MINUTE)
		continue;
	    else
		meetingEvents.add(m);
	    if (m instanceof ItemFinish) {
		// A finish lets us fix up the most recent start.
		mostRecentStart.setFrom((ItemFinish)m);
		// And add a start for the next item.
		mostRecentStart = new ItemStart(); // to be patched
		meetingEvents.add(mostRecentStart);
	    }
	}
	if (meetingEvents.getLast() == mostRecentStart)
	    meetingEvents.removeLast();
	Meeting meeting = new Meeting();
	meeting.events = meetingEvents;
	return meeting;
    }

    protected MeetingEvent makeMeetingEvent(HistoryEvent h) {
	if (h instanceof MessageReceived)
	    return makeMeetingEvent((MessageReceived)h);
	else if (h instanceof ActivityHandledEvent)
	    return makeMeetingEvent((ActivityHandledEvent)h);
	else
	    return NO_MINUTE;
    }

    /* * * Activity-handled events * * */

    protected MeetingEvent makeMeetingEvent(ActivityHandledEvent h) {
	ItemFinish f = new ItemFinish();
	f.pattern = h.getPattern();
	f.carriedToNextMeeting = isCarryToNextMeeting(h);
	f.type = f.pattern.car() == DISCUSS_ACTION
	    ? ItemType.ACTION
	    : ItemType.AGENDA_ITEM;
	return f;
    }

    protected boolean isCarryToNextMeeting(ActivityHandledEvent h) {
	return h.getAction()
	    .matches("[Cc]arry .* next meeting.*");
    }

    /* * * Message-received events * * */

    protected MeetingEvent makeMeetingEvent(MessageReceived h) {
	Object contents = h.getContents();
	if (contents instanceof Report)
	    return makeMeetingEvent((Report)contents);
	else
	    return NO_MINUTE;
    }

    protected MeetingEvent makeMeetingEvent(Report r) {
	String text = r.getText();
	return Language.parseText(text, NO_MINUTE);
    }

    /**
     * Standalone main program for testing.  The most useful
     * command-line arguments are:
     * <pre>
     *   -plan=<i>plan file from end of meeting</i>
     *   -log=<i>log file from end of meetting</i>
     *   -output=<i>output html file</i>
     * </pre>
     */
    public static void main(String[] argv) {

	Debug.off();

	Ip2 ip2 = new ix.test.PlainIp2();
	ip2.mainStartup(argv);	// should load a plan

	String outputFileName = Parameters.requireParameter("output");
	String logName = Parameters.requireParameter("log");

	List<HistoryEvent> events = util.readHistoryEvents(logName);

	MinutesMaker mm = new MinutesMaker(ip2, events);
	Meeting meeting = mm.makeMeetingDescription();
	MinutesHtmlOutputter out = new MinutesHtmlOutputter(outputFileName);
	out.writeMinutes(meeting);

    }

}
