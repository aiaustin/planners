/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Feb 27 11:33:26 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet;

import java.util.*;

import ix.icore.*;
import ix.icore.domain.*;
import ix.iview.SimpleDomainEditor;
import ix.ip2.*;
import ix.util.*;
import ix.util.lisp.*;
import ix.util.match.*;
import ix.util.xml.XML;

/**
 * A handler that says an item should be carried to the next meeting.
 */
public class CarryToNextMeetingHandler extends CompletionHandler {

    private final LList discussItemPattern =
	Lisp.elementsFromString("discuss &rest ?description");

    private final LList discussActionPattern =
	Lisp.elementsFromString("discuss-action &rest ?description");

    private final LList syntaxList =
	Lisp.list(discussItemPattern, discussActionPattern);

    public CarryToNextMeetingHandler(Ip2 ip2) {
	super(ip2);
    }

    public List getSyntaxList() {
	return syntaxList;
    }

    public boolean appliesTo(AgendaItem item) {
	return SimpleMatcher.matchAnyPattern(syntaxList, item.getPattern())
	    != null;
    }

    public void addHandlerActions(AgendaItem item) {
	item.addAction(new CarryAction(item));
    }

    public class CarryAction extends DoneAction {

	public CarryAction(AgendaItem item) {
	    super(item, "Carry to next meeting", "Carry to next meeting");
	}

    }

}
