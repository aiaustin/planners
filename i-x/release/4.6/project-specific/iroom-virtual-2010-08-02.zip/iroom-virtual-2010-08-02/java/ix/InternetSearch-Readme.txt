InternetSearch.txt - a readme for the InternetSearch handler.

Stephen Potter, AIAI, 
stephenp@inf.ed.ac.uk
Updated: Tue Jun 15 11:50:39 2010

InternetSearch
--------------

As the name suggests, this is a simple handler that invokes a
search engine in an internet browser, using the content of the 
current AgendaItem as the search term.

See/edit config/internet-search.xml for details of the set-up.



