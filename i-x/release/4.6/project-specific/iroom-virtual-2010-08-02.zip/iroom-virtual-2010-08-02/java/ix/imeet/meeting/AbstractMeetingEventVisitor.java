/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Feb 27 17:42:16 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet.meeting;

public class AbstractMeetingEventVisitor 
       implements MeetingEventVisitor {

    public void visitItemStart(ItemStart start) {
    }

    public void visitMinute(Minute minute) {
    }

    public void visitDecision(Decision decision) {
    }

    public void visitNewAction(NewAction action) {
    }

    public void visitNewAgendaItem(NewAgendaItem item) {
    }

    public void visitItemFinish(ItemFinish finish) {
    }

}
