/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Feb 27 18:16:02 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet;

import java.util.*;

import ix.icore.*;
import ix.icore.domain.*;
import ix.icore.log.*;

import ix.iview.SimpleDomainEditor;

import ix.ip2.*;
import ix.ip2.log.*;

import ix.imeet.meeting.*;

import ix.util.*;
import ix.util.lisp.*;
import ix.util.match.*;
import ix.util.xml.XML;

/**
 * Prepares refinements that represent the agenda for the next meeting.
 */
public class NextMeetingPrep {

    protected static IMeetUtil util = new IMeetUtil();

    protected static final Symbol
	DISCUSS = Symbol.intern("discuss"),
	DISCUSS_ACTION = Symbol.intern("discuss-action");

    protected Ip2 ip2;
    protected Meeting meeting;

    protected Domain templateDomain;
    protected Refinement meetingTemplate;

    /**
     * Create a NextMeetingPrep for the given Ip2 and meeting description.
     * The Ip2 is used only as a plan-holder.
     */
    public NextMeetingPrep(Ip2 ip2, Meeting meeting) {
	this.ip2 = ip2;
	this.meeting = meeting;
    }

    protected Domain makeNextMeetingAgendaDomain() {
	Domain dom = new Domain();
	dom.addRefinement(makeActionItemsRefinement());
	dom.addRefinement(makeAgendaItemsRefinement());
	return dom;
    }

    /**
     * Make a refinement for the action items.
     */
    protected Refinement makeActionItemsRefinement() {
	Refinement r = makeRefinement("address-action-items",
				      "address-action-items ?meeting");
	addNextMeetingNodes(r, new VisitorForActionItems());
	return r;
    }

    protected void addNextMeetingNodes(Refinement r,
				       PatternCollector collector) {

	// Get relevant node patterns
	for (MeetingEvent e: meeting.events) {
	    e.accept(collector);
	}
	// Turn them into a list of NodeSpecs,
	// and order them sequentially.
	ListOfNodeSpec nodes = new LinkedListOfNodeSpec();
	int i = 1;
	for (LList pat: collector.getPatterns()) {
	    nodes.add(new NodeSpec(i, pat));
	    i++;
	}
	if (!nodes.isEmpty()) {
	    r.setNodes(nodes);
	    r.setOrderings(SimpleDomainEditor.sequentialOrderings(nodes));
	}

    }

    protected abstract class PatternCollector
	               extends AbstractMeetingEventVisitor {
	protected List<LList> patterns = new LinkedList<LList>();
	protected List<LList> getPatterns() {
	    return patterns;
	}
    }

    protected class VisitorForActionItems extends PatternCollector {

	public void visitNewAction(NewAction action) {
	    patterns.add(Lisp.list(DISCUSS_ACTION, action.responsibleAgent,
				   action.actionText));
	}

	public void visitItemFinish(ItemFinish finish) {
	    if (finish.type == ItemType.ACTION
		  && finish.carriedToNextMeeting) {
		patterns.add(finish.pattern);
	    }
	}

    }

    /**
     * Make a refinement for the agenda items.
     */
    protected Refinement makeAgendaItemsRefinement() {
	Refinement r = makeRefinement("address-agenda-items",
				      "address-agenda-items ?meeting");
	addNextMeetingNodes(r, new VisitorForAgendaItems());
	return r;
    }

    protected class VisitorForAgendaItems extends PatternCollector {

	public void visitNewAgendaItem(NewAgendaItem item) {
	    patterns.add(Lisp.list(DISCUSS, item.text));
	}

	public void visitItemFinish(ItemFinish finish) {
	    if (finish.type == ItemType.AGENDA_ITEM
		  && finish.carriedToNextMeeting) {
		patterns.add(finish.pattern);
	    }
	}

    }

    protected Refinement makeRefinement(String name, String patternText) {
	LList pattern = Lisp.elementsFromString(patternText);
	Refinement r = new Refinement(name, pattern);
	Set vars = r.getVariablesUsed();
	if (!vars.isEmpty()) {
	    ListOfVariableDeclaration dcls =
		new LinkedListOfVariableDeclaration();
	    for (Object v: vars) {
		dcls.add(new VariableDeclaration((ItemVar)v));
	    }
	    r.setVariableDeclarations(dcls);
	}
	return r;
    }

    /**
     * Standalone main program for testing.  The most useful
     * command-line arguments are:
     * <pre>
     *   -plan=<i>plan file from end of meeting</i>
     *   -log=<i>log file from end of meetting</i>
     *   -output=<i>output domain file</i>
     * </pre>
     */
    public static void main(String[] argv) {

	Debug.off();

	Ip2 ip2 = new ix.test.PlainIp2();
	ip2.mainStartup(argv);	// should load a plan

	String outputFileName = Parameters.requireParameter("output");
	String logName = Parameters.requireParameter("log");

	List<HistoryEvent> historyEvents = util.readHistoryEvents(logName);

	// Get a description of the meeting as if for minutes.
	MinutesMaker mm = new MinutesMaker(ip2, historyEvents);
	Meeting meeting = mm.makeMeetingDescription();

 	NextMeetingPrep prep = new NextMeetingPrep(ip2, meeting);
	Domain dom = prep.makeNextMeetingAgendaDomain();
	XML.writeObject(dom, outputFileName);

    }

}
