package ix.iroom.nlg;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;


public class Grep {
	private File f;
	
	public Grep(String file){
		f = new File(file);
	}
	
	// Charset and decoder for ISO-8859-15
	private Charset charset = Charset.forName("ISO-8859-15");
	private CharsetDecoder decoder = charset.newDecoder();

	// Pattern used to parse lines
	private Pattern linePattern = Pattern.compile(".*\r?\n");

	// The input pattern that we're looking for
	private Pattern pattern;

	// Compile the pattern from the command line
	//
	private void compile(String pat) {
		try {
			pattern = Pattern.compile(pat);
		} catch (PatternSyntaxException x) {
			System.err.println(x.getMessage());
			System.exit(1);
		}
	}
	
	private ArrayList<String> grep1(File f, CharBuffer cb) {
		ArrayList<String> matches = new ArrayList<String>();
		Matcher lm = linePattern.matcher(cb);	// Line matcher
		Matcher pm = null;	// Pattern matcher
		String tmp = "";
		while (lm.find()) {
			CharSequence cs = lm.group(); 	// The current line
			pm = pattern.matcher(cs);
			while (pm.find()) {
				tmp = cs.toString();
//				tmp = pm.group();
//				tmp = tmp.substring(tmp.indexOf('"')+1, tmp.length()-1);
				matches.add(tmp);
			}
			if (lm.end() == cb.limit())
				break;
		}
		return matches;
	}

	// Use the linePattern to break the given CharBuffer into lines, applying
	// the input pattern to each line to see if we have a match
	//
	private ArrayList<String> grep2(File f, CharBuffer cb) {
		ArrayList<String> matches = new ArrayList<String>();
		Matcher lm = linePattern.matcher(cb);	// Line matcher
		Matcher pm = null;	// Pattern matcher
		String tmp = "";
		while (lm.find()) {
			CharSequence cs = lm.group(); 	// The current line
			pm = pattern.matcher(cs);
			while (pm.find()) {
				tmp = pm.group();
				tmp = tmp.substring(tmp.indexOf('"')+1, tmp.length()-1);
				matches.add(tmp);
			}
			if (lm.end() == cb.limit())
				break;
		}
		return matches;
	}

	// Search for occurrences of the input pattern in the given file
	//
	private ArrayList<String> grepFile(File f) throws IOException {
		ArrayList<String> strMatches;

		// Open the file and then get a channel from the stream
		FileInputStream fis = new FileInputStream(f);
		FileChannel fc = fis.getChannel();

		// Get the file's size and then map it into memory
		int sz = (int)fc.size();
		MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0, sz);

		// Decode the file into a char buffer
		CharBuffer cb = decoder.decode(bb);

		// Perform the search
		strMatches = grep2(f, cb);

		// Close the channel and the stream
		fc.close();
		return strMatches;
	}
	
	private ArrayList<String> grepFileFull(File f) throws IOException {
		ArrayList<String> strMatches;

		// Open the file and then get a channel from the stream
		FileInputStream fis = new FileInputStream(f);
		FileChannel fc = fis.getChannel();

		// Get the file's size and then map it into memory
		int sz = (int)fc.size();
		MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0, sz);

		// Decode the file into a char buffer
		CharBuffer cb = decoder.decode(bb);

		// Perform the search
		strMatches = grep1(f, cb);

		// Close the channel and the stream
		fc.close();
		return strMatches;
	}
	
	public ArrayList<String> grep(String pat) {
	    // System.out.println("GREP: "+pat+" on "+f.toString());
		ArrayList<String> matches = null;
		compile(pat+".*");
		try {
			matches = grepFile(f);
		}
		catch (IOException e){
			System.err.println(f + ": " + e);
		}
		// System.out.println("GREP EXIT: "+pat+" on "+f.toString());

		return matches;
	}
	
	public ArrayList<String> grepFull(String pat) {
		ArrayList<String> matches = null;
		compile(pat+".*");
		try {
			matches = grepFileFull(f);
		}
		catch (IOException e){
			System.err.println(f + ": " + e);
		}
		return matches;
	}
}
