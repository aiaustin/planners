/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Mon Sep 14 14:29:51 2009 by Jeff Dalton
 * Copyright: (c) 2009, AIAI, University of Edinburgh
 */

package ix.ichat;

import java.util.*;

import ix.ip2.*;

import ix.util.*;

/**
 * Variant of Ip2 that can be used as a chat-relay.
 */
public class IChatRelayer extends Ip2 {

    protected Set<Name> chatting = new LinkedHashSet<Name>();

    public IChatRelayer() {
        super();
    }

    public static void main(String[] argv) {
	Util.printGreeting("I-Chat Relayer");
	new IChatRelayer().mainStartup(argv);
    }

    @Override
    public void startup() {
        super.startup();
        addResetHook(new ResetHook());
    }

    protected class ResetHook implements Runnable {
	public void run() {
	    Debug.noteln("Reset hook for", this);
            chatting.clear();
	}
    }

    @Override
    public void handleNewChatMessage(ChatMessage chat) {
        relayChat(chat);
        super.handleNewChatMessage(chat);
    }

    protected void relayChat(ChatMessage chat) {
        Name sender = chat.getSenderId();
        // Don't add ourself to the set of chatting agents.
        // We will display all chat anyway because of what
        // super.handleNewChatMessage does.
        if (!wasSentToSelf(chat)) {
            chatting.add(sender);
        }
        // Echo back to the sender.
        // We don't echo to ourself or to any "Relay" agent
        if (!wasSentToSelf(chat) && !wasSentByARelayer(chat)) {
            sendChat(sender, chat);
        }
        // Send to everyone else who's chatting.
        // I.e., copy the message to everyone but the sender.
        for (Name who: chatting) {
            if (!who.equals(sender))
                sendChat(who, chat);
        }
    }

    private boolean wasSentToSelf(ChatMessage chat) {
        return getAgentIPCName().equals(chat.getSenderId().toString());
    }

    protected boolean wasSentByARelayer(ChatMessage chat) {
        // /\/: We need something better than looking for "Relay"
        // in the name, but that will do for now.
        return agentIsRelayer(chat.getSenderId());
    }

    protected boolean agentIsRelayer(Name agentName) {
        return agentIsRelayer(agentName.toString());
    }

    protected boolean agentIsRelayer(String agentName) {
        return agentName.indexOf("Relay") > -1
            || agentName.indexOf("relay") > -1;
    }

    protected void sendChat(Name to, ChatMessage chat) {
        if (agentIsRelayer(to)) {
            String speaker = chat.getSenderId().toString();
            IPC.sendObject(to.toString(),
                           new ChatMessage(speaker + ": " + chat.getText(),
                                           speaker)); // /\/
        }
        else
            IPC.sendObject(to.toString(), chat);
    }

}
