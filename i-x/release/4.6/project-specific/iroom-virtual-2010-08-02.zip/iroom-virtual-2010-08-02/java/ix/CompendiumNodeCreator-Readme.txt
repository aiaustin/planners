CompendiumNodeCreatorReadme.txt - a readme for the CompendiumNodeCreator 
Handler.

Stephen Potter, AIAI
stephenp@inf.ed.ac.uk
Updated: Tue Jun 15 11:51:06 2010

CompendiumNodeCreator
---------------------

The purpose of this code is to relay AgendaItems to a Jabber client 
acting as a listener for a Compendium map. (Messages in the other 
direction, from Compendium to I-X, are handled from within Compendium.)

Overview
--------

Compendium includes the facility to run a Jabber client which acts
as a 'gatekeeper' to the current map: simple Jabber messages, when
sent to this gatekeeper are transformed into Compendium nodes and
added to the map. Prefixing a message with one of a set of special
strings will cause that message to be interpreted as a particular
node type. These prefixes include the following:
     [?] = Question Node;
     [!] = Answer Node;
     [D] = Decision Node;
     [U] = Argument Node;
     [N] = Note Node;
(with a Note Node also being the default if the message contains
no recognised prefix.)

The CompendiumNodeCreator handler exists to create and send the 
appropriate messages for converting I-X agenda items into Compendium
Nodes of these types.

Usage
-----

To use this handler it is necessary to explicitly declare it  
in the relevant props file. For example, the following line
in a props file will add the handler: 

additional-handlers=ix.coakting.CompendiumNodeCreator

Naturally, the relevant Compendium process must also be started and
the appropriate map opened, and the option:
    File>Connections>Jabber Connection
selected. This brings up a pop-up window, into which the login 
details of the JID to use for the client should be input to begin 
that client.
(Note that, if jabber-allow-queuing=false (the default) it is 
necessary that the JID used is on the roster of the JID that will 
be used to invoke I-X.)   

Next, the file config/compendium-node-creator.xml needs to be
edited to provide details of the JID of this Compendium client.
This props file is in XML format, and the fields are as follows:
     <compendium-name> - the username of the Compendium Jabber client; 
     <compendium-server> - the name of the server used by this client;
     <compendium-resource> - the resource name of the client.

Now, when I-X is invoked, the specified handler should appear 
on the Action menus for agenda items.




