/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Thu Jun 10 17:16:05 2010
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet;

import java.util.*;

import ix.iface.util.HtmlWriter;

import ix.imeet.meeting.*;

import ix.util.*;
import ix.util.lisp.*;

/**
 * Outputs a description of a meeting as HTML.
 */
public class MinutesHtmlOutputter {

    protected static final Symbol
	DISCUSS = Symbol.intern("discuss"),
	DISCUSS_ACTION = Symbol.intern("discuss-action");

    protected IMeetUtil util = new IMeetUtil();

    protected String outputFileName;
    protected HtmlWriter out;

    public MinutesHtmlOutputter(String fileName) {
	this.outputFileName = fileName;
    }

    public void writeMinutes(Meeting meeting) {
	EventOutputter eventOutputter = new EventOutputter();
	out = util.openHtmlWriter(outputFileName);
	for (MeetingEvent event: meeting.events) {
	    event.accept(eventOutputter);
	    out.newLine();
	}
	out.flush();
	out.close();
    }

    protected class EventOutputter implements MeetingEventVisitor {

	protected EventOutputter() {
	}

	public void visitItemStart(ItemStart start) {
	    out.write("<!-- Start " + start.pattern + " -->");
	    if (start.pattern != null) {
		String text = itemStartText(start);
		out.newLine();
		out.tagged("h3", Strings.capitalize(text));
	    }
	}

	protected String itemStartText(ItemStart start) {
	    LList pattern = start.pattern;
	    if (pattern.car() == DISCUSS)
		pattern = pattern.cdr();
	    else if (pattern.car() == DISCUSS_ACTION)
		pattern = new Cons("Action", pattern.cdr());
	    StringBuffer buf = new StringBuffer();
	    for (Iterator i = pattern.iterator(); i.hasNext();) {
		buf.append(i.next().toString());
		if (i.hasNext())
		    buf.append(" ");
	    }
	    return buf.toString();
	}

	public void visitMinute(Minute minute) {
	    out.tagged("p", "<b>Minuted:</b> "+ minute.text);
	}

	public void visitDecision(Decision decision) {
	    out.tagged("p", "<b>Decision:</b> " + decision.text);
	}

	public void visitNewAction(NewAction action) {
	    String text = "<b>Action</b> on " + action.responsibleAgent
		   + ": " + action.actionText;
	    out.tagged("p", text);
	}

	public void visitNewAgendaItem(NewAgendaItem item) {
	    String text = "<b>Agenda</b> item for next meeting: " + item.text;
	    out.tagged("p", text);
	}

	public void visitItemFinish(ItemFinish finish) {
	    if (finish.carriedToNextMeeting) {
		out.tagged("p", "To be continued in the next meeting.");
		out.newLine();
	    }
	    out.write("<!-- Finish " + finish.pattern + " -->");
	}

    }

}
