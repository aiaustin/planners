/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Tue Feb 26 22:08:15 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet.meeting;

import java.util.*;

/**
 * A meeting.
 */
public class Meeting {

    public List<MeetingEvent> events;

    public Meeting() {
    }

}
