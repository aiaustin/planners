/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Mon Jan 25 17:24:35 2010 by Jeff Dalton
 * Copyright: (c) 2009, AIAI, University of Edinburgh
 */

package ix.ichat.log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.*;

import ix.icore.log.*;

import ix.ichat.ChatMessage;

import ix.util.*;
import ix.util.lisp.Symbol;

public class PrintChatEventLog extends PrintEventLog {

    // Annotation key
    // /\/: A send-date should be part of Sendable.
    private static Symbol SEND_DATE = Symbol.intern("send-date");

    private SimpleDateFormat dayDateFormat =
        new SimpleDateFormat("EEEE, dd MMMM yyyy z");

    private int lastNotedDay = 0; // day of year

    private DateFormat timeFormat =
        DateFormat.getTimeInstance(DateFormat.SHORT);

    public PrintChatEventLog() {
        super();
    }

    public static void main(String[] argv) throws Exception {
	Parameters.processCommandLineArguments(argv);
	new PrintChatEventLog().run();
    }

    protected void describeEvent(HistoryEvent event) {
        if (event instanceof MessageReceived) {
            MessageReceived received = (MessageReceived)event;
            if (received.getContents() instanceof ChatMessage) {
                describeChat(event.getDate(),
                             (ChatMessage)received.getContents());
            }
        }
    }

    /*
    protected void describeEvent(HistoryEvent event) {
        if (event instanceof MessageReceived) {
            MessageReceived received = (MessageReceived)event;
            if (received.getContents() instanceof ChatMessage)
                describeChat(event.getDate(),
                             (ChatMessage)received.getContents());
            else
                super.describeEvent(event);
        }
        else if (event instanceof MessageSent) {
            MessageSent sent = (MessageSent)event;
            if (sent.getContents() instanceof ChatMessage)
                ;
            else
                super.describeEvent(event);
        }
        else
            super.describeEvent(event);
    }
    */

    protected void describeChat(Date whenReceived, ChatMessage chat) {
        Date sendDate = (Date)chat.getAnnotation(SEND_DATE);
        Date when = sendDate != null ? sendDate : whenReceived;
        noteIfNewDay(when);
        out.print(timeFormat.format(when));
        out.println(" " + chat.getSenderId() + ": " + chat.getText());
        out.println("");
    }

    private void noteIfNewDay(Date when) {
        Calendar cal = dayDateFormat.getCalendar();
        cal.setTime(when);
        int day = cal.get(Calendar.DAY_OF_YEAR);
        // Will work across year boundaries if messages are frequent enough.
        if (day > lastNotedDay || day < (lastNotedDay - 300)) {
            lastNotedDay = day;
            out.println(dayDateFormat.format(when) + "\n");
        }
    }

}
