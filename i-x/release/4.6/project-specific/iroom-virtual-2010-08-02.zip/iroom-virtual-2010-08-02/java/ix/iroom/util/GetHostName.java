/* Author: Stephen Potter
 * Updated: Wed May 19 16:20:15 2010
 * Copyright: (c) 2010, AIAI, University of Edinburgh
 */

package ix.iroom.util;

import java.util.*;

import ix.util.Util;

public class GetHostName {

    public static void main(String[] argv) {

	try{
	    String hostname = Util.getHostName();
	    System.out.println(hostname);
	}
	catch(Exception e){
	    e.printStackTrace();
	}

    }
}
