/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Feb 27 04:03:45 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet;

import java.util.*;

import ix.icore.IXAgent;
import ix.icore.log.*;

import ix.util.*;

/**
 * An EventLogger for use during meetings.   It keeps a list of the
 * HistoryEvents as well as logging them to a file (if desired).
 */
public class IMeetEventLogger extends EventLogger {

    protected List<HistoryEvent> events = new LinkedList<HistoryEvent>();

    public IMeetEventLogger(IXAgent agent) {
	super(agent);
    }

    public synchronized void log(HistoryEvent event) {
	events.add(event);
	super.log(event);
    }

    public List<HistoryEvent> getEvents() {
	return events;
    }

}
