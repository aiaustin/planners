/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Sun Nov 30 15:04:59 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet.meeting;

import java.util.*;

import ix.util.*;

/**
 * A simple language that can be used during meetings.
 * Parsing a string is determined by the first word, which is
 * mapped to one of the enum constants.
 */
public enum Language {

    /** Syntax: <b>minute</b> <i>text...</i> */
    minute {
	Minute parse(String text) {
	    Minute m = new Minute();
	    m.text = Strings.afterFirst(" ", text);
	    return m;
	}
    },

    /** Syntax: <b>decision</b> <i>text...</i> */
    decision {
	Decision parse(String text) {
	    Decision d = new Decision();
	    d.text = Strings.afterFirst(" ", text);
	    return d;
	}
    },

    /** Syntax: <b>action</b> <i>name1 name2 text...</i> */
    action {
	NewAction parse(String text) {
	    NewAction a = new NewAction();
	    // Syntax: action name1 name2 description...
	    LinkedList<String> words = 
		(LinkedList<String>)Strings.breakAt(" ", text);
	    // Check length
	    if (words.size() < 4) {
		a.responsibleAgent = "Someone";
		a.actionText = text;
		return a;
	    }
	    // Remove "action "
	    Debug.expectEquals(words.removeFirst(), "action");
	    // Get names, etc
	    String name1 = words.removeFirst();
	    String name2 = words.removeFirst();
	    a.responsibleAgent = name1 + " " + name2;
	    a.actionText = Strings.joinWith(" ", words);
	    return a;
	}
    },

    /** Syntax: <b>agenda</b> <i>text...</i> */
    agenda {
	NewAgendaItem parse(String text) {
	    NewAgendaItem i = new NewAgendaItem();
	    i.text = Strings.afterFirst(" ", text);
	    return i;
	}
    };

    abstract MeetingEvent parse(String text);

    /**
     * Translates text to a MeetingEvent.  <i>ifNone</i> is a default value
     * used if the text doesn't begin with a recognised word.
     */
    public static MeetingEvent parseText(String text, MeetingEvent ifNone) {
	Language word1 = getFirstWord(text);
	if (word1 == null)
	    return ifNone;
	else
	    return word1.parse(text);
    }

    public static Language getFirstWord(String text) {
	return getWord(Strings.beforeFirst(" ", text));
    }

    public static Language getWord(String w) {
	try {
	    return valueOf(w);
	}
	catch (IllegalArgumentException e) {
	    return null;
	}
    }

}
