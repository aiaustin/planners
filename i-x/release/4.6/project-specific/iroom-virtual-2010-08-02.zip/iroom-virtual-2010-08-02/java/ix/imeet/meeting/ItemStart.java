/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Feb 27 03:46:12 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet.meeting;

import ix.util.lisp.*;

/**
 * The point where discussion of an item starts.
 */
public class ItemStart extends MeetingEvent {

    public ItemType type = ItemType.AGENDA_ITEM;
    public LList pattern = null;

    public ItemStart() {
    }

    public void accept(MeetingEventVisitor v) {
	v.visitItemStart(this);
    }

    public void setFrom(ItemFinish f) {
	type = f.type;
	pattern = f.pattern;
    }

}
