/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Feb 27 02:06:23 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet.meeting;

import ix.util.lisp.*;

/**
 * The point where discussion of an item finishes.
 */
public class ItemFinish extends MeetingEvent {

    public ItemType type = ItemType.AGENDA_ITEM;
    public LList pattern = Lisp.NIL;
    public boolean carriedToNextMeeting = false;

    public ItemFinish() {
    }

    public void accept(MeetingEventVisitor v) {
	v.visitItemFinish(this);
    }

}
