package ix.iroom.nlg;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Random;
import java.util.Calendar;

import com.hp.hpl.jena.ontology.*;
import com.hp.hpl.jena.rdf.model.Literal;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.util.iterator.*;


public class WhiskyOntologyLookup {

	static final String whiskyOntologyURI = "http://www.aiai.ed.ac.uk/project/i-room/whisky.owl#";
	static final String whiskyOntologyFile = "resources/whisky.owl";

	OntModel model = ModelFactory.createOntologyModel(); // a Jena RDF model

	static final String scotchWhisky = "ScotchWhisky";
	static public final String name = "Name", colour = "Colour", palate = "Palate", 
	nose = "Nose", finish = "Finish", body = "Body", bottling="Bottling", status="Status";
	static public final String region = "Region", regions = "Regions", distillery = "Distillery", 
	owner = "Owner";
	static OntClass scotchWhiskyRes;
	static Property nameRes, colourRes, noseRes, finishRes, palateRes, bodyRes, regionRes, 
	distilleryRes, regionsRes, ownerRes, bottlingRes, statusRes, typeRes, subclassRes;

    static final String typeuri = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type";
    static final String subclassuri = "http://www.w3.org/2000/01/rdf-schema#subClassOf";

	public WhiskyOntologyLookup() {
		model.getDocumentManager().addAltEntry(whiskyOntologyURI, "file:"+whiskyOntologyFile);
		model.read(whiskyOntologyURI);
		//scotchWhiskyRes = model.getResource(whiskyOntologyURI+scotchWhisky);
		scotchWhiskyRes = model.getOntClass(whiskyOntologyURI+scotchWhisky);


		nameRes = model.getProperty(whiskyOntologyURI+name);
		colourRes = model.getProperty(whiskyOntologyURI+colour);
		palateRes = model.getProperty(whiskyOntologyURI+palate);
		noseRes = model.getProperty(whiskyOntologyURI+nose);
		finishRes = model.getProperty(whiskyOntologyURI+finish);
		bodyRes = model.getProperty(whiskyOntologyURI+body);
		bottlingRes = model.getProperty(whiskyOntologyURI+bottling);
		regionRes = model.getProperty(whiskyOntologyURI+region);
		regionsRes = model.getProperty(whiskyOntologyURI+regions);
		distilleryRes = model.getProperty(whiskyOntologyURI+distillery);
		ownerRes = model.getProperty(whiskyOntologyURI+owner);
		statusRes = model.getProperty(whiskyOntologyURI+status);

		typeRes = model.getProperty(typeuri);
		subclassRes = model.getProperty(subclassuri);
	}

	/**
	 * Just a test method!
	 * @param argv
	 *
	public static void main(String[] argv) {
		WhiskyOntologyLookup ol = new WhiskyOntologyLookup();
		//String w = "Millburn";
		String w = "Laphroaig";
		System.out.println("Testing with "+w+"\nnose:"+ol.getNose(w)+"\npalate:"+ol.getPalate(w)
				+"\ncolour:"+ol.getColour(w)+"\nfinish:"+ol.getFinish(w)+"\nbody:"+ol.getBody(w)
				+"\ndistillery:"+ol.getDistillery(w)+"\nregion:"+ol.getRegion(w)+"\nbottling:"
				+ol.getBottling(w));
		System.out.println("Age: "+ol.getAge(ol.getBottling(w)));
		System.out.println("Year: "+ol.getYear(ol.getBottling(w)));
		System.out.println("Vol: "+ol.getVol(ol.getBottling(w)));
		if (ol.isDistClosed(w)) System.out.println("Distillery Closed");
	}
	*/

	public Resource lookupWhisky(String whisky){
		ResIterator it = model.listSubjectsWithProperty(nameRes, whisky);
		if(!it.hasNext()) {
			System.err.println("Whisky "+whisky+" unknown.");
			System.exit(-1);
			return null;
		}
		else{
			return it.nextResource();
		}
	}

        public String randomWhisky(){
	    // 218 whiskies in ontology!

	    Random rand = new Random(Calendar.getInstance().getTimeInMillis());

    	    ResIterator scit = model.listSubjectsWithProperty(subclassRes, (OntResource) scotchWhiskyRes);

	    int count = 0;
	    int selected = rand.nextInt(218);

	    //System.out.println("RANDOM SELECTED:"+selected);
	    while(scit.hasNext()){
		ResIterator it = model.listSubjectsWithProperty(typeRes, scit.nextResource());
		//ExtendedIterator<Individual> it = model.listIndividuals(scotchWhiskyRes);
	    
		while(it.hasNext()){
		    if(count==selected)
			return ((Literal)((it.nextResource().getProperty(nameRes)).getObject())).getString();
		    else {
			it.nextResource();
			count++;
		    }
		  
		    //System.out.println(++count + ((Literal)((it.nextResource().getProperty(nameRes)).getObject())).getString());
		}
	    }
	    return "";
	}

	public String getTypeName(String whisky){
	    return ((Resource) ((lookupWhisky(whisky).getProperty(typeRes)).getObject())).getLocalName();
	    
	    /*
		StmtIterator si = lookupWhisky(whisky).listProperties();
		if (si.hasNext()){
			while (si.hasNext()){
			    Statement ns = si.nextStatement();
			    System.out.println(ns.getSubject().toString()+" "+
					       ns.getPredicate().toString()+" "+
					       ns.getObject().toString());
			}
		}
		return "";
	    */
	}

	public ArrayList<String> getNose(String whisky){
		ArrayList<String> nose = new ArrayList<String>();
		StmtIterator si = lookupWhisky(whisky).listProperties(noseRes);
		if (si.hasNext()){
			while (si.hasNext()){
				nose.add(((Literal) si.nextStatement().getObject()).getString());
			}
		}
		else nose.add("unknown");
		return nose;
		
	}
	
	public ArrayList<String> getPalate(String whisky){
		ArrayList<String> palate = new ArrayList<String>();
		StmtIterator si = lookupWhisky(whisky).listProperties(palateRes);
		if (si.hasNext()){
			while (si.hasNext()){
				palate.add(((Literal) si.nextStatement().getObject()).getString());
			}
		}
		else palate.add("unknown");
		return palate;
	}
	
	public ArrayList<String> getColour(String whisky){
		ArrayList<String> colour = new ArrayList<String>();
		StmtIterator si = lookupWhisky(whisky).listProperties(colourRes);
		if (si.hasNext()){
			while (si.hasNext()){
				colour.add(((Literal) si.nextStatement().getObject()).getString());
			}
		}
		else colour.add("unknown");
		return colour;
	}
	
	public ArrayList<String> getFinish(String whisky){
		ArrayList<String> finish = new ArrayList<String>();
		StmtIterator si = lookupWhisky(whisky).listProperties(finishRes);
		if (si.hasNext()){
			while (si.hasNext()){
				finish.add(((Literal) si.nextStatement().getObject()).getString());
			}
		}
		else finish.add("unknown");
		return finish;
	}
	
	public ArrayList<String> getBody(String whisky){
		ArrayList<String> body = new ArrayList<String>();
		StmtIterator si = lookupWhisky(whisky).listProperties(bodyRes);
		if (si.hasNext()){
			while (si.hasNext()){
				body.add(((Literal) si.nextStatement().getObject()).getString());
			}
		}
		else body.add("unknown");
		return body;
	}
	
	public ArrayList<String> getDistillery(String whisky){
		ArrayList<String> distAndOwn = new ArrayList<String>();
		Resource distRes;
		StmtIterator si = lookupWhisky(whisky).listProperties(distilleryRes);
		if(si.hasNext()){
			distRes = ((Resource) si.nextStatement().getObject());
			distAndOwn.add(((Literal)(distRes.getProperty(nameRes)).getObject()).getString());
			StmtIterator si2 = distRes.listProperties(ownerRes);
			if(si2.hasNext()) {
				distAndOwn.add(((Literal)si2.nextStatement().getObject()).getString());
			}
			if (isDistClosed(whisky)) distAndOwn.add("closed");
		}
		else distAndOwn.add("unknown");
		return distAndOwn;
	}
	
	public String getBottling(String whisky){
		String bottling = "";
		StmtIterator si = lookupWhisky(whisky).listProperties(bottlingRes);
		if (si.hasNext()){
			while (si.hasNext()){
				bottling = ((Literal) si.nextStatement().getObject()).getString();
			}
		}
		else bottling = "unknown";
		return bottling;
	}
	
	public String getRegion(String whisky){
		String region = "";
		Resource thisregionRes;
		StmtIterator si = lookupWhisky(whisky).listProperties(regionRes);
		if(si.hasNext()){
				thisregionRes = ((Resource) si.nextStatement().getObject());
				region = ((Literal)(thisregionRes.getProperty(nameRes)).getObject()).getString();
		}
		else region = "unknown";
		return region;
	}

	public String getAge(String btl){
		if (btl.indexOf("year-old")>0){
			int start = btl.indexOf("year-old")-3;
			if(start<0) start=0;
			//return btl.substring(btl.indexOf("year-old")-3, btl.indexOf("year-old")-1);
			return btl.substring(start, btl.indexOf("year-old")-1);
		}
		else return null;
	}
	
	public String getYear(String btl){
		Pattern p = Pattern.compile("\\d{4}+");
		Matcher m = p.matcher(btl);
		if (m.find()) return btl.substring(m.start(),m.end());
		else return null;
	}
	
	public String getVol(String btl){
		if (btl.indexOf("vol")>0)
			return btl.substring(btl.indexOf("vol")-3, btl.indexOf("vol")-1);
		else return null;
		
	}
	
	public boolean isDistClosed(String whisky){
		boolean closed=false;
		Resource distRes;
		StmtIterator si = lookupWhisky(whisky).listProperties(distilleryRes);
		if(si.hasNext()){
			distRes = ((Resource) si.nextStatement().getObject());
			if (((Literal)(distRes.getProperty(statusRes)).getObject()).getString().equalsIgnoreCase("closed")){
				closed=true;
			}
		}
		return closed;
	}
}
