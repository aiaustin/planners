/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Tue Feb 26 22:26:21 2008 by Jeff Dalton
 * Copyright: (c) 2008, AIAI, University of Edinburgh
 */

package ix.imeet.meeting;

/**
 * A decision.
 */
public class Decision extends MeetingEvent {

    public String text;

    public Decision() {
    }

    public void accept(MeetingEventVisitor v) {
	v.visitDecision(this);
    }

}
