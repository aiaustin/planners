/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Thu Jun 10 16:11:50 2010
 * Copyright: (c) 2007, AIAI, University of Edinburgh
 */

package ix.iroom;

import javax.swing.*;
import javax.imageio.ImageIO;

import java.awt.Component;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.event.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.StringTokenizer;

import ix.icore.Activity;
import ix.icore.IXAgentExtension;

import ix.iface.util.ToolController;
import ix.iface.util.IFUtil;
import ix.ip2.*;
import ix.ip2.ImageViewerExtension;
//import ix.ip2.ImageViewerExtension.ImageFinderTool;
import ix.ip2.ImageViewerExtension.ImageFinderTool.ICFrame;

import ix.util.*;

public class IRoomToolExtension implements IXAgentExtension {

    private String imageDirectory = "./tmp";
    private String webDirectory= "./tmp";;
    private String urlBase;
    public static String virtualWorldHelper;
    
    private String imageType = "jpg";        // can be png or jpg

    public static Ip2 ip2;

    public IRoomToolExtension(Ip2 ip2) {
    	this.ip2 = ip2;
    }

    public void installExtension() {
	ip2.addTool(new ToolController("I-Room Tool") {
	    public Object createTool() {
	    	if(Parameters.haveParameter("web-directory")){
	    		webDirectory = Parameters.getParameter("web-directory");
	    		System.out.println("set web directory to: "+webDirectory);
	    	}
	    	if(Parameters.haveParameter("image-directory")){
	    		imageDirectory = Parameters.getParameter("image-directory");
	    		System.out.println("set image directory to: "+imageDirectory);
	    	}
	    	else imageDirectory = webDirectory;
	    	
	    	if(Parameters.haveParameter("virtual-world-helper")){
	    		virtualWorldHelper = Parameters.getParameter("virtual-world-helper");
	    		System.out.println("set virtual world helper agent to "+virtualWorldHelper);
	    	}

	    	if(Parameters.haveParameter("url-base")){
	    		urlBase = Parameters.getParameter("url-base");
	    		//if(!urlBase.endsWith(File.separator)) urlBase+=File.separator;
	    		System.out.println("set url base to "+urlBase);
	    	}
	    	
	    	return new IRoomTool();
	    }
	});
    }

    private void snapAllFrames() {
	for (Frame f: Frame.getFrames()) {
	    if (isSnappable(f))
		savePicture((JFrame)f);
	}
    }

    private boolean isSnappable(Frame f) {
	return f instanceof JFrame
	    && f.isVisible()
	    && !(f instanceof IRoomTool.SnapFrame)
	    && !(f instanceof ICFrame);
    }

    private void savePicture(JFrame frame) {
	BufferedImage image = takePicture(frame);
	writeImageFile(image, imagePathname(frame));
    }

    private BufferedImage takePicture(JFrame frame) {

	// Get an image of the frame.
	// We use the content-pane, rather than the frame itself,
	// because if we use the frame there can be a black area
	// where the title bar would be.
	Component p = frame.getContentPane();
        BufferedImage image = 
	    new BufferedImage(p.getWidth(),
			      p.getHeight(),
			      BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = image.createGraphics();
	try {
	    p.paintAll(g2);
	}
	finally {
	    g2.dispose();
	}
	return image;
    }

    private void writeImageFile(BufferedImage image, String fileName) {

	// Write it as a file of type imageType, usually "png".
	Debug.noteln("Writing", fileName);
	try {
	    ImageIO.write(image, imageType, new File(fileName));
	}
	catch (IOException e) {
	    throw new RethrownException(e);
	}

    }

    private String imagePathname(Frame f) {
	String slash = System.getProperty("file.separator");
	return imageDirectory + slash + fileName(f) + "."+imageType;
    }

    /** 
     * The file-name, without directory or type, that corresponds
     * to the frame.
     */
    private String fileName(Frame f) {
	// Replace each space by a "-".
	return Strings.replace(" ", "-", f.getTitle());
    }

    /**
     * The GUI that lets the user interact with the I-Room
     */
    protected class IRoomTool {

	private JFrame frame;
	private JMenu displayMenu;
	private JMenu meetingMenu;
	private JMenu housekeepingMenu;
	
	public IRoomTool() {
	    frame = new SnapFrame();
	    //frame.getContentPane().
	    frame.getContentPane()
		     .add(IFUtil.makeButton("Build Matrix", new SnapListener()));
	    frame.pack();
	    JMenuBar mb = new JMenuBar();

	    frame.setJMenuBar(mb);
	    frame.setSize(270,85);
	    
	    // create meeting actions menu:
	    meetingMenu = new JMenu("Meeting Actions");
	    meetingMenuItem("minute");
	    meetingMenuItem("action");
	    meetingMenuItem("decision");
	    meetingMenuItem("agenda");
	    
	    mb.add(meetingMenu);
	    
	    housekeepingMenu = new JMenu("Describe");
	    housekeepingMenuItem("avatars");
	    housekeepingMenuItem("display");
	    housekeepingMenuItem("objects");
	    
	    mb.add(housekeepingMenu);
	    
	    displayMenu = new JMenu("Display");
	    mb.add(displayMenu);
	}

	
	public void meetingMenuItem(String itemType){
		JMenuItem item = new JMenuItem(itemType);
		if(itemType.equals("action")){
			item.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					String target = e.getActionCommand();
					String actioned = JOptionPane.showInputDialog("Action who?");
					if(!actioned.equals("")&&actioned.matches("[A-Za-z]+[ ]+[A-Za-z]+")){
						String action = JOptionPane.showInputDialog("Action?");
						if(!action.equals("")){
							IPC.sendObject(virtualWorldHelper, new Activity(target+" "+actioned+" "+action));
						}
					}
					//System.out.println("display "+displayob+" "+target);
				}
			});
			
		}
		else{
			item.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					String target = e.getActionCommand();
					String content = JOptionPane.showInputDialog("Content of "+target+"?");
					if(!content.equals(""))
						IPC.sendObject(virtualWorldHelper, new Activity(target+" "+content));
					//System.out.println("display "+displayob+" "+target);
				}
			});
		}
		meetingMenu.add(item);
	}
	
	public void housekeepingMenuItem(String itemType){
		JMenuItem item = new JMenuItem(itemType);
		item.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String target = e.getActionCommand();
				//String content = JOptionPane.showInputDialog("Content of "+target+"?");
				//if(!content.equals(""))
				IPC.sendObject(virtualWorldHelper, new Activity("describe "+target));
				//System.out.println("display "+displayob+" "+target);
			}
		});
		housekeepingMenu.add(item);
	}
	
	public void addDisplayMenuItem(String displayname){
		JMenuItem newitem = new JMenuItem(displayname);
		newitem.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String target = e.getActionCommand();
				String displayob = JOptionPane.showInputDialog("Name of display object?\n(press OK for default object)");
				IPC.sendObject(virtualWorldHelper, new Activity("display "+displayob+" "+target));
				//System.out.println("display "+displayob+" "+target);
			}

		});
		displayMenu.add(newitem);
	}
	
	
	public void setVisible(boolean v) {
	    frame.setVisible(v);
	}
	
	private void parseNames(String names){
		StringTokenizer st = new StringTokenizer(names);
		while(st.hasMoreTokens()){
			addDisplayMenuItem(st.nextToken());
		}
		
	}
	
	private class SnapFrame extends JFrame {
	    private SnapFrame() {
	    	super(ip2.getAgentDisplayName() + " I-Room Tool");
	    }
	}

	private class SnapListener implements ActionListener {
	    public void actionPerformed(ActionEvent event) {
		// takePictureFromFrame();
	    //String basename = (ip2.getAgentSymbolName()).replaceAll(" ", "-");
	    String basename = (ip2.getAgentDisplayName()).replaceAll(" ", "-");
	    MosaicBuilder.cleanup(imageDirectory,basename);
	    displayMenu.removeAll();
		snapAllFrames();
		try {
			//String mosaicName = MosaicBuilder.createScaledMosaic(imageDirectory,webDirectory,basename);
			String[] mosaicResults = MosaicBuilder.createScaledMosaic(imageDirectory,webDirectory,basename);
			
			if(mosaicResults[0]!=null){
				JOptionPane.showMessageDialog(null, "Matrix created: "+mosaicResults[0]);
				System.out.println("Matrix: "+mosaicResults[1]);
				if(virtualWorldHelper!=null){
					// also try to send to second life:
					IPC.sendObject(virtualWorldHelper, new Activity("display "+urlBase+mosaicResults[0]));
					IPC.sendObject(virtualWorldHelper, new Activity("inform "+mosaicResults[1]));
					parseNames(mosaicResults[2]);
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }
	}

	
    }

}
