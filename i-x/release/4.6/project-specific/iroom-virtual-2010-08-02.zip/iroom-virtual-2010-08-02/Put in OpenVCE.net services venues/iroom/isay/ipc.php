<?php

// Edit these two lines to match the comm server URL:
$host = "iserve.hostname.here";
$port = 80;

// Make sure we do this first.
header("Content-type: text/plain");

$req_path = $_SERVER['PATH_INFO'];
$req_addr = $_SERVER['REMOTE_ADDR'];

$data = file_get_contents("php://input");

echo request($host, $port, $req_path, $data);

function request($host, $port, $path, $content) {

    // We make HTTP 1.0 requests, not 1.1, to avoid chunked replies.

    // Build headers
    $h = array();
    $h []= 'POST ' . $path . ' HTTP/1.0';
    $h []= 'Content-Type: text/plain';
    $h []= 'Host: ' . $host . ':' . $port;
    $h []= 'Content-Length: ' . strlen($content);
    $h []= 'Connection: close';
    $h = implode("\r\n", $h) . "\r\n\r\n";

    // Open socket
    $socket = fsockopen($host, $port, $errno, $errstr);

    if (!$socket) {
        header("HTTP/1.0 503 Service Unavailable");
        // echo "Error when connecting: $errno: $errstr\n";
        return false;
    }

    // Send request
    if (!fwrite($socket, $h . $content)) {
        fclose($socket);
        return false;
    }

    // Read the reply
    $reply = "";
    while (!feof($socket)) {
        $reply .= fgets($socket);
    }

    fclose($socket);

    // Perhaps the reply is empty.
    if ($reply == "") {
        header("HTTP/1.0 502 Bad Gateway - Empty Response");
        // echo 'Empty response';
        return false;
    }

    // Split reply headers from reply content.
    $parts = explode("\r\n\r\n", $reply);
    $headers = explode("\r\n", $parts[0]);
    $reply_content = $parts[1];  // <------ s.b. all after 1st /\/

    // print_r($headers);

    // Check the response statue
    $status = trim(strtolower($headers[0]));
    switch ($status) {
      case 'http/1.0 200 ok':
      case 'http/1.1 200 ok':
        break;
      default:
        header($status); // return the same status
        echo "Request returned: $status\n";
        return false;
    }

    return $reply_content;
    
}

?>
