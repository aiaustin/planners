<?php
header("Content-Type: text/plain");
$base_url = file_get_contents("comm-server-url.txt");
$base_url = trim($base_url);
$status_url = $base_url . "/ipc/status";
$server_status = file_get_contents($status_url);
header("Content-Length: " . strlen($server_status));
echo $server_status;
?>
