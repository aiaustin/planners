ISAY APPLET
-----------
Stephen Potter
Last updated: Mon Jul 26 14:17:23 2010

The isay applet provides a lightweight mechanism for those unable to run a
virtual world viewer to interact with a meeting through chat. It runs as
an applet in a standard internet browser; it requires a running I-Serve 
communications server, and needs two additional services to be running, namely 
the in-world chat relay object and the I-X chat relayer service, both of which 
are included in this app. (It is assumed that the server and related services
will be for the dedicated use of a particular (I-Room) location within the 
virtual world.) In addition, the applet must be mounted on a HTTP server for
which PHP has been enabled.

Configuration
-------------

Copy the contents of this directory to an accessible location on the HTTP 
server (you may wish to rename the "iroom" directory to better describe the 
location or purpose of your I-Room). 
Next, it is necessary to edit several files:

- edit comm-server-url to the URL of the I-Serve server that you wish to use 
for the I-Room in question (if you are already running the I-Serve server from 
within this app, you can copy the file 
<app-root>/http-doc-root/comm-server-url.txt).
- edit isay/applet.html to provide the full URL of the isay-code sub-directory 
as the value of the codebase applet parameter.
- edit isay/ipc.php to provide values for $host and $port corresponding to
the I-Serve server that you wish to use for the I-Room in question.

Running
-------

Visiting the URL http://<web-server>/<path-to-isay>/isay using a web-browser
will display a link to the applet (note that the browser must be enabled to
run applets - in other words, it must have the java plug-in installed).
Following the link should cause the applet to be loaded automatically.
The upper text area shows current chat in the I-Room; the lower text field 
allows the user to type chat that will be seen by all those currently in the
location (or following chat in their own browser applets). The first time the 
user types a chat message, s/he will be asked to provide a login name which
will be used to register her/him with I-Serve and also to identify her/him to
the other I-Room users.