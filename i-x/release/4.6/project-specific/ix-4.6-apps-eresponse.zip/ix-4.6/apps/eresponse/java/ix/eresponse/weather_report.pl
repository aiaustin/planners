#!c:\Perl\bin\perl.exe -i'C:\Perl\site\lib\SOAP'
use SOAP::Lite;
use Tie::RefHash;
#print "args:$ARGV\n";

#print 
#   "Content-type: text/html\n\n";
#print "<html>\n<head><title>soap call</title><head\>\n<body>";

#print "Loading SOAP::Lite";

use SOAP::Lite
    on_fault => sub{
	#my $first = \@_[0];
	#tie %first, "Tie::RefHash";
	#print "first: $$first\n";
	#($ke=$ve) = %first;
	#foreach $item ($$first){
	#    print "yj: $item\n";
	#}
	#my %lh = @_[0];
	#while((%key,$val) = each(%lh)){
	#    print "keys: %key=$val\n";
	#    while(($kay,$vee) = each(%key)){
	#	print "$kay=$vee\n";
	#    }
	#}
	#foreach $item (@_){
	#    print "$item\n";
	#    while(($key,$value)=each(%$item)){
	#	print "next:$key=$value\n";
	#    }
	#}
#	print(@_[1]);

	my $xmlt = @_[1];

	#my $nsubs = ($xmlt =~ s/&apos;/ /g);
	#print "numsubs=$nsubs\n";

	if($xmlt =~ /(.*)(<\?xml .*)/s){
	    print "discarding $1\n";
	    $xmlt = $2;
	}
	#print $xmlt;
	
	#use XML::Parser;
	#$p1 = new XML::Parser(Style=>'Debug');
	#$p1 -> parse($xmlt);

	use XML::Simple;
	my $ref = XMLin($xmlt);

	use Data::Dump qw(dump);
	dump($ref);
	#print $ref;
	
	while(($key,$value)=each(%ref)){
	    print "$key is $value";
	    #if($key=="SOAP-ENV:Body"){
		while(($bk,$bv)=each(%key)){
		    print "next:$bk=$bv\n";
		}
	    #}
	}

	#printf '%s#%s', @_
    },
    typelookup => {
      '{http://www.capeclear.com/GlobalWeather.xsd}PhenomenonType' => [100, sub {1}, 'as_string'],
      },
    autotype => true,
    service => 'http://live.capescience.com/wsdl/GlobalWeather.wsdl';
#    service => 'http://homepages.inf.ed.ac.uk/stephenp/GlobalWeather.wsdl';


# EGHI

my $response = getWeatherReport($ARGV[0]);

#print searchByName($ARGV[0]);
   # -> searchByCountry("united kingdom");

#print $response;

#while(($key,$value) = each(%$response)){
#    print "$key = $value\n";
#}

#foreach $item (@$response){
#	print "$item\n";
#	
#}

#foreach $item (@$response){
#	print "$item\n";
#	while(($key,$value) = each(%$item)){
#	    print "$key=$value\n";
#	}
#    }

