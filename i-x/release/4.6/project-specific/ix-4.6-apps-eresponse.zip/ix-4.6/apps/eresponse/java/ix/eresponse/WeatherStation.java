/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 *    and: Stephen Potter <stephenp@inf.ed.ac.uk>
 * Updated: Tue Sep 28 12:07:27 2004
 * Copyright: (c) 2001, 2003, 2004, AIAI, University of Edinburgh
 */

package ix.eresponse;

import java.util.*;
import java.io.IOException;
import java.io.*;
import java.net.*;

import javax.swing.JOptionPane;

import ix.icore.*;
import ix.ip2.*;
import ix.util.*;
import ix.util.lisp.*;
import ix.ichat.*;


import org.jdom.*;
import org.jdom.input.*;

/**
 * Adds a handler action initiates a google search for the content
 * of an AgendaItem. 
 */
public class WeatherStation extends ItemHandler {

    //String PROPS_FILE="local-properties/internet-search.props";

    //private Symbol ACTION_SYMBOL_NAME = Symbol.intern("action");

    protected Ip2 ip2;

    public WeatherStation(Ip2 ip2) {
	super("Get nearest weather station");
	this.ip2 = ip2;
    }

    public List getSyntaxList(){
	return (LList)Lisp.readFromString("((get-weather-station ?place-name))");
    }

    public boolean appliesTo(AgendaItem item) {	
	return (((item.getAbout()).getVerb()).toString().equals("get-weather-station"));
    }

    public void addHandlerActions(AgendaItem item) {
	item.addAction
	    (new HandlerAction.AutomaticWhenBound(item, this));
    }

    public void handle(AgendaItem item) {

	try{

	    TaskItem act = item.getAbout();

	    act.setPattern((LList)Variable.removeVars(item.getPattern()));

	    //String loc = PatternParser.unparse((LList)Variable.removeVars(act.getParameters().get(0)));

	    String loc = (act.getParameters().get(0)).toString();
	    //System.out.println("loc="+loc);

	    //System.out.println("verb="+(act.getVerb()).toString()+" param="+((act.getParameters().get(0)).toString()));

    	    //Process wp = (Runtime.getRuntime()).exec("perl D:\\ix-3.2\\apps\\eresponse\\java\\ix\\eresponse\\weather_station.pl "+loc);
	    Process wp = (Runtime.getRuntime()).exec("perl java\\ix\\eresponse\\weather_station.pl "+loc);

	    BufferedReader stdInput = new BufferedReader(new InputStreamReader(wp.getInputStream()));
	    BufferedReader stdError = new BufferedReader(new InputStreamReader(wp.getErrorStream()));

	    //System.out.println("Here is the standard output of the command:\n");
	    String s;
	    String response = "";
	    while ((s = stdInput.readLine()) != null) {
		System.out.println(s);
		response += s+"\n";
	    }

	    //System.out.println("Here is the standard error of the command (if any):\n");
	    while ((s = stdError.readLine()) != null) {
		//System.out.println(s);
		response += s+"\n";
	    } 

	    IXAgent agent = IXAgent.getAgent();
	    System.out.println("RESPONSE:\n"+response);
	    ChatMessage chatmsg = new ChatMessage(response,"Global Weather (http://www.capescience.com/webservices/globalweather)");
	    ChatFrame ichat = (ChatFrame)agent.ensureTool("Messenger");
	    (ichat.getSendPanel()).sendCopy("me",chatmsg);

	}
	catch (Exception e){
	    Debug.noteln("Handler error : "+e.toString());
	    // Uh, better do something with this exception:
	    JOptionPane.showMessageDialog(null,
					  "Handler problem:\n"+Debug.foldException(e),
					  "Internet Search Handler Error",
					  JOptionPane.ERROR_MESSAGE);
	}   

	// don't do anything to the status:
	item.setStatus(Status.COMPLETE);

    }


}
