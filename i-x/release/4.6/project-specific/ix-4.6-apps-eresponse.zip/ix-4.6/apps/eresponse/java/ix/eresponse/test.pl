#!c:\Perl\bin\perl.exe -i'C:\Perl\site\lib\SOAP'
use SOAP::Lite;
print "args:$ARGV\n";

print 
   "Content-type: text/html\n\n";
print "<html>\n<head><title>soap call</title><head\>\n<body>";

print "Loading SOAP::Lite";

use SOAP::Lite
    on_fault => sub{printf '%s#%s', @_},
#my $response = new SOAP::Lite
    autotype => 'false',
    service => 'http://live.capescience.com/wsdl/GlobalWeather.wsdl';

# EGHI

print getWeatherReport($ARGV[0]);
   # -> searchByCountry("united kingdom");

#print $response;

#while(($key,$value) = each(%$response)){
#    print "$key = $value\n";
#}

#foreach $item (@$response){
#	print "$item\n";
#	
#}
print "end";
