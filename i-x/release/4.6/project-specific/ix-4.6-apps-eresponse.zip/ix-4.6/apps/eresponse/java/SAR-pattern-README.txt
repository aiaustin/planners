README for:
Search and Rescue Management Map Code for BBN Openmap and I-X
author: Helen Wollan
email:  lyzel79@hotmail.com
date:   2-Sep-2004 (amended 7-Oct-2004)

Files:
   MapTool.java
   IxPatternLayer.java
   IxSectorLayer.java
   IxStatusLayer.java

Permission is given to use this add-on code for any purpose

Base code found at:
   I-X:           http://www.aiai.ed.ac.uk/project/ix
   BBN Openmap:   http://openmap.bbn.com

Other sources:
   PointInPolygon code: http://www.alienryderflex.com/polygon

These add-on layers allow the user to create search sectors on the map, generate search patterns
within these sectors, and monitor the status of the sectors.  

MapTool.java is written by Clauriton Siebra, but modified slightly for the Ix... java files to work properly.

IxSectorLayer, in package ix.ip2.map, provides the functionality to generate the search sectors on the map
by clicking on the map to indicate the vertices of the sector and double-clicking on the end vertex.
This sector also provides a menu obtainable by right-clicking in a defined sector.  This menu contains
searcher names, notes, status, and probability of the sector.  The sectors defined by the user are stored 
in I-X as constraints.  The searcher names, notes, status, and probability are also stored in I-X as constraints.

IxPatternLayer, in package ix.ip2.map, provides the functionality to generate search patterns in sectors.  There
is a bug in the code currently.  The pattern generation is based on bearing, or azimuth, calculations.  The
bearings used in the code need to be re-defined at each step instead of defined once at the beginning
to accomodate large sectors since the bearing changes over large distances.  This is indicated as a comment
in line 577 of the java file.

IxStatusLayer, in package ix.ip2.map, provides the status functionality. This class merely changes the fill color
of the sectors based on the status percentage defined in the right-click menu of IxSectorLayer.  The colors
are red for 0<=status<= 33, yellow for 33<status<=66, orange for 66<status<=99, and green for status = 100.

All information is stored in I-X as constraints:

sector search1 = ((53.283417 -8.193763) (53.466858 -7.2712874) (52.78151 -7.666634) (52.808075 -8.23769) (53.283417 -8.193763))
pattern search1 = ((52.80123 -7.7225776) (53.004585 -7.923754) (53.065742 -7.9865227) (52.80924 -7.840717) (52.81724 -7.9588776) (53.126896 -8.049379) (53.18805 -8.112326) (52.82525 -8.07706) (52.833256 -8.195264) (53.249207 -8.175362) (53.248917 -8.112423) (53.279297 -8.112199) (53.302498 -7.9984107) (53.18677 -8.0521345) (53.12463 -7.991934) (53.325703 -7.8845615) (53.3489 -7.7706504) (53.062492 -7.9318204) (53.000355 -7.871793) (53.3721 -7.656677) (53.395306 -7.5426407) (52.938217 -7.8118525) (52.876076 -7.751998) (53.418507 -7.428543) (53.441704 -7.3143835) (52.81394 -7.692229))
probability search1 = 20.0
status search1 = 67.0
note search1 = (("2004.09.18 at 13:17:20 BST" "another note") ("2004.09.18 at 13:17:11 BST" "a note is added"))
searcher search1 = ("Sam" "Joe")
trackWidth search1 = 4.0


SAR Pattern Mouse Handling - Helen Wollan 7-Oct-2004

The mouse handling that didn't work with the World Objects layer enabled was
only the double clicking to end the building of a sector - the getMouseClick()
method in the MouseEvent class always returned 1 (the Sector layer only
received the initial mouse event, no consecutive events) until I disabled the
World Objects Layer.  All other mouse events filter through and can be used.
A right click would bring up both the Sector layer menu and the World Objects
dialog box if you enabled both.  I can try to figure this out some more but I
did spend about 2 weeks working on this small bit before figuring out that
disabling the World Objects layer allowed the Sector layer to get all the mouse
clicks instead of only the initial one.
