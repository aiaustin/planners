/* Author: Stephen Potter <stephenp@inf.ed.ac.uk> and Jeff Dalton
 * Updated: Thu May 19 11:54:30 2005
 * Copyright: (c) 2004, AIAI, University of Edinburgh
 */

package ix.eresponse;
import ix.util.*;
import ix.util.lisp.*;
import ix.icore.*;
import ix.icore.domain.*;
import ix.iface.util.*;
import ix.ichat.ChatFrame;

import java.util.*;

public class Vehicle extends IXAgent {

    static String vehiclename;
    static String target;

    public Vehicle() {
	super(); 
    }

    // Next few methods copied from JD's IQuery code:

    /**
     * Command-line argument processing.
     */
    protected void processCommandLineArguments() {
	super.processCommandLineArguments();
    }

    /**
     * Agent setup and initialization.
     * The method supplied by the IQuery class just
     * calls {@link #setupGUI()} in the AWT event thread.
     *
     * @see IXAgent#startup()
     */
    protected void startup() {
	Util.swingAndWait(new Runnable() {
	    public void run() {
		setupGUI();
	    }
	});
    }

    /**
     * Creates a "transcript" frame for this agent, including
     * an "Exit" button.
     */
    protected void setupGUI() {
	// This is optional.  We could just let the first incoming message
	// cause the text frame to be created.  But this way we can make it
	// appear right away and can add an "Exit" button.


	String framename = ipcName;
	if(Parameters.haveParameter("jabber-resource"))
	    framename = Parameters.getParameter("jabber-resource");
	else{ // if no jabber-resource use symbol-name instead?
	    if(Parameters.haveParameter("symbol-name"))
		vehiclename = Parameters.getParameter("symbol-name");
	}

	textFrame = new TextAreaFrame("Messages for " + framename,
				      new String[] { "Exit" } );
	textFrame.setFoldLongLines(0);
	textFrame.addToolManager();
	textFrame.addListener(new TextAreaFrame.TListener() {
	    public void buttonPressed(String action) {
		if (action.equals("Exit"))
		    if (Util.dialogConfirms
			    (textFrame, "Are you sure you want to exit?"))
			exit();
	    }
	});
    }

    /**
     * Called when the agent should cease execution.
     */
    public void exit() {
	System.exit(0);
    }

    public void addTool(ToolController tc) {
	textFrame.addTool(tc);
    }

    public static double abs(double ent){
	if(ent<0) return -ent;
	else return ent;
    }

    public static void sendConstraint(String att, Object val){
	    LListCollector pattern = new LListCollector();
	    pattern.add(Symbol.intern(att));
	    pattern.add(Symbol.intern(vehiclename));
	    PatternAssignment pa = new PatternAssignment(pattern.contents(),val);
	    LListCollector lonp = new LListCollector();
	    lonp.add(pa);

	    try{
		//JabberCommunicationStrategy.getTheStrategy().sendObject(target, new Constraint("world-state", "effect",lonp.contents()));
		IPC.getCommunicationStrategy().sendObject(target, new Constraint("world-state", "effect",lonp.contents()));

	    }
	    catch (Exception e){
		e.printStackTrace();
	    }
    }

    public static double round(double val){
	// rounds val to dp decimal places
	double dp = 4;
	double mult = Math.pow(10,dp);
	return (double) (Math.round(val*mult))/mult;
    }

    public static void main(String[] args){
	new Vehicle().mainStartup(args);
	//super.processCommandLineArguments();

	if(Parameters.haveParameter("message-target"))
	    target = Parameters.getParameter("message-target");
	
	double lat = 50.73;
	double beginlon = -0.3;
	double endlon = -0.3;
	double beginlat = 50.73;
	double endlat = 50.6;
	double step = 0.01;

	vehiclename = "unknown-agent";
	if(Parameters.haveParameter("jabber-resource"))
	    vehiclename = Parameters.getParameter("jabber-resource");
	else{ // if no jabber-resource use symbol-name instead?
	    if(Parameters.haveParameter("symbol-name"))
		vehiclename = Parameters.getParameter("symbol-name");
	}

	//double beginlat = -0.3;
	if(Parameters.haveParameter("begin-lat"))
	    beginlat = (new Double(Parameters.getParameter("begin-lat"))).doubleValue();

	//double endlat;
	if(Parameters.haveParameter("end-lat"))
	    endlat = (new Double(Parameters.getParameter("end-lat"))).doubleValue();
	
	//double beginlon;
	if(Parameters.haveParameter("begin-lon"))
	    beginlon = (new Double(Parameters.getParameter("begin-lon"))).doubleValue();

	//double endlon;
	if(Parameters.haveParameter("end-lon"))
	    endlon = (new Double(Parameters.getParameter("end-lon"))).doubleValue();


	int delay = 5; // time in secs btw messages:
	if(Parameters.haveParameter("message-delay"))
	    delay = (new Integer(Parameters.getParameter("message-delay"))).intValue();

	double speed = 0.001; // approx lat(long)/s
	if(Parameters.haveParameter("speed"))
	    speed = (new Double(Parameters.getParameter("speed"))).doubleValue();

	String motion = "line"; // should be "line" or "area"
	if(Parameters.haveParameter("motion"))
	    motion = Parameters.getParameter("motion");

	System.out.println("Motion="+motion);

	if(motion.equals("line")){

	    double latinc = abs((endlat-beginlat))*speed;
	    double loninc = abs((endlon-beginlon))*speed;

	    System.out.println("li="+latinc+" lo="+loninc);

	    double currlon = beginlon;
	    double currlat = beginlat;
	    boolean forward = true;
	    while(true){
		try{
		    Thread.sleep(delay*1000);
		    //(new Object()).wait(5000);
		}
		catch(Exception e){
		    e.printStackTrace();
		}

		if(forward){ // towards endlon & endlat;
		    if(currlon>endlon){
			currlon -= loninc;
			//currlat -= latinc;
			if(currlon<=endlon) forward = false;
		    }
		    else{
			currlon += loninc;
			//currlat += latinc;
			if(currlon>=endlon) forward = false;
		    }

		    if(currlat>endlat){
			currlat -= latinc;
			//if(currlon<=endlon) forward = false;
		    }
		    else{
			currlat += latinc;
			// if(currlon>=endlon) forward = false;
		    }
		}
		else{// towards startlon;
		    if(currlon>beginlon){
			currlon -= loninc;
			//currlat -= latinc;
			if(currlon<=beginlon) forward = true;
		    }
		    else{
			currlon += loninc;
			//currlat += latinc;
			if(currlon>=beginlon) forward = true;
		    }

		    if(currlat>beginlat){
			currlat -= latinc;
			//if(currlon<=beginlon) forward = true;
		    }
		    else{
			currlat += latinc;
			//if(currlon>=beginlon) forward = true;
		    }
		}

		System.out.println("newlong="+currlon+"\nnewlat="+currlat);
		
		sendConstraint("longitude",new Double(round(currlon)));
		sendConstraint("latitude",new Double(round(currlat)));
	    }
	}
	else{
	    // motion = "area"
	    //double centrelat = ((endlat-beginlat))/2;
	    //double centrelon = ((endlon-beginlon))/2;
	    // want to always have 'tendency' towards the center;
	    // also include momentum (ie current direction);
	    // and random step...

	    if(beginlat>endlat){
		double temp = endlat;
		endlat = beginlat;
		beginlat = temp;
	    }

	    if(beginlon>endlon){
		double temp = endlon;
		endlon = beginlon;
		beginlon = temp;
	    }

	    double currlat = beginlat;
	    double currlon = beginlon;
	    double momlat = 0.0;
	    double momlon = 0.0;
	    boolean initial = true;
	    Random rand = new Random(System.currentTimeMillis());

	    double difflat = endlat - beginlat;
	    double difflon = endlon - beginlon;

	    double centrelat = (difflat/2)+beginlat;
	    double centrelon = (difflon/2)+beginlon;

	    double lastlat = 0.0;
	    double lastlon = 0.0;

	    while(true){
		try{
		    Thread.sleep(delay*1000);
		    //(new Object()).wait(5000);
		}
		catch(Exception e){
		    e.printStackTrace();
		}

		double rstep = speed*rand.nextDouble(); // 0.0 < rstep < 1.0

		System.out.println("Currlat="+currlat+" rstep="+rstep+" momlat="+momlat);
		if(currlat>centrelat){
		    if(initial) currlat -= rstep;
		    else currlat = currlat - rstep + momlat;
		}
		else{
		    if(initial) currlat += rstep;
		    else currlat = currlat + rstep + momlat;
		}

		//if(currlat>=endlat) currlat = endlat;
		//if(currlat<=beginlat) currlat = beginlat;

		System.out.println("newlat="+currlat);

		if(initial) momlat = speed;
		else
		    momlat = speed*(currlat - lastlat);
		lastlat = currlat;

		rstep = speed*rand.nextDouble();
		if(currlon>centrelon){
		    if(initial) currlon -= rstep;
		    else currlon = currlon - rstep + momlon;
		}
		else{
		    if(initial) currlon += rstep;
		    else currlon = currlon + rstep + momlon;
		}

		//if(currlon>=endlon) currlon = endlon;
		//if(currlon<=endlon) currlon = beginlon;

		if(initial) momlon = speed;
		else momlon = speed*(currlon - lastlon);
		lastlon = currlon;

		initial = false;
		sendConstraint("longitude",new Double(round(currlon)));
		sendConstraint("latitude",new Double(round(currlat)));
	    
	    }		          
	}      
    }
}
