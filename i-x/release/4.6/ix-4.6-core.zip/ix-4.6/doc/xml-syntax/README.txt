Start with index.html or index.xhtml.
