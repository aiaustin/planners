This is the basic IDemo. It contains a single panel which is used as
an intelligent todo list.

- INCA engine
- show UI: areas
- how to put new things into areas
- how to load/save different things
- actions on activities
- domain models
- expansions from models vs manual
- context-sensitive right-click
