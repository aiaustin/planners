/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed 17 April 2002 by Austin Tate
 * Copyright: (c) 2002, AIAI, University of Edinburgh
 */

package isample;

import java.awt.event.*;
import java.util.*;

import ix.icore.*;
import ix.ip2.*;
import ix.util.*;
import ix.util.lisp.*;


/**
 * An example of various ways to entend Ip2.
 */

public class Isample extends Ip2 {

    public Isample() {
	super();
        /* Put in modifications to Basic Ip2 here */
    }

    public static void main(String[] argv) {
	Util.printGreeting("I-X Process Panel Sample");
	new Isample().mainStartup(argv);
    }

    /**
     * Command-line argument processing used by all versions of I-Test.
     * Add in any special extra parameter handlign required here.
     * @see ix.icore.IXAgent#processCommandLineArguments()
     */
    protected void processCommandLineArguments() {
        super.processCommandLineArguments();
    }

    /**
     * Completes setup and initialization.
     */
    public void startup() {
	super.startup();
    }

}
