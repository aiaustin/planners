I-X MAP TOOL  (Austin Tate 8-Sep-2003; Clauirton Siebra 01-June-2006)

Based on OpenMap Technology (TM) http://openmap.bbn.com
Sources of the I-X addon adaptor are included with this release as required by the Openmap Open Source licence.

Using the Map Tool (previous version):

1) You need to make sure the Map Tool class (ix.ip2.StateViewMap) and the related default icon resources.map.map-default-icon.gif are on the claspath.  

This is normally done by adding these to the application's classpath
    ..\addon\map\java;..\addon\map\imports\openmap.jar


2) In the files "I-X/apps/[your application]/config/*.props", you need to set the parameters below:

# State Viewer

state-viewer-class=ix.ip2.StateViewMap

# Map tool configuration 
map-properties=resources/map/map.props
map-type-icons=resources/map/type-icons/
map-object-icons=resources/map/object-icons/
map-default-icon=resources/map/map-default-icon.gif

Observations:

* map-properties parameter points out the file that contains the information about the layers of the map. You need to have one if you want to use the map;

* map-type-icons points out the directory where you can put general icons to objects. This parameter is optional;

* map-object-icons points out the directory where you can put specific icons to objects. This parameter is optional;

* map-default-icon points out the icon that will be used if a object doesn�t have another icon to represent it. This parameter is optional;

* Icons can be represented by gif, png or jpg images.

3) Setting the map.props
This file defines the plugins that will support the map layers. A complete explanation about how to configure this file can be found in the OpenMap (TM) web page: http://openmap.bbn.com/doc/user-guide.html

4) The object is associated with an icon following the algorithm below:

IF there is an icon in the directory specified in "map-object-icons" parameter (see above) with the same name of the object (without extension), this icon will be used to.

ELSE IF the object has a type pattern (e.g. Buckingham.type=palace) AND there is an icon in the directory specified in "map-object-icons" parameter with the same name of the type value (in the example, palace), this icon will be used to.

ELSE IF the "map-default-icon" parameter was specified, the related icon will be used to.

ELSE the system will use its default icon (in resources/map/map-default-icon.gif on the classpath).


5) Fixing objects on the map

The special property "geo-fixed=true" can be added for objects to specify that their geographical locations are "fixed". Thus icons that represent such objects cannot be moved on the map (latitude or longitude cannot be edited).


6) The plug-in ix.ip2.map.JpgMapLayer can be used if the application needs to use a jpg figure as a map. In this case the map property file can be configured as the example below: 

map.layers=jpgmaplayer
map.Latitude=17.0f # centre map latitude
map.Longitude=39.0f # centre map longitude
map.Scale=8000000.0f
map.Width=800
map.Height=600

jpgmaplayer.class=com.bbn.openmap.plugin.PlugInLayer
jpgmaplayer.prettyName=Binni Boundaries # name to represent the layer
jpgmaplayer.plugin=ix.ip2.map.JpgMapLayer
jpgmaplayer.jpgPath=resources/map/binni.jpg # path to the jpg file
jpgmaplayer.selfSetting=true # if true, you do not need to set the parameters below
jpgmaplayer.latLeftSuperior=25.0f # top-left latitude
jpgmaplayer.lonLeftSuperior=28.0f # top-left longitude
jpgmaplayer.latRightInferior=10.0f # bottom-right latitude
jpgmaplayer.lonRightInferior=48.0f # bottom-right longitude


======= ADDITIONAL REQUIREMENTS AND INFORMATION  FOR THE NEW VERSION ==========

In brief, the I-X Map Tool can be installed via two options. The first option was explained above and it is still being supported by the tool to keep it compatible with previous applications. 

To use the second option, the following additional parameters must be defined. Note that if this map tool option is defined, the parameter <i>-state-viewer-class=StateViewMap</i> can be omitted in the properties file.

(1) extension-classes=ix.ip2.MapViewExtension, ... - turn available the multiple map tool (required parameter);

(2) object-view-directory=<directory - URL syntax> - specifies the path to the directory where the views are defined (optional parameter);

(3) map-view-directory=<directory - URL syntax> - specifies the path to the directory where the map views properties are defined (optional parameter);

(4) map-view-default-properties=<props-file> - specifies the path to a default map view property file, which is used if a specific map-view-property is not defined to a view. If this parameter is not specified, a default map property will be used (optional parameter).

An important detail is that each view can be associated with a specific layer property file. For example, the first line of a view file could be defined as: <object-view name="City-level">, where "City-level" is the name of the view. So the tool will look for a file (inside the directory specified in map-view-directory called "City-level.props". If this file does not exist, a default property file (specified via the parameter 'map-view-default-properties') is used.

The principal advantage of this new version is that several windows can be open via the "File->New View Windows" and each of these windows can have a different initial state in terms of latitude/longitude or scale for example.

HOW VIEWS ARE SELECTED

Views are selected as detailed in follow:

IF there is a correspondent view property file in the directory specified in 'map-view-directory', such file will be used;

ELSE IF there is a default file specified in 'map-view-default-properties', such file will be used;

ELSE a default inbuilt property file, representing a world map, is used.
