JabberCommunicationStrategy - README.txt
Updated: Thu Sep 02 16:25:52 2004


This directory sub-tree contains the java source and compiled 
classes for JabberCommunicationStrategy. This code implements 
message-passing between the various I-X packages using the Jabber
protocol (specifically using the classes and methods of the
jabberbeans library). 

USE

When a panel is invoked with this strategy, a window appears
in which the user is prompted to supply various login data:
in order to communicate using Jabber, the user will have to log 
on to a Jabber server. This requires either an existing account
with a server, or else the creation (if this is permitted) of a
new account on some server.

The following parameters are relevant to this strategy, and can
be declared in a .props file or at the command line (shown here
with their default settings):

jabber-username=[name of the user on this machine] (the identifier 
used to log into a jabber account)
jabber-password=[no default] (the password for that account)
jabber-server="jabber.org" (the jabber server for which the 
account is held)
jabber-resource="I-X" (the identifier of this panel resource on the 
server)
jabber-port=5222 (the port number to be used for communication with 
the server)
jabber-allow-queuing=false (set to true this allows messages to 
be sent to any other jabber user at any time; when set to false,
it is required that the intended recipient's presence is 
subscribed to and he/she is currently on-line for a message to
be sent)
jabber-autosubscribe=true (incoming subscription messages are
accepted, and a reciprocal request is generated; messages to
unsubscribed contacts cause a subscription request to be generated)
jabber-priority=1 (sets the priority of this jabber client)

The user will be prompted to confirm/modify these values in the
login window.

For more details, see the I-X User Guide.

[2-Sep-2004: add new method to allow 'external' access directly
to the jabber strategy.]
 


COMPILATION

There are two java source files that require compilation in this
directory: 
UserPassword.java (contains the login window code).
JabberCommunicationStrategy.java (contains the core communications
mechanism). 

In order to compile (& run) the latter the following must be added 
to the normal I-X classpath:
jabberbeans.jar
jabbericons.jar

For convenience these .jar files have been located in
<I-X base>\comms\jabber\imports\


