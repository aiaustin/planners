CSS and SSI
Cascading Style Sheet Files and files for Server Side Includes.

For CSS use add this line in <head></head> section
changing the ../ to locate the correct directory.

<link href="../inc/cisa.css" rel="stylesheet" type="text/css">

For SSI
Use .shtml postfix files for this.

.htaccess file need to include

AddType text/html .shtml
AddHandler server-parsed .shtml
Options +IncludesNOEXEC

If .html files a are also to have server side include enabled, must also add

AddHandler server-parsed .html

Colours

CISA Team   is #339999   R: 102  G: 153  B: 153
AIAI Orange is #FF9933   R: 255  G: 153  B:  51
I-X Blue    is #6688BB   R: 102  G: 136  B: 187
