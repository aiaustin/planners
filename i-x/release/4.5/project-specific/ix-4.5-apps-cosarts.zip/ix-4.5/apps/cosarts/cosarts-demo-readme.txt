CoSAR-TS Demonstration - Read me - 2-Apr-2004
Austin Tate, AIAI, University of Edinburgh

http://www.aiai.ed.ac.uk/project/coax/

You can view an 8 minute movie of the demonstration with a voice over at
http://www.aiai.ed.ac.uk/project/cosar-ts/demo/isd/

A Vidio diagram of teh components of the demonstratiion is abvailable at
http://www.aiai.ed.ac.uk/project/cosar-ts/demo/2003-10-16/visio/CoSAR-TS_Demo_Concept.htm

Quick start for CoSAR-TS demonstration on preconfigured CoABS Grid only...  follow steps 1, 3 and 6a only.

------------------------------------

Step 1: Unzip the distribution file and place the 2 resulting directories (comms and I-X) at the top level of the D: drive  on a Windows 2000/XP machine.  If this is done, no configuration is needed, so go to step 3.

Step 2: Otherwise, note that the I-X directory can be placed anywhere, but if the CoABS Grid and KAoS are not the version in the zip file or are not placed in d:\comms\grid and D:\comms\kaos respectively, then several configuration files need to be altered to specify the CoABs Grid and KAoS directory bases:

I-X\comms\grid\scripts\win\grid-setvars.bat
I-X\comms\kaos\scripts\win\kaos-setvars.bat

comms\kaos\scripts\win\set-kaos-vars.bat
  also sets up Java SDK root (e.g. C:\j2sdk1.4.2_01)
comms\kaos\scripts\win\grid\set-kaos-grid-vars.bat

Also files are needed in the Grid/lib/codebase directory for I-X and KAoS.  These are in the directory comms\put-in-grid-lib-codebase

Step 3: Start the CoABS Grid Manager (v 5.0.3) via Grid\runGrid.bat and "Start All".

If the demo is only to use the CoABS Grid skip straight to Step 6.

Step 4: If KAoS is to be run, start up the following scripts from comms\kaos\scripts\win\grid\kgh_dm_directory

1_DirectoryService.bat (wait until the Directory Service is completely running and shows up in Grid Manager)
2_Start_DM1.bat (wait until the Domain Manager DM1 shows up in Grid Manager)
3_startServletRunner.bat (wait until http server end point 8081 says it is running)
4_start_KPAT.bat

In KPAT:
Go to Namespaces/Configuration tab
Click on Load Namespace button.
Click on http://ontology.ihmc.us/CoSAR-TS/Demos/CoSAR-TS-Demo-Ontologies.owl
Load Selected Namespace
Go to Domain View tab and verify there are a number of Coalition and Counytry HQ tabs present.
Click on Binni-Coalition domain
Hit Load button and load the prebuilt policy
    comms\kaos\scripts\win\grid\kgh_dm_directory\policy-restrict-flights-gao-arabello.msg
Commit it to distribute it across relevant domains.
Hit "OK" and KAoS is ready to go.

Step 5: For the full demonstration, a CMU Notification service running via the Jabber XML instant messaging framework should be running.  A suitable notification system can be run via I-X\apps\cosarts\CMU Notifier\runNotifier.bat (this logs onto the server jabber.org  with name CMUNotifier and password jabber).  Only run it while needed for the demo. When the script is terminated the service will stop, so other can run the demo.

Step 6a: CoABS Grid communications only. Scripts to run are:

Startup I-X panels and I-Q query adaptors via the directory
I-X\apps\cosarts\scripts\win

Which scripts you run will depend on whether you wish to run only on the Grid, or also with KAoS, and whether you wish to add in the Jabber instant messaging notifications.  The instructions here are initially just to run with the CoABS Grid.

grid-cosar.bat
grid-ussar.bat
grid-hospitals.bat
grid-resources-soap-simulated.bat

The demonstration will function except that the CMU Notifier cannot be notified via jabber for the final steps of the Search & Rescue process.

Step 6b: Full demonstration with CoABS GRid, KAoS and Jabber communications.  Scripts to run are:

Startup I-X panels and I-Q query adaptors via the directory
I-X\apps\cosarts\scripts\win

1b-kaos-jabber-cosar.bat
2-kaos-ussar.bat
3-jabber-usheli.bat
4-kaos-hospitals.bat
5b-kaos-resources-soap-simulated.bat


---------------------------------------------------------

Script for demonstration

US SAR Officer Panel:
     Test -> Initiate Sea Rescue
     Activity "rescue F15-Pilot sea burns 18.0 40.0" Action select "Escalate to CoSAR"

CoSAR Panel:
     Activity "rescue F15-Pilot sea burns 18.0 40.0" Action select "Expand using sop-sar-mission-simple"
     Activity "select-hospital burns [1:?hospital] [2:?country]" Action select "Expand using sop-select-hospitals-1"
     Bring up CoSAR Tools -> Map Tool to see area of operations. Keep this visible to see hospital data as it appears in next step.
     Activity "lookup-hospitals" Action select "Invoke hospitals" - this calls a web service at BBN in Cambridge, MA, that uses OWL data about elements of national power (SONAT DB from DARPA DAML program) to look up hospitals and their medical capabilities.  After data appears on map (and in CoSAR panel "state" table as well), you can right click on a hospital icon to show medical-capabilities discovered.
     Activity "select (hospital [4:?hospital]) (medical-capability [4:?hospital] [7:?med-capability]) (country [4:?hospital]) = [5:?country]" Action select "Match world state"
     Over same Activity entry right click to select "Bind variables"
     Select burn-care medical facility and say Ghawad El and select Bind. Cancel to get rid of teh bind variables dialogue box.
     Activity "select-sar-resource sea [9:?country="Arabello"] [10:?sar-resource]" Action select "Expand using sop-select-sar-resource"
     Activity "lookup-sar-resources sea "Arabello"" Action select "Invoke resources" - this simulates lookup of OWL-S described services on the CMU Matchmaker.
     Activity "select (sar-resource [10:?sar-resource])" Action select "Match world state"
     Over same Activity entry right click to select "Bind variables"
     Select a suitable SAR resource offered and select Bind. Note if using KAoS and the policy that was loaded earlier in the demonstration KAoS KPAT set up phase, that policies will have ensured only relevant SAR resources are available at this stage.  if not using KAoS all SAR resources will be available including the Gao helicopter which is normally prevented from being used if Arabello is the destination country. Cancel to get rid of the bind variables dialogue box.

If Jabber is available and the CMU Notifier is running, then the 2 notify activities can be done by selecting the "Invoke cmunotifier@jabber.org/Home" action.

If the US Heli panel is running at that stage.. the demo is set up to have messages appear in its messenger window.



