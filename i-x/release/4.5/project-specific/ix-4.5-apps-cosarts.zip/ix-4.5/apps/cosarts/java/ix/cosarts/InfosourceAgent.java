/* Generic wrapper for simple information source I-X agents.
 * Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Wed Oct  1 15:26:35 2003 by Jeff Dalton
 * Copyright: (c) 2003, AIAI, University of Edinburgh
 */

package ix.cosarts;		// for now /\/

import java.util.*;

import ix.iface.util.Reporting;

import ix.icore.*;
import ix.icore.domain.*;
import ix.util.*;
import ix.util.lisp.*;

/**
 * Generic wrapper for simple information source I-X agents.
 */
public abstract class InfosourceAgent {

    public static InfosourceAgent.InfosourceIXAgent theIXAgent = null;

    public InfosourceAgent() {
	super();
	if (theIXAgent == null) {
	    theIXAgent = makeIXAgent();
	}
    }

    public void mainStartup(String[] argv) {
	theIXAgent.mainStartup(argv);
    }

    protected InfosourceAgent.InfosourceIXAgent makeIXAgent() {
	return new InfosourceAgent.InfosourceIXAgent(this);
    }

    /**
     * Command-line argument processing.
     */
    protected void processCommandLineArguments() {
	Debug.noteln("Processing command-line arguments as " +
		     "InfosourceAgent in", this);
    }

    protected static class InfosourceIXAgent extends IXAgent {

	protected InfosourceAgent mainInfoAgent;

	public InfosourceIXAgent(InfosourceAgent mainInfoAgent) {
	    super();
	    this.mainInfoAgent = mainInfoAgent;
	}

	/**
	 * Command-line argument processing.
	 */
	protected void processCommandLineArguments() {
	    super.processCommandLineArguments();
	    Debug.noteln("Processing command-line arguments in", this);
	    mainInfoAgent.processCommandLineArguments();
	}

	protected void startup() {
	    // This is optional.  We could just let the first incoming message
	    // cause the text frame to be created.  But this way we can make it
	    // appear right away and can add an "Exit" button.

	    textFrame = new TextAreaFrame("Messages for " + ipcName,
					  new String[] { "Exit" } );

	    textFrame.addListener(new TextAreaFrame.TListener() {
		public void buttonPressed(String action) {
		    if (action.equals("Exit"))
			System.exit(0);
		}

	    });

	}

	public void do_transcript(String line) {
	    textFrame.appendLine(line);
	    if (!textFrame.getFrame().isShowing())
		textFrame.setVisible(true);
	}

	/**
	 * Handles new activities from external sources.
	 */
	public void handleNewActivity(Activity activity) {
	    handleReceivedReport(activity);
	    do_transcript(Reporting.activityDescription(activity));
	    if (mainInfoAgent.isLookupActivity(activity))
		mainInfoAgent.handleLookupActivity(activity);
	    else
		super.handleNewActivity(activity);
	}

    }

    protected void handleLookupActivity(Activity activity) {
	new LookupThread(activity)
	    .start();
    }

    class LookupThread extends CatchingThread {
	Activity act;
	LookupThread(Activity act) { this.act = act; }
	public void innerRun() {
            makeNewSource().handleLookup(act);
	}
    }

    protected void sleepSeconds(int seconds) {
	if (seconds > 0) {
	    int delay = seconds * 1000;
	    Debug.noteln("Sleeping", delay);
	    try { Thread.sleep(delay); }
	    catch (InterruptedException e) {}
	}
    }

    protected InfosourceAgent makeNewSource() {
	return (InfosourceAgent)Util.makeInstance(this.getClass());
    }

    protected void transcript(final String line) {
	Util.swingAndWait(new Runnable() {
	    public void run() {
		do_transcript(line);
	    }
	});
    }

    protected void do_transcript(String line) {
	theIXAgent.do_transcript(line);
    }

    protected void sendReport(final Activity about,
			      final ReportType type,
			      final String text) {
	sendReport(about, type, text, null);
    }

    protected void sendReport(final Activity about,
			      final ReportType type,
			      final String text,
			      final List constraints) {
	Util.swingAndWait(new Runnable() {
	    public void run() {
		do_sendReport(about, type, text, constraints);
	    }
	});
    }

    protected void do_sendReport(Activity about,
				 ReportType type,
				 String text,
				 List constraints) {
        Name ourName = Name.valueOf(theIXAgent.getAgentIPCName());
        String toName = about.getSenderId().toString();

	Report r = new Report(text);
	r.setReportType(type);
	r.setRef(about.getRef());
	r.setSenderId(ourName);
	r.setConstraints(constraints);
	do_transcript("Sending " + Reporting.reportDescription(r));
	IPC.sendObject(toName, r);
    }

    /* Constraint utilities */

    protected Constraint makeStateConstraint(LList pattern, Object value) {
	return new Constraint
	              ("world-state", "effect",
		       Lisp.list(new PatternAssignment(pattern, value)));
    }

    protected Constraint makeStateConstraint(LList pattern) {
	return new Constraint
	              ("world-state", "effect",
		       Lisp.list(new PatternAssignment(pattern)));
    }

    /* Here's what a subclass must define. */

    /**
     * Determines whether the activity is one that should be handled
     * by {@link #handleLookup(Activity)}.
     */
    protected abstract boolean isLookupActivity(Activity activity);

    /**
     * Looks up information and sends report back to the agent
     * that sent us the activity.  Note that this method is
     * called in a separate thread and is a method of a new
     * instance of the relevant InfosourceAgent subclass.
     * This allows multiple activities to be handled in
     * parallel without interfering with each other.
     */
    protected abstract void handleLookup(Activity activity);

}
