/**
 * Last Modified by: $Author: skulkarni $
 * On: $Date: 2003/04/04 23:22:35 $
 */

package ix.cosarts;

import java.io.*;
import java.util.*;
import java.net.*;

import EDU.cmu.softagents.larks.debug.*;
import EDU.cmu.softagents.DAML.soap.*;
import EDU.cmu.softagents.DAML.soap.MMOptions;

import cosarts.matchmaker.MatchMakerProxy;
import cosarts.util.DAMLDescriptionReader;
import cosarts.enforcer.KAoSSoapEnforcer;
import cosarts.query.QueryMMRescueResources;

public class FallbackQueryMMRescueResources
       extends QueryMMRescueResources
{
    private MatchMakerProxy myMatchMakerProxy = null;
	private KAoSSoapEnforcer _enforcer;
	
    public FallbackQueryMMRescueResources(MatchMakerProxy _matchMakerProxy)
    {
	super(_matchMakerProxy);
	_enforcer = new KAoSSoapEnforcer();
    }

	public Vector getRescueResourceDesc(String areaOfOperation, String destinationCountry)
	{		
	    System.out.println("\n\n getRescueResourceDesc called \n\n");
		
	    Vector    results = new Vector();
	    
	    // Get the description directly from the web			
	    try
		{
		    String    gaoMarineHelicopter_txt   = DAMLDescriptionReader.load_url("http://ontology.coginst.uwf.edu/CoSAR-TS/Demos/GaoMarineHelicopter.daml");
		    results.add(gaoMarineHelicopter_txt);
		    
		    String    usMarineHelicopter_txt   = DAMLDescriptionReader.load_url("http://ontology.coginst.uwf.edu/CoSAR-TS/Demos/USMarineHelicopter.daml");
		    results.add(usMarineHelicopter_txt);
			    
		    String    usArmyHelicopter_txt   = DAMLDescriptionReader.load_url("http://ontology.coginst.uwf.edu/CoSAR-TS/Demos/USArmyHelicopter.daml");
		    results.add(usArmyHelicopter_txt);
			    
		    String    arabelloCoastguardCutter_txt   = DAMLDescriptionReader.load_url("http://ontology.coginst.uwf.edu/CoSAR-TS/Demos/ArabelloCoastguardCutter.daml");
		    results.add(arabelloCoastguardCutter_txt);
		}
	    catch (Exception ex)
		{
		    System.out.println("\n-------------- Error reading descriptions from the web");
		}
			
	    System.out.println("\n-------------- Done");
			
	    Vector ret = _enforcer.enforcePolicy(results, destinationCountry);
	    
	    return ret;
	}
}
