/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 *    and: Stephen Potter <stephenp@inf.ed.ac.uk>
 * Updated: Sat Feb 23 00:41:05 2008 by Jeff Dalton
 * Copyright: (c) 2001, 2003, 2004, 2008, AIAI, University of Edinburgh
 */

package ix.coakting;

import java.util.*;
import java.io.IOException;
import java.io.*;

import ix.icore.*;
import ix.ip2.*;
import ix.util.*;
import ix.util.lisp.*;

import ix.util.xml.XMLSaver;
import ix.icore.plan.Plan;
import ix.icore.plan.build.PlanBuilder;
import ix.icore.plan.build.SimplePlanBuilder;

import com.hp.hpl.jena.db.*;
import com.hp.hpl.jena.ontology.*;
import com.hp.hpl.jena.vocabulary.*;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.util.iterator.*;
import com.hp.hpl.jena.shared.*;

import org.jdom.*;
import org.jdom.input.*;

/**
 * Adds a handler action that publishes an action item as rdf, and generates
 * an OWL description of the event of the creation of this item. 
 */
public class ActionPublisher extends ActivityHandler {

    //private Symbol ACTION_SYMBOL_NAME = Symbol.intern("action");

    protected Ip2 ip2;

    public ActionPublisher(Ip2 ip2) {
	super("Publish this as an action item");
	this.ip2 = ip2;
    }

    public List getSyntaxList() {
	//	return (LList)Lisp.readFromString
	//  ("((action ?action))");
	return (LList)Lisp.readFromString("((?action-item))");
    }

    public boolean appliesTo(AgendaItem item) {
	// Need to think about the pattern that this applies to...
	//LList pattern = item.getPattern();
	//return pattern.get(0) == ACTION_SYMBOL_NAME;
	return true;
    }

    public void addHandlerActions(AgendaItem item) {
	item.addAction
	    (new HandlerAction.AutomaticWhenBound(item, this));
    }

    public void handle(AgendaItem item) {
	// (change-symbol-name ?name)
	//LList pattern = (LList)Variable.removeVars(item.getPattern());
	//Debug.noteln("Publishing="+pattern.toString());

	PlanBuilder builder = new SimplePlanBuilder();
	Activity activity = (Activity)item.getAbout();
	builder.addActivity(activity);
	Plan p = builder.getPlan();
	Debug.noteln("Publishing="+p.toString());

	//publish(p, (String) ((AbstractAnnotatedObject) activity).getAnnotation("comments"));
	//publish(p, ((AbstractAnnotatedObject) activity).getComments());
	publish(p, activity);

	//String name = pattern.get(1).toString();
	//ip2.setAgentSymbolName(name);
	item.setStatus(Status.COMPLETE);
    }


    public void publish(final Object actionitem, final Activity activity){
	final ThreadCondition fileCreationComplete = new ThreadCondition("file-creation-complete");
	int timeout = 10000; // file creation timeout in milliseconds

	fileCreationComplete.setFalse();

	new Thread(){
		public void run(){

		    // Now want to add the supporting information, start and end-points:
		    String SUPPORT_URI = "http://www.aktors.org/ontology/support";
		    String PORTAL_URI = "http://www.aktors.org/ontology/portal";
		    String MEETING_URI = "http://www.ecs.soton.ac.uk/~krp/coakting/rdf/meeting-20030606-2";
		    String EXTENDED_URI = "http://www.aktors.org/ontology/extension";
		    String IX_URI = "http://www.aiai.ed.ac.uk/~jeff/ix/3.x/owl";
		    String COAKTING_URI = "http://i-me.info/coakting";
		    String IXMEETING_URI = "http://i-me.info/resources/coakting/ontology/ix-meeting-support.owl";
		    String COAKTING_PATH = "";
		    String PROPS_FILE = "local-properties/action-publisher.props";

		    // terms from the support ontology:
		    String ACTION_ITEM = "Action-Item";
		    String CREATING_AN_ACTION_ITEM = "Creating-an-Action-Item";
		    String HAS_ACTION_ITEM = "has-action-item";
		    String HAS_IX_REPRESENTATION = "has-IX-representation";
		    String HAS_STRING_CONTENT = "has-string-content";
		    String HAS_STRING_COMMENTS = "has-string-comments";
		    String IN_REGARD_TO = "in-regard-to";
		    String IS_PLACED_ON = "is-placed-on";
		    String HAS_PRIORITY = "has-priority";
		    String HAS_TARGET_DATE = "has-target-date";

		    Hashtable participantsTable = new Hashtable();

		    try{
			// read in local properties:
			SAXBuilder builder = new SAXBuilder(); //SAXDriverClass);
			Document doc = builder.build(PROPS_FILE);
			Element root = doc.getRootElement(); // should be <properties>
			COAKTING_URI = root.getChildText("base-uri");
			COAKTING_PATH = root.getChildText("local-dir")+"/";
			//System.out.println("URI="+COAKTING_URI+" PATH="+COAKTING_PATH);
			Iterator parti = (root.getChildren("participant")).iterator();
			while(parti.hasNext()){
			    Element participant = (Element) parti.next();
			    String pname = participant.getChildText("name");
			    String puri = participant.getChildText("uri");
			    //System.out.println("Found: "+pname+" = "+puri);
			    participantsTable.put(pname,puri);
			}

		    }
		    catch (JDOMException e){
			Debug.displayException
			    ("Error reading local-properties file", e);
		    }
		    catch (IOException e){
			Debug.displayException
			    ("Error reading local-properties file", e);
		    }

		    XMLPublisher saver = new XMLPublisher();

		    Calendar rightNow = Calendar.getInstance();
		    String filenamebase = "action-"+rightNow.getTimeInMillis();

		    // generate action-item as ix-plan RDF:
		    try {
			//String workingdir = System.getProperty("user.dir");
			//System.out.println("wd="+workingdir);

		        File opdir = new File(COAKTING_PATH);
			if(!opdir.isDirectory()){
			    // either doesn't exist or is not a directory...
			    // try to create directory then:
			    if(!opdir.mkdir()){
				// problem creating directory...so decide to dump files 
				// in current working dir:
				COAKTING_PATH="";
			    }
			}
			saver.writeObjectToFile(actionitem, new File(COAKTING_PATH+filenamebase+".rdf"));
		    }
		    catch (IOException e){
			Debug.displayException(e);
		    }



		    try{

			// read in local properties:
//  			SAXBuilder builder = new SAXBuilder(); //SAXDriverClass);
//  			Document doc = builder.build(PROPS_FILE);
//  			Element root = doc.getRootElement(); // should be <properties>
//  			COAKTING_URI = root.getChildText("base-uri");
//  			COAKTING_PATH = root.getChildText("local-dir");
//  			System.out.println("URI="+COAKTING_URI+" PATH="+COAKTING_PATH);

			// now want to read it back and add an extra time element:
			OntModel aimodel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM_TRANS_INF, null);
			OntModel supportmodel = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM_TRANS_INF, null);

			supportmodel.getDocumentManager().addAltEntry(SUPPORT_URI, "file:ontology/support.owl" );
			supportmodel.getDocumentManager().addAltEntry(IXMEETING_URI, "file:ontology/ix-meeting-support.owl" );
			supportmodel.getDocumentManager().addAltEntry(IX_URI, "file:ontology/ix.owl" );

			supportmodel.read(SUPPORT_URI);
			supportmodel.read(PORTAL_URI);
			supportmodel.read(MEETING_URI);
			supportmodel.read(IX_URI);
			supportmodel.read(IXMEETING_URI);

			String targetURI = COAKTING_URI+"/"+filenamebase+".rdf";
			String thisURI = COAKTING_URI+"/"+filenamebase+"-support.rdf";

			// don't know whether the following actually exists...?:
			//OntProperty hasStartTime = supportmodel.getOntProperty(PORTAL_URI+"#has-start-time");
			//OntProperty hasEndTime = supportmodel.getOntProperty(PORTAL_URI+"#has-end-time");
			OntProperty hasStartTime = supportmodel.getOntProperty(SUPPORT_URI+"#begins-at-time-point");
			OntProperty hasEndTime = supportmodel.getOntProperty(SUPPORT_URI+"#ends-at-time-point");

			OntClass TimePoint = supportmodel.getOntClass(SUPPORT_URI+"#Time-Point");
			OntClass TimeInterval = supportmodel.getOntClass(SUPPORT_URI+"#Time-Interval");
			OntProperty hasTimeInterval = supportmodel.getOntProperty(SUPPORT_URI+"#has-time-interval");

			OntProperty yearOf = supportmodel.getOntProperty(SUPPORT_URI+"#year-of");
			OntProperty monthOf = supportmodel.getOntProperty(SUPPORT_URI+"#month-of");
			OntProperty dayOf = supportmodel.getOntProperty(SUPPORT_URI+"#day-of");
			OntProperty hourOf = supportmodel.getOntProperty(SUPPORT_URI+"#hour-of");
			OntProperty minuteOf = supportmodel.getOntProperty(SUPPORT_URI+"#minute-of");
			OntProperty secondOf = supportmodel.getOntProperty(SUPPORT_URI+"#second-of");
			OntProperty millisecondOf = supportmodel.getOntProperty(MEETING_URI+"#millisecond-of");
			OntClass ixplan = supportmodel.getOntClass(IX_URI+"#plan");

			Individual startTime = aimodel.createIndividual(thisURI+"#creation-time",TimePoint);
			Individual thisTimeInterval = aimodel.createIndividual(thisURI+"#assertion-time",TimeInterval);

			startTime.setPropertyValue(yearOf,aimodel.createLiteral(Integer.toString(rightNow.get(Calendar.YEAR)),"en"));
			startTime.setPropertyValue(monthOf,aimodel.createLiteral(Integer.toString(rightNow.get(Calendar.MONTH)),"en"));
			startTime.setPropertyValue(dayOf,aimodel.createLiteral(Integer.toString(rightNow.get(Calendar.DAY_OF_MONTH)),"en"));
			startTime.setPropertyValue(hourOf,aimodel.createLiteral(Integer.toString(rightNow.get(Calendar.HOUR_OF_DAY)),"en"));
			startTime.setPropertyValue(minuteOf,aimodel.createLiteral(Integer.toString(rightNow.get(Calendar.MINUTE)),"en"));
			startTime.setPropertyValue(secondOf,aimodel.createLiteral(Integer.toString(rightNow.get(Calendar.SECOND)),"en"));
			startTime.setPropertyValue(millisecondOf,aimodel.createLiteral(Integer.toString(rightNow.get(Calendar.MILLISECOND)),"en"));

			// this will need to change to refer to the proper class:
			//OntClass InformationTransferEvent = supportmodel.getOntClass(PORTAL_URI+"#Information-Transfer-Event");
			//OntClass ActionItemEvent = aimodel.createClass(thisURI+"#"+CREATING-AN-ACTION-ITEM);
			//OntProperty hasActionItem = aimodel.createObjectProperty(thisURI+"#has-action-item");
			//ActionItemEvent.setSuperClass(InformationTransferEvent);

			OntClass ActionItemEvent = supportmodel.getOntClass(IXMEETING_URI+"#"+CREATING_AN_ACTION_ITEM);
			OntClass ActionItem = supportmodel.getOntClass(IXMEETING_URI+"#"+ACTION_ITEM);
			OntProperty hasActionItem = supportmodel.getOntProperty(IXMEETING_URI+"#"+HAS_ACTION_ITEM);
			OntProperty hasIXRepresentation = supportmodel.getOntProperty(IXMEETING_URI+"#"+HAS_IX_REPRESENTATION);


			//System.out.println("AIE="+ActionItemEvent.toString());

			Individual aievent = aimodel.createIndividual(thisURI+"#action-item-creation-instance", ActionItemEvent);
			// actitem points to the actual action item RDF: it is what this file is about...
			Resource ixactitem = aimodel.createResource(targetURI);	    
			Individual actitem = aimodel.createIndividual(thisURI+"#action-item", ActionItem);	    
			actitem.addProperty(hasIXRepresentation,ixactitem);

			//OntProperty hasStartTime = aimodel.createOntProperty(thisURI+"#has-start-time");
			//OntProperty hasEndTime = aimodel.createOntProperty(thisURI+"#has-end-time");

			//actitem.setPropertyValue(hasStartTime,startTime);
			//actitem.addProperty(hasStartTime,startTime);
			//actitem.addProperty(hasEndTime,startTime);

			// so, in English:
			// - this action item event has a duration thisTimeInterval which is demarked by
			// two time-points, which, in this case, are identical (ie the event has zero extension
			// in time - which may be a problem).
 
			thisTimeInterval.setPropertyValue(hasStartTime, startTime);
			thisTimeInterval.setPropertyValue(hasEndTime, startTime);
			aievent.addProperty(hasTimeInterval, thisTimeInterval);
			aievent.addProperty(hasActionItem, actitem);

			OntProperty hasStringContent = supportmodel.getOntProperty(IXMEETING_URI+"#"+HAS_STRING_CONTENT);
			OntProperty hasStringComments = supportmodel.getOntProperty(IXMEETING_URI+"#"+HAS_STRING_COMMENTS);
			OntProperty hasPriority = supportmodel.getOntProperty(IXMEETING_URI+"#"+HAS_PRIORITY);
			
			actitem.addProperty(hasStringContent, aimodel.createLiteral(activity.getShortDescription(),"en"));
			actitem.addProperty(hasPriority, aimodel.createLiteral((activity.getPriority()).toString(),"en"));

			final String annotation = ((AbstractAnnotatedObject) activity).getComments();

			if((annotation!=null) && !(annotation.equals(""))){
			    actitem.addProperty(hasStringComments, aimodel.createLiteral(annotation, "en"));

			    String onkey="on:";
			    int placedon = annotation.indexOf(onkey);
			    if(placedon!=-1){
				// ie "on:" occurs in the annotation:
				OntProperty isPlacedOn = supportmodel.getOntProperty(IXMEETING_URI+"#"+IS_PLACED_ON);
				// now get following substring, terminated by ";" or end of annotation:
				int term = annotation.indexOf(";",placedon);
				String who="";
				if(term!=-1){
				    who=(annotation.substring(placedon+(onkey.length()),term)).trim();
				}
				else{
				    who=(annotation.substring(placedon+(onkey.length()))).trim();
				}
				String twho = (String) participantsTable.get(who);
				if(twho==null){
				//aievent.addProperty(isPlacedOn, aimodel.createLiteral(who,"en"));
				    actitem.addProperty(isPlacedOn, aimodel.createLiteral(who,"en"));
				}
				else{
				//aievent.addProperty(isPlacedOn, aimodel.createResource(twho));
				    actitem.addProperty(isPlacedOn, aimodel.createResource(twho));

				}
			    }

			    String whenkey = "when:";
			    int dated = annotation.indexOf(whenkey);
			    if(dated!=-1){
				// ie "when:" occurs in the annotation:
				OntProperty hasTargetDate = supportmodel.getOntProperty(IXMEETING_URI+"#"+HAS_TARGET_DATE);
				// now get following substring, terminated by ";" or end of annotation:
				int term = annotation.indexOf(";",dated);
				String when="";
				if(term!=-1){
				    when=(annotation.substring(dated+(whenkey.length()),term)).trim();
				}
				else{
				    when=(annotation.substring(dated+(whenkey.length()))).trim();
				}

				if(when!=""){
				//aievent.addProperty(hasTargetDate, aimodel.createLiteral(when,"en"));
				    actitem.addProperty(hasTargetDate, aimodel.createLiteral(when,"en"));
				}
			    }

			    String aboutkey = "re:";
			    int regards = annotation.indexOf(aboutkey);
			    if(regards!=-1){
				// ie "when:" occurs in the annotation:
				OntProperty inRegardTo = supportmodel.getOntProperty(IXMEETING_URI+"#"+IN_REGARD_TO);
				// now get following substring, terminated by ";" or end of annotation:
				int term = annotation.indexOf(";",regards);
				String reg="";
				//System.out.println("regards="+regards+" term="+term);
				if(term!=-1){
				    reg=(annotation.substring(regards+(aboutkey.length()),term)).trim();
				}
				else{
				    reg=(annotation.substring(regards+(aboutkey.length()))).trim();
				}

				if(reg!=""){
				//aievent.addProperty(inRegardTo, aimodel.createLiteral(reg,"en"));
				    actitem.addProperty(inRegardTo, aimodel.createLiteral(reg,"en"));
				}
			    }
			}


			// may not need the following, eventually?:
			aimodel.createOntology(thisURI);

			// NB: the following doesn't seem to work?:
			aimodel.setNsPrefix("support",SUPPORT_URI);
			aimodel.setNsPrefix("portal",PORTAL_URI);
			aimodel.setNsPrefix("meeting",MEETING_URI);
			aimodel.setNsPrefix("ix",IX_URI);

			aimodel.write(new FileWriter(COAKTING_PATH+filenamebase+"-support.rdf"));
			Debug.noteln("created file: "+COAKTING_PATH+filenamebase+"-support.rdf");
		    }
		    catch (Exception e){
			Debug.noteln(e.toString());
			e.printStackTrace();
		    }

		    fileCreationComplete.setTrue();

		}}.start();


	// note, this doesn't actually kill the thread or anything...
	fileCreationComplete.waitUntilTrue(timeout);
	if(fileCreationComplete.isTrue()){
	    Debug.noteln("File creation completed successfully."); 
	}
	else{
	    Debug.noteln("File creation problem (no internet response?)."); 
	}

    }   

    public class XMLPublisher extends XMLSaver {
	public XMLPublisher(){
	    super(null);
	}
	public void writeObjectToFile(Object obj, File file) 
	    throws IOException {
	    super.writeObjectToFile(obj,file);
	}
	
    }



}
