CoSAR-TS DAML-S use of CMU Matchmaker
16-Oct-2003 Andrzej Uszok, IHMC

Currently we want to register these four offerings:

http://ontology.coginst.uwf.edu/CoSAR-TS/Demos/ArabelloCoastguardCutter.daml
http://ontology.coginst.uwf.edu/CoSAR-TS/Demos/GaoMarineHelicopter.daml
http://ontology.coginst.uwf.edu/CoSAR-TS/Demos/USArmyHelicopter.daml
http://ontology.coginst.uwf.edu/CoSAR-TS/Demos/USMarineHelicopter.daml


This is our current request:

http://ontology.coginst.uwf.edu/CoSAR-TS/Demos/SeaRescue.daml

