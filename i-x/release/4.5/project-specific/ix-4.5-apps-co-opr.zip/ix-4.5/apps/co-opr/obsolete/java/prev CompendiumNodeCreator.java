/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 *    and: Stephen Potter <stephenp@inf.ed.ac.uk>
 * Updated: Thu Sep 02 17:44:54 2004
 * Copyright: (c) 2001, 2003, 2004, AIAI, University of Edinburgh
 */

package ix.coakting;

import java.util.*;
import java.io.IOException;
import java.io.*;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

import ix.icore.*;
import ix.ip2.*;
import ix.util.*;
import ix.util.lisp.*;
import ix.util.ipc.*;
import ix.jabber.*;


import org.jdom.*;
import org.jdom.input.*;

/**
 * Adds a handler action that translates an Agenda Item into a
 * Compendium node by first prompting the user for the type of
 * node to create, and then generating & sending the appropriate 
 * Jabber message to a Compendium jabber client (whose address
 * is specified in the props file). 
 */
public class CompendiumNodeCreator extends ItemHandler {

    private String PROPS_FILE="local-properties/compendium-node-creator.props";

    private String question = "Question";
    private String answer = "Answer";
    private String note = "Note";
    private String argument = "Argument";
    private String decision = "Decision";

    private String iconfile = "images/ix2compendium.gif";

    //private Symbol ACTION_SYMBOL_NAME = Symbol.intern("action");

    protected Ip2 ip2;

    //   private String command = "Send to Compendium as a node";


    public CompendiumNodeCreator(Ip2 ip2) {
	super("Send to Compendium as a node");
	//IPC.setCommunicationStrategy("jabber");
	this.ip2 = ip2;
    }

    public List getSyntaxList(){
	return (LList)Lisp.readFromString("((?Compendium-node-to-be))");
    }

    public boolean appliesTo(AgendaItem item) {
	// Need to think about the pattern that this applies to...
	//LList pattern = item.getPattern();
	//return pattern.get(0) == ACTION_SYMBOL_NAME;
	return true;
    }

    public void addHandlerActions(AgendaItem item) {
	item.addAction
	    (new HandlerAction.AutomaticWhenBound(item, this));
    }

    public void handle(AgendaItem item) {
	// (change-symbol-name ?name)
	//LList pattern = (LList)Variable.removeVars(item.getPattern());
	//Debug.noteln("Publishing="+pattern.toString());

	//PlanBuilder builder = new SimplePlanBuilder();
	//Activity activity = (Activity)item.getAbout();
	//builder.addActivity(activity);
	//Plan p = builder.getPlan();
	//Debug.noteln("Publishing="+p.toString());

	//publish(p, (String) ((AbstractAnnotatedObject) activity).getAnnotation("comments"));
	//publish(p, ((AbstractAnnotatedObject) activity).getComments());
	//publish(p, activity);

	//String name = pattern.get(1).toString();
	//ip2.setAgentSymbolName(name);


	
	Object[] possibilities = {question,answer,decision,argument,note};
	String typest = (String)JOptionPane.showInputDialog(
                    null,
                    "Select Compendium node type:\n",
                    "Node Type Selection",
                    JOptionPane.PLAIN_MESSAGE,
                    new ImageIcon(iconfile),
                    possibilities,
                    question);

	// get contents of this agenda item:

	if(typest!=null && !(typest.equals(""))){
	    String msg =  (item.getAbout()).getShortDescription();
	    if(typest.equals(question))
		msg = "[?]"+msg;
	    else if(typest.equals(answer))
		msg = "[!]"+msg;
	    else if(typest.equals(note))
		msg = "[N]"+msg;
	    else if(typest.equals(decision))
		msg = "[D]"+msg;
	    else if(typest.equals(argument))
		msg = "[U]"+msg;

	    if(sendToCompendium(msg))
		item.setStatus(Status.COMPLETE);
	}

    }

    public boolean sendToCompendium(String msg){
	String compendiumName;
	String compendiumServer;
	String compendiumResource;

	//String PROPS_FILE="local-properties/compendium.props";

	try{
	    // read in local properties:
	    SAXBuilder builder = new SAXBuilder(); //SAXDriverClass);
	    Document doc = builder.build(PROPS_FILE);
	    Element root = doc.getRootElement(); // should be <properties>

	    compendiumName = root.getChildText("compendium-name");
	    compendiumServer = root.getChildText("compendium-server");
	    compendiumResource = root.getChildText("compendium-resource");


	    // Note here that the simple text contents of the agenda item are
	    // passed on to Compendium (and using a JabberCommunicationStrategy-
	    // specific method): there is no recording of the recipient, no 
	    // report-back stipulated, etc, all of which one might want to 
	    // implement in a fully integrated environment...

	    JabberCommunicationStrategy.getTheStrategy().sendPlainObject(compendiumName+"@"+compendiumServer+"/"+compendiumResource, msg);



	}
	catch (Exception e){
	    Debug.displayException("Handler error", e);
	    return false;
	}
	return true;
    }

    //  public void forwardTo(String msg, Object destination, boolean reportBack) {
    //Name ipcName = Name.valueOf(IXAgent.getAgent().getAgentIPCName());
    //ensureId();
	//try {
	    //String copy = (TaskItem)clone();
	    // /\/: Make sure we don't include a short id in what
	    // we send.
	    //if (!Gensym.usingUniquePrefix())
	    //copy.id = null;
	    // /\/: Remove Variables unless we get a better idea.
	    //copy.setPattern((LList)Variable.removeVars(this.getPattern()));
	    //copy.setSenderId(ipcName);
	    //copy.setReportBack(YesNo.valueOf(reportBack));
	    //copy.setRef(this.id);
    //    IPC.sendObject(destination, msg);
	    //if (Gensym.usingUniquePrefix()) {
		// Remember where forwarded-to.  N.B. This annotation
		// is not in the copy.
	    //this.setForwardedTo(Name.valueOf(destination));
	    //}
	    //}
	    //catch (CloneNotSupportedException e) {
	    //throw new Error("Can't clone " + this);
	    //}
    //}

}
