//-----------------------------------------------------------------------------
// Copyright (C) 2002 by BBNT Solutions, LLC
// All Rights Reserved.
//-----------------------------------------------------------------------------

package com.bbn.abs.util;

import java.util.ArrayList;
import java.util.StringTokenizer;


public class StringHelper {

  //-------------------------------------------------------------------------
  /** Return an ArrayList containing the individual elements of list, which
   * are delimited by whitespace. */
  
  public static ArrayList parsePropertyListValue (String list)
  {
    StringTokenizer tokenizer = new StringTokenizer(list);
    ArrayList elements = new ArrayList();
    
    while (tokenizer.hasMoreTokens())
      elements.add(tokenizer.nextToken().trim());
    
    return elements;
    
  }//parsePropertyListValue

} //StringHelper

