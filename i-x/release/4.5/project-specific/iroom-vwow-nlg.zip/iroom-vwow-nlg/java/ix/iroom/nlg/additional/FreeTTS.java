package ix.iroom.nlg;

import java.util.Locale;

import javax.speech.Central;
import javax.speech.synthesis.Synthesizer;
import javax.speech.synthesis.SynthesizerModeDesc;
import javax.speech.synthesis.Voice;
import javax.sound.sampled.AudioFileFormat.Type;
import com.sun.speech.freetts.audio.SingleFileAudioPlayer;

public class FreeTTS {

	private String voiceName;
	private Synthesizer synthesiser;

	public FreeTTS(boolean outputToFile){
		voiceName = "kevin16";
		com.sun.speech.freetts.Voice freettsVoice = null;

		try {
			SynthesizerModeDesc desc = new SynthesizerModeDesc(
					null,          // engine name
					"general",     // mode name
					Locale.US,     // locale
					null,          // running
					null);         // voice
			synthesiser = Central.createSynthesizer(desc);

			if (synthesiser == null) {
				System.err.println("Error: No synthesizer created.");
				System.exit(1);
			}

			/* Get the synthesizer ready to speak
			 */
			synthesiser.allocate();
			synthesiser.resume();

			/* Choose the voice.
			 */
			desc = (SynthesizerModeDesc) synthesiser.getEngineModeDesc();
			Voice[] voices = desc.getVoices();
			Voice voice = null;
			for (int i = 0; i < voices.length; i++) {
				if (voices[i].getName().equals(voiceName)) {
					voice = voices[i];
					break;
				}
			}
			if (voice == null) {
				System.err.println(
						"Synthesizer does not have a voice named "
						+ voiceName + ".");
				System.exit(1);
			}
			
			if (outputToFile){
				//Create the audio file output
				SingleFileAudioPlayer audio = new SingleFileAudioPlayer("speech",Type.WAVE);

				/* Non-JSAPI modification of voice audio player
				 */
				if (voice instanceof com.sun.speech.freetts.jsapi.FreeTTSVoice) {
					freettsVoice = ((com.sun.speech.freetts.jsapi.FreeTTSVoice) voice).getVoice();
					freettsVoice.setAudioPlayer(audio);
				}
			}
			synthesiser.getSynthesizerProperties().setVoice(voice);


		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

	public void sayText(String text){
		try{
			synthesiser.speakPlainText(text, null);
			synthesiser.waitEngineState(Synthesizer.QUEUE_EMPTY);
		}
		catch (Exception e) {
			e.printStackTrace();
		}	
	}

	public void closeSynthesiser(){
		try{
			synthesiser.deallocate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

	public static void main(String[] args) {
		FreeTTS SS = new FreeTTS(false);
		SS.sayText("Hi, my name is Christos. It was about time FreeTTS started to talk like me.\n" +
		"I'm having a great time talking to you.");
		SS.closeSynthesiser();
	}
}

