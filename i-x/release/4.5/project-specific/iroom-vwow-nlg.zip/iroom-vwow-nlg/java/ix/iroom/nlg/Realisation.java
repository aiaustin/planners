package ix.iroom.nlg;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Realisation {

	private String surfaceText="";
	private ArrayList<String> sentences = new ArrayList<String>();
	private String whisky, region, history;
	boolean refExp = true;
	boolean isIndefinite=false;
	boolean noviceMode;
	List<Message> messageList;
	static String[] vowelarray = new String[]{"a", "e", "i", "o", "u"};
    static Set<String> vowels = new HashSet<String>();
    static {for(int i=0;i<vowelarray.length;i++) vowels.add(vowelarray[i]);};

	public Realisation(List<Message> messages, List<int[]> sentStructure, String w, String r, String h){
		whisky=w;
		history=h;
		region=r;
		messageList=messages;
		//Flag novice mode
		noviceMode=messageList.get(0).forNovice();

		for (int sentCnt=0; sentCnt<sentStructure.size(); sentCnt++){
			//Choose whether to have a referring expression
			//The first sentence must always have a reffering expression
			if (refExp && sentCnt!=0) {
				double threshold = ((double)sentCnt/10)+0.1;
				double rand = Math.random();
				if (rand<threshold) refExp = false;
			}
			sentences.add(createSurfaceForm(sentStructure.get(sentCnt)));
		}
	}

	public String getSurfaceText(){
		Iterator<String> it = sentences.iterator();
		String tmpStr = "";
		String postStr = "";
		while (it.hasNext()){
			tmpStr = it.next();
			//Do some post-processing: Capitalise, insert periods ".", fix number agreement
			postStr = postProcess(tmpStr);
			surfaceText+=postStr;
			if(it.hasNext()) surfaceText += "\n";
		}
		return surfaceText;
	}
	
	public String postProcess(String sentence){
		String postStr="";
		//Capitalise the first character
		postStr=sentence.substring(0, 1).toUpperCase()+sentence.substring(1);
		//Append the period at the end of each sentence
		postStr+=".";
		//Fix number agreement (a amber -> an amber)
		int aIndex=postStr.indexOf(" a ");
		int charIndex=aIndex+3;
		String tmp = postStr.substring(charIndex,charIndex+1);
		if (vowels.contains(tmp)){
			postStr = replace(postStr," a "," an ");
		}
		return postStr;
	}

	public String createSurfaceForm(int[] structure){
		String surfaceForm="";
		Message curMsg;
		String curStr="";
		String curStr2="";
		boolean followsRefExp=false;
		boolean compare=false;
		Grep g;
		boolean oneMsg=structure.length==1;

		//NOVICE MODE
		if (noviceMode){
			//For the first sentence get the first two messages
			if (!oneMsg){
				curMsg=messageList.get(structure[0]);
				g = new Grep("resources/LexExp/"+curMsg.getName()+curMsg.getSpecial()+".dat");
				//See if there is a comparison
				if (curMsg.getCompValues()!=null) compare=true;
				ArrayList<String> allPS = g.grep(compare+","+refExp+","+followsRefExp+",");
				//Select a random surface
				curStr=randSelect(allPS);
				//If the refExp is used at the end raise the followsRefExp flag
				if (refExp && curStr.endsWith("{refExp}")) followsRefExp=true;
				//Substitute the templates
				//If there is a comparison use the generateCompareValues function
				if (compare) curStr = replace(curStr,"{compareVal}",generateCompareValues(curMsg.getValues(),curMsg.getCompValues()));
				curStr = replace(curStr,"{values}",generateValues(curMsg));
				//If there is a refExp replace it and swith to indefinite expressions
				if (refExp) {
					curStr = replace(curStr,"{refExp}",generateRefExp(isIndefinite));
					isIndefinite=true;
				}
				//For the second message in the sentence
				curMsg=messageList.get(structure[1]);
				g = new Grep("resources/LexExp/"+curMsg.getName()+curMsg.getSpecial()+".dat");
				//See if there is a comparison
				if (curMsg.getCompValues()!=null) compare=true;
				//The second sentence cannot contain a referring expression
				allPS = g.grep(compare+","+false+","+followsRefExp+",");
				//Select a random surface
				curStr2=randSelect(allPS);
				//Substitute the templates
				//If there is a comparison use the generateCompareValues function
				if (compare) curStr2 = replace(curStr2,"{compareVal}",generateCompareValues(curMsg.getValues(),curMsg.getCompValues()));
				curStr2 = replace(curStr2,"{values}",generateValues(curMsg));
				//Aggregate the two sentences:
				//If there is a refExp border use a comma
				if (followsRefExp) surfaceForm=curStr+curStr2;
				//Else use "and" (for now)
				else surfaceForm=curStr+" and "+curStr2;
			}
			else{
				//Only one message in the sentence
				curMsg=messageList.get(structure[0]);
				//Get the novice file
				g = new Grep("resources/LexExp/novice.dat");
				//No comparisons allowed
				//Get the attribute that we are interested in
				String att = curMsg.getName();
				ArrayList<String> allPS = g.grep(att+",");
				//Select a random surface
				curStr=randSelect(allPS);
				//Substitute the templates & refExps
				curStr = replace(curStr,"{values}",generateValues(curMsg));
				if (refExp) {
					curStr = replace(curStr,"{refExp}",generateRefExp(isIndefinite));
					isIndefinite=true;
				}
				//Return the string
				surfaceForm=curStr;
			}
		}
		//EXPERT MODE
		else {
			//For the first message in the sentence
			curMsg=messageList.get(structure[0]);
			g = new Grep("resources/LexExp/"+curMsg.getName()+curMsg.getSpecial()+".dat");
			//See if there is a comparison
			if (curMsg.getCompValues()!=null) compare=true;
			ArrayList<String> allPS = g.grep(compare+","+refExp+","+followsRefExp+",");
			//Select a random surface
			curStr=randSelect(allPS);
			//If there is only one message don't choose a refExp suffix
			if (oneMsg){
				while (curStr.endsWith("{refExp}")){
					curStr=randSelect(allPS);
				}
			}
			//If the refExp is used at the end raise the followsRefExp flag
			if (refExp && curStr.endsWith("{refExp}")) followsRefExp=true;
			//Substitute the templates
			//If there is a comparison use the generateCompareValues function
			if (compare) curStr = replace(curStr,"{compareVal}",generateCompareValues(curMsg.getValues(),curMsg.getCompValues()));
			//Else use generateValues & fancy descriptions
			else {
				if (curStr.endsWith("{values}")){
					curStr = replace(curStr,"{values}",generateFancyDesc(curMsg));
				}
				else {
					curStr = replace(curStr,"{values}",generateValues(curMsg));
				}
			}
			//If there is a refExp replace it and swith to indefinite expressions
			if (refExp) {
				curStr = replace(curStr,"{refExp}",generateRefExp(isIndefinite));
				isIndefinite=true;
			}
			//If there is a second message
			if (!oneMsg){
				//Reset compare value
				compare=false;
				//For the second message in the sentence
				curMsg=messageList.get(structure[1]);
				g = new Grep("resources/LexExp/"+curMsg.getName()+curMsg.getSpecial()+".dat");
				//See if there is a comparison
				if (curMsg.getCompValues()!=null) compare=true;
				//The second sentence cannot contain a referring expression
				allPS = g.grep(compare+","+false+","+followsRefExp+",");
				//Select a random surface
				curStr2=randSelect(allPS);
				//Substitute the templates
				//If there is a comparison use the generateCompareValues function
				if (compare) curStr2 = replace(curStr2,"{compareVal}",generateCompareValues(curMsg.getValues(),curMsg.getCompValues()));
				//Else use generateValues & fancy descriptions
				else {
					//Allow fancy descriptions only if the "{values}" is at the end
					if (curStr2.endsWith("{values}")){
						curStr2 = replace(curStr2,"{values}",generateFancyDesc(curMsg));
					}
					else {
						curStr2 = replace(curStr2,"{values}",generateValues(curMsg));
					}
				}
				//Aggregate the two sentences:
				//If there is a refExp border use a comma
				if (followsRefExp) surfaceForm=curStr+curStr2;
				//Else use "and" (for now)
				else surfaceForm=curStr+" and "+curStr2;

			}
			else surfaceForm=curStr;
		}

		return surfaceForm;
	}
	
	public String generateFancyDesc(Message msg){
		ArrayList<String> values = msg.getValues();
		String fancyDesc="";
		ArrayList<String> allPS=new ArrayList<String>();
		Grep g = new Grep("resources/LexExp/fancy.dat");
		//Search for all the possible permutations of the values
		fancyDesc=searchAllPermutations(msg.getValues(), g);
		//If you don't find anything search for individual values
		if (fancyDesc=="") {
			for (int i=0; i<values.size();i++){
				//Search for lines that contain only this value
				String temp = "1,"+values.get(i);
				allPS=g.grep(temp);
				//If you find some lines
				if (!allPS.isEmpty()){
					//Pick a random line
					fancyDesc=randSelect(allPS);
					//Remove the value from the list
					values.remove(i);
					//Substitute the remaining values
					fancyDesc=replace(fancyDesc,"{restValues}",generateValues(msg));
					//Break the loop
					break;
				}
				//Else simply keep searching
			}
			//If there were no matches substitute normally the values
			if (allPS.isEmpty()) {
				fancyDesc=generateValues(msg);
			}
		}
		return fancyDesc;
	}
	
	public String searchAllPermutations(ArrayList<String> values, Grep g){
		String str="";
		ArrayList<String> allPS=new ArrayList<String>();
		//Search for the first value in the file and create a list with all the line that contain it
		allPS=g.grepFull(values.get(0));
		//If there are some lines search the list for all the other values (if any)
		if (!allPS.isEmpty()){
			//For all the values
			for (int valCnt=0;valCnt<values.size();valCnt++){
				//For all the lines
				for (int lineCnt=0; lineCnt<allPS.size();lineCnt++){
					//If the value is not in the line remove the line
					if (!allPS.get(lineCnt).contains(values.get(valCnt))){
						allPS.remove(lineCnt);
						lineCnt--;
					}
				}
			}
			//If the list is not empty (there were complete matches)
			if (!allPS.isEmpty()){
				//Pick one of the lines
				String temp = randSelect(allPS);
				//Get only the part between the ""
				//...to do: investigate strange behaviour
				str = temp.substring(temp.indexOf('"')+1, temp.length()-3);
			}
		}
		return str;
	}

	public String randSelect(ArrayList<String> ps){
		String str;
		if (ps.size()>1){
			int choices = ps.size()-1;
			int rand = (int)Math.round(Math.random()*choices);
			str = ps.get(rand);
		}
		else str = ps.get(0);
		return str;
	}

	public String generateCompareValues(ArrayList<String> valueList, ArrayList<String> compareValues){
		ArrayList<String> cmpVals = new ArrayList<String>();
		String compare="";
		String compareTxt=" like the "+history+", but also ";
		//Find the matching values, add it to the comparison list and remove them from the main list
		for (int cnt=0; cnt<valueList.size(); cnt++){
			if (compareValues.contains(valueList.get(cnt))){
				cmpVals.add(valueList.get(cnt));
				valueList.remove(cnt);
				cnt--;
			}
		}
		//Do the actual comparison
		int size = valueList.size();
		int cmpSize = cmpVals.size();
		for (int cnt=0; cnt<cmpSize; cnt++){
			compare+=cmpVals.get(cnt);
			//If the next element is the last
			if (cmpSize!=1) {
				if (cnt+2==cmpSize) compare+=" and ";
				else if (cnt+1!=cmpSize) compare+=", ";
			}
		}
		compare+=compareTxt;
		size = valueList.size();
		for (int cnt=0; cnt<size; cnt++){
			compare+=valueList.get(cnt);
			//If the next element is the last
			if (cnt+2==size) compare+=" and ";
			else if (cnt+1!=size) compare+=", ";
		}
		return compare;
	}

	public String generateValues(Message msg){
		ArrayList<String> valueList=msg.getValues();
		String values="";
		//Get only the name (and perhaps status) from the distillery message
		if (msg.getName().equalsIgnoreCase("distillery")){
			if (valueList.contains("closed")){
				values="the closed"+valueList.get(0);
			}
			else {
				values=valueList.get(0);
			}
		}
		else {
			boolean hasContrast=false;
			//Seatch for contrast words
			if (valueList.contains("sweet") && valueList.contains("dry")){
				values+=generateContrast("sweet","dry");
				valueList.remove("sweet");
				valueList.remove("dry");
				hasContrast=true;
			}
			else if (valueList.contains("sweet") && valueList.contains("bitter")){
				values+=generateContrast("sweet","bitter");
				valueList.remove("sweet");
				valueList.remove("bitter");
				hasContrast=true;
			}
			else if (valueList.contains("creamy") && valueList.contains("dry")){
				values+=generateContrast("creamy","dry");
				valueList.remove("creamy");
				valueList.remove("dry");
				hasContrast=true;
			}
			else if (valueList.contains("sweet") && valueList.contains("smoky")){
				values+=generateContrast("sweet","smoky");
				valueList.remove("sweet");
				valueList.remove("smoky");
				hasContrast=true;
			}
			int size = valueList.size();
			if (size>0 && hasContrast) values+=", ";
			for (int cnt=0; cnt<size; cnt++){
				values+=valueList.get(cnt);
				//If the next element is the last
				if (cnt+2==size) values+=" and ";
				else if (cnt+1!=size) values+=", ";
			}
		}
		return values;
	}

	public String generateContrast(String val1, String val2){
		String contrast="";
		contrast+=val1+" but "+val2;
		return contrast;
	}

	public String generateRefExp(boolean indefinite){
		String expr="";
		Grep g = new Grep("resources/LexExp/malt.dat");
		ArrayList<String> allPS = g.grep(indefinite+",");
		int choices = allPS.size()-1;
		int rand = (int)Math.round(Math.random()*choices);
		expr = allPS.get(rand);
		//If there is a refference to the region
		if (expr.indexOf("{region}")>=0) expr=replace(expr,"{region}",extractRegion(region)); 
		//If there is a refference to the name
		else if (expr.indexOf("{name}")>=0) expr=replace(expr,"{name}",whisky);
		return expr;
	}

	public String extractRegion(String input){
		String region="";
		if (input.equalsIgnoreCase("the Eastern Highlands")) region="Eastern Highland";
		else if (input.equalsIgnoreCase("the Central Highlands")) region="Central Highland";
		else if (input.equalsIgnoreCase("the Western Highlands")) region="Western Highland";
		else if (input.equalsIgnoreCase("the Southern Highlands")) region="Southern Highland";
		else if (input.equalsIgnoreCase("the Northen Highlands")) region="Northen Highland";
		else if (input.equalsIgnoreCase("the Speyside area")) region="Speyside";
		else if (input.equalsIgnoreCase("the Islands")) region="Island";
		else if (input.equalsIgnoreCase("the Lowlands")) region="Lowland";
		else if (input.equalsIgnoreCase("the island of Islay")) region="Islay";
		else if (input.equalsIgnoreCase("the Campbeltown area")) region="Campbeltown";
		return region;
	}

	public String replace(String mainStr, String pattern, String replacement){
		String str = "";
		if (mainStr.indexOf(pattern)>=0){
			str=mainStr.substring(0,mainStr.indexOf(pattern));
			if (replacement.equalsIgnoreCase("-1"))
				str+=mainStr.substring(mainStr.indexOf(pattern)+pattern.length()+1);
			else
				str+=replacement+mainStr.substring(mainStr.indexOf(pattern)+pattern.length());
		}
		else str=mainStr;
		return str;
	}
}
