package ix.iroom.nlg;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;

public class DialogueGenerator {

	private WhiskyOntologyLookup WOL;
	private DocumentPlan DP;
	private Realisation RL;
	private String whisky, goal, user, history;
	private String outputText;

	public DialogueGenerator(){
		whisky = goal = user = history = null;
	}

	public static void main (String[] args){
		DialogueGenerator DG = new DialogueGenerator();
		String text = DG.generateText("Laphroaig", "instruct", "expert");
		String text2 = DG.generateText("Millburn", "instruct", "expert");
//		String text = DG.generateText("Glenlivet", "instruct", "expert");
		String text3 = DG.generateText("Fettercairn", "instruct", "expert");
		System.out.println(text);
		System.out.println(text2);
		System.out.println(text3);
		//Synthesise text -- the boolean is true for file output and false for live audio
		// need to uncomment lines here to have this run.
		//	FreeTTS SS = new FreeTTS(false);
		//	MaryTTS SS = new MaryTTS(true);
		//      SS.sayText(text);
		//      SS.sayText(text2);
		//	SS.closeSynthesiser();
	}

	public String generateText(String w, String g, String u){
		//Create a temp history file
		File histFile = new File("history");
		FileOutputStream fos;
		FileReader fr;
		PrintStream ps;
		BufferedReader br;
		String line;
		try {
			if (histFile.exists()){
				fr = new FileReader(histFile);
				br = new BufferedReader(fr);
				line = br.readLine();
				history=line;
				fos = new FileOutputStream(histFile);
				ps = new PrintStream(fos);
				ps.print(w);
			}
			else {
				fos = new FileOutputStream(histFile);
				ps = new PrintStream(fos);
				ps.print(w);
			}
		}catch (Exception e){}
		whisky=w;
		goal=g;
		user=u;
		WOL = new WhiskyOntologyLookup();

		//Create the document plan
		DP = new DocumentPlan(WOL, whisky, goal, user, history);

		//Create the surface realisation
		RL = new Realisation(DP.getMessageList(),DP.getDocStructure(), 
				whisky, WOL.getRegion(whisky), history);
		outputText = RL.getSurfaceText();
		return outputText;
	}
}
