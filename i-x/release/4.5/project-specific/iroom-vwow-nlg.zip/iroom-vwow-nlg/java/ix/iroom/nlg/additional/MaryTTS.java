package ix.iroom.nlg;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;

import de.dfki.lt.mary.client.MaryClient;
import de.dfki.lt.signalproc.util.AudioPlayer;

public class MaryTTS {
	private MaryClient mary;
	private String inputType;
	private String outputType;
	private String audioType;
	private String voiceName;
	private ByteArrayOutputStream baos;
	private boolean outToFile;
	private AudioInputStream ais;
	private LineListener lineListener;
	private AudioPlayer ap;

	public MaryTTS(boolean outToFile) {
		String serverHost = System.getProperty("server.host", "localhost");
		int serverPort = Integer.getInteger("server.port", 59125).intValue();
		try {
		    //mary = new MaryClient(serverHost, serverPort);
		    mary = new MaryClient();
		}
		catch (IOException e){}
		inputType = "TEXT_EN";
		outputType = "AUDIO";
		audioType = "WAVE";
		//Other voices: bdl-arctic, hmm-slt, hmm-jmk, hmm-bdl
		voiceName = "bdl-arctic";
		baos = new ByteArrayOutputStream();
		this.outToFile=outToFile;

		lineListener = new LineListener() {
			public void update(LineEvent event) {
//				if (event.getType() == LineEvent.Type.START) {
//				System.err.println("Audio started playing.");
//				} else if (event.getType() == LineEvent.Type.STOP) {
//				System.err.println("Audio stopped playing.");
//				} else if (event.getType() == LineEvent.Type.OPEN) {
//				System.err.println("Audio line opened.");
//				} else if (event.getType() == LineEvent.Type.CLOSE) {
//				System.err.println("Audio line closed.");
//				}
			}
		};
	}

	public void sayText(String text) {
		try {
			mary.process(text, inputType, outputType, audioType, voiceName, baos);
			if (outToFile){
				FileOutputStream fos= new FileOutputStream("speech.wav");
				fos.write(baos.toByteArray());
			}
			else {
				try {
					ais = AudioSystem.getAudioInputStream(
							new ByteArrayInputStream(baos.toByteArray()));
				}
				catch (Exception e){e.printStackTrace();}
				ap = new AudioPlayer(ais, lineListener);
				ap.start();
			}
		}
		catch (Exception e){e.printStackTrace();}
	}

	public static void main(String[] args){
		MaryTTS mar = new MaryTTS(false);
		mar.sayText("Welcome to the world of Speech Synthesis");
	}
}
