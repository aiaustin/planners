Stephen Potter (stephenp@inf.ed.ac.uk)
updated: Sat Mar 04 00:47:00 2006

This app directory contains a basic I-X agent which also runs as an URBI 
client, allowing access to an AIBO robot (or to a Webots simulation of
an AIBO).

Compatible with URBI-0.9.8 MS-ERS7 AIBO controller.

The agent recognises the following I-X activities, turning them into
AIBO commands (N is some positive or negative integer):

Activity	Command
--------	-------
walk Ns		robot.walk(Ns);
stopwalk	robot.stopwalk();
turn Ns		robot.turn(Ns);
stopturn	robot.stopturn();
sit		robot.sit();
beg		robot.beg();
stand		robot.stand();
initiate	robot.initial();
lie		robot.lay();
stretch		robot.stretch();

In addition, 
   urbi-execute "C" 
where C is some valid command will send C as a command to the AIBO. eg:
   urbi-execute "robot.walk(-3s);"
(note: don't forget trailing semi-colon inside the terminating quotes!)		