package ix.rcragents.handlers;

import java.util.Iterator;
import java.util.Hashtable;
import java.util.Vector;
import java.util.List;

import ix.ip2.*;
import ix.ispace.ContactManager;
import ix.ispace.AgentRelationship;
import ix.ispace.AgentData;
import ix.icore.domain.Constraint;
import ix.icore.domain.NodeSpec;
import ix.icore.domain.Refinement;
import ix.icore.domain.PatternAssignment;
import ix.icore.Report;
import ix.icore.Status;
import ix.util.Name;
import ix.util.lisp.*;
import ix.util.Gensym;

//import yab.agent.DisasterSpace;
//import yab.agent.Router;
import yab.agent.*;
import yab.agent.object.*;
import ix.rcragents.PoliceOffice;

public class SimpleAllocatorHandler extends ActivityHandler  {

    private Ip2 ip2;
    private DisasterSpace world;

    public SimpleAllocatorHandler(Ip2 ip2){
	super("Simple Allocation");
	this.ip2 = ip2;
    }

    public boolean appliesTo(AgendaItem item) {
	LList pattern = item.getPattern();
	if (pattern.get(0) == Symbol.intern("Clear")){
	    return true;
	}
	else
	    return false;
    }

    public void handle(AgendaItem item) {

	List subordinates = (ip2.getContactManager()).getAgentData(AgentRelationship.SUBORDINATE);
	Hashtable ixrcr = createTable(subordinates);

	Iterator i = subordinates.iterator();

	String ixAgentChosen = null;
	String ixTemp;
	int target;
	float costTemp = Float.MAX_VALUE;
	float currentChosenCost = Float.MAX_VALUE;
	while(i.hasNext()) {
	    ixTemp = ((AgentData) i.next()).getName();
	    Object rcr = ixrcr.get(ixTemp);
	    if(rcr!=null){
		target = (new Integer(((item.getPattern()).get(1)).toString())).intValue();

		MotionlessObject origin = getMotionlessPosition(rcr.toString());
		Vector destination = new Vector();
		destination.add((((PoliceOffice)ip2).getWorldObject(target)).motionlessPosition());
		
		if (!(origin instanceof Road)  ||  ((Road) origin).passableLines() >= 1) {
		    try{
			costTemp =  (Router.get(origin, destination, RELIABILITY_COST_FUNCTION)).cost;
		    }catch(Exception e){System.out.println("NO POSSIBLE!!!");}
		}
		else {
		    Road rd = (Road) getMotionlessPosition(rcr.toString());
		    try{
			costTemp = (Router.get(rd.head(), destination,RELIABILITY_COST_FUNCTION)).cost;
			//(self().positionExtra() < rd.length() / 2) ? rd.head() : rd.tail();
		    }catch(Exception e){System.out.println("NO POSSIBLE!!!");}
		}

		if (costTemp < currentChosenCost) {
		    currentChosenCost = costTemp;
		    ixAgentChosen = ixTemp;
		}
	    }
	}

	Refinement ref = new Refinement();
	ref.setPattern(item.getPattern());
	NodeSpec node = new NodeSpec();
	LList nodeName = Lisp.cons(ixrcr.get(ixAgentChosen),Lisp.NIL);
	//nodeName = Lisp.cons(Symbol.intern("Allocate"),nodeName);
	nodeName = Lisp.cons(Symbol.intern("to"),nodeName);
	nodeName = Lisp.cons(Symbol.intern(((item.getPattern()).get(1)).toString()),nodeName);
	nodeName = Lisp.cons(Symbol.intern("Allocate"),nodeName);
	node.setPattern(nodeName);	
	Vector nodes = new Vector();
	nodes.add(node);
	ref.setNodes(nodes);
	((ip2.getController()).getActivityAgenda()).expandItem(item, ref);

	Iterator iii = (((ip2.getController()).getActivityAgenda()).getItems()).iterator();
	AgendaItem child;
	while(iii.hasNext()){
	    child = (AgendaItem) iii.next();
	    if( child.getParent() == item) {
		child.clearActions();
		ForwardingHandler fh = new ForwardingHandler(ip2, "Delegate", AgentRelationship.SUBORDINATE, true);
		HandlerAction ha = fh.makeForwardingAction(ixAgentChosen,child);
		child.addAction(ha);
		((ip2.getController()).getActivityAgenda()).handleItem(child,ha);
		break;
	    }
	}
    }

    private MotionlessObject getMotionlessPosition(String rcr){

	LList pattern;
	Object posO;
	int posI;
	
	pattern = Lisp.cons(new Long(rcr),Lisp.NIL);
	pattern = Lisp.cons(Symbol.intern("position"),pattern);

	posO = (((Ip2ModelManager)ip2.getModelManager()).getWorldStateMap()).get(pattern);	
	posI = (new Integer(posO.toString())).intValue();

	return (((PoliceOffice)ip2).getWorldObject(posI)).motionlessPosition() ;
    }

    private Hashtable createTable(List sub) {
	Hashtable result = new Hashtable();
	LList pattern;
	Object rcr;

	Iterator i = sub.iterator();
	String ix;
	while(i.hasNext()) {
	    ix = ((AgentData) i.next()).getName();
	    pattern = Lisp.cons(Symbol.intern(ix),Lisp.NIL);
	    pattern = Lisp.cons(Symbol.intern("rcrId"),pattern);
	    rcr = (((Ip2ModelManager)ip2.getModelManager()).getWorldStateMap()).get(pattern);
	    if(rcr != null) result.put(ix,rcr);
	}
	return result;
    }

    private static final Router.CostFunction RELIABILITY_COST_FUNCTION = new Router.CostFunction() {
	public float cost(MotionlessObject from, MotionlessObject to) {
	    final int WEIGHT = Integer.MAX_VALUE;
            float c = 1;
            if (!(to instanceof Road))
		return c;
            Road rd = (Road) to;
            PointObject po = (PointObject) from;
            if (rd.passableLinesFrom(po) == 0)
		return c * WEIGHT * WEIGHT;
            return rd.hasBeenSeen() ? c : c * WEIGHT; 
	}
    };
}

