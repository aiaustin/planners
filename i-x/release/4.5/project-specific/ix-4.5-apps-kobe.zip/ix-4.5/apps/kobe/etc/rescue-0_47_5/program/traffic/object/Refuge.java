package traffic.object;

public class Refuge extends Building {
  public Refuge(int id) { super(id); }
  public int type() { return TYPE_REFUGE; }
}
