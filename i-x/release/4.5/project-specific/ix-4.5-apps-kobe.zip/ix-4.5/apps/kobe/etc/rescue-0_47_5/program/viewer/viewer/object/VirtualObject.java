package viewer.object;

public abstract class VirtualObject extends RescueObject {
  public VirtualObject(int id) { super(id); }
}
