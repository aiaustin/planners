#! /bin/sh
DIR=`dirname $0`
java -cp $DIR/../program/ traffic.Main localhost 7000 $*
