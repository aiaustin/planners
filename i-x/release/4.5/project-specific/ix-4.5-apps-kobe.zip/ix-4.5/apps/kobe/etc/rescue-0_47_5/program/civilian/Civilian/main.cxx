/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#include "input.h"
#include "output.h"
#include "tcp.h"
#include "connection.h"

using namespace Rescue;
using namespace Librescue;

class Controller {
protected:
  Id m_selfId;
  Address m_to;
  ObjectPool m_pool;

public:
  virtual ~Controller() { }
  Controller(Id selfId, const Address& to, Input& input) {
    m_selfId = selfId;
    m_to = to;
    m_pool.restructure(0, input);
  }
  virtual void sensed(Connection& socket, Input& input, Output& output) = 0;
  virtual void heard(Connection& socket, Id speaker, const char* message, Input& input, Output& output);

private:
  Controller(const Controller& source);
  Controller& operator= (const Controller& rhs);
  bool operator== (const Controller& rhs) const;
};
void Controller::heard(Connection& socket, Id speaker, const char* message, Input& input, Output& output) { }

int main2(int argc, char** argv);
typedef std::map<Id, AutoPtr<Controller> > IdToController;
void connectOk(IdToController& idToController, Connection& socket, Input& input, Output& output);
void senseReveived(IdToController& idToController, Connection& socket, Input& input, Output& output);
void hearReveived(IdToController& idToController, Connection& socket, Input& input, Output& output);

int main(int argc, char** argv){
  return main2(argc, argv);
}

class SampleController : public Controller {
protected:
  Id m_destination;
  Id m_destination2;
public:
  SampleController(Id selfId, const Address& to, Input& input) : Controller(selfId, to, input) {
    m_destination = 0;
    m_destination2 = 0;
    long nearestLengthSquared = LONG_MAX;
    long farthestLengthSquared = 0;
    Objects::const_iterator it = m_pool.objects().begin();
	MovingObject* me = (MovingObject*)m_pool.get(selfId);
	int meX, meY;
	m_pool.locate(me,&meX,&meY);
    for(; it != m_pool.objects().end(); it++) {
      Refuge* refuge = dynamic_cast<Refuge*>(*it);
      if(refuge != 0) {
		int refugeX, refugeY;
		if (m_pool.locate(refuge,&refugeX,&refugeY)) {
		  long xdiff = (long)(refugeX - meX);
		  long ydiff = (long)(refugeY - meY);
		  long value = xdiff*xdiff + ydiff*ydiff;
		  if(value < nearestLengthSquared) {
			nearestLengthSquared = value;
			m_destination = refuge->id();
		  }
		  if(value > farthestLengthSquared) {
			farthestLengthSquared = value;
			m_destination2 = refuge->id();
		  }
		}
      }
    }
  }
  virtual void sensed(Connection& socket, Input& input, Output& output);
  virtual void heard(Connection& socket, Id speaker, const char* message, Input& input, Output& output);
  
private:
  SampleController(const SampleController& source);
  SampleController& operator= (const SampleController& rhs);
  bool operator== (const SampleController& rhs) const;
};

using namespace Itk;
typedef RingBufferT<Input*> LocalBuffer;

int main2(int argc, char** argv) {
  const char* host = "localhost";
  Config config;
  LocalBuffer buf("foo",100);

  int number = INT_MAX;   // ��³���륨��������Ȥο�
  // ��������
  int i;
  int count = 0;
  for(i=1; i<argc; i++) {
    if(argv[i][0] == '-') {
      if(strcmp(argv[i], "-file") == 0) {
		if(++i < argc) {
		  config.readConfigFile(argv[i]);
		} else {
		  fprintf(stderr, "error: '-file'\n");
		}
      } else {
		if(++i < argc) {
		  if(!config.setValue(argv[i-1]+1, argv[i]))
			fprintf(stderr, "error: '%s'\n", argv[i]);
		} else {
		  fprintf(stderr, "error: '%s'\n", argv[i-1]);
		}
      }
    } else {
      switch(count++) {
      case 0:
		host = argv[i];
		break;
      case 1:
		number = atoi(argv[i]);
		break;
      default:
		fprintf(stderr, "error: '%s'\n", argv[i]);
		break;
      }
    }
  }
  // �����åȺ���
  //  LongUDPSocket socket(config.textlogname_samplecivilian());
  Input input;
  Output output;
  //  output.setWait(config.send_udp_wait());
  //  output.resetFrameSize(config.send_udp_size());
  Address kernelAddress(host, config.port());    //��������
  TcpConnection socket(kernelAddress);
  //  manager.sendViaTCP(kernelAddress);
  //  manager.start();
  //  TcpConnection socket(to);

  int countttt = 0;
  // ��å������롼��
  IdToController idToController;
  for(;;) {
    //try {
    if(number-- > 0) {
      // ��³��å�����������
      printf("connecting...\n");
      output.clear();
      output.writeInt32(AK_CONNECT);
      Cursor base = output.writeInt32(~(INT_32)0);
      output.writeInt32(number);    // temporaryId
      output.writeInt32(0);         // version
      output.writeInt32(~(INT_32)0);
      output.writeSize(base);
      output.writeInt32(HEADER_NULL);
      socket.send(output);
    }
    // ����
	while (!socket.isDataAvailable(-1)); // Wait for input forever
    socket.receive(input);
    for(;;) {
      Header header = (Header)input.readInt32();
      if(header == HEADER_NULL)
		break;
      INT_32 size = input.readInt32();
      
      Cursor start = input.cursor();
      //fprintf(stderr, "Received header=0x%X.\n", (int)header);
      switch(header) {
      default:
		fprintf(stderr, "Unknown header. 0x%lX\n", (long)header);
		break;
      case KA_CONNECT_ERROR:
		{
		  std::string reason;
		  input.readInt32();    // temporaryId
		  input.readString(reason);
		  fprintf(stderr, "Connection failed. '%s'\n", reason.c_str());
		  number = 0;
		  break;
		}
      case KA_CONNECT_OK:
		connectOk(idToController, &socket, input, output);
		break;
      case KA_SENSE:
		senseReveived(idToController, &socket, input, output);
		break;
      case KA_HEAR:
		hearReveived(idToController, &socket, input, output);
		break;
      }
      input.setCursor(start);
      input.skip(size);
    }
  }
  return 0;
}

void connectOk(IdToController& idToController, Connection* socket, const Address& kernelAddress, Input& input, Output& output){
  /*S32 temporaryId = */ input.readInt32();
  Id selfId = input.readInt32();
  
  // ack
  output.clear();
  output.writeInt32(AK_ACKNOWLEDGE);
  Cursor base = output.writeInt32(~(INT_32)0);
  output.writeInt32(selfId);
  output.writeSize(base);
  output.writeInt32(HEADER_NULL);
  socket.send(output);
    
  AutoPtr<Controller> controller = AutoPtr<Controller>(new SampleController(selfId, socket.addressRecievedFrom(), input));
  idToController[selfId] = controller;
  printf("connect ok: id=%ld\n", (long)selfId);
}

void senseReveived(IdToController& idToController, Connection* socket, Input& input, Output& output){
  Id id = input.readInt32();
  Controller* controller = idToController[id].get();
  controller->sensed(socket, input, output);
}

void hearReveived(IdToController& idToController, Connection* socket, Input& input, Output& output){
  //printf("hearReveived\n");
  Id id = input.readInt32();
  Controller* controller = idToController[id].get();
  Id speaker = input.readInt32();
  std::string message;
  input.readString(message);
  controller->heard(socket, speaker, message.c_str(), input, output);
}


// �ʲ���SampleController �ѥ�����


typedef std::vector<const RescueObject*> Places;
class Comparer : public std::binary_function<Places, Places, bool> {
    double m_x, m_y;
public:
  Comparer() {
  }
  Comparer(double x, double y) {
    m_x = x;
    m_y = y;
  }
  bool operator()(const Places& lhs, const Places& rhs) const {
    const RescueObject* l = lhs.back();
    const RescueObject* r = rhs.back();
    double x1 = l->getX() - m_x;
    double y1 = l->getY() - m_y;
    double x2 = r->getX() - m_x;
    double y2 = r->getY() - m_y;
    return (x1 * x1 + y1 * y1 < x2 * x2 + y2 * y2);
  }
};


void SampleController::sensed(Connection* socket, Input& input, Output& output){
  INT_32 time = input.readInt32();
  m_pool.update(input,time);

  Object* selfObject = m_pool.getObject(m_selfId);
  Humanoid* self = dynamic_cast<Humanoid*>(selfObject);
  if(self == 0)
    return;
  
  const Object* destination = m_pool.getObject(m_destination);
  if(destination == 0)
    return;
  
  const RescueObject* current = m_pool.getObject(self->getPosition());
  if(dynamic_cast<Humanoid*>(current) == 0)
    return;     // on an ambulance etc.
  
  if(self->getBuriedness() > 0)
    return;     // cannot move!

  bool arrive = false;
  //  const Node* nodeDestination = dynamic_cast<const Node*>(destination);
  //  if(nodeDestination != 0) {
  if(self->getPosition()==destination)
	arrive = true;
  //  } else {
  //    if(current == destination)
  //      arrive = true;
  //  }
  if(arrive) {
    // say to myself.
    output.clear();
    output.writeInt32(AK_SAY);
	Cursor base = output.writeInt32(~(INT_32)0);
    output.writeInt32(m_selfId);                   // the ID of self
    output.writeString("What a relief!");     // the message to say
    output.writeInt32(m_selfId);                   // the ID of target
    output.writeSize(base);
    output.writeInt32(HEADER_NULL);
    //printf("saying\n");
    socket.send(output);
        
    m_destination = 0;

    return;
  }

  // õ������
  typedef std::set<Places, Comparer> Set;

  Set set(Comparer(destination->x(), destination->y()));
  set.insert(Places(1, current));
  for(;;) {
    if(set.empty())
      return;
    Set::iterator bestIt = set.begin();
    const Places& best = *bestIt;
    if(best.back() == destination || best.size() > 50)
      break;  // ȯ����������50��꿼��õ�������齪λ
    Places tmp;
    const RescueObject* place = best.back();
	Objects neighbours = m_pool.getNeighbours(place);
	Objects::const_iterator it = neighbors.begin();
    for(; it != neighbors.end(); it++) {
	  //      ASSERT(dynamic_cast<const RescueObject*>(*it) != 0);
      const RescueObject* neighbor = (const RescueObject*)*it;
      if(std::find(best.begin(), best.end(), neighbor) == best.end()) {
		tmp = best;
		tmp.push_back(neighbor);
		set.insert(tmp);
      }
    }
    set.erase(bestIt);
  }

  // ���ϥХåե������
  output.clear();
  output.writeInt32(AK_MOVE);
  Cursor base = output.writeInt32(~(INT_32)0);
  output.writeInt32(m_selfId);

  // õ����̤����
  const Places& best = *set.begin();
  Places::const_iterator it = best.begin();
  ASSERT(it != best.end());
  for(it++; it != best.end(); it++) {
    output.writeInt32((*it)->id());
  }
  output.writeInt32(0);

  output.writeSize(base);
  output.writeInt32(HEADER_NULL);
  socket->send(output);
}

void SampleController::heard(Connection* socket, Id, const char* message, Input&, Output&)
{
    printf("heard '%s'\n", message);
}
