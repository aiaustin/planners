/* Author: Jeff Dalton <J.Dalton@ed.ac.uk>
 * Updated: Sun Apr  4 19:14:42 2004 by Jeff Dalton
 * Copyright: (c) 2003, AIAI, University of Edinburgh
 */

package ix.thesis;

import java.util.*;

import ix.icore.Variable;
import ix.icore.domain.PatternAssignment;
import ix.util.*;
import ix.util.lisp.*;
import ix.util.match.*;

public class ThesisVariableManager extends MatchChoiceManager {

    protected final boolean MATCH_DEBUG = false;

    protected boolean noticeForced = true;

    protected ThesisModelManager modelManager;

    public ThesisVariableManager(ThesisModelManager modelManager) {
	this.modelManager = modelManager;
    }

    public void showState() {
	if (MATCH_DEBUG) super.showState();
    }

    public List evalFilters(List conds, Map state, MatchEnv env) {
	return new FilterMatcher(state).evalFilters(conds, env);
    }

    public void tryBindings(Map bindings) {
	Debug.noteln("Var manager trying", bindings);
	try {
	    noticeForced = false;
	    MatchChoice choice =
		new MatchChoice(Lisp.list(new Bindings(bindings)));
	    add(choice);
	    try {
		recalculate();
		if (choice.getLiveBranches().isEmpty())
		    throw new IllegalArgumentException
			("Cannot apply binding combination " +
			 bindings);
	    }
	    finally {
		remove(choice);
		recalculate();
	    }
	}
	finally {
	    noticeForced = true;
	}
    }

    public void newBindings(Map bindings) {
	// N.B. The bindings have already been applied.
	Debug.noteln("Var manager sees bindings", bindings);
	// Add the bindings as a 1-branch MatchChoice.
	// /\/: This is kind of a hack.
	add(new MatchChoice(Lisp.list(new Bindings(bindings))));
	recalculate();
    }

    public List getConstraints() {
	List constraints = new LinkedList();
	for (Iterator i = matchChoices.iterator(); i.hasNext();) {
	    MatchChoice mc = (MatchChoice)i.next();
	    if (!Variable.unboundVarsIn(mc.getVariables()).isEmpty())
		// If the vars in the match-choice don't all already
		// have values, include it as a constraint.
		constraints.add(mc.toConstraint());
	}
	return constraints;
    }

    /**
     * Called within the variable manager when it notices that some
     * variables have only one possible value remaining.
     */
    protected MatchEnv noticeForcedBindings() {
	// /\/: Super method returns a value only for use here.
	if (noticeForced == false)
	    return null;
	MatchEnv forced = super.noticeForcedBindings();
	if (!forced.isEmpty())
	    modelManager.forcedBindings(forced); // /\/ temporary???
	return forced;
    }

    protected class FilterMatcher {

	protected Map stateMap;
	protected List resultEnvs;

	FilterMatcher(Map stateMap) {
	    this.stateMap = stateMap;
	}

	List evalFilters(List conds, MatchEnv env) { // -> List<MatchEnv>
	    Debug.expect(!conds.isEmpty());
	    Debug.expect(resultEnvs == null);
	    resultEnvs = new LinkedList();
	    try {
		LList cl = LList.newLList(conds);
		filter((PatternAssignment)cl.car(), cl.cdr(), env);
		return resultEnvs;
	    }
	    finally {
		resultEnvs = null;
	    }
	}

	protected void filter(PatternAssignment pv,
			      LList conds,
			      MatchEnv baseEnv) {
	    if (MATCH_DEBUG) Debug.noteln("PMM filter", pv);
	    for (Iterator m = stateMap.entrySet().iterator(); m.hasNext();) {
		Map.Entry entry = (Map.Entry)m.next();
		MatchEnv env = matchFilter(pv, entry, baseEnv);
		if (env != null) {
		    if (conds.isEmpty()) {
			// We've matched all conds, so remember the result.
			if (!resultEnvs.contains(env))
			    resultEnvs.add(env);
		    }
		    else {
			// We've matched one cond, now on to the next.
			filter((PatternAssignment)conds.car(),
			       conds.cdr(), env);
		    }
		}
		// Try the next entry to match the cond against
	    }
	}

	protected MatchEnv matchFilter(PatternAssignment pv,
				       Map.Entry entry,
				       MatchEnv baseEnv) {
	    if (MATCH_DEBUG)
		Debug.noteln("Matching " + pv + ", " + entry + ", " + baseEnv);
	    MatchEnv env = new MatchEnv(baseEnv); // copy /\/
	    env = Matcher.match(pv.getPattern(), entry.getKey(), env);
	    if (env == null)
		return null;
	    env = Matcher.match(pv.getValue(), entry.getValue(), env);
	    if (env == null)
		return null;
	    else if (consistentBindings(env))
		return env;
	    else {
		Debug.noteln("Rejected", env);
		return null;
	    }
	}

	protected boolean consistentBindings(MatchEnv env) {
	    for (Iterator i = env.entrySet().iterator(); i.hasNext();) {
		Map.Entry e = (Map.Entry)i.next();
		Object k = e.getKey();
		Object v = e.getValue();
		if (k instanceof Variable)
		    if (!consistentBinding((Variable)k, v))
			return false;
	    }
	    return true;
	}

	protected boolean consistentBinding(Variable var, Object val) {
	    // /\/: Inefficient
	    if (!getVariables().contains(var)
		  || getPossibleValues(var).contains(val))
		return true;
	    Debug.noteln("Can't bind " + var + " to " + val +
			 " because the only possible values are " +
			 getPossibleValues(var));
	    Debug.noteln("Vars are", getVariables());
	    showState();
	    return false;
	}

    }

}
