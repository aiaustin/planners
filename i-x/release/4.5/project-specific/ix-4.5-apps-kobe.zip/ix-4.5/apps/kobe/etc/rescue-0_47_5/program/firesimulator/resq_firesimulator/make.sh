javac -classpath ./log4j-1.2.8.jar:./ */*/*/*.java
javac -classpath ./log4j-1.2.8.jar:./ */*/*.java
javac -classpath ./log4j-1.2.8.jar:./ */*.java
javac -classpath ./log4j-1.2.8.jar:./ *.java

