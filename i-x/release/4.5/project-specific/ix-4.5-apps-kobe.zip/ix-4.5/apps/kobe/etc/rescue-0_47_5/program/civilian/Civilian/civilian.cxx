/*
 * Header    :
 * File      : civilian.cxx
 * Auther    : Kosuke Shinoda
 * Since     : 2001/11/16
 * Time-stamp: "2002-04-28 01:25:05 kshinoda"
 * Comment   :
 * End       :
 */
/*
 * Copyright (C) 2001 SHINODA, Kosuke. Jaist,Japan & CARC, AIST, JAPAN
 * Copyright (C) 2001 NODA, Itsuki, CARC, AIST, JAPAN
 */

/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#include "config.h"
#include "connection.h"
#include "tcp.h"
#include "input.h"
#include "output.h"
#include "common.h"
//#include <stdio.h>
#include <map>
#include <string>
#include "../itk/itk.h"
#include "CivilianController.hxx"
#include "Controller.hxx"
#include "AutoPtr.hxx"

using namespace Itk;
using namespace Librescue;
using namespace RescueCivilian;

typedef std::map<Id, AutoPtr<Controller> > IdToController;

//------------------------------------------------------------
// connectOk(IdToController&, LongUDPSocket& Input&, Output&);
void connectOk(IdToController& idToController, 
	       const char* filename,
	       Connection& socket, 
	       Input& input,
	       Output& output) {
  input.readInt32();
  Id selfId = input.readInt32();

  //return acknowledge to kernel
  output.clear();
  output.writeInt32(AK_ACKNOWLEDGE);
  Cursor base = output.writeInt32(~(INT_32)0);
  output.writeInt32(selfId);
  output.writeSize(base);
  output.writeInt32(HEADER_NULL);
  socket.send(output);
  
  // set Controller list
  AutoPtr<Controller> controller = AutoPtr<Controller>(new CivilianController(selfId, socket.addressReceivedFrom(), filename, socket, input, output));
  //CivilianController* c = dynamic_cast<CivilianController*>(&*controller);
  //c->env()._controller() = c;
  idToController[selfId] = controller;
  printf("connect ok: id = %ld\n", (long)selfId);
};

//------------------------------------------------------------
// senseReceived(S32, IdToController&, LongUDPSocket&, Input&, Output&)
void senseReceived(Id id, S32 time,
		   IdToController& idToController,
		   Connection& socket, 
		   Input& input, Output& output){
  Controller* controller = idToController[id].get();
  controller->sensed(time, socket, input, output);
};

void hearReceived(IdToController& idToController, 
		  Connection& socket, 
		  Input& input, 
		  Output& output){
  Id id = input.readInt32();
  CivilianController* controller = 
    dynamic_cast<CivilianController*>(idToController[id].get());
  Id speaker = input.readInt32();
  std::string message = input.readString();
  controller->heard(socket, speaker, message.c_str(), input, output);
};

//------------------------------------------------------------
// action loop;
void agent_loop(IdToController& idToController,
	  Connection& socket, Input& input, Output& output){
  static IdToController::iterator it = idToController.begin();
  while(!socket.isDataAvailable(1)){
    Controller* controller = it->second.get();
    if(controller->needToCycle()){
      Sexp* result = controller->cycle();
      controller->needToCycle2(result);
    }
    //----------------------------------------
    // chenge next controller;
    if(++it == idToController.end()){
      it = idToController.begin();
    }
  }
};

//------------------------------------------------------------
// 
int main(int argc, char** argv){
  const char* host = "localhost";
  Config config;
  const char* rulefile_name = "rule.txt";

  int number = INT_MAX;
  int count = 0;
  INT_32 current_time = 0;

  //----------------------------------------
  // Option
  //  -file FILENAME     : configuration filename
  //  -rulefile FILENAME : rulefile for agent
  for(int i = 1; i < argc; i++){
    if(argv[i][0] == '-') {
      if(strcmp(argv[i], "-file") == 0) {
		if(++i < argc) {
		  config.readConfigFile(argv[i]);
		} else {
		  fprintf(stderr, "error: '-file'\n");
		}
      } else if(strcmp(argv[i], "-rulefile") == 0) {
		if(++i < argc){
		  rulefile_name = argv[i];
		} else {
		  fprintf(stderr, "error: '-rulefile'\n");
		}
      } else {
		if(++i < argc) {
		  if(!config.setValue(argv[i-1]+1, argv[i]))
			fprintf(stderr, "error: '%s'\n", argv[i]);
		} else {
		  fprintf(stderr, "error: '%s'\n", argv[i-1]);
		}
      }
    } else {
      switch(count++) {
      case 0:
		host = argv[i];
		break;
      case 1:
		number = atoi(argv[i]);
		break;
      default:
		fprintf(stderr, "error: '%s'\n", argv[i]);
		break;
      }
    }
  }

  //----------------------------------------
  // set LongUDPSocket
  Input input;
  Output output;
  //  output.setWait(config.send_udp_wait());
  Address to(host, config.port());
  IdToController idToController;
  TcpConnection socket(to);

  INT_32 num_of_waitingmessage = 0;
  Bool first = True;
  // agent connection
  for(;;) {
    if(number-- > 0) {
      printf("connecting...\n");
      output.clear();
      output.writeInt32(AK_CONNECT);
      Cursor base = output.writeInt32(~(S32)0);
      output.writeInt32(number);    // temporaryId
      if(first){
		output.writeInt32(0);         // version
		first = False;
      } else {
		output.writeInt32(1);
      }
      output.writeInt32(AGENT_TYPE_CIVILIAN);
      output.writeSize(base);
      output.writeInt32(HEADER_NULL);
      socket.send(output);
      num_of_waitingmessage++;

    }
    if(socket.isDataAvailable(1) || num_of_waitingmessage > 0){
      socket.receive(input);
      num_of_waitingmessage--;

      for(;;){
		Header header = (Header)input.readInt32();
		if(header == HEADER_NULL)
		  break;
		INT_32 size = input.readInt32();
		Cursor start = input.cursor();
		switch(header){
		case KA_CONNECT_ERROR:
		  {
			std::string reason;
			input.readInt32(); // tmporaryId
			reason = input.readString();
			fprintf(stderr, "Connection failed: '%s'\n", reason.c_str());
			number = 0;
			break;
		  }
		case KA_CONNECT_OK:
		  connectOk(idToController, rulefile_name, socket, input, output);
		  break;    
		default:
		  fprintf(stderr, "Unknown header. 0x%lX\n", (long)header);
		  break;
		}
		input.setCursor(start);
		input.skip(size);
      }
    }
    if(number <= 0 && num_of_waitingmessage <= 0)
      break;
  }
    
  // loop
  for(;;) {
    // receive data from kernel
    socket.receive(input);
    //ITK_TIME("civilian cycle",{
    for(;;){
      Header header = (Header)input.readInt32();
      if(header == HEADER_NULL)
		break;
      INT_32 size = input.readInt32();
      Cursor start = input.cursor();
      
      INT_32 time = 0;
      switch(header) {
      default:
		fprintf(stderr, "Unknown header2. 0x%lX\n", (long)header);
		break;
      case KA_SENSE:
		{
		  Id id = input.readInt32();
		  time = input.readInt32(); //current time
		  //----------------------------------------
		  // check point :: for next step 
		  if(time > current_time) {
			printf("loop----------------------------------\n");
			ITK_DBG(time);
			current_time = time;//Controller will have new step
			for(IdToController::iterator it = idToController.begin();
				it != idToController.end();it++){
			  Controller* controller = it->second.get();
			  controller->nextstep();
			}
		  }
		  senseReceived(id, time, idToController, socket, input, output);
		  Controller* controller = idToController[id].get();
		  controller->cycle();
		  //agent_loop(idToController, socket, input, output);
		  break;
		}
      case KA_HEAR:
		hearReceived(idToController, socket, input, output);
		agent_loop(idToController, socket, input, output);      
		break;
      }
      input.setCursor(start);
      input.skip(size);
    }
    //  });
  }
  return 0;
};

