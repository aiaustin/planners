/*
 * Copyright (c) 2005, The Black Sheep, Department of Computer Science, The University of Auckland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of The Black Sheep, The Department of Computer Science or The University of Auckland nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 Contributors and list of changes:

 Cameron Skinner
   Converted original Robocup Rescue software into librescue
*/

#include "objects.h"
#include "common.h"
#include "error.h"
#include <string.h>

namespace Librescue {
  RescueObject* newRescueObject(TypeId type) {
	RescueObject* result = 0;
  	switch (type) {
	case TYPE_WORLD:
	  result = new World();
	  break;
	case TYPE_CIVILIAN:
	  result = new Civilian();
	  break;
	case TYPE_CAR:
	  result = new Car();
	  break;
	case TYPE_FIRE_BRIGADE:
	  result = new FireBrigade();
	  break;
	case TYPE_AMBULANCE_TEAM:
	  result = new AmbulanceTeam();
	  break;
	case TYPE_POLICE_FORCE:
	  result = new PoliceForce();
	  break;
	case TYPE_BUILDING:
	  result = new Building();
	  break;
	case TYPE_REFUGE:
	  result = new Refuge();
	  break;
	case TYPE_FIRE_STATION:
	  result = new FireStation();
	  break;
	case TYPE_AMBULANCE_CENTER:
	  result = new AmbulanceCenter();
	  break;
	case TYPE_POLICE_OFFICE:
	  result = new PoliceOffice();
	  break;
	case TYPE_ROAD:
	  result = new Road();
	  break;
	case TYPE_RIVER:
	  result = new River();
	  break;
	case TYPE_NODE:
	  result = new Node();
	  break;
	case TYPE_RIVER_NODE:
	  result = new RiverNode();
	  break;
	case TYPE_NULL:
	  result = 0;
	  break;
	}
	return result;
  }

  Property::Property(PropertyId type_) {
	m_type = type_;
	m_value = 0;
	m_values = new INT_32[1];
	m_values[0] = 0;
	m_numValues = 0;
	m_valuesLength = 1;
	m_lastUpdate = -1;
  }

  Property::~Property() {
	delete[] m_values;
  }

  PropertyId Property::type() const {
	return m_type;
  }

  INT_32 Property::getIntValue() const {
	return m_value;
  }

  INT_32* Property::getIntValues() const {
	return m_values;
  }

  INT_32 Property::lastUpdate() const {
	return m_lastUpdate;
  }

  void Property::setIntValue(INT_32 value_) {
	m_value = value_;
  }

  void Property::setIntValues(INT_32* values_) {
	//	LOG_DEBUG("setIntValues called");
	int count = 0;
	while (values_[count++]!=0); // Count the number of non-zero values
	resizeValues(count);
	memcpy(m_values,values_,sizeof(INT_32)*count);
	//	m_values[count] = 0; // Don't need this because values_ is already zero-terminated
	m_numValues = count-1;
	//	LOG_DEBUG("m_numValues is now %d",m_numValues);
  }

  void Property::appendIntValue(INT_32 value_) {
	//	LOG_DEBUG("appendIntValue called");
	resizeValues(m_numValues+2);
	m_values[m_numValues++] = value_;
	m_values[m_numValues] = 0;
	//	LOG_DEBUG("m_numValues is now %d",m_numValues);
  }

  void Property::clearIntValues() {
	m_numValues = 0;
	m_values[0] = 0;
  }

  void Property::setLastUpdate(INT_32 time) {
	m_lastUpdate = time;
  }

  void Property::resizeValues(int size) {
	//	LOG_DEBUG("resizeValues(%d) called. Current m_valuesLength=%d, m_values=0x%p, m_numValues=%d",size,m_valuesLength,m_values,m_numValues);
	if (m_valuesLength<size) {
	  // Reallocate to the larger of size and m_valuesLength*2
	  if (m_valuesLength*2 > size) size = m_valuesLength*2;
	  INT_32* newValues = new INT_32[size];
	  //	  LOG_DEBUG("newValues = 0x%p",newValues);
	  if (m_numValues!=0) memcpy(newValues,m_values,sizeof(INT_32)*m_numValues);
	  delete[] m_values;
	  m_values = newValues;
	  m_valuesLength = size;
	}
  }

  void Property::read(Input& buffer) {
	INT_32 next;
	switch (m_type) {
	case PROPERTY_NULL:
	  logError("Tried to read a property with type PROPERTY_NULL");
	  break;

	  // Integer values
	  // World
	case PROPERTY_START_TIME:
	case PROPERTY_LONGITUDE:
	case PROPERTY_LATITUDE:
	case PROPERTY_WIND_DIRECTION:
	case PROPERTY_WIND_FORCE:
	  // Moving object
	case PROPERTY_POSITION:
	case PROPERTY_POSITION_EXTRA:
	case PROPERTY_DIRECTION:
	  // Humanoid
	case PROPERTY_STAMINA:
	case PROPERTY_HP:
	case PROPERTY_DAMAGE:
	case PROPERTY_BURIEDNESS:
	  // Fire brigade
	case PROPERTY_WATER_QUANTITY:
	case PROPERTY_STRETCHED_LENGTH:
	  // Motionless object
	case PROPERTY_X:
	case PROPERTY_Y:
	  // Building
	case PROPERTY_FLOORS:
	case PROPERTY_BUILDING_ATTRIBUTES:
	case PROPERTY_IGNITION:
	case PROPERTY_FIERYNESS:
	case PROPERTY_BROKENNESS:
	case PROPERTY_BUILDING_CODE:
	case PROPERTY_BUILDING_AREA_GROUND:
	case PROPERTY_BUILDING_AREA_TOTAL:
	  // Edge
	case PROPERTY_HEAD:
	case PROPERTY_TAIL:
	case PROPERTY_LENGTH:
	  // Road
	case PROPERTY_ROAD_KIND:
	case PROPERTY_CARS_PASS_TO_HEAD:
	case PROPERTY_CARS_PASS_TO_TAIL:
	case PROPERTY_HUMANS_PASS_TO_HEAD:
	case PROPERTY_HUMANS_PASS_TO_TAIL:
	case PROPERTY_WIDTH:
	case PROPERTY_BLOCK:
	case PROPERTY_REPAIR_COST:
	case PROPERTY_MEDIAN_STRIP:
	case PROPERTY_LINES_TO_HEAD:
	case PROPERTY_LINES_TO_TAIL:
	case PROPERTY_WIDTH_FOR_WALKERS:
	  // Node
	case PROPERTY_SIGNAL:
	  m_value = buffer.readInt32();
	  //	  snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Value: %d",m_value);
	  //	  logDebug(errorBuffer);
	  break;

	  // Array values that are specified as zero-terminated list
	case PROPERTY_ENTRANCES:
	case PROPERTY_POSITION_HISTORY:
	case PROPERTY_EDGES:
	  clearIntValues();
	  while ((next=buffer.readInt32())!=0) {
		appendIntValue(next);
	  }
	  /*
	  resizeValues(result.size()+1);
	  next = 0;
	  for (std::vector<INT_32>::iterator it = result.begin();it!=result.end();++it) {
		m_values[next++] = *it;
	  }
	  m_values[next] = 0;
	  m_numValues = next;
	  */
	  //	  snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"%d values",next);
	  //	  logDebug(errorBuffer);
	  break;
	  // Array values that are specified by size
	case PROPERTY_BUILDING_APEXES:
	case PROPERTY_SHORTCUT_TO_TURN:
	case PROPERTY_POCKET_TO_TURN_ACROSS:
	case PROPERTY_SIGNAL_TIMING:
	  clearIntValues();
	  next = buffer.readInt32()/INT_32_SIZE;
	  for (int i=0;i<next;++i) appendIntValue(buffer.readInt32());
	  //	  resizeValues(m_numValues+1);
	  //	  for (int i=0;i<m_numValues;++i) m_values[i] = buffer.readInt32();
	  //	  m_values[m_numValues] = 0;
	  //	  snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"%d values",m_numValues);
	  //	  logDebug(errorBuffer);
	  break;
	default:
	  char error[255];
	  snprintf(error,255,"Unknown property type: %d",m_type);
	  logError(error);
	  break;
	}
  }

  void Property::write(Output& buffer) const {
	buffer.writeInt32(m_type);
	switch (m_type) {
	  // Integer values
	  // World
	case PROPERTY_START_TIME:
	case PROPERTY_LONGITUDE:
	case PROPERTY_LATITUDE:
	case PROPERTY_WIND_DIRECTION:
	case PROPERTY_WIND_FORCE:
	  // Moving object
	case PROPERTY_POSITION:
	case PROPERTY_POSITION_EXTRA:
	case PROPERTY_DIRECTION:
	  // Humanoid
	case PROPERTY_STAMINA:
	case PROPERTY_HP:
	case PROPERTY_DAMAGE:
	case PROPERTY_BURIEDNESS:
	  // Fire brigade
	case PROPERTY_WATER_QUANTITY:
	case PROPERTY_STRETCHED_LENGTH:
	  // Motionless object
	case PROPERTY_X:
	case PROPERTY_Y:
	  // Building
	case PROPERTY_FLOORS:
	case PROPERTY_BUILDING_ATTRIBUTES:
	case PROPERTY_IGNITION:
	case PROPERTY_FIERYNESS:
	case PROPERTY_BROKENNESS:
	case PROPERTY_BUILDING_CODE:
	case PROPERTY_BUILDING_AREA_GROUND:
	case PROPERTY_BUILDING_AREA_TOTAL:
	  // Edge
	case PROPERTY_HEAD:
	case PROPERTY_TAIL:
	case PROPERTY_LENGTH:
	  // Road
	case PROPERTY_ROAD_KIND:
	case PROPERTY_CARS_PASS_TO_HEAD:
	case PROPERTY_CARS_PASS_TO_TAIL:
	case PROPERTY_HUMANS_PASS_TO_HEAD:
	case PROPERTY_HUMANS_PASS_TO_TAIL:
	case PROPERTY_WIDTH:
	case PROPERTY_BLOCK:
	case PROPERTY_REPAIR_COST:
	case PROPERTY_MEDIAN_STRIP:
	case PROPERTY_LINES_TO_HEAD:
	case PROPERTY_LINES_TO_TAIL:
	case PROPERTY_WIDTH_FOR_WALKERS:
	  // Node
	case PROPERTY_SIGNAL:
#ifdef __ADD_LENGTH_FIELD__
	  buffer.writeInt32(INT_32_SIZE); // Length
#endif
	  buffer.writeInt32(m_value);
	  break;

#ifdef __OLD_CONSTANTS__
	  // Use the old method for encoding variable-length lists.
	case PROPERTY_ENTRANCES:
	case PROPERTY_POSITION_HISTORY:
	case PROPERTY_EDGES:
	  // These guys write a zero-terminated list
#ifdef __ADD_LENGTH_FIELD__
	  buffer.writeInt32((m_numValues+1)*INT_32_SIZE); // Length. Each INT_32 takes up 4 bytes
#endif
	  for (int i=0;i<m_numValues;++i) buffer.writeInt32(m_values[i]);
	  buffer.writeInt32(0);
	  break;
	case PROPERTY_BUILDING_APEXES:
	case PROPERTY_SHORTCUT_TO_TURN:
	case PROPERTY_POCKET_TO_TURN_ACROSS:
	case PROPERTY_SIGNAL_TIMING:
	  // These ones write the number of bytes used followed by the data
#ifdef __ADD_LENGTH_FIELD__
	  buffer.writeInt32((m_numValues+1)*INT_32_SIZE); // Length. Each INT_32 takes up 4 bytes
#endif
	  //	  if (m_type==PROPERTY_BUILDING_APEXES) {
	  //		snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Writing %d building apexes",m_numValues);
	  //		logDebug(errorBuffer);
	  //	  }
	  buffer.writeInt32(m_numValues*INT_32_SIZE);
	  for (int i=0;i<m_numValues;++i) {
		buffer.writeInt32(m_values[i]);
		//		snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Apex %d = %d",i,m_values[i]);
		//		logDebug(errorBuffer);
	  }
	  break;
#else
	  // Use new method for encoding variable-length lists. First write the number of values, then the values themselves.
	  // Array values
	  // Moving object
	case PROPERTY_POSITION_HISTORY:
	  // Building
	case PROPERTY_BUILDING_APEXES:
	case PROPERTY_ENTRANCES:
	  // Vertex
	case PROPERTY_EDGES:
	  // Node
	case PROPERTY_SHORTCUT_TO_TURN:
	case PROPERTY_POCKET_TO_TURN_ACROSS:
	case PROPERTY_SIGNAL_TIMING:
#ifdef __ADD_LENGTH_FIELD__
	  buffer.writeInt32((m_numValues+1)*INT_32_SIZE); // Length. Each INT_32 takes up 4 bytes
#endif
	  buffer.writeInt32(m_numValues);
	  for (int i=0;i<m_numValues;++i) buffer.writeInt32(m_values[i]);
	  break;
#endif
	case PROPERTY_NULL:
	  logError("Tried to write a property with type PROPERTY_NULL");
#ifdef __ADD_LENGTH_FIELD__
	  buffer.writeInt32(0); // Length
#endif
	  break;
	default:
	  char error[255];
	  snprintf(error,255,"Tried to write an unknown property type: %d",m_type);
	  logError(error);
	  buffer.writeInt32(0); // Length
	  break;
	}
  }

  RescueObject::RescueObject() {
	m_id = 0;
  }

  RescueObject::~RescueObject() {
  }

  void RescueObject::read(Input& buffer, int time) {
	m_id = buffer.readInt32();
	PropertyId next;
	while ((next = (PropertyId)buffer.readInt32())!=PROPERTY_NULL) {
#ifdef __ADD_LENGTH_FIELD__
	  int length = buffer.readInt32();
	  readProperty(buffer,next,length,time);
#else
	  readProperty(buffer,next,0,time);
#endif
	}
  }

  void RescueObject::readProperty(Input& buffer, PropertyId property, INT_32 length, int time) {
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Reading property %d",property);
	//	logDebug(errorBuffer);
	Property* p = getProperty(property);
	if (p) {
	  p->read(buffer);
	  p->setLastUpdate(time);
	}
	else {
	  //	  logDebug("Not found");
	  buffer.skip(length);
	}
  }

  void RescueObject::write(Output& buffer) const {
	buffer.writeInt32(type());
	buffer.writeInt32(m_id);
	for (int i=PROPERTY_MIN;i<PROPERTY_MAX;++i) {
	  const Property* p = getProperty((PropertyId)i);
	  if (p)
		p->write(buffer);
	}
	buffer.writeInt32(PROPERTY_NULL);
  }

  void RescueObject::write(Output& buffer, INT_32 time) const {
	Output temp;
	temp.writeInt32(type());
	temp.writeInt32(m_id);
	int count = 0;
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Sending update of object %d (type %d)",m_id,type());
	//	logDebug(errorBuffer);
	for (int i=PROPERTY_MIN;i<PROPERTY_MAX;++i) {
	  const Property* p = getProperty((PropertyId)i);
	  //	  if (p) {
	  //		snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Checking if we need to send update for property %d. Last update was %d ",p->type(),p->lastUpdate());
	  //		logDebug(errorBuffer);
	  //	  }
	  if (p && p->lastUpdate()>=time) {
		p->write(temp);
		++count;
		//		logDebug("Sending update");
	  }
	}
	temp.writeInt32(PROPERTY_NULL);
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Sent %d properties",count);
	//	logDebug(errorBuffer);
	// Did we actually write anything?
	if (time<=0 || count > 0) {
	  buffer.write(temp);
	}
  }
  
  /*
  void RescueObject::write(Output& buffer, INT_32 time) const {
	buffer.writeInt32(type());
	buffer.writeInt32(m_id);
	for (int i=PROPERTY_MIN;i<PROPERTY_MAX;++i) {
	  const Property* p = getProperty((PropertyId)i);
	  if (p && p->lastUpdate()>=time) {
		p->write(buffer);
	  }
	}
	buffer.writeInt32(PROPERTY_NULL);
  }
  */

  void RescueObject::writeProperty(Output& buffer, PropertyId property) const {
	const Property* p = getProperty(property);
	if (p) p->write(buffer);
  }

  //  void RescueObject::output(Output& buffer, PropertyId property) {
  //	writeProperty(buffer,property);
  //  }

  Id RescueObject::id() const {
	return m_id;
  }

  void RescueObject::setId(Id id_) {
	m_id = id_;
  }

  Property* RescueObject::getProperty(PropertyId type) {
	//	logDebug("In RescueObject::getProperty");
	return 0;
  }

  const Property* RescueObject::getProperty(PropertyId type) const {
	// We want to call the non-const version and return a constified result
	RescueObject* nonconstThis = const_cast<RescueObject*>(this);
	return nonconstThis->getProperty(type);
  }

  VirtualObject::VirtualObject() {
  }

  VirtualObject::~VirtualObject() {
  }

  World::World(): m_startTime(PROPERTY_START_TIME), m_longitude(PROPERTY_LONGITUDE), m_latitude(PROPERTY_LATITUDE), m_windForce(PROPERTY_WIND_FORCE), m_windDirection(PROPERTY_WIND_DIRECTION) {
  }

  World::~World() {
  }

  TypeId World::type() const {
	return TYPE_WORLD;
  }

  Property* World::getProperty(PropertyId type) {
	//	logDebug("In World::getProperty");
	switch (type) {
	case PROPERTY_START_TIME:
	  return &m_startTime;
	case PROPERTY_LONGITUDE:
	  return &m_longitude;
	case PROPERTY_LATITUDE:
	  return &m_latitude;
	case PROPERTY_WIND_FORCE:
	  return &m_windForce;
	case PROPERTY_WIND_DIRECTION:
	  return &m_windDirection;
	default:
	  return VirtualObject::getProperty(type);
	}
  }

  INT_32 World::getStartTime() const {
	return m_startTime.getIntValue();
  }

  INT_32 World::getLongitude() const {
	return m_longitude.getIntValue();
  }

  INT_32 World::getLatitude() const {
	return m_latitude.getIntValue();
  }

  INT_32 World::getWindForce() const {
	return m_windForce.getIntValue();
  }

  INT_32 World::getWindDirection() const {
	return m_windDirection.getIntValue();
  }

  void World::setStartTime(INT_32 value, INT_32 time) {
	m_startTime.setIntValue(value);
	m_startTime.setLastUpdate(time);
  }

  void World::setLongitude(INT_32 value, INT_32 time) {
	m_longitude.setIntValue(value);
	m_longitude.setLastUpdate(time);
  }

  void World::setLatitude(INT_32 value, INT_32 time) {
	m_latitude.setIntValue(value);
	m_latitude.setLastUpdate(time);
  }

  void World::setWindForce(INT_32 value, INT_32 time) {
	m_windForce.setIntValue(value);
	m_windForce.setLastUpdate(time);
  }

  void World::setWindDirection(INT_32 value, INT_32 time) {
	m_windDirection.setIntValue(value);
	m_windDirection.setLastUpdate(time);
  }

  INT_32 World::getStartTimeUpdate() const {
	return m_startTime.lastUpdate();
  }

  INT_32 World::getLongitudeUpdate() const {
	return m_longitude.lastUpdate();
  }

  INT_32 World::getLatitudeUpdate() const {
	return m_latitude.lastUpdate();
  }

  INT_32 World::getWindForceUpdate() const {
	return m_windForce.lastUpdate();
  }

  INT_32 World::getWindDirectionUpdate() const {
	return m_windDirection.lastUpdate();
  }

  RealObject::RealObject() {
  }

  RealObject::~RealObject() {
  }

  MovingObject::MovingObject(): m_position(PROPERTY_POSITION), m_positionExtra(PROPERTY_POSITION_EXTRA), m_direction(PROPERTY_DIRECTION), m_positionHistory(PROPERTY_POSITION_HISTORY) {
  }

  MovingObject::~MovingObject() {
  }

  Property* MovingObject::getProperty(PropertyId type) {
	switch (type) {
	case PROPERTY_POSITION:
	  return &m_position;
	case PROPERTY_POSITION_EXTRA:
	  return &m_positionExtra;
	case PROPERTY_DIRECTION:
	  return &m_direction;
	case PROPERTY_POSITION_HISTORY:
	  return &m_positionHistory;
	default:
	  return RealObject::getProperty(type);
	}
  }

  INT_32 MovingObject::getPosition() const {
	return m_position.getIntValue();
  }

  INT_32 MovingObject::getPositionExtra() const {
	return m_positionExtra.getIntValue();
  }

  INT_32 MovingObject::getDirection() const {
	return m_direction.getIntValue();
  }

  INT_32* MovingObject::getPositionHistory() const {
	return m_positionHistory.getIntValues();
  }

  void MovingObject::setPosition(INT_32 value, INT_32 time) {
	m_position.setIntValue(value);
	m_position.setLastUpdate(time);
  }

  void MovingObject::setPositionExtra(INT_32 value, INT_32 time) {
	m_positionExtra.setIntValue(value);
	m_positionExtra.setLastUpdate(time);
  }

  void MovingObject::setDirection(INT_32 value, INT_32 time) {
	m_direction.setIntValue(value);
	m_direction.setLastUpdate(time);
  }

  void MovingObject::setPositionHistory(INT_32* values, INT_32 time) {
	m_positionHistory.setIntValues(values);
	m_positionHistory.setLastUpdate(time);
  }

  void MovingObject::appendPositionHistory(INT_32 value, INT_32 time) {
	m_positionHistory.appendIntValue(value);
	m_positionHistory.setLastUpdate(time);
  }

  void MovingObject::clearPositionHistory(INT_32 time) {
	m_positionHistory.clearIntValues();
	m_positionHistory.setLastUpdate(time);
  }

  INT_32 MovingObject::getPositionUpdate() const {
	return m_position.lastUpdate();
  }

  INT_32 MovingObject::getPositionExtraUpdate() const {
	return m_positionExtra.lastUpdate();
  }

  INT_32 MovingObject::getDirectionUpdate() const {
	return m_direction.lastUpdate();
  }

  INT_32 MovingObject::getPositionHistoryUpdate() const {
	return m_positionHistory.lastUpdate();  
  }

  Humanoid::Humanoid(): m_stamina(PROPERTY_STAMINA), m_hp(PROPERTY_HP), m_damage(PROPERTY_DAMAGE), m_buriedness(PROPERTY_BURIEDNESS) {
  }

  Humanoid::~Humanoid() {
  }

  Property* Humanoid::getProperty(PropertyId type) {
	switch (type) {
	case PROPERTY_STAMINA:
	  return &m_stamina;
	case PROPERTY_HP:
	  return &m_hp;
	case PROPERTY_DAMAGE:
	  return &m_damage;
	case PROPERTY_BURIEDNESS:
	  return &m_buriedness;
	default:
	  return MovingObject::getProperty(type);
	}
  }

  INT_32 Humanoid::getStamina() const {
	return m_stamina.getIntValue();
  }

  INT_32 Humanoid::getHP() const {
	return m_hp.getIntValue();
  }

  INT_32 Humanoid::getDamage() const {
	return m_damage.getIntValue();
  }

  INT_32 Humanoid::getBuriedness() const {
	return m_buriedness.getIntValue();
  }

  void Humanoid::setStamina(INT_32 value, INT_32 time) {
	m_stamina.setIntValue(value);
	m_stamina.setLastUpdate(time);
  }

  void Humanoid::setHP(INT_32 value, INT_32 time) {
	m_hp.setIntValue(value);
	m_hp.setLastUpdate(time);
  }

  void Humanoid::setDamage(INT_32 value, INT_32 time) {
	m_damage.setIntValue(value);
	m_damage.setLastUpdate(time);
  }

  void Humanoid::setBuriedness(INT_32 value, INT_32 time) {
	m_buriedness.setIntValue(value);
	m_buriedness.setLastUpdate(time);
  }

  INT_32 Humanoid::getStaminaUpdate() const {
	return m_stamina.lastUpdate();
  }

  INT_32 Humanoid::getHPUpdate() const {
	return m_hp.lastUpdate();
  }

  INT_32 Humanoid::getDamageUpdate() const {
	return m_damage.lastUpdate();
  }

  INT_32 Humanoid::getBuriednessUpdate() const {
	return m_buriedness.lastUpdate();
  }

  Civilian::Civilian() {
  }

  Civilian::~Civilian() {
  }

  TypeId Civilian::type() const {
	return TYPE_CIVILIAN;
  }

  Car::Car() {
  }

  Car::~Car() {
  }

  TypeId Car::type() const {
	return TYPE_CAR;
  }

  FireBrigade::FireBrigade(): m_water(PROPERTY_WATER_QUANTITY), m_stretchedLength(PROPERTY_STRETCHED_LENGTH) {
  }

  FireBrigade::~FireBrigade() {
  }

  TypeId FireBrigade::type() const {
	return TYPE_FIRE_BRIGADE;
  }

  Property* FireBrigade::getProperty(PropertyId type) {
	switch (type) {
	case PROPERTY_WATER_QUANTITY:
	  return &m_water;
	case PROPERTY_STRETCHED_LENGTH:
	  return &m_stretchedLength;
	default:
	  return Humanoid::getProperty(type);
	}
  }

  INT_32 FireBrigade::getWater() const {
	return m_water.getIntValue();
  }

  INT_32 FireBrigade::getStretchedLength() const {
	return m_stretchedLength.getIntValue();
  }

  void FireBrigade::setWater(INT_32 value, INT_32 time) {
	m_water.setIntValue(value);
	m_water.setLastUpdate(time);
  }

  void FireBrigade::setStretchedLength(INT_32 value, INT_32 time) {
	m_stretchedLength.setIntValue(value);
	m_stretchedLength.setLastUpdate(time);
  }

  INT_32 FireBrigade::getWaterUpdate() const {
	return m_water.lastUpdate();
  }

  INT_32 FireBrigade::getStretchedLengthUpdate() const {
	return m_stretchedLength.lastUpdate();
  }

  AmbulanceTeam::AmbulanceTeam() {
  }

  AmbulanceTeam::~AmbulanceTeam() {
  }

  TypeId AmbulanceTeam::type() const {
	return TYPE_AMBULANCE_TEAM;
  }

  PoliceForce::PoliceForce() {
  }

  PoliceForce::~PoliceForce() {
  }

  TypeId PoliceForce::type() const {
	return TYPE_POLICE_FORCE;
  }

  MotionlessObject::MotionlessObject(): m_x(PROPERTY_X), m_y(PROPERTY_Y) {
  }

  MotionlessObject::~MotionlessObject() {
  }

  Property* MotionlessObject::getProperty(PropertyId type) {
	switch (type) {
	case PROPERTY_X:
	  return &m_x;
	case PROPERTY_Y:
	  return &m_y;
	default:
	  return RealObject::getProperty(type);
	}
  }

  INT_32 MotionlessObject::getX() const {
	return m_x.getIntValue();
  }

  INT_32 MotionlessObject::getY() const {
	return m_y.getIntValue();
  }

  void MotionlessObject::setX(INT_32 value, INT_32 time) {
	m_x.setIntValue(value);
	m_x.setLastUpdate(time);
  }

  void MotionlessObject::setY(INT_32 value, INT_32 time) {
	m_y.setIntValue(value);
	m_y.setLastUpdate(time);
  }

  INT_32 MotionlessObject::getXUpdate() const {
	return m_x.lastUpdate();
  }

  INT_32 MotionlessObject::getYUpdate() const {
	return m_y.lastUpdate();
  }

  Building::Building(): m_floors(PROPERTY_FLOORS), m_attributes(PROPERTY_BUILDING_ATTRIBUTES), m_ignition(PROPERTY_IGNITION), m_fieryness(PROPERTY_FIERYNESS), m_brokenness(PROPERTY_BROKENNESS), m_entrances(PROPERTY_ENTRANCES), m_buildingCode(PROPERTY_BUILDING_CODE), m_groundArea(PROPERTY_BUILDING_AREA_GROUND), m_totalArea(PROPERTY_BUILDING_AREA_TOTAL), m_apexes(PROPERTY_BUILDING_APEXES) {
  }

  Building::~Building() {
  }

  TypeId Building::type() const {
	return TYPE_BUILDING;
  }

  Property* Building::getProperty(PropertyId type) {
	switch (type) {
	case PROPERTY_FLOORS:
	  return &m_floors;
	case PROPERTY_BUILDING_ATTRIBUTES:
	  return &m_attributes;
	case PROPERTY_IGNITION:
	  return &m_ignition;
	case PROPERTY_FIERYNESS:
	  return &m_fieryness;
	case PROPERTY_BROKENNESS:
	  return &m_brokenness;
	case PROPERTY_ENTRANCES:
	  return &m_entrances;
	case PROPERTY_BUILDING_CODE:
	  return &m_buildingCode;
	case PROPERTY_BUILDING_AREA_GROUND:
	  return &m_groundArea;
	case PROPERTY_BUILDING_AREA_TOTAL:
	  return &m_totalArea;
	case PROPERTY_BUILDING_APEXES:
	  return &m_apexes;
	default:
	  return MotionlessObject::getProperty(type);
	}
  }

  INT_32 Building::getFloors() const {
	return m_floors.getIntValue();
  }

  INT_32 Building::getAttributes() const {
	return m_attributes.getIntValue();
  }

  INT_32 Building::getIgnition() const {
	return m_ignition.getIntValue();
  }

  INT_32 Building::getFieryness() const {
	return m_fieryness.getIntValue();
  }

  INT_32 Building::getBrokenness() const {
	return m_brokenness.getIntValue();
  }

  INT_32* Building::getEntrances() const {
	return m_entrances.getIntValues();
  }

  INT_32 Building::getBuildingCode() const {
	return m_buildingCode.getIntValue();
  }

  INT_32 Building::getGroundArea() const {
	return m_groundArea.getIntValue();
  }

  INT_32 Building::getTotalArea() const {
	return m_totalArea.getIntValue();
  }

  INT_32* Building::getApexes() const {
	return m_apexes.getIntValues();
  }

  void Building::setFloors(INT_32 value, INT_32 time) {
	m_floors.setIntValue(value);
	m_floors.setLastUpdate(time);
  }

  void Building::setAttributes(INT_32 value, INT_32 time) {
	m_attributes.setIntValue(value);
	m_attributes.setLastUpdate(time);
  }

  void Building::setIgnition(INT_32 value, INT_32 time) {
	m_ignition.setIntValue(value);
	m_ignition.setLastUpdate(time);
  }

  void Building::setFieryness(INT_32 value, INT_32 time) {
	m_fieryness.setIntValue(value);
	m_fieryness.setLastUpdate(time);
  }

  void Building::setBrokenness(INT_32 value, INT_32 time) {
	m_brokenness.setIntValue(value);
	m_brokenness.setLastUpdate(time);
  }

  void Building::setBuildingCode(INT_32 value, INT_32 time) {
	m_buildingCode.setIntValue(value);
	m_buildingCode.setLastUpdate(time);
  }

  void Building::setGroundArea(INT_32 value, INT_32 time) {
	m_groundArea.setIntValue(value);
	m_groundArea.setLastUpdate(time);
  }

  void Building::setTotalArea(INT_32 value, INT_32 time) {
	m_totalArea.setIntValue(value);
	m_totalArea.setLastUpdate(time);
  }

  void Building::setEntrances(INT_32* values, INT_32 time) {
	m_entrances.setIntValues(values);
	m_entrances.setLastUpdate(time);
  }

  void Building::appendEntrance(INT_32 value, INT_32 time) {
	m_entrances.appendIntValue(value);
	m_entrances.setLastUpdate(time);
  }

  void Building::clearEntrances(INT_32 time) {
	m_entrances.clearIntValues();
	m_entrances.setLastUpdate(time);
  }

  void Building::setApexes(INT_32* values, INT_32 time) {
	//	logDebug("Setting building apexes");
	//	for (int i=0;values[i]!=0;++i) {
	//	  snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Apex %d = %d",i,values[i]);
	//	  logDebug(errorBuffer);
	//	}
	m_apexes.setIntValues(values);
	m_apexes.setLastUpdate(time);
  }

  void Building::appendApex(INT_32 value, INT_32 time) {
	m_apexes.appendIntValue(value);
	m_apexes.setLastUpdate(time);
  }

  void Building::clearApexes(INT_32 time) {
	m_apexes.clearIntValues();
	m_apexes.setLastUpdate(time);
  }

  INT_32 Building::getFloorsUpdate() const {
	return m_floors.lastUpdate();
  }

  INT_32 Building::getAttributesUpdate() const {
	return m_attributes.lastUpdate();
  }

  INT_32 Building::getIgnitionUpdate() const {
	return m_ignition.lastUpdate();
  }

  INT_32 Building::getFierynessUpdate() const {
	return m_fieryness.lastUpdate();
  }

  INT_32 Building::getBrokennessUpdate() const {
	return m_brokenness.lastUpdate();
  }

  INT_32 Building::getBuildingCodeUpdate() const {
	return m_buildingCode.lastUpdate();
  }

  INT_32 Building::getGroundAreaUpdate() const {
	return m_groundArea.lastUpdate();
  }

  INT_32 Building::getTotalAreaUpdate() const {
	return m_totalArea.lastUpdate();
  }

  INT_32 Building::getEntrancesUpdate() const {
	return m_entrances.lastUpdate();
  }

  INT_32 Building::getApexesUpdate() const {
	return m_apexes.lastUpdate();
  }

  Refuge::Refuge() {
  }

  Refuge::~Refuge() {
  }

  TypeId Refuge::type() const {
	return TYPE_REFUGE;
  }

  FireStation::FireStation() {
  }

  FireStation::~FireStation() {
  }

  TypeId FireStation::type() const {
	return TYPE_FIRE_STATION;
  }

  AmbulanceCenter::AmbulanceCenter() {
  }

  AmbulanceCenter::~AmbulanceCenter() {
  }

  TypeId AmbulanceCenter::type() const {
	return TYPE_AMBULANCE_CENTER;
  }

  PoliceOffice::PoliceOffice() {
  }

  PoliceOffice::~PoliceOffice() {
  }

  TypeId PoliceOffice::type() const {
	return TYPE_POLICE_OFFICE;
  }

  Edge::Edge(): m_head(PROPERTY_HEAD), m_tail(PROPERTY_TAIL), m_length(PROPERTY_LENGTH) {
  }

  Edge::~Edge() {
  }

  Property* Edge::getProperty(PropertyId type) {
	switch (type) {
	case PROPERTY_HEAD:
	  return &m_head;
	case PROPERTY_TAIL:
	  return &m_tail;
	case PROPERTY_LENGTH:
	  return &m_length;
	default:
	  return RealObject::getProperty(type);
	}
  }

  INT_32 Edge::getHead() const {
	return m_head.getIntValue();
  }

  INT_32 Edge::getTail() const {
	return m_tail.getIntValue();
  }

  INT_32 Edge::getLength() const {
	return m_length.getIntValue();
  }

  void Edge::setHead(INT_32 value, INT_32 time) {
	m_head.setIntValue(value);
	m_head.setLastUpdate(time);
  }

  void Edge::setTail(INT_32 value, INT_32 time) {
	m_tail.setIntValue(value);
	m_tail.setLastUpdate(time);
  }

  void Edge::setLength(INT_32 value, INT_32 time) {
	m_length.setIntValue(value);
	m_length.setLastUpdate(time);
  }

  INT_32 Edge::getHeadUpdate() const {
	return m_head.lastUpdate();
  }

  INT_32 Edge::getTailUpdate() const {
	return m_tail.lastUpdate();
  }

  INT_32 Edge::getLengthUpdate() const {
	return m_length.lastUpdate();
  }

  Road::Road(): m_roadKind(PROPERTY_ROAD_KIND), m_carsPassToHead(PROPERTY_CARS_PASS_TO_HEAD), m_carsPassToTail(PROPERTY_CARS_PASS_TO_TAIL), m_humansPassToHead(PROPERTY_HUMANS_PASS_TO_HEAD), m_humansPassToTail(PROPERTY_HUMANS_PASS_TO_TAIL), m_width(PROPERTY_WIDTH), m_block(PROPERTY_BLOCK), m_repairCost(PROPERTY_REPAIR_COST), m_medianStrip(PROPERTY_MEDIAN_STRIP), m_linesToHead(PROPERTY_LINES_TO_HEAD), m_linesToTail(PROPERTY_LINES_TO_TAIL), m_widthForWalkers(PROPERTY_WIDTH_FOR_WALKERS) {
  }

  Road::~Road() {
  }

  TypeId Road::type() const {
	return TYPE_ROAD;
  }

  Property* Road::getProperty(PropertyId type) {
	switch (type) {
	case PROPERTY_ROAD_KIND:
	  return &m_roadKind;
	case PROPERTY_CARS_PASS_TO_HEAD:
	  return &m_carsPassToHead;
	case PROPERTY_CARS_PASS_TO_TAIL:
	  return &m_carsPassToTail;
	case PROPERTY_HUMANS_PASS_TO_HEAD:
	  return &m_humansPassToHead;
	case PROPERTY_HUMANS_PASS_TO_TAIL:
	  return &m_humansPassToTail;
	case PROPERTY_WIDTH:
	  return &m_width;
	case PROPERTY_BLOCK:
	  return &m_block;
	case PROPERTY_REPAIR_COST:
	  return &m_repairCost;
	case PROPERTY_MEDIAN_STRIP:
	  return &m_medianStrip;
	case PROPERTY_LINES_TO_HEAD:
	  return &m_linesToHead;
	case PROPERTY_LINES_TO_TAIL:
	  return &m_linesToTail;
	case PROPERTY_WIDTH_FOR_WALKERS:
	  return &m_widthForWalkers;
	default:
	  return Edge::getProperty(type);
	}
  }

  INT_32 Road::getRoadKind() const {
	return m_roadKind.getIntValue();
  }
  INT_32 Road::getCarsPassToHead() const {
	return m_carsPassToHead.getIntValue();
  }
  INT_32 Road::getCarsPassToTail() const {
	return m_carsPassToTail.getIntValue();
  }
  INT_32 Road::getHumansPassToHead() const {
	return m_humansPassToHead.getIntValue();
  }
  INT_32 Road::getHumansPassToTail() const {
	return m_humansPassToTail.getIntValue();
  }
  INT_32 Road::getWidth() const {
	return m_width.getIntValue();
  }
  INT_32 Road::getBlock() const {
	return m_block.getIntValue();
  }
  INT_32 Road::getRepairCost() const {
	return m_repairCost.getIntValue();
  }
  INT_32 Road::getMedianStrip() const {
	return m_medianStrip.getIntValue();
  }
  INT_32 Road::getLinesToHead() const {
	return m_linesToHead.getIntValue();
  }
  INT_32 Road::getLinesToTail() const {
	return m_linesToTail.getIntValue();
  }
  INT_32 Road::getWidthForWalkers() const {
	return m_widthForWalkers.getIntValue();
  }

  void Road::setRoadKind(INT_32 value, INT_32 time) {
	m_roadKind.setIntValue(value);
	m_roadKind.setLastUpdate(time);
  }
  void Road::setCarsPassToHead(INT_32 value, INT_32 time) {
	m_carsPassToHead.setIntValue(value);
	m_carsPassToHead.setLastUpdate(time);
  }
  void Road::setCarsPassToTail(INT_32 value, INT_32 time) {
	m_carsPassToTail.setIntValue(value);
	m_carsPassToTail.setLastUpdate(time);
  }
  void Road::setHumansPassToHead(INT_32 value, INT_32 time) {
	m_humansPassToHead.setIntValue(value);
	m_humansPassToHead.setLastUpdate(time);
  }
  void Road::setHumansPassToTail(INT_32 value, INT_32 time) {
	m_humansPassToTail.setIntValue(value);
	m_humansPassToTail.setLastUpdate(time);
  }
  void Road::setWidth(INT_32 value, INT_32 time) {
	m_width.setIntValue(value);
	m_width.setLastUpdate(time);
  }
  void Road::setBlock(INT_32 value, INT_32 time) {
	m_block.setIntValue(value);
	m_block.setLastUpdate(time);
  }
  void Road::setRepairCost(INT_32 value, INT_32 time) {
	m_repairCost.setIntValue(value);
	m_repairCost.setLastUpdate(time);
  }
  void Road::setMedianStrip(INT_32 value, INT_32 time) {
	m_medianStrip.setIntValue(value);
	m_medianStrip.setLastUpdate(time);
  }
  void Road::setLinesToHead(INT_32 value, INT_32 time) {
	m_linesToHead.setIntValue(value);
	m_linesToHead.setLastUpdate(time);
  }
  void Road::setLinesToTail(INT_32 value, INT_32 time) {
	m_linesToTail.setIntValue(value);
	m_linesToTail.setLastUpdate(time);
  }
  void Road::setWidthForWalkers(INT_32 value, INT_32 time) {
	m_widthForWalkers.setIntValue(value);
	m_widthForWalkers.setLastUpdate(time);
  }
	
  INT_32 Road::getRoadKindUpdate() const {
	return m_roadKind.lastUpdate();
  }

  INT_32 Road::getCarsPassToHeadUpdate() const {
	return m_carsPassToHead.lastUpdate();
  }
  INT_32 Road::getCarsPassToTailUpdate() const {
	return m_carsPassToTail.lastUpdate();
  }
  INT_32 Road::getHumansPassToHeadUpdate() const {
	return m_humansPassToHead.lastUpdate();
  }
  INT_32 Road::getHumansPassToTailUpdate() const {
	return m_humansPassToTail.lastUpdate();
  }
  INT_32 Road::getWidthUpdate() const {
	return m_width.lastUpdate();
  }
  INT_32 Road::getBlockUpdate() const {
	return m_block.lastUpdate();
  }
  INT_32 Road::getRepairCostUpdate() const {
	return m_repairCost.lastUpdate();
  }
  INT_32 Road::getMedianStripUpdate() const {
	return m_medianStrip.lastUpdate();
  }
  INT_32 Road::getLinesToHeadUpdate() const {
	return m_linesToHead.lastUpdate();
  }
  INT_32 Road::getLinesToTailUpdate() const {
	return m_linesToTail.lastUpdate();
  }
  INT_32 Road::getWidthForWalkersUpdate() const {
	return m_widthForWalkers.lastUpdate();
  }

  River::River() {
  }

  River::~River() {
  }

  TypeId River::type() const {
	return TYPE_RIVER;
  }


  Vertex::Vertex(): m_edges(PROPERTY_EDGES) {
  }

  Vertex::~Vertex() {
  }

  Property* Vertex::getProperty(PropertyId type) {
	switch (type) {
	case PROPERTY_EDGES:
	  return &m_edges;
	default:
	  return MotionlessObject::getProperty(type);
	}
  }

  INT_32* Vertex::getEdges() const {
	return m_edges.getIntValues();
  }

  void Vertex::setEdges(INT_32* values, INT_32 time) {
	m_edges.setIntValues(values);
	m_edges.setLastUpdate(time);
  }

  void Vertex::appendEdge(INT_32 value, INT_32 time) {
	m_edges.appendIntValue(value);
	m_edges.setLastUpdate(time);
  }

  void Vertex::clearEdges(INT_32 time) {
	m_edges.clearIntValues();
	m_edges.setLastUpdate(time);
  }

  INT_32 Vertex::getEdgesUpdate() const {
	return m_edges.lastUpdate();
  }

  Node::Node(): m_signals(PROPERTY_SIGNAL), m_shortcutToTurn(PROPERTY_SHORTCUT_TO_TURN), m_pocketToTurnAcross(PROPERTY_POCKET_TO_TURN_ACROSS), m_signalTiming(PROPERTY_SIGNAL_TIMING) {
  }

  Node::~Node() {
  }

  TypeId Node::type() const {
	return TYPE_NODE;
  }

  Property* Node::getProperty(PropertyId type) {
	switch (type) {
	case PROPERTY_SIGNAL:
	  return &m_signals;
	case PROPERTY_SHORTCUT_TO_TURN:
	  return &m_shortcutToTurn;
	case PROPERTY_POCKET_TO_TURN_ACROSS:
	  return &m_pocketToTurnAcross;
	case PROPERTY_SIGNAL_TIMING:
	  return &m_signalTiming;
	default:
	  return Vertex::getProperty(type);
	}
  }

  INT_32 Node::getSignals() const {
	return m_signals.getIntValue();
  }
  INT_32* Node::getShortcutToTurn() const {
	return m_shortcutToTurn.getIntValues();
  }
  INT_32* Node::getPocketToTurnAcross() const {
	return m_pocketToTurnAcross.getIntValues();
  }
  INT_32* Node::getSignalTiming() const {
	return m_signalTiming.getIntValues();
  }

  void Node::setSignals(INT_32 value, INT_32 time) {
	m_signals.setIntValue(value);
	m_signals.setLastUpdate(time);
  }

  void Node::setShortcutToTurn(INT_32* values, INT_32 time) {
	m_shortcutToTurn.setIntValues(values);
	m_shortcutToTurn.setLastUpdate(time);
  }

  void Node::appendShortcutToTurn(INT_32 value, INT_32 time) {
	m_shortcutToTurn.appendIntValue(value);
	m_shortcutToTurn.setLastUpdate(time);
  }

  void Node::clearShortcutToTurn(INT_32 time) {
	m_shortcutToTurn.clearIntValues();
	m_shortcutToTurn.setLastUpdate(time);
  }

  void Node::setPocketToTurnAcross(INT_32* values, INT_32 time) {
	m_pocketToTurnAcross.setIntValues(values);
	m_pocketToTurnAcross.setLastUpdate(time);
  }

  void Node::appendPocketToTurnAcross(INT_32 value, INT_32 time) {
	m_pocketToTurnAcross.appendIntValue(value);
	m_pocketToTurnAcross.setLastUpdate(time);
  }

  void Node::clearPocketToTurnAcross(INT_32 time) {
	m_pocketToTurnAcross.clearIntValues();
	m_pocketToTurnAcross.setLastUpdate(time);
  }

  void Node::setSignalTiming(INT_32* values, INT_32 time) {
	m_signalTiming.setIntValues(values);
	m_signalTiming.setLastUpdate(time);
  }

  void Node::appendSignalTiming(INT_32 value, INT_32 time) {
	m_signalTiming.appendIntValue(value);
	m_signalTiming.setLastUpdate(time);
  }

  void Node::clearSignalTiming(INT_32 time) {
	m_signalTiming.clearIntValues();
	m_signalTiming.setLastUpdate(time);
  }

  INT_32 Node::getSignalsUpdate() const {
	return m_signals.lastUpdate();
  }
  INT_32 Node::getShortcutToTurnUpdate() const {
	return m_shortcutToTurn.lastUpdate();
  }
  INT_32 Node::getPocketToTurnAcrossUpdate() const {
	return m_pocketToTurnAcross.lastUpdate();
  }
  INT_32 Node::getSignalTimingUpdate() const {
	return m_signalTiming.lastUpdate();
  }

  RiverNode::RiverNode() {
  }

  RiverNode::~RiverNode() {
  }

  TypeId RiverNode::type() const {
	return TYPE_RIVER_NODE;
  }
}
