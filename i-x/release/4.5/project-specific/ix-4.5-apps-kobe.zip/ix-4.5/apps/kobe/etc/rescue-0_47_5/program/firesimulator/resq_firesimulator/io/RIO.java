package io;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.util.Collection;
import java.util.Iterator;

import world.RescueObject;
import world.World;

/**
 * @author tn
 *
 */
public class RIO implements IOConstans{

	
	//	LIO lio;
	TCPIO lio;
	

	public RIO(InetAddress kernelIP, int kernelPort){
		//		lio=new LIO(kernelIP,kernelPort);
		lio=new TCPIO(kernelIP,kernelPort);
	}
	

	
	public int[] connect(World world){
		System.out.print("sending SK_CONNECT..");
		sendConnect();
		System.out.print("ok\nwaiting for KS_CONNECT_OK..");
		int[] data=receiveConnectOK(world);
		System.out.println("ok");
		return data;
	}
	
	public void receiveUpdate(World world){
		int[]data;
		data=receive();   
		if(data[0]!=KS_UPDATE){
			System.out.println("warning: received not an KS_UPDATE");
		}
		world.processUpdate(data,3,data[2]);
	}
	
	public void sendReadyness(){
		System.out.print("sending SK_ACKNOWLEDGE..");
		sendAcknowledge();
		System.out.println("ok");
	}
	
	public void sendConnect(){
		send(SK_CONNECT,new byte[]{0,0,0,0});
	}
	
	public void sendAcknowledge(){
		send(SK_ACKNOWLEDGE,new byte[0]);
	}
	
	public void receiveCommands(World world){
		int[] data=receive();
		if(data[0]!=KS_COMMAND){
			System.out.println("warning: received not an KS_COMMAND");
		}
		world.processCommands(data);
	}
	
	
	public int[] receiveConnectOK(World world){
		int[]data;
		data=receive();
		if(data[0]!=KS_CONNECT_OK){
			System.out.println("warning: received not an KS_CONNECT_OK");
		}
		world.processUpdate(data,2,INIT_TIME);
		lio.resetSocket();
		return data;
	}
	
	private int[] receive(){
		return lio.receive();
	}
	
	public void sendUpdate(Collection objects){
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);
		for(Iterator i=objects.iterator();i.hasNext();){
			RescueObject o=(RescueObject)i.next();
			o.encode(dos);		
		}
		try {
			dos.writeInt(TYPE_NULL);
		  	dos.close();
		  	send(SK_UPDATE, baos.toByteArray());
		  	baos.close();
		} catch (Exception e) {
			e.printStackTrace();  
			System.exit(1); 
		}
	}
	
	private void send (int header, byte[] body) {
		try{
			ByteArrayOutputStream baos=new ByteArrayOutputStream();
			DataOutputStream dos=new DataOutputStream(baos);
			dos.writeInt(header);
			dos.writeInt(body.length);
			dos.write(body);
			dos.writeInt(HEADER_NULL);
			dos.close();
			byte[] ludpBody=baos.toByteArray();
			baos.close();
			lio.send(ludpBody);
		}catch(Exception e){
			e.printStackTrace();
			System.exit(1);
		}
	}

}
