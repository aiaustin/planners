/*
 * Header    :
 * File      : CivilianController.hxx
 * Auther    : Kosuke Shinoda
 * Since     : 2001/11/16
 * LastUpdate: 2001/11/16
 * Comment   :
 * End       :
 */
/*
 * Copyright (C) 2001 SHINODA, Kosuke. Jaist,Japan & CARC, AIST, JAPAN
 * Copyright (C) 2001 NODA, Itsuki, CARC, AIST, JAPAN
 */

/*
 Modified by Cameron Skinner
 May 2005: Converted to librescue
*/

#ifndef __CivilianController_hxx__
#define __CivilianController_hxx__

#include <map>
#include <list>
#include "../itk/itk.h"
#include "../rescuelang/EvalEngine.h"
#include "Environment.hxx"
#include "Controller.hxx"

namespace RescueCivilian {
  using namespace Librescue;
  using namespace Itk;

  typedef std::map<RescueObject*, S32> CounterTable;

  class CivilianController : public Controller {
    //--------------------------------------------------
    // CivilianController environemtal information
  public:  
    Environment m_env;
    ITK_DEF_ACCESS(Environment& env(), { return m_env; });

    //--------------------------------------------------
    //
  public:
    Bool needto_cyclep;
    Bool needToCycle(){ return needto_cyclep; };
    void needToCycle2(Sexp* result);
    void nextstep();

    //--------------------------------------------------
    // inter Knowledge Base
  public:
    CounterTable m_NumOfVisited;
    
    //--------------------------------------------------
    // CivilianController :: Constractor
  public:
    virtual ~CivilianController(){};
    CivilianController(Id selfId, const Address& to, const char* filename,
                       Connection& socket, Input& input, Output& output) 
      : Controller(selfId, to, socket, input, output){
      env().scanRuleText(filename);
      env().setEnvironmentalInformation(0,input,this);
      init();
    };
    
  protected:
    void init(){
      needto_cyclep = False;
    }
    
  public:
    virtual Sexp* cycle();

    //--------------------------------------------------
    // CivilianController::sensed and heard
  public:
    virtual void sensed(INT_32 time, 
                        Connection& connection,
                        Input& input, Output& output);
    virtual void heard(Connection& connection, Id speaker, const char* message,
                       Input& input, Output& output);
  
  private:
    CivilianController(const CivilianController& source);
    CivilianController& operator= (const CivilianController& rhs);
    bool operator= (const CivilianController& rhs) const;

    //--------------------------------------------------
    // saerch road-path
    RescueObject* selectNode(RescueObject* current);
    Path setRoadPath(RescueObject* start, RescueObject* goal);
    Path circuitWalk();
    //--------------------------------------------------
    // utility
    S32 distance(RescueObject* from, RescueObject* to);
    S32 getAliveLinesToHead(Road* road);
    S32 getAliveLinesToTail(Road* road);
    void sortByHeuristicValue(Path open, CounterTable heuristic); 

    //--------------------------------------------------
    // action
  public:
    void move_to_refuge();
    void move_to_refuge(Id refuge_id);
    void move_to(Id target_id);
    void say_message(Sexp* message);
  };

};
#endif
