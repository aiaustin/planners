package kernel.viewer;

import world.RescueObject;

/**
 * @author tn
 *
 */
public interface SelectorListener {

	public void select(RescueObject o, int modifier);

}
