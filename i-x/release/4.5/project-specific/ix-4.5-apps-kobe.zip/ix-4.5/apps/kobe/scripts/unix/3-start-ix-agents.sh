#!/bin/bash

# Start the IX police office
echo "Starting the Police Office...."
./PoliceOffice.sh &
sleep 10

# Start the 10 IX police forces

# TO apps/kobe/java
cd ../../java

clpath="../../../ix.jar:../../../imports/jdom.jar:../../../imports/jena2/xercesImpl.jar:../imports/yab.jar:."

apparam="-ipc=xml -rcr-hostname=soay.inf.ed.ac.uk -rcr-port=8000 -action-message-time=10" 

echo "Starting the IX Police Force 1"
xterm -T PoliceForce1 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce1 -superiors=PoliceOffice -peers=PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &
sleep 4

echo "Starting the IX police force 2"
xterm -T PoliceForce2 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce2 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &
sleep 4

echo "Starting the IX police force 3"
xterm -T PoliceForce3 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce3 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &
sleep 4

echo "Starting the IX police force 4"
xterm -T PoliceForce4 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce4 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &
sleep 4
echo "Starting the IX police force 5"
xterm -T PoliceForce5 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce5 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 6"
xterm -T PoliceForce6 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce6 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce7,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 7"
xterm -T PoliceForce7 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce7 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce8,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 8"
xterm -T PoliceForce8 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce8 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce9,PoliceForce10 &

sleep 4
echo "Starting the IX police force 9"
xterm -T PoliceForce9 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce9 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce10 &

sleep 4
echo "Starting the IX police force 10"
xterm -T PoliceForce10 -e java -classpath ${clpath} ix/rcragents/PoliceForce ${apparam} -ipc-name=PoliceForce10 -superiors=PoliceOffice -peers=PoliceForce1,PoliceForce2,PoliceForce3,PoliceForce4,PoliceForce5,PoliceForce6,PoliceForce7,PoliceForce8,PoliceForce9 &