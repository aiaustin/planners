package kernel.viewer;

import java.awt.Color;

import world.Building;

/**
 * @author tn
 *
 */
public interface BuildingColorizer {

	public Color getColor(Building b);
	
}
