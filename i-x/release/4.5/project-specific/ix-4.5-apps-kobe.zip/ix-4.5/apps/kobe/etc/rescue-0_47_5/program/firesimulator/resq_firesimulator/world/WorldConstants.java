package world;

/**
 * @author tn
 *
 */
public interface WorldConstants {
	
	static final int TYPE_NULL             				= 0;
	static final int TYPE_ROAD             				= 168;
	static final int TYPE_RIVER            				= 169;
	static final int TYPE_BUILDING         			= 176;
	static final int TYPE_REFUGE           			= 184;
	static final int TYPE_FIRE_STATION     			= 185;
	static final int TYPE_AMBULANCE_CENTER 	= 186;
	static final int TYPE_POLICE_OFFICE    		= 187;
	static final int TYPE_RIVER_NODE       			= 201;
	static final int TYPE_NODE             				= 200;
	static final int TYPE_WORLD           				= 208;
	static final int TYPE_CIVILIAN         				= 232;
	static final int TYPE_FIRE_BRIGADE     		= 233;
	static final int TYPE_FIRE_COMPANY     		= TYPE_FIRE_BRIGADE;
	static final int TYPE_AMBULANCE_TEAM   	= 234;
	static final int TYPE_POLICE_FORCE     		= 235;
	static final int TYPE_CAR              				= 236;
	
	static final int PROPERTY_NULL                  						=   0;
	static final int PROPERTY_WIDTH                 					=  38;
	static final int PROPERTY_BUILDING_AREA_TOTAL	  	 	=  52;
	static final int PROPERTY_START_TIME            				=  29;
	static final int PROPERTY_SIGNAL_TIMING         				= 130;
	static final int PROPERTY_LINES_TO_HEAD         				=  41;
	static final int PROPERTY_POSITION_HISTORY      			= 207;
	static final int PROPERTY_CARS_PASS_TO_HEAD     		=  34;
	static final int PROPERTY_LATITUDE              					=  31;
	static final int PROPERTY_DIRECTION             					=  27;
	static final int PROPERTY_BLOCK                 					=  22;
	static final int PROPERTY_STAMINA               					=   9;
	static final int PROPERTY_HEAD                  						=  12;
	static final int PROPERTY_EDGES                 					= 242;
	static final int PROPERTY_BUILDING_CODE         				=  50;
	static final int PROPERTY_SIGNAL                					=  44;
	static final int PROPERTY_FIERYNESS             					=  16;
	static final int PROPERTY_WIND_DIRECTION        			=  33;
	static final int PROPERTY_LENGTH                					=  24;
	static final int PROPERTY_FLOORS                					=  14;
	static final int PROPERTY_HUMANS_PASS_TO_TAIL  	 	=  37;
	static final int PROPERTY_ROAD_KIND             				=  19;
	static final int PROPERTY_REPAIR_COST           				=  39;
	static final int PROPERTY_IGNITION              					=  48;
	static final int PROPERTY_BUILDING_AREA_GROUND  		=  51;
	static final int PROPERTY_BROKENNESS            				=  17;
	static final int PROPERTY_WIND_FORCE            				=  32;
	static final int PROPERTY_SHORTCUT_TO_TURN      		= 128;
	static final int PROPERTY_WIDTH_FOR_WALKERS     		=  43;
	static final int PROPERTY_MEDIAN_STRIP          				=  40;
	static final int PROPERTY_Y                   							=   4;
	static final int PROPERTY_ENTRANCES             				= 235;
	static final int PROPERTY_X                     						=   3;
	static final int PROPERTY_POSITION              					=   6;
	static final int PROPERTY_POSITION_EXTRA        				=   7;
	static final int PROPERTY_WATER_QUANTITY        			=  25;
	static final int PROPERTY_LONGITUDE             					=  30;
	static final int PROPERTY_STRETCHED_LENGTH      			=  26;
	static final int PROPERTY_HUMANS_PASS_TO_HEAD  	 	=  36;
	static final int PROPERTY_BURIEDNESS            				=  23;
	static final int PROPERTY_LINES_TO_TAIL         				=  42;
	static final int PROPERTY_HP                    						=  10;
	static final int PROPERTY_BUILDING_APEXES       			= 131;
	static final int PROPERTY_DAMAGE                					=  11;
	static final int PROPERTY_CARS_PASS_TO_TAIL     			=  35;
	static final int PROPERTY_BUILDING_ATTRIBUTES   			=  15;
	static final int PROPERTY_POCKET_TO_TURN_ACROSS 	= 129;
	static final int PROPERTY_TAIL                  						=  13;
	
	static final int AK_EXTINGUISH 										= 0x86;
	static final int AK_REST       											= 0x80;
	static final int AK_MOVE       											= 0x81;
	static final int AK_LOAD       											= 0x82;
	static final int AK_UNLOAD     											= 0x83;
	static final int AK_SAY        												= 0x84;
	static final int AK_TELL       												= 0x85;	
	static final int AK_STRETCH    											= 0x87;
	static final int AK_RESCUE     											= 0x88;
	static final int AK_CLEAR      											= 0x89;
}
