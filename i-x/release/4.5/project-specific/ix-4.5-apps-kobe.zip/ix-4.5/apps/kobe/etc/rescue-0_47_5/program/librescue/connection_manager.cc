/*
 * Copyright (c) 2005, The Black Sheep, Department of Computer Science, The University of Auckland
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of The Black Sheep, The Department of Computer Science or The University of Auckland nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 Contributors and list of changes:

 Cameron Skinner
*/

#include "connection_manager.h"
#include "error.h"
#include <pthread.h>
#include <sys/time.h>
#include <exception>

namespace Librescue {
  ConnectionManager::ConnectionManager() {
	m_udp = 0;
	m_udpWait = 30;
	m_udpSize = 1024;
	//	m_listenOnUDPSendPort = true;
	// Set up the data mutex
	pthread_mutexattr_t lockAttr;
	pthread_mutexattr_init(&lockAttr);
	pthread_mutexattr_settype(&lockAttr,PTHREAD_MUTEX_FAST_NP);
	pthread_mutex_init(&m_dataLock,&lockAttr);
	pthread_mutexattr_destroy(&lockAttr);
	// Set up the data condition
	pthread_cond_init(&m_dataCondition,NULL); // LinuxThreads has no attributes for pthread_cond_init
	started = false;
  }

  ConnectionManager::~ConnectionManager() {
	stop();
	// Destroy the data mutex
	pthread_mutex_destroy(&m_dataLock);
	// Destroy the data condition
	pthread_cond_destroy(&m_dataCondition);
  }

  void ConnectionManager::start() {
	if (started) return;
	//logDebug("Starting connection manager");
	// Open a LongUDPConnection for sending and receiving responses
	Address a((int)INADDR_ANY,0);
	m_udp = openLongUDPConnection(a);
	/*
	  if (m_udp) {
	  Listener* listener = createListener(m_udp);
	  if (listener) m_listeners.push_back(listener);
	  else {
	  closeLongUDPConnection(m_udp);
	  delete m_udp;
	  }
	  }
	*/
	started = true;
	//	logDebug("Connection manager started");
  }

  void ConnectionManager::stop() {
	if (!started) return;
	started = false;
	LOG_DEBUG("Stopping connection manager");
	// Close all listeners
	for (ListenerList::iterator it = m_listeners.begin();it!=m_listeners.end();) {
	  //	  LOG_DEBUG("Destroying listener");
	  Listener* next = *it;
	  destroyListener(next);
	  //	  LOG_DEBUG("Done");
	}
	m_listeners.clear();
	m_connectionToListener.clear();
	m_udp = 0;
	// Close any TCP servers
	for (TCPServerList::iterator it = m_tcpServers.begin();it!=m_tcpServers.end();) {
	  //	  LOG_DEBUG("Closing TCP server");
	  TcpServer* next = *it;
	  next->stop();
	  delete next;
	  //	  LOG_DEBUG("Done");
	}
	m_tcpServers.clear();
	LOG_DEBUG("Connection manager stopped");
  }

  bool ConnectionManager::send(const Output& buffer, const Address& address) {
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Sending %d bytes to %s",buffer.size(),address.toString());
	//	logDebug(errorBuffer);
	// What method do we use to send this?
	if (m_udpTargets.find(address)!=m_udpTargets.end()) return sendUDP(buffer,address);
	else if (m_tcpTargets.find(address)!=m_tcpTargets.end()) return sendTCP(buffer,address);
	else {
	  LOG_WARNING("WARNING: Could not find method for sending to %s",address.toString());
	  return false;
	}
  }

  Connection* ConnectionManager::getConnection(const Address& address) {
	//	LOG_DEBUG("Finding connection for %s",address.toString());
	if (m_udpTargets.find(address)!=m_udpTargets.end()) return m_udp;
	if (m_tcpTargets.find(address)!=m_tcpTargets.end()) {
	  TcpConnection* connection = m_tcpOpen[address];
	  if (!connection) {
		//		LOG_DEBUG("No open TCP connection. Creating new one");
		connection = openTCPConnection(address);
		if (!connection) {
		  // Still no connection
		  LOG_ERROR("Couldn't open TCP connection to %s",address.toString());
		  m_tcpOpen[address] = NULL;
		  return NULL;
		}
		m_tcpOpen[address] = connection;
	  }
	  if (!connection->isOpen()) {
		//		LOG_DEBUG("TCP connection is closed. Creating new one");
		closeTCPConnection(connection);
		connection = openTCPConnection(address);
		if (!connection) {
		  // Still no connection
		  LOG_ERROR("Couldn't open TCP connection to %s",address.toString());
		  m_tcpOpen[address] = NULL;
		  return NULL;
		}
		m_tcpOpen[address] = connection;
	  }
	  return connection;
	}
	return NULL;
  }

  // Receive data and store in a buffer. If "from" is not null then the address the data came from will be stored in "from". This function will block until data is available, or until "timeout" milliseconds have elapsed. If timeout is zero then this function will not block, if timeout is less than zero then it will not timeout (this is the default). Returns true iff data has been received.
  bool ConnectionManager::receive(Input& buffer, Address* from, int timeout) {
	if (!started) {
	  //	  logWarning("WARNING: receive called before connection manager was started!");
	  return false;
	}
	if (!isDataAvailable(timeout)) return false;
	//	LOG_DEBUG("%s: Locking input queue",__func__);
	pthread_mutex_lock(&m_dataLock);
	//	LOG_DEBUG("%d messages waiting",m_data.size());
	InputInfo next = m_data.front();
	m_data.pop();
	pthread_mutex_unlock(&m_dataLock);
	//	LOG_DEBUG("%s: Input queue unlocked",__func__);
	buffer = next.input;
	if (from) {
	  *from = next.from; // Will this work? Who knows. It seems to.
	}
	return true;
  }

  // Find out if any data is available for reading. If timeout is zero then this function will not block, if timeout is less than zero then it will not timeout (this is the default). Returns true iff data has been received.
  bool ConnectionManager::isDataAvailable(int timeout) {
	if (!started) return false;
	// Check whether anything we are listening to has data available
	pthread_mutex_lock(&m_dataLock);
	bool empty = m_data.empty();
	//	snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Checking for available data (timeout %dms)",timeout);
	//	logDebug(errorBuffer);
	if (empty) {
	  if (timeout < 0) {
		// Wait for data without timing out
		//		logDebug("Waiting for data with no timeout");
		while (empty) {
		  pthread_cond_wait(&m_dataCondition,&m_dataLock);
		  empty = m_data.empty();
		}
	  }
	  else if (timeout>0) {
		// Wait for data with the given timeout
		struct timeval now;
		gettimeofday(&now,NULL);
		struct timespec wait;
		wait.tv_sec = now.tv_sec + timeout/1000;
		wait.tv_nsec = now.tv_usec*1000 + ((timeout%1000)*1000000);
		while (wait.tv_nsec >= 1000000000) {
		  ++wait.tv_sec;
		  wait.tv_nsec -= 1000000000;
		}
		while (empty && before(&now,&wait)) {
		  //		  snprintf(errorBuffer,ERROR_BUFFER_LENGTH,"Waiting for data. Now: %d:%d, timeout: %d:%d",now.tv_sec,now.tv_usec*1000,wait.tv_sec,wait.tv_nsec);
		  //		  logDebug(errorBuffer);
		  pthread_cond_timedwait(&m_dataCondition,&m_dataLock,&wait);
		  empty = m_data.empty();
		  if (empty) gettimeofday(&now,NULL);
		}
	  }
	}
	pthread_mutex_unlock(&m_dataLock);
	return !empty;
  }

  // TCP
  // Instruct the connection manager to listen for TCP connections on a particular port
  void ConnectionManager::listenTCP(int port) {
	try {
	  //	  LOG_DEBUG("Attemping to listen on TCP port %d",port);
	  TcpServer* server = new TcpServer(port,*this);
	  m_tcpServers.push_back(server);
	  server->start();
	}
	catch (std::string& ex) {
	  LOG_WARNING("WARNING: Error creating TcpServer: %s",ex.c_str());
	}
	catch (std::bad_alloc& ex) {
	  LOG_ERROR("std::bad_alloc when constructing TcpServer");
	}
  }

  void ConnectionManager::sendViaTCP(const Address& target) {
	m_tcpTargets.insert(target);
  }

  void ConnectionManager::setUDPSize(int size) {
	if (m_udp) logWarning("WARNING: Setting UDP size when connection manager has already started!");
	m_udpSize = size;
  }

  void ConnectionManager::setUDPWait(int wait) {
	if (m_udp) logWarning("WARNING: Setting UDP wait when connection manager has already started!");
	m_udpWait = wait;
  }

  // Instruct the connection manager to listen for UDP connections on a particular address and port
  void ConnectionManager::listenUDP(int port, const char* address, int timeout) {
	Address a(address,port);
	//	LongUDPConnection* connection = openLongUDPConnection(a,timeout);
	openLongUDPConnection(a,timeout);
	LOG_INFO("Listening for UDP connections on %s",a.toString());
  }

  void ConnectionManager::sendViaUDP(const Address& target) {
	m_udpTargets.insert(target);
  }

  bool ConnectionManager::sendUDP(const Output& buffer, const Address& target) {
	if (m_udp) {
	  return m_udp->send(buffer,target);
	}
	logWarning("WARNING: Attempted to send UDP without starting connection manager!");
	return false;
  }

  bool ConnectionManager::sendTCP(const Output& buffer, const Address& target) {
	//	logDebug("Sending TCP data");
	// Find the connection
	TcpConnection* connection = dynamic_cast<TcpConnection*>(getConnection(target));
	// Now send the data
	//	logDebug("Sending data via open TCP connection");
	if (!connection) {
	  LOG_WARNING("WARNING: Could not find TCP connection to %s",target.toString());
	  return false;
	}
	if (!connection->send(buffer)) {
	  // Connection failed. Close it.
	  LOG_WARNING("WARNING: Send via TCP to %s failed",target.toString());
	  closeTCPConnection(connection);
	  m_tcpOpen[target] = NULL;
	  return false;
	}
	return true;
  }

  LongUDPConnection* ConnectionManager::openLongUDPConnection(const Address& address, int timeout) {
	//	logDebug("Opening LongUDPConnection");
	LongUDPConnection* result;
	try {
	  result = new LongUDPConnection(address,m_udpSize,m_udpWait,(time_t)timeout);
	}
	catch (std::bad_alloc& ex) {
	  logError("std::bad_alloc when constructing LongUDPConnection");
	  return NULL;
	}
	Listener* listener = createListener(result);
	if (listener) {
	  m_listeners.push_back(listener);
	  m_connectionToListener[result] = listener;
	  listener->start();
	  return result;
	}
	else {
	  result->close();
	  delete result;
	  return NULL;
	}
  }

  void ConnectionManager::closeLongUDPConnection(LongUDPConnection* c) {
	//	logDebug("Closing LongUDPConnection");
	Listener* l = m_connectionToListener[c];
	l->stop();
	// The listener will delete c later on
  }

  TcpConnection* ConnectionManager::openTCPConnection(const Address& target) {
	//	logDebug("Opening TcpConnection");
	TcpConnection* result;
	try {
	  result = new TcpConnection(target);
	}
	catch (std::string& ex) {
	  return NULL;
	}
	catch (std::bad_alloc& ex) {
	  logError("std::bad_alloc when constructing TcpConnection");
	  return NULL;
	}
	Listener* listener = createListener(result);
	if (listener) {
	  m_listeners.push_back(listener);
	  m_connectionToListener[result] = listener;
	  listener->start();
	  return result;
	}
	else {
	  result->close();
	  delete result;
	  return NULL;
	}
  }

  void ConnectionManager::closeTCPConnection(TcpConnection* c) {
	//	logDebug("Closing TcpConnection");
	Listener* l = m_connectionToListener[c];
	l->stop();
	// The listener will delete c later on
  }

  void ConnectionManager::incomingTCPConnection(TcpConnection* c, const Address& from) {
	Listener* l = createListener(c);
	if (l) {
	  m_listeners.push_back(l);
	  m_connectionToListener[c] = l;
	  sendViaTCP(from);
	  m_tcpOpen[from] = c;
	  //	  logDebug("Incoming TCP listener created");
	  l->start();
	}
	else {
	  logWarning("Couldn't create listener for incoming TCP connection");
	  c->close();
	  delete c;
	}
  }

  void ConnectionManager::addData(InputInfo info) {
	//	LOG_DEBUG("%s: Locking input queue",__func__);
	pthread_mutex_lock(&m_dataLock);
	m_data.push(info);
	//	LOG_DEBUG("Now have %d messages waiting",m_data.size());
	// Tell everyone that data is available
	pthread_cond_broadcast(&m_dataCondition);
	pthread_mutex_unlock(&m_dataLock);
	//	LOG_DEBUG("%s: Input queue unlocked",__func__);
  }

  Listener* ConnectionManager::createListener(LongUDPConnection* connection) {
	//	logDebug("Creating LongUDPListener");
	UDPListener* listener;
	try {
	  listener = new UDPListener(connection,this);
	}
	catch (std::bad_alloc& ex) {
	  logError("std::bad_alloc when constructing UDPListener");
	  return NULL;
	}
	return listener;
  }

  Listener* ConnectionManager::createListener(TcpConnection* connection) {
	//	logDebug("Creating TCPListener");
	TCPListener* listener;
	try {
	  listener = new TCPListener(connection,this);
	}
	catch (std::bad_alloc& ex) {
	  logError("std::bad_alloc when constructing TCPListener");
	  return NULL;
	}
	return listener;
  }

  void ConnectionManager::destroyListener(Listener* listener) {
	//	logDebug("Destroying Listener");
	listener->stop();
	delete listener;
  }

  inline bool before(struct timeval* first, struct timespec* last) {
	bool b = first->tv_sec < last->tv_sec || (first->tv_sec==last->tv_sec && first->tv_usec*1000 < last->tv_nsec);
	//	LOG_DEBUG("Is %d:%d before %d:%d? %s",first->tv_sec,first->tv_usec*1000,last->tv_sec,last->tv_nsec,b?"Yes":"No");
	return b;
  }

  Listener::Listener(Connection* c, ConnectionManager* m) {
	connection = c;
	manager = m;
	running = false;
	// Initialise the mutex
	pthread_mutex_init(&lock,0);
  }

  Listener::~Listener() {
	stop();
	// Destroy the mutex
	pthread_mutex_destroy(&lock);
  }

  void Listener::start() {
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_JOINABLE);
	pthread_attr_setschedpolicy(&attr,SCHED_OTHER);
	pthread_attr_setinheritsched(&attr,PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setscope(&attr,PTHREAD_SCOPE_SYSTEM);
	// Start the listen thread
	running = true;
	//	logDebug("Starting listen thread");
	if (pthread_create(&thread,&attr,&Librescue::poll,this)) {
	  logWarning("Could not create listen thread");
	  thread = 0;
	  stop();
	}
	pthread_attr_destroy(&attr);
  }

  void Listener::stop() {
	//	LOG_DEBUG("Listener::stop()");
	pthread_mutex_lock(&lock);
	bool temp = running;
	running = false;
	pthread_mutex_unlock(&lock);
	//	LOG_DEBUG("Listener::stop() %s to shut down the listener for thread %d",temp?"needs":"does not need",thread);
	if (temp) {
	  // Close the connection
	  //	  LOG_DEBUG("Listener::stop() closing connection");
	  pthread_mutex_lock(&lock);
	  connection->close();
	  pthread_mutex_unlock(&lock);
	  // Stop the thread
	  //	  LOG_DEBUG("Listener::stop() joining the listener thread %d",thread);
	  if (thread) pthread_join(thread,0);
	  //	  LOG_DEBUG("Listener::stop() listener thread joined");
	  delete connection;
	}
  }

  void Listener::poll() {
	bool finished = false;
	while (!finished) {
	  // See if data is available
	  pthread_mutex_lock(&lock);
	  bool available = connection->isDataAvailable(100);
	  pthread_mutex_unlock(&lock);
	  if (available) {
		Input input;
		InputInfo info;
		pthread_mutex_lock(&lock);
		connection->receive(input);
		info.input = input;
		info.from = connection->addressReceivedFrom();
		pthread_mutex_unlock(&lock);
		// Add the data to the queue
		handleInput(info.from,info.input);
		manager->addData(info);
	  }
	  pthread_mutex_lock(&lock);
	  finished = !running || !connection->isOpen();
	  pthread_mutex_unlock(&lock);
	}
	//	LOG_DEBUG("Listener thread %d finished",thread);
  }

  UDPListener::UDPListener(Connection* c, ConnectionManager* m) : Listener(c,m) {
  }

  UDPListener::~UDPListener() {
  }

  void UDPListener::handleInput(const Address& from, const Input& buffer) {
	manager->sendViaUDP(from);
  }

  TCPListener::TCPListener(Connection* c, ConnectionManager* m) : Listener(c,m) {
  }

  TCPListener::~TCPListener() {
  }

  void TCPListener::handleInput(const Address& from, const Input& buffer) {
	manager->sendViaTCP(from);
	manager->m_tcpOpen[from] = (TcpConnection*)connection;
  }

  void* poll(void* arg) {
	Listener* listener = (Listener*)arg;
	listener->poll();
	pthread_exit(0);
  }
}
