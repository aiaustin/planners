Created by: Stephen Potter (stephenp@inf.ed.ac.uk)
Updated: Wed Aug 31 15:30:39 2005

This apps directory contains a number of items related to the 
e-Response (http://www.e-response.org) project.

There is a demo script in the "scripts/win/eresponse-script.txt" which briefly explains how to run things.

There are basically two panels: the "Incident Commander" (that one is optional) and the "Operations Section Commander" (which is more interesting - the various vehicles are set up to "report" their positions to the latter, though this is configurable).

Helen Wollan's search patterns code (this needed a bit of debugging and recompiling, but now appears to work with the latest version of the map tool). It seems to work okay if you make the "world objects" layer invisible). I.e. either have the world objects layer OR the SAR patterns layer on - but not both. It can be reached through the Operations Section Commander's map tool.

Perl is needed for some facilities. On Windows use ActivePerl, available here:
   http://www.activestate.com/Products/Download/Download.plex?id=ActivePerl
