#/usr/bin/perl
##!c:\Perl\bin\perl.exe -i'C:\Perl\site\lib\SOAP'
use SOAP::Lite;
print 
   "Content-type: text/html\n\n";

print "<html>\n<head><title>soap call</title><head\>\n<body>";

print "Loading SOAP::Lite";
$response=SOAP::Lite
    -> service('http://live.capescience.com/wsdl/GlobalWeather.wsdl')
    #-> getWeatherReport("LHR");
    -> searchByCountry("United Kingdom");
	#-> blastp_BasicRequest("seq","form");

#print $response;

#foreach $item ($response){
#	print "$item\n";
#}

print "\n</body>";


