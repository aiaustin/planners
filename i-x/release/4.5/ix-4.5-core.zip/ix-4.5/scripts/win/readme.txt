I-X
Copyright 2003, AIAI, University of Edinburgh

Scripts in I-X/scripts are used to support the running of I-X
applications, and will not normally be used directlly.  They require
parameters and environment variables to be set when called.

Normally use scripts in I-X/apps/<app-name>/scripts to start I-X
applications.
