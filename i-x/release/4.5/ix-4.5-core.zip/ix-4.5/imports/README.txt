Updated: Tue Feb 19 14:11:51 2008 by Jeff Dalton

This "imports" directory contains jar files for non-I-X software
used by the main I-X classes -- but not jar files needed only by
specific communication strategies or specific applications.

It also contains copies of the relevant licences.

The terms of the open source licences of some of the software
provided as jar files in this directory (or its subdirectories)
require that we provide a way to obtain the source code of that
software.  That can be done by sending e-mail to i-x@aiai.ed.ac.uk.
